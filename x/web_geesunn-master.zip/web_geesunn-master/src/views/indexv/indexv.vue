<template>
  <div>
    <full-screen-banner></full-screen-banner>
    <div class="index-content-wrap">
      <div v-for="data in prductData.value" class="index-content-model">
        <div class="model-small-content">
          <h2><a :href="data.link">{{data.bTit}}</a></h2>
          <span class="blue-line">&nbsp;</span>
          <p>{{data.sTit}}</p>
        </div>
        <div v-if="data.type === 'left'" class="model-img text-left">
          <span>
            <img :src="data.procutImg">
          </span>
        </div>
        <div class="model-large-content">
          <h2><a :href="data.link">{{data.bTit}}</a></h2>
          <span class="blue-line">&nbsp;</span>
          <p>{{data.sTit}}</p>
          <div class="content-tips">
            <div v-for="tip in data.tips" class="tip-wrap">
              <img :src="tip.logo">
              <p>{{tip.name}}</p>
              <span>{{tip.content}}</span>
            </div>
          </div>
        </div>
        <div v-if="data.type === 'right'" class="model-img text-right">
          <span>
            <img :src="data.procutImg">
          </span>
        </div>
        <div class="model-small-content">
          <div class="small-content-scroll-wrap">
            <div class="small-content-scroll-fram">
              <swiper :options="swiperOption" ref="mySwiper">
                <!-- slides -->
                <swiper-slide v-for="tip in data.tips" :key="tip.name">
                  <div class="tip-wrap">
                    <img :src="tip.logo">
                    <p>{{tip.name}}</p>
                    <span>{{tip.content}}</span>
                  </div>
                </swiper-slide>
                <div class="swiper-pagination"  slot="pagination"></div>
              </swiper>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="geesunn-partners">
      <h2>合作伙伴</h2>
      <span class="mline">&nbsp;</span>
      <div class="partners-content">
        <div><img src="../../assets/partners-aly.png"></div>
        <div><img src="../../assets/partners-txy.png"></div>
        <div><img src="../../assets/partners-wywl.png"></div>
        <div><img src="../../assets/partners-szsjgj.png"></div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { swiper, swiperSlide } from 'vue-awesome-swiper'
  export default {
    name: '',
    data () {
      return {
        swiperOption: {  
          //是一个组件自有属性，如果notNextTick设置为true，组件则不会通过NextTick来实例化swiper，也就意味着你可以在第一时间获取到swiper对象，假如你需要刚加载遍使用获取swiper对象来做什么事，那么这个属性一定要是true  
          pagination : '.swiper-pagination',
          // paginationType : 'fraction',
          notNextTick: true,
          spaceBetween: 12,
          slidesPerView: 1,
          freeMode : true
        },

        prductData: {
          value: [
            {
              bTit: '智象综合监控运维平台',
              link: '/product-detail?name=zhjkywpt',
              sTit: '降低运维复杂度、减轻运维人员压力',
              procutImg: require('../../assets/index-content-model-zhjkywpt.png'),
              type: 'right',
              tips: [
                {
                  name: '软硬一体化',
                  logo: require('../../assets/index-content-tips-ryyt.png'),
                  content: '安装部署更简单，维护成本更低，即插即用，适用多种类型和规模的网络架构。'
                },
                {
                  name: '自动化、智能化',
                  logo: require('../../assets/index-content-tips-zdhznh.png'),
                  content: '任务自动化，异常只能识别和处理，多种告警方式。'
                },
                {
                  name: '全流程',
                  logo: require('../../assets/index-content-tips-qlc.png'),
                  content: '网络、系统及应用全方位监控和ITIL流程和模块全面整合。'
                },
                {
                  name: '云运维',
                  logo: require('../../assets/index-content-tips-yyw.png'),
                  content: '通过云平台，为用户提供云运维解决方案。'
                },
                {
                  name: '便利性',
                  logo: require('../../assets/index-content-tips-blx.png'),
                  content: '版本在线升级，随时随地任务处理。'
                },
                {
                  name: '安全性',
                  logo: require('../../assets/index-content-tips-aqx.png'),
                  content: '系统数据支持加密，本地和云端备份，故障机器快速迁移。'
                }
              ]
            },
            {
              bTit: '智象数据平台',
              link: '/product-detail?name=zxsjpt',
              sTit: '帮用户进行高效率、安全、灵活的数据备份及管理',
              procutImg: require('../../assets/index-content-model-zxsjpt.png'),
              type: 'left',
              tips: [
                {
                  name: '软硬一体化',
                  logo: require('../../assets/index-content-tips-ryyt.png'),
                  content: '安装部署更简单，购买、维护成本更低。'
                },
                {
                  name: '灵活',
                  logo: require('../../assets/index-content-tips-lh.png'),
                  content: '支持备份到本地服务器、远程服务器、各种云存储平台，同时支持数据按照日期和版本回滚。'
                },
                {
                  name: '安全',
                  logo: require('../../assets/index-content-tips-aq.png'),
                  content: '支持针对每份数据的加密技术和验证技术，保证数据安全。'
                },
                {
                  name: '高性能',
                  logo: require('../../assets/index-content-tips-gxn.png'),
                  content: '采用高级差异算法实现高性能备份。'
                },
                {
                  name: '多用户、平台化',
                  logo: require('../../assets/index-content-tips-dyh.png'),
                  content: '针对企业不同角色和不同业务部门提供多任务、个性化备份服务，互不影响。'
                },
                {
                  name: '可靠性',
                  logo: require('../../assets/index-content-tips-kkx.png'),
                  content: '去中心化的备份策略，实时在线备份。'
                }
              ]
            },
            {
              bTit: '智能化的CMDB',
              link: '/product-detail?name=zxCMDB',
              sTit: '实现IT环境的数字化，运维分析的基础，满足运维信息化、标准化、平台化、服务化需求。',
              procutImg: require('../../assets/index-content-model-znhcmbd.png'),
              type: 'right',
              tips: [
                {
                  name: '软硬一体化',
                  logo: require('../../assets/index-content-tips-ryyt.png'),
                  content: '安装部署更简单，购买维护成本更低。'
                },
                {
                  name: '智能化',
                  logo: require('../../assets/index-content-tips-znh.png'),
                  content: '自动采集和发现数据，避免手工维护带来的错误和低效率，发现错误数据自动纠正。'
                },
                {
                  name: '全面',
                  logo: require('../../assets/index-content-tips-qm.png'),
                  content: '可管理IT环境中的所有数据，如业务数据、应用程序、硬件配置等。'
                },
                {
                  name: '扩展性',
                  logo: require('../../assets/index-content-tips-kzx.png'),
                  content: '提供全套API便于其他系统接入。'
                },
                {
                  name: '智能U位',
                  logo: require('../../assets/index-content-tips-znuw.png'),
                  content: '通过物联网技术，实现机位的数字化、自动化、可视化管理。'
                },
                {
                  name: '资产管理',
                  logo: require('../../assets/index-content-tips-zcgl.png'),
                  content: '资产全生命周期管理。'
                }
              ]
            }
          ]
        }
      }
    },
    components: {
      swiper,
      swiperSlide
    },

    created () {
      let self = this
      let docElWidth = document.documentElement.clientWidth
      self.swiperOption.slidesPerView = docElWidth/205
    },
    computed: {
      swiper() { 
        return this.$refs.mySwiper.swiper
      } 
    },
    methods: {
      // setSwiper() {
      //   let self = this
      //   let docElWidth = document.documentElement.clientWidth
      //   self.swiperOption.slidesPerView = docElWidth/205
      //   return this.$refs.mySwiper.swiper
      // }
    },
    mounted() {
      // this.swiper.slideTo(0, 1000, true)
    }
  }
</script>

<style lang="scss" scoped>


  .swiper-container {
    overflow: visible;
    // width: 10.1rem;
    // margin: 0 auto;
  }

  .swiper-pagination-fraction, .swiper-pagination-custom, .swiper-container-horizontal > .swiper-pagination-bullets {
    bottom: -24px;
    height: 16px;
    // overflow: hidden;
    line-height: 0;
    padding: 0; 
    margin: 0;
  }

  .geesunn-partners {
    max-width: 1280px;
    padding: 0 1.25rem;
    margin: 0 auto;
    margin-bottom: 1.5rem;

    h2 {
      font-size: 1.25rem;
      font-weight: normal;
      color: #0DB8FF;
      text-align: center;
    }
    
    span.mline {
      border: none;
      display: block;
      height: .125rem;
      width: 2.78125rem;
      background: #0DB8FF;
      margin: .625rem auto;
    }

    .partners-content {

      &::before,
      &::after {
        content: '';
        display: table;
        clear: both;
      }

      div {
        width: 23%;
        margin: 1%;
        float: left;
        line-height: 0;
        border: 1px solid #56D0FF;
        
        img {
          width: 100%;
        }
      }

      @media (max-width: 750px) {
        div {
          width: 46%;
          margin: 2%;
        }
      }

    }

  }
  .index-content-wrap {
    margin-top: 3rem;
    width: 100%;
    
    &::before,
    &::after {
      content: '';
      display: table;
      clear: both;
    }
    
  }

  .index-content-model {
    max-width: 1280px;
    padding: 0 1.25rem;
    margin: 0 auto;
    margin-bottom: 3rem;

    &::before,
    &::after {
      content: '';
      display: table;
      clear: both;
    }
    


    .model-large-content {
      width: 55%;
      float: left;
      

      &::before,
      &::after {
        content: '';
        display: table;
        clear: both;
      }

      h2 {
        font-size: 1.25rem;
        font-weight: normal;
        color: #0DB8FF;

        a {
          text-decoration: none;
          color: #0DB8FF;
        }
      }

      span.blue-line {
        display: block;
        height: .125rem;
        width: 2.78125rem;
        background: #0DB8FF;
        margin: .625rem 0;
      }

      p {
        font-size: .5rem;
        color: #525859;
      }

      .content-tips {
        margin-top: 1.375rem;

        &::before,
        &::after {
          content: '';
          display: table;
          clear: both;
        }

        .tip-wrap {
          width: 32%;
          float: left;
          height: 170px;
          margin-right: 2%;
          text-align: center;

          img {
            width: 2.8125rem;
            height: 1.875rem;
          }

          p {
            padding: .2rem 0;
            font-size: .5rem;
            color: #525859;
          }

          span {
            display: inline-block;
            color: #525859;
            font-size: 0.4375rem;
            text-align: left;
            line-height: .7rem;
          }
        }

        .tip-wrap:nth-child(3) {
          margin-right: 0;
        }

        .tip-wrap:nth-child(6) {
          margin-right: 0;
        }
        @media (max-width: 1150px) {
          .tip-wrap {
            height: 150px;
          }
        }
      }
    }

    .model-small-content {
      &::before,
      &::after {
        content: '';
        display: table;
        clear: both;
      }
      display: none;
    }

    .model-img {
      width: 45%;
      float: left;
      text-align: center;
      // display: table;
      line-height: 0;
      // height: 100%;

      span {
        // display: table-cell;
        // vertical-align: middle;
      }

      img {
        width: 100%;
      }
    }

    .text-right {
      text-align: right;
    }

    .text-left {
      text-align: left;
    }


    
  }

  // @media (max-width: 1000px) {
  //   .index-content-model {
  //     margin-bottom: 3rem;
  //   }
  // }

  @media (max-width: 750px) {
    .index-content-wrap {
      margin-top: 2rem;
    }

    .index-content-model {
      height: auto;
      padding: 0 .25rem .25rem .25rem;
      margin-top: 2rem;
      border-bottom: 1px solid #f1f1f1;

      .model-large-content {
        display: none;
      }


      .model-small-content {
        display: block;

         h2 {
          font-size: 1rem;
          font-weight: normal;
          text-align: center;
          color: #0DB8FF;

          a {
            text-decoration: none;
            color: #0DB8FF;
          }
        }

        span.blue-line {
          display: block;
          height: .125rem;
          width: 2.32432432432435rem;
          background: #0DB8FF;
          margin: .625rem auto;
        }

        p {
          font-size: .75675675675676rem;
          color: #525859;
          text-align: center;
        }

        .small-content-scroll-wrap {
          overflow: hidden;
          padding: .5rem 0 1.5rem 0;
          border-top: 1px solid #f1f1f1;

          .small-content-scroll-fram { 
            // width: 10.1rem;
            // margin: 0 auto;
            margin: 0;
            padding: 0;
            margin-left:10px;

            .tip-wrap {
              border: 1px solid #0DB8FF;
              text-align: center;
              padding: 0 .5rem;
              height: 9.7rem;
              width: 10rem;
              margin: 0;
              padding: 0;

              img {
                margin-top: .6rem;
              }

              p {
                font-size: .75675675675676rem;
                margin-bottom: .2rem;
              }

              span {
                font-size: .64864864864865rem;
                color: #525859;
                display: block;
                margin-bottom: .2rem;
              }
            }

            .tip-wrap:last-child {
              margin-right: 0;
            }
          }
        }
      }

      .model-img {
        display: block;
        width: 100%;
        float: initial;
        padding-bottom: 0;

        span {
          display: inline;
        }

        img {
          width: 9.1891891891892rem;
          margin: 1rem 0;
        }
      }

      .text-left {
        text-align: center;
      }
      .text-right {
        text-align: center;
      }
      
    }
  }
</style>
