import productDetail from './productDetail'
export default productDetail