<template>
  <div>
    <product-banner :bannerData="productData.bannerData"></product-banner>
    <product-nav :productData="productDatas" :onMenu="onMenu"></product-nav>
    <div class="product-detail-wrap">
      <div class="product-img">
        <img :src="productData.productImage">
      </div>
      <h2>{{productData.name}}</h2>
      <div class="product-tips-wrap">
        <product-content-model :productDataTips="productData.tips"></product-content-model>
      </div>
    </div>
    <div v-if="productData.editions.length > 0" class="editions-wrap">
      <h2>IDC监控管理平台提供以下四个版本</h2>
      <div class="edition-contents-wrap">
        <div v-for="edition in productData.editions" class="edition-content-wrap">
          <div class="edition-tit">{{edition.name}}</div>
          <div class="edition-content">
            <span v-for="con in edition.content">{{con}}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: '',
    data () {
      return {
        productDatas: {
          zhjkywpt: {
            name: '综合监控运维平台',
            Ename: 'zhjkywpt',
            productImage: require('../../assets/product-detail-zhjkywpt.png'),
            bannerData: {
              bTit: '综合监控运维平台',
              sTit: 'IT监控、IT运维一站式、一体化运维服务平台，帮助各行业、各规模政企建立完整的监控、运维体系。从而彻底改变错综无序的IT服务现状，提高IT团队的生产效率，改善终端用户的满意度。',
              image: require('../../assets/product-banner-content-zhjkywpt.png')
            },
            tips: {
              '0': {
                open: true,
                index: 0,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-pzgl-white.png'),
                logoB: require('../../assets/product-detail-tip-pzgl-blue.png'),
                tit: '配置管理',
                content: '全面追踪和管理所有IT配置项，映射配置项之间的关系及依赖性。直观地分析变更和故障可能产生的影响，从而制定明智决策，同时为其他模块提供数据支撑。可管理网络设备、服务器、IDC、专线、IP资源、产品业务、应用程序等'
              },
              '1': {
                open: false,
                index: 1,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-jkst-white.png'),
                logoB: require('../../assets/product-detail-tip-jkst-blue.png'),
                tit: '监控视图',
                content: '实现整个IT环境的拓扑架构、运行状况、监控指标通过二维视图、折线图等形式展现，易于运维人员分析和发现问题。主要包括拓扑监控、流量监控、设备运行监控、应用监控、业务监控等'
              },
              '2': {
                open: false,
                index: 2,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-jkgj-white.png'),
                logoB: require('../../assets/product-detail-tip-jkgj-blue.png'),
                tit: '监控告警',
                content: '7*24小时不间断监测IT环境各运行指标，并以多种方式通知到相关人员，以便于相关人员最快发现异常并进行预防和解决。可监测产品业务健康状况，服务器硬件、系统、软件运行情况，网络设备系统、端口运行状况，网络专线健康状况等。'
              },
              '3': {
                open: false,
                index: 3,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zdfxycj-white.png'),
                logoB: require('../../assets/product-detail-tip-zdfxycj-blue.png'),
                tit: '自动发现与采集',
                content: '通过自动化采集和发现，有效解决运维效率、数据准确性、数据完整性问题，避免人工录入的麻烦和数据录入错误，将IT环境数据全面的、正确的展示给运维人员和管理人员。本系统通过多种手段如Agent、SNMP、IPMI、TCP/IP、HTTP等对IT环境所有可采集的设备、系统和运用进行采集。'
              },
              '4': {
                open: false,
                index: 4,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zyfx-white.png'),
                logoB: require('../../assets/product-detail-tip-zyfx-blue.png'),
                tit: '资源分析',
                content: '通过各角度的资源统计与视图，对IT资源分配、使用及资产信息进行全面了解，以便于进行IT资源统筹规划，有效利用各种IT资源，降低IT资源空闲和不合理的情况，降低IT资源成本。同时为业务系统提供IT架构优化依据。'
              },
              '5': {
                open: false,
                index: 5,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-sjgd-white.png'),
                logoB: require('../../assets/product-detail-tip-sjgd-blue.png'),
                tit: '事件工单',
                content: '承接告警事件，并管理支持工单的整个生命周期，提高运维人员的效率，符合SLA。支持告警自动建单、人工建单。'
              },
              '6': {
                open: false,
                index: 6,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zsk-white.png'),
                logoB: require('../../assets/product-detail-tip-zsk-blue.png'),
                tit: '知识库',
                content: '为运维人员提供学习和交流的平台，实现工单经验一键转到知识库。同时基于本知识库，可智能化地为告警和故障处理提供最佳解决方案。'
              },
              '7': {
                open: false,
                index: 7,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-yyw-white.png'),
                logoB: require('../../assets/product-detail-tip-yyw-blue.png'),
                tit: '云运维',
                content: '通过互联网线上平台如浏览器、微信、APP，为企业运维人员提供更优的运维工具，在异地仍可使用本系统，为运维人员提供最大便利性。'
              },
              '8': {
                open: false,
                index: 8,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zcjk-white.png'),
                logoB: require('../../assets/product-detail-tip-zcjk-blue.png'),
                tit: '资产监控',
                content: '集中管理所有IT资产，实现IT资产的生命周期管理，优化资产的利用并保证资产的合规性。'
              },
              '9': {
                open: false,
                index: 9,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-ycgl-white.png'),
                logoB: require('../../assets/product-detail-tip-ycgl-blue.png'),
                tit: '远程管理',
                content: '对远程服务器进行冷启动和关机，避免需要机房现场操作的麻烦，实现无SSH客户端的SSH登录。'
              },
              '10': {
                open: false,
                index: 10,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-dhjk-white.png'),
                logoB: require('../../assets/product-detail-tip-dhjk-blue.png'),
                tit: '动环监控',
                content: '动环监控将分散的空调系统、温湿度传感器、安防设备、机柜、网络设备以真实的机房背景有机的整合，实时显示各项关键参数，使机房摆脱纯数据管理模式。'
              },
              '11': {
                open: false,
                index: 11,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-3dst-white.png'),
                logoB: require('../../assets/product-detail-tip-3dst-blue.png'),
                tit: '3D视图',
                content: '所见即所得的透明化。'
              }
            },
            editions: [
              {
                name: '标准版',
                content: [
                  '最多支持50个监控节点',
                  '1U设备'
                ]
              },
              {
                name: '专业版',
                content: [
                  '最多支持100个监控管理节点',
                  '1U设备'
                ]
              },
              {
                name: '高级版',
                content: [
                  '最多支持200个监控管理节点',
                  '2U设备'
                ]
              },
              {
                name: '分布式版',
                content: [
                  '管理节点无限，根据实际规模按需部署'
                ]
              }
            ]
          },
          IDCglkzpt: {
            name: 'IDC管理控制平台',
            Ename: 'IDCglkzpt',
            productImage: require('../../assets/product-detail-IDCglkzpt.png'),
            bannerData: {
              bTit: 'IDC管理控制平台',
              sTit: 'IT监控、IT运维一站式、一体化运维服务平台，帮助各行业、各规模政企建立完整的监控、运维体系。从而彻底改变错综无序的IT服务现状，提高IT团队的生产效率，改善终端用户的满意度。',
              image: require('../../assets/product-banner-content-IDCglkzpt.png')
            },
            tips: {
              '0': {
                open: true,
                index: 0,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-pzgl-white.png'),
                logoB: require('../../assets/product-detail-tip-pzgl-blue.png'),
                tit: '配置管理',
                content: '全面追踪和管理所有IT配置项，映射配置项之间的关系及依赖性。直观地分析变更和故障可能产生的影响，从而制定明智决策，同时为其他模块提供数据支撑。可管理网络设备、服务器、IDC、专线、IP资源、产品业务、应用程序等'
              },
              '1': {
                open: false,
                index: 1,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-jkst-white.png'),
                logoB: require('../../assets/product-detail-tip-jkst-blue.png'),
                tit: '监控视图',
                content: '实现整个IT环境的拓扑架构、运行状况、监控指标通过二维视图、折线图等形式展现，易于运维人员分析和发现问题。主要包括拓扑监控、流量监控、设备运行监控、应用监控、业务监控等'
              },
              '2': {
                open: false,
                index: 2,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zcgl-white.png'),
                logoB: require('../../assets/product-detail-tip-zcgl-blue.png'),
                tit: '资产管理',
                content: '集中管理所有IT资产，实现IT资产的生命周期管理，优化资产的利用并保证资产的合规性。'
              },
              '3': {
                open: false,
                index: 3,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zdfxycj-white.png'),
                logoB: require('../../assets/product-detail-tip-zdfxycj-blue.png'),
                tit: '自动发现与采集',
                content: '通过自动化采集和发现，有效解决运维效率、数据准确性、数据完整性问题，避免人工录入的麻烦和数据录入错误的问题，将IT环境数据全面的、正确的展示给运维人员和管理人员。本系统通过多种手段如Agent、SNMP、IPMI、TCP/IP、HTTP等对IT环境所有可采集的设备和数据进行采集。'
              },
              '4': {
                open: false,
                index: 4,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zyfx-white.png'),
                logoB: require('../../assets/product-detail-tip-zyfx-blue.png'),
                tit: '资源分析',
                content: '基于CMDB的数据，通过各角度的资源统计与视图，对IT资源分配、使用及资产信息进行全面了解，以便于进行IT资源统筹规划，有效利用各种IT资源，降低IT资源空闲和不合理的情况，降低IT资源成本。同时为业务系统提供IT架构优化依据。'
              },
              '5': {
                open: false,
                index: 5,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-sjgd-white.png'),
                logoB: require('../../assets/product-detail-tip-sjgd-blue.png'),
                tit: '事件工单',
                content: '承接告警事件，并管理支持工单的整个生命周期，提高运维人员的效率，符合SLA。支持告警自动建单、人工建单。'
              },
              '6': {
                open: false,
                index: 6,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-ckpj-white.png'),
                logoB: require('../../assets/product-detail-tip-ckpj-blue.png'),
                tit: '仓库配件',
                content: '机房内部的库区及配件管理，可自动采集整机配件信息，含出入库流程跟踪，配件的生命周期管理。'
              },
              '7': {
                open: false,
                index: 7,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-bggl-white.png'),
                logoB: require('../../assets/product-detail-tip-bggl-blue.png'),
                tit: '变更管理',
                content: '完善的变更流程管理，高效的变更实施，与需求的紧密结合使需求的实现更清晰、更简洁、更高效。'
              },
              '8': {
                open: false,
                index: 8,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-dhjk-white.png'),
                logoB: require('../../assets/product-detail-tip-dhjk-blue.png'),
                tit: '动环监控',
                content: '动环监控将分散的空调系统、温湿度传感器、安防设备、机柜、网络设备以真实的机房背景有机的整合，实时显示各项关键参数，使机房摆脱纯数据管理模式。'
              },
              '9': {
                open: false,
                index: 9,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-3dst-white.png'),
                logoB: require('../../assets/product-detail-tip-3dst-blue.png'),
                tit: '3D视图',
                content: '所见即所得的透明化。'
              }
            },
            editions: [
              {
                name: '标准版',
                content: [
                  '最多支持50个监控节点',
                  '1U设备'
                ]
              },
              {
                name: '专业版',
                content: [
                  '最多支持100个监控管理节点',
                  '1U设备'
                ]
              },
              {
                name: '高级版',
                content: [
                  '最多支持200个监控管理节点',
                  '2U设备'
                ]
              },
              {
                name: '分布式版',
                content: [
                  '管理节点无限，根据实际规模按需部署'
                ]
              }
            ]
          },
          zxsjpt: {
            name: '智象数据平台',
            Ename: 'zxsjpt',
            productImage: require('../../assets/product-detail-zxsjpt.png'),
            bannerData: {
              bTit: '智象数据平台',
              sTit: '简单高效的企业级云备份服务系统，支持数据库、文件、文档加密备份与高效恢复。通过浏览器管理、安全、灵活、扩展性强的本地&云端备份管理平台。',
              image: require('../../assets/product-banner-content-zxsjpt.png')
            },
            tips: {
              '0': {
                open: true,
                index: 0,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-dyhgl-white.png'),
                logoB: require('../../assets/product-detail-tip-dyhgl-blue.png'),
                tit: '多用户管理',
                content: '支持多部门多业务多用户自主建立备份策略，互不影响。'
              },
              '1': {
                open: false,
                index: 1,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-drwgl-white.png'),
                logoB: require('../../assets/product-detail-tip-drwgl-blue.png'),
                tit: '多任务管理',
                content: '系统同时可建立多个备份任务，每个任务有自己的备份内容和备份策略。满足用户多样化备份需求。'
              },
              '2': {
                open: false,
                index: 2,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-bbhg-white.png'),
                logoB: require('../../assets/product-detail-tip-bbhg-blue.png'),
                tit: '版本回滚',
                content: '备份的数据支持任意版本回滚，让数据真正可回溯。'
              },
              '3': {
                open: false,
                index: 3,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-ccsbglq-white.png'),
                logoB: require('../../assets/product-detail-tip-ccsbglq-blue.png'),
                tit: '存储设备管理器',
                content: '支持本地、云端（阿里云、亚马逊、腾讯云）等存储方式，灵活易用。'
              },
              '4': {
                open: false,
                index: 4,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-dlxsjbf-white.png'),
                logoB: require('../../assets/product-detail-tip-dlxsjbf-blue.png'),
                tit: '多类型数据备份',
                content: '支持图片、视频、文档、数据库的备份，支持数据库自动导出备份'
              },
              '5': {
                open: false,
                index: 5,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-html5jmhcz-white.png'),
                logoB: require('../../assets/product-detail-tip-html5jmhcz-blue.png'),
                tit: 'HTML5界面化操作',
                content: 'HTML5自适应Web控制台界面'
              }
            },
            editions: []
          },
          zxCMDB: {
            name: '智象CMDB',
            Ename: 'zxCMDB',
            productImage: require('../../assets/product-detail-zxCMBD.png'),
            bannerData: {
              bTit: '智象CMDB',
              sTit: '存储和管理IT环境中的所有配置项信息以及配置项之间的关系，完成IT环境数字化，是运维分析的基础，满足运维信息化、标准化、平台化、服务化需求。',
              image: require('../../assets/product-banner-content-zxCMBD.png')
            },
            tips: {
              '0': {
                open: true,
                index: 0,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-ywsjfx-white.png'),
                logoB: require('../../assets/product-detail-tip-ywsjfx-blue.png'),
                tit: '业务数据分析',
                content: '支持企业产品和业务的管理，并从业务角度分析所以用的IT资源状况。'
              },
              '1': {
                open: false,
                index: 1,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zcgl-white.png'),
                logoB: require('../../assets/product-detail-tip-zcgl-blue.png'),
                tit: '资产管理',
                content: '管理及追踪所有IT资产，IT资产的生命周期中的变化可跟踪。'
              },
              '2': {
                open: false,
                index: 2,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zyfx-white.png'),
                logoB: require('../../assets/product-detail-tip-zyfx-blue.png'),
                tit: '资源分析',
                content: '通过视图展示IT资源的分配和使用状况，便于用户规划IT资源使用，有效提高IT资源的利用率，'
              },
              '3': {
                open: false,
                index: 3,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-zdh-white.png'),
                logoB: require('../../assets/product-detail-tip-zdh-blue.png'),
                tit: '自动化',
                content: '自动发现CMDB配置项和资产数据，如服务器与机位的关系、服务器配置信息、网络设备型号信息、IP信息等。'
              },
              '4': {
                open: false,
                index: 4,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-xxrz-white.png'),
                logoB: require('../../assets/product-detail-tip-xxrz-blue.png'),
                tit: '详细日志',
                content: '记录配置项及关系的操作日记，实现数据修改可追踪。'
              },
              '5': {
                open: false,
                index: 5,
                realheight: 0,
                logoW: require('../../assets/product-detail-tip-API-white.png'),
                logoB: require('../../assets/product-detail-tip-API-blue.png'),
                tit: 'API',
                content: '完整API接口、开放的态度、获取的自由。'
              }
            },
            editions: []
          }
        },
        productData: null,
        bannerData: null,
        onMenu: ''
      }
    },
    components: {

    },
    methods: {

      // 获取路径参数
      GetQueryString(name) {
        let reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
        let r = window.location.search.substr(1).match(reg)
        if(r !== null)return  unescape(r[2]); return null
      }
    },
    created () {
      let self = this
      let productName = self.GetQueryString('name')
      self.productData = self.productDatas[productName]
      self.onMenu = productName
    }
  }
</script>

<style lang="scss" scoped>

  .product-detail-wrap {
    max-width: 1280px;
    // padding: 0 1.25rem;
    margin: 0 auto;


    .product-img {
      text-align: center;
      padding: 1.5625rem 0 2.03125rem 0;
      img {
        width: 20.3125rem;
      }
    }

    >h2 {
      font-size: .9375rem;
      font-weight: normal;
      color: #0DB8FF;
      text-align: center;
      margin-bottom: 1.5625rem;
    }

    .product-tips-wrap {
      margin-bottom: 1.5625rem;
    }
  }

  @media (max-width: 750px) {
    .product-detail-wrap {

      .product-img {

        text-align: center;

        img {
          width: 80%;
        }
      }

      >h2 {
        font-size: 1.2rem;
      }
    }
  }


  .editions-wrap {
    margin-bottom: 1.5rem;

    h2 {
      font-size: .9375rem;
      font-weight: normal;
      color: #0DB8FF;
      text-align: center;
      // margin-top: 1.5625rem;
    }

    .edition-contents-wrap {

      max-width: 1280px;
      padding: 0 1.25rem;
      margin: 0 auto;

      &::after,
      &::before {
        content: '';
        display: table;
        clear: both;
      }

      .edition-content-wrap {
        border: 1px solid #c4c4c4;
        width: 21%;
        min-height: 7rem;
        float: left;
        margin: 1.5625rem 2% 0 2%;

        .edition-tit {
          line-height: 2rem;
          font-size: .75rem;
          color: #FFF;
          text-align: center;
          background: #00B7FF;

          background: -webkit-linear-gradient(left, #0060FF, #00B7FF); /* Safari 5.1 - 6.0 */
          background: -o-linear-gradient(left, #0060FF, #00B7FF); /* Opera 11.1 - 12.0 */
          background: -moz-linear-gradient(left, #0060FF, #00B7FF); /* Firefox 3.6 - 15 */
          background: linear-gradient(left, #0060FF, #00B7FF); /* 标准的语法 */
        }

        .edition-content {
          padding: 1rem .5rem 0 1.2rem;

          span {
            display: block;
            font-size: 0.5625rem;
            color: #888888;
            position: relative;
            line-height: 1rem;

            &::before {
              display: inline-block;
              position: absolute;
              left: -10px;
              top: .35rem;
              content: '';
              height: 5px;
              width: 5px;
              border-radius: 5px;
              background: #087bce;
            }
          }
        }
      }

      @media (max-width: 750px) {

        .edition-content-wrap {
          width: 42%;
          height: 8.5405405405405rem;
          margin: 1.5625rem 4% 0 4%;

          .edition-content {
            span {
              line-height: 1.5rem;

              &::before {
                top: .6rem;
              }
            }
          }

        }
      }
    }

  }

  //
</style>
