<template>
  <div class="">
    <div class="contact-banner">
      <g-nav></g-nav>
      <div class="banner-content">
        <h2>智象运维</h2>
        <p>专业企业级综合运维解决方案提供商</p>
      </div>
    </div>
    <div class="contact-us-content">
      <div class="geesunn-explain">
        <h2>关于智象</h2>
        <p>深圳市智象科技有限公司（Shenzhen Geesunn Technology Co., Ltd.）成立于2016年，是由多位行业运维专家成立的互联网科技公司。公司为客户提供专业的、具有先进性的运维产品、解决方案和服务。</p>
        <p>团队核心成员曾任职于腾讯、东软等大型互联网企业，团队成员均具有优秀的创新意识和服务理念，具备IDC、海量IT设备的运维经验和专业的ITIL/ITSM、操作系统、网络、安全、数据等知识能力。</p>
        <p>团队通过多年努力，打造了一系列IT自动化管理和运维、智能IDC管理、运维SaaS平台相关产品。业务涉及IT网管监控、ITIL运维流程、自动化运维工具、网络优化、云运维平台等产品的开发建设和运营。客户范围包括政府、金融、教育、电力、企业、IDC运营商等多个领域。智象产品线包括：</p>
        <div style="margin-top: .5rem;">一站式综合监控运维平台：包含了网管、资产、设备监控告警、应用分析监控、配置管理（CMDB）、事件工单、知识库、堡垒机等模块。满足了企业资产管理、网络拓扑管理、业务健康度分析、资源使用率分析、设备健康度分析、故障解决效率分析、统一认证等业务应用场景。</div>
        <div>智能化IDC监控运营平台：包含IDC动力环境监控、资产管理、基础设施巡检、维保等功能模块。实现IDC高质量、精细化运维与运营。</div>
        <div>自动化运维SaaS平台：实现了高度自治的自动化运维流程平台。允许用户自行定义运维工具和流程。真正实现自动化运维，有效提升运维效率。</div>
        <p>通过如上的产品平台可帮助企业和运营商实现高效率、高质量的精细化运维与运营，以提高企业的IT服务质量和效率，降低IT运维成本。</p>
        <p>2017年智象科技获得广东唯一网络的战略投资，并达成战略合作伙伴，已经在IDC管理、监控、运维流程、客户管理等方面进行了深入的合作，以帮助唯一网络在自动化、智能化运维和精细化、高质量运营方面进行优化提升。</p>
        <p>智象科技将持续发挥创新研发优势，坚持以服务客户为核心，形成以智能IT服务为核心的综合解决方案，努力打造成为业界领先、专业的的智能IT服务提供商！</p>
        <!-- <p>深圳市智象科技有限公司（Shenzhen Geesunn Technology Co., Ltd.）是由多位腾讯专业运维团队成员组建的互联网科技公司，是国内最具有创新意识和最佳服务理念的运维产品服务及方案提供商。团队具备海量IT设备的运营运维经验，并具有专业的ITIL/ITSM、操作系统、网络、安全、数据等知识和能力，打造了一系列监控、运维、数据安全、资产管理等系统以及SaaS平台。业务涉及IT网管监控、IT运维、IT流程、网络优化、数据安全、云运维平台等产品的开发建设和运营。客户范围包括政府、金融、教育、电力、企业、IDC运营商等多个领域。</p>
        <p>智象科技作为一家新型的互联网科技企业，一直秉承以用户为中心的服务理念，以知识和技术创新为手段，为用户提供最完整、最实用的一站式运维流程和体验，解决当前运维中遇到的各种问题，帮助用户提高IT服务质量，降低IT运维成本。</p>
        <p>2017年智象科技与唯一网络达成战略合作伙伴，在IDC管理、监控、运维流程、客户管理等方面进行深入的合作。</p>
        <p>智象科技根据用户需求及现状，当前已经推出了智象运维（for 企业 和for IDC）、智象CMDB、智象数据、智象云四大产品平台，智象科技将继续发挥创新研发优势，坚持以服务客户为核心，形成以智能IT服务为核心的综合解决方案，努力打造成为业界领先的智能IT服务提供商！</p> -->
      </div>
    </div>
    <div class="geesunn-adress">
      <div class="geesunn-adress-wrap">
        <div>
          <h2>联系我们</h2>
          <p><span>联系电话</span>：0755-86521101 / 18988791008</p>
          <p><span>邮箱</span>：service@geesunn.com</p>
          <p><span>地址</span>：深圳市南山区科技园高新技术产业园R3-B栋5楼508</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: '',
    data () {
      return {}
    },
    components: {}
  }
</script>

<style lang="scss" scoped>
  .contact-banner {
    background: url('../../assets/contact-us-banner-bak.png');
    padding-top:2.0833333333333rem;
    padding-bottom: 2rem;

    .banner-content {
      background-image: url('../../assets/contact-us-banner-content.png');
      background-size: auto 100%;
      height: 11.71875rem;
      width: 20.1875rem;
      margin: 0 auto;

      h2 {
        color: #FFF;
        text-align: center;
        font-size: 1.125rem;
        font-weight: normal;
        padding-top: 4rem;
      }

      p {
        color: #FFF;
        text-align: center;
        font-size: .75rem;
        padding-top: .8rem;
      }
    }

    @media (max-width: 400px) {
      .banner-content {
        width: 100%;
      }
    }

  }

  .geesunn-explain {
    margin: 0 auto 2rem auto;
    max-width: 1280px;
    padding: 0 3.25rem;

    h2 {
      text-align: center;
      color: #0DB8FF;
      font-size: 1.125rem;
      font-weight: normal;
      margin-top: 1.5rem;
    }

    p {
      font-size: 14px;
      line-height: 24px;
      color: #555;
      margin-top: 1rem;

    }
    div {
      font-size: 14px;
      color: #555;
      line-height: 24px;
      margin-left: 1.2rem;
      margin-top: .2rem;
      position: relative;
    }

    div::before {
      content: '';
      position: absolute;
      left: -.5rem;
      top: 9px;
      height: 6px;
      display: inline-block;
      width: 6px;
      border-radius: 3px;
      background-color: #555;
    }
  }

  .geesunn-adress {

    background-image: url('../../assets/contact-us-adress-bak2.jpg');
    background-position: center center;
    background-color: #f2f2f2;
    background-repeat: no-repeat;

    .geesunn-adress-wrap {
      max-width: 1280px;
      padding: 3rem 1.25rem;
      margin: 0 auto;

      h2 {
        font-size: 1.125rem;
        color: #0DB8FF;
        font-weight: normal;
        padding: 0 1.7rem .5rem 1.7rem;
      }

      p {
        font-size: 14px;
        color: #555;
        padding: .1rem 1.7rem;
      }


    }
  }

  @media (max-width: 750px) {
    .geesunn-explain {
      padding: 0 .7rem;
    }

    .geesunn-adress {

      .geesunn-adress-wrap {

        padding: 3rem 0;

        h2 {
          padding: 0 .7rem .5rem .7rem;
        }
        p {
          padding: .2rem .7rem;
          font-size: 10px;
        }
      }
    }
  }
</style>
