import Vue from 'vue'
import Router from 'vue-router'
// import HelloWorld from '@/components/HelloWorld'
// import nav from '@/components/nav'

import indexv from '@/views/indexv'
import productDetail from '@/views/productDetail'
import contactUs from '@/views/contactUs'



Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [

    // 首页
    {
      path: '/',
      name: 'index',
      component: indexv
    },

    // 产品详情页
    {
      path: '/product-detail',
      name: 'product-detail',
      component: productDetail
    },
    // 联系我们
    {
      path: '/contact-us',
      name: 'contact-us',
      component: contactUs
    }
  ]
})
