// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import './styles/index.scss'
import 'font-awesome/css/font-awesome.css'
import 'swiper/dist/css/swiper.css'
import VueAwesomeSwiper from 'vue-awesome-swiper'

import GNav from './components/nav'
import fullScreenBanner from './components/full-screen-banner'
import productBanner from './components/product-banner'
import indexSwiper from './components/index-swiper'
import productContentModel from './components/product-content-model'
import productNav from './components/product-nav' 
import GBottom from './components/g-bottom'
import GContact from './components/g-contact'


Vue.use(VueAwesomeSwiper)
Vue.use(GNav)
Vue.use(fullScreenBanner)
Vue.use(productBanner)
Vue.use(indexSwiper)
Vue.use(productContentModel)
Vue.use(productNav)
Vue.use(GBottom)
Vue.use(GContact)



Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})
