import GNav from './nav'

GNav.install = vue => {
  vue.component(GNav.name, GNav)
}

export default GNav