<template>
  <div class="nav" :class="[isTop ? 'is-top' : 'no-top', isSmallScreenNavOut ? 'is-small-screen-nav-out' : 'no-small-screen-nav-out']">
    <div class="nav-wrap clearBoth">
      <div class="nav-left">
        <a href="/" class="nav-logo"></a>
      </div>
      <div class="nav-right">
        <ul class="large-screen">
          <!-- <li>首页</li> -->
          <li v-for='data in navData.value' @mousemove="pOpenTwoMenu(data.index)" @mouseout="pCloseTwoMenu(data.index)" :class="navData.checkedStatus && !data.checkedStatus ? 'noChecked' : ''">
            <a :href="data.link === '#' || data.link === '' ? 'javascript:void(0)' : data.link">
              {{data.value}}
              <span></span>
            </a>
            <div v-if="data.children && data.children.length > 0" :id="`two-links-${data.index}`" class="two-links" :style="{height: `${data.largeChildrenHeight}px`}">
              <div class="two-links-wrap" :id="`two-links-wrap-${data.index}`">
                <a v-for='_data in data.children' :href="_data.link === '#' || _data.link === '' ? 'javascript:void(0)' : _data.link">
                  {{_data.value}}
                </a>
              </div>
            </div>
          </li>
        </ul>
        <span class="small-screen nav-cont-out" :class=" isSmallScreenNavOut ? 'close' : ''" @click="switchOneMenu()">
          <span class="top"></span>
          <span class="middle"></span>
          <span class="bottom"></span>
        </span>
      </div>
    </div>
    <div class="small-screen-content" @touchmove="touchmoveDown" @touchstart="touchstartEvent">
      <div>
        <ul  class="parent-ul" :class="isSmallScreenNavOut ? 'small-screen-nav-out': 'small-screen-nav-in'" :style="{height: navData.height}">
          <li v-for='data in navData.value' :class=" data.active ? 'active' : ''">
            <div>
              <a @click.top="data.hadChildren === true ? switchTwoMenu($event, data.index) : ''" :href="data.link === '#' || data.link === '' || data.hadChildren === true ? 'javascript:void(0)' : data.link">
                {{data.value}}
              </a>
              <span v-if="data.hadChildren && !data.active" class="fa fa-angle-down" @click.top="data.hadChildren === true ? switchTwoMenu($event, data.index) : ''"></span>
              <span v-if="data.hadChildren && data.active" class="fa fa-angle-up" @click.top="data.hadChildren === true ? switchTwoMenu($event, data.index) : ''"></span>
            </div>
            <ul v-if="data.hadChildren" :style="{height: data.active ? data.smallChildrenHeight : '0'}">
              <li v-for='_data in data.children'>
                <div>
                  <a :href="_data.link === '#' || _data.link === '' ? 'javascript:void(0)' : _data.link">
                    {{_data.value}}
                  </a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'GNav',
    data () {
      return {
        isTop: true,
        isSmallScreenNavOut: false,
        screenHeigt: 0,
        startX: 0,
        startY: 0,
        navData: {
          checkedStatus: false,
          value: {
            '0': {
              value: '首页',
              index: 0,
              link: '/',
              checkedStatus: false,
              hadChildren: false,
              active: false,
              children: [],
              smallChildrenHeight: '0',
              largeChildrenHeight: '0'
            },
            '1': {
              value: '产品服务',
              index: 1,
              link: '/product-detail?name=zhjkywpt',
              checkedStatus: false,
              hadChildren: true,
              active: false,
              children: [
                {
                  value: '综合监控运维平台',
                  link: '/product-detail?name=zhjkywpt'
                },
                {
                  value: 'IDC管理控制平台',
                  link: '/product-detail?name=IDCglkzpt'
                },
                {
                  value: '智象数据平台',
                  link: '/product-detail?name=zxsjpt'
                },
                {
                  value: '智象CMDB',
                  link: '/product-detail?name=zxCMDB'
                }
              ],
              smallChildrenHeight: '0',
              largeChildrenHeight: '0'
            },
            // '2': {
            //   value: '解决方案',
            //   link: '',
            //   index: 2,
            //   checkedStatus: false,
            //   hadChildren: false,
            //   active: false,
            //   children: [],
            //   smallChildrenHeight: '0',
            //   largeChildrenHeight: '0'
            // },
            // '3': {
            //   value: '人才招聘',
            //   link: '',
            //   index: 3,
            //   checkedStatus: false,
            //   hadChildren: false,
            //   active: false,
            //   children: [],
            //   smallChildrenHeight: '0',
            //   largeChildrenHeight: '0'
            // },
            '4': {
              value: '关于我们',
              link: 'contact-us',
              index: 4,
              checkedStatus: false,
              hadChildren: false,
              active: false,
              children: [],
              smallChildrenHeight: '0',
              largeChildrenHeight: '0'
            },
            // '5': {
            //   value: '技术支持',
            //   link: '',
            //   index: 5,
            //   checkedStatus: false,
            //   hadChildren: true,
            //   active: false,
            //   children: [
            //     {
            //       value: '产品文档',
            //       link: 'static/cpwd.pdf'
            //     }
            //   ],
            //   smallChildrenHeight: '0',
            //   largeChildrenHeight: '0'
            // }
          },
          height: '0'
        }
      }
    },

    created () {
      let self = this
      for (let item in self.navData.value) {
        if(self.navData.value[item].children && self.navData.value[item].children.length > 0) {
          self.navData.value[item].smallChildrenHeight = `${self.navData.value[item].children.length * 54}px` 
        }
      }

      self.checkPageIsTop()
      let docEl = document.documentElement
      self.screenHeigt = docEl.clientHeight
      let rem = docEl.clientWidth <= 1280  &&  docEl.clientWidth  >= 750  ?  docEl.clientWidth / 40 : (docEl.clientWidth > 1280 ? 1280 / 40 : 750  / 40) 
      self.navData.height = docEl.clientHeight - 2.1*rem + 'px'
    },

    methods: {

      // 检测是否在屏幕顶部
      checkPageIsTop () {
        let self = this

        //判断当前页面是否位于顶部，并为导航栏添加响应样式
        let nwoPosition = document.documentElement.scrollTop || document.body.scrollTop
        if (nwoPosition >= 20) {
          self.isTop = false
        } else {
          self.isTop = true
        }

        window.onscroll = function () {
          let nwoPosition = document.documentElement.scrollTop || document.body.scrollTop
          if (nwoPosition >= 20) {
            self.isTop = false
          } else {
            self.isTop = true
          }
        }
      },

      // 移动端 开关下拉菜单
      switchOneMenu () {
        let self = this
        self.isSmallScreenNavOut ? self.isSmallScreenNavOut = false : self.isSmallScreenNavOut = true
        if(self.isSmallScreenNavOut === false) {
          for(let item in self.navData.value) {
            self.navData.value[item].active = false
          }
        }
        self.lockBody()
      },

      // 电脑端打开二级菜单
      pOpenTwoMenu(index) {
        let self = this

        self.navData.checkedStatus = true
        self.navData.value[index].checkedStatus = true
        if(self.navData.value[index].hadChildren) {
          self.navData.value[index].largeChildrenHeight = document.getElementById(`two-links-wrap-${index}`).clientHeight + 5
        }
      },

      pCloseTwoMenu(index) {
        let self = this
        self.navData.checkedStatus = false
        self.navData.value[index].checkedStatus = false

        if(self.navData.value[index].hadChildren) {
          self.navData.value[index].largeChildrenHeight = 0
        }
      },

      //开关移动端二级菜单
      switchTwoMenu(event,index) {
        let self = this
        if(self.navData.value[index].hadChildren) {
          for(let item in self.navData.value) {
            if(item !== `${index}`) {
              self.navData.value[item].active = false
            }
          }
        }
        self.navData.value[index].active = !self.navData.value[index].active
        self.eventPreventDefault(event)
      },

      // 禁止事件默认行为
      eventPreventDefault(event) {
        if (event.cancelable) {
          if (!event.defaultPrevented) {
            event.preventDefault()
          }
        }
      },

      // 所有屏幕禁止屏幕滚动

      lockBody() {
        let self = this
        if(self.isSmallScreenNavOut) {
          document.body.style.overflow = 'hidden'
          // document.addEventListener('touchmove', self.eventPreventDefault,false)
        } else {
          // document.removeEventListener('touchmove', self.eventPreventDefault,false)
          document.body.style.overflow = 'visible'
        }
      },

      touchstartEvent (event) {
        let self = this
        self.startX = event.changedTouches[0].pageX
        self.startY = event.changedTouches[0].pageY
      },

      // 滑动关闭
      touchmoveDown (event) {
        let self = this

        self.eventPreventDefault(event)

        let moveEndX = event.changedTouches[0].pageX
        let moveEndY = event.changedTouches[0].pageY
        // console.log(event)
        // console.log(moveEndX)

        let distanceX  = moveEndX - self.startX
        let distanceY = moveEndY - self.startY

        if( Math.abs(distanceX) < Math.abs(distanceY) && distanceY<0 && Math.abs(distanceY) > 100){
          self.isSmallScreenNavOut = false
          self.lockBody()
        }
        
        // if( Math.abs(distanceX) > Math.abs(distanceY) && distanceX > 0){
        //   console.log('往右滑动')
        // } else if( Math.abs(distanceX) > Math.abs(distanceY) && distanceX < 0){
        //   console.log('往左滑动')
        // } else if( Math.abs(distanceX) < Math.abs(distanceY) && distanceY<0){
        //   console.log('往上滑动')
        // } else if( Math.abs(distanceX) < Math.abs(distanceY) && distanceY>0){
        //   console.log('往下滑动')
        // } else{
        //   console.log('点击未滑动')
        // }
        
      }
    }
  }
</script>

<style lang="scss" scoped>
  .nav {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 100;
    width: 100%;
    height:  2.1rem;
    padding: 0;
    margin: 0;
    z-index: 1010;
  }

  .clearBoth::before,
  .clearBoth::after {
    content: '';
    display: table;
    clear: both;
  }

  .nav-wrap {
    height: 100%;
    max-width: 1280px;
    padding: 0 1.25rem;
    margin: 0 auto;
  }

  
  .nav-left {
    float: left;
    padding-top: .6875rem;

    .nav-logo {
      background-image: url('../../assets/geesunn-logo.png');
      display: inline-block;
      width: 4.4270833333334rem;
      height:  1.0416666666667rem;
      background-size: 100% 100%;
      vertical-align: top;
      text-decoration: none;
    }
  }

  .nav-right{
    float: right;
    font-size: 14px;

    ul::before,
    ul::after {
      content: '';
      display: table;
      clear: both;
    }

    ul.large-screen {
      

      li {
        float: left;
        padding: .9rem 1.1rem;
        position: relative;
        opacity: 1;

        a {
          color: #FFF;
          display: inline-block;
          text-decoration: none;
          font-size: .41666666666667rem;

          -moz-transition: opacity .5s ease; /* Firefox 4 */
          -o-transition: opacity .5s ease; /* Opera */
          -webkit-transition: opacity .5s ease; /* Safari 和 Chrome */
          transition: opacity .5s ease;
        }

        span {
          display: block;
          border-top: 2px solid transparent;
          border-bottom: 2px solid #FFF;
          border-radius: 3px;
          margin-top: .15rem;

          transform: scale(0,1);
          transform: scale(0,1);
          -ms-transform: scale(0,1); 	/* IE 9 */
          -moz-transform: scale(0,1); 	/* Firefox */
          -webkit-transform: scale(0,1); /* Safari 和 Chrome */
          -o-transform: scale(0,1);

          -moz-transition: transform .5s ease; /* Firefox 4 */
          -o-transition: transform .5s ease; /* Opera */
          -webkit-transition: transform .5s ease; /* Safari 和 Chrome */
          transition: transform .5s ease;
        }


        .two-links {
          position: absolute;
          left: 0;
          top: 2.2rem;

          height: 0;
          overflow: hidden;
          
          transition: height .5s ease;
          -moz-transition: height .5s ease;
          -webkit-transition: height .5s ease;
          -o-transition: height .5s ease;
          
          .two-links-wrap {
            background: #FFF;
            border-radius: 5px;
            position: relative;
            padding: .7rem .5rem;
            margin-top: 5px;

            &::before {
              content: '';
              position: absolute;
              left: 1.5rem;
              top: -5px;
              border-top: none;
              border-bottom: 5px solid #FFF;
              border-left: 5px solid transparent;
              border-right: 5px solid transparent;
            }

            a {
              display: block;
              color: #333;
              display: block;
              width: 5rem;
              font-size: .4375rem;
              padding: .1rem 0;
              text-decoration: none;
            }

            a:hover {
              color: #0DB8FF;
            }
          }
        }
      }

      li:hover {
        span {
          transform: scale(1,1);
          transform: scale(1,1);
          -ms-transform: scale(1,1); 	/* IE 9 */
          -moz-transform: scale(1,1); 	/* Firefox */
          -webkit-transform: scale(1,1); /* Safari 和 Chrome */
          -o-transform: scale(1,1);

          transition: transform .5s ease;
          -moz-transition: transform .5s ease; /* Firefox 4 */
          -webkit-transition: transform .5s ease; /* Safari 和 Chrome */
          -o-transition: transform .5s ease; /* Opera */
        }

        .two-links {
          transition: height .5s ease;
          -moz-transition: height .5s ease;
          -webkit-transition: height .5s ease;
          -o-transition: height .5s ease;
        }
      }

      li.noChecked {
        a {
          opacity: .5;
          transition: opacity .5s ease;
          -moz-transition: opacity .5s ease; /* Firefox 4 */
          -webkit-transition: opacity .5s ease; /* Safari 和 Chrome */
          -o-transition: opacity .5s ease; /* Opera */
        }
      }

    }

    .nav-cont-out {
      display: block;
      margin: .8rem .6rem;
      height: 1.2rem;
      width: 1.2rem;
      line-height: 1.2rem;
      text-align: center;
      cursor: pointer;
      position: relative;

      span {
        display: block;
        position: relative;
        // border-top: 2px solid  #FFF;
        background: #FFF;
        width: 1.2rem;
        height: 2px;
        margin-bottom: .33rem;

        transform-origin: 1.2rem;
        -ms-transform-origin: 1.2rem;
        -moz-transform-origin: 1.2rem;
        -webkit-transform-origin: 1.2rem;
        -o-transform-origin: 1.2rem;
        

        transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
        -moz-transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
        -webkit-transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
        -o-transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
      }

      .middle {
        transform: rotate(0);
        -ms-transform: rotate(0);
        -moz-transform: rotate(0);
        -webkit-transform: rotate(0);
        -o-transform: rotate(0);

        transition: width .5s ease;
        -moz-transition: width .5s ease;
        -webkit-transition: width .5s ease;
        -o-transition: width .5s ease;
      }

      .bottom {
        margin-bottom: 0;
      }


      &.close {

        span {
          opacity: 1;
          transform: rotate(45deg);
          -ms-transform: rotate(45deg);
          -moz-transform: rotate(45deg);
          -webkit-transform: rotate(45deg);
          -o-transform: rotate(45deg);

          transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
          -moz-transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
          -webkit-transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
          -o-transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
        }

        .top {
          opacity: 1;
          transform: rotate(-45deg);
          -ms-transform: rotate(-45deg);
          -moz-transform: rotate(-45deg);
          -webkit-transform: rotate(-45deg);
          -o-transform: rotate(-45deg);

          // transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
          // -moz-transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
          // -webkit-transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
          // -o-transition: background .5s ease,opacity .5s ease,transform .5s ease, width .5s ease;
        }

        .middle {
          width: 0;
          opacity: 1;
          transform: rotate(0);
          -ms-transform: rotate(0);
          -moz-transform: rotate(0);
          -webkit-transform: rotate(0);
          -o-transform: rotate(0);


          transition: width .5s ease;
          -moz-transition: width .5s ease;
          -webkit-transition: width .5s ease;
          -o-transition: width .5s ease;
        }
      }

    }

    .small-screen {
      display: none;
    }
  }
  .large-screen {
    display: block;
  }

  .small-screen {
    display: none;
  }

  // 是否在顶部
  .is-top {
    // box-shadow: 0 0 0 rgba(0, 0, 0, 0.2);
    // color: #FFF;

    // transition: box-shadow 1s ease, background  1s ease, color  1s ease;
    // -ms-transition: box-shadow 1s ease, background  1s ease, color  1s ease;
    // -moz-transition: box-shadow 1s ease, background  1s ease, color  1s ease; /* Firefox 4 */
    // -webkit-transition: box-shadow 1s ease, background  1s ease, color  1s ease;/* Safari and Chrome */
    // -o-transition: box-shadow 1s ease, background  1s ease, color  1s ease; /* Opera */

    // .nav-logo {
    //   background-image: url('../../assets/geesunn-logo.png');
    // }

    // .nav-right {
    //   ul.large-screen {
    //     li {
    //       a {
    //         color: #FFF;
    //       }
    //     }
    //   }
    // }
  }

  .no-top {
    // background: #FFF;
    // // color: #000;
    // box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
    // transition: background 1s ease, color  1s ease;
    // -moz-transition: background 1s ease, color  1s ease; /* Firefox 4 */
    // -webkit-transition: background 1s ease, color  1s ease; /* Safari and Chrome */
    // -o-transition: background 1s ease, color  1s ease; /* Opera */

    // .nav-logo {
    //   background-image: url('../../assets/geesunn-logo.png');
    // }

    // .nav-right {
    //   ul.large-screen {
    //     li {
    //       a {
    //         // color: #000;
    //       }
    //     }
    //   }
    // }
  }

  .small-screen-content {
    display: none;
  }
  

  @media (max-width: 750px) {

    .nav {

      height: 2.5rem;
      

      .nav-left {
        float: left;
        padding-top: .6rem;
  
        .nav-logo {
          width: 5.525rem;
          height: 1.3rem;
        }
      }
      .nav-wrap {
        padding: 0;
        padding-left: .5rem;
      }
  
      .large-screen {
        display: none ;
      }
  
      .small-screen {
        display: block;
      }

      .small-screen-content {
        display: block;
        position: relative;

        >div {
          position: fixed;
          top: 2.5rem;
          // top: 0;
          // height: 100%;
          right: 0;
          width: 100%;
          // position: relative;
        }


        ul.parent-ul {
          padding-top: .8rem;
          position: relative;

          li {
            
            
            div {
              line-height: 54px;
              
              border-bottom: 1px solid #323232; 
              -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
              position: relative;

              &::after{
                content: '';
                display: table;
                clear: both;
              }

              a {
                display: block;
                height: 100%;
                line-height: 54px;
                font-size: 1rem;
                color: #FFF;
                text-decoration: none;
                padding-left: 20px;
              }

              a:hover {
                opacity: .3;
              }

              a[href='javascript:void(0)']:hover {
                opacity: 1;
              }

              span {
                // float: right;
                position: absolute;
                color: #FFF;
                right: 0;
                top: 0;

                display: inline-block;
                line-height: 54px;
                font-size: 1.5rem;
                font-weight: lighter;
                width: 43px;
                text-align: center;

              }
            }

            ul {
              background: #272727;
              overflow: hidden;

              transform: scale(1,0);
              -ms-transform: scale(1,0); 	/* IE 9 */
              -moz-transform: scale(1,0); 	/* Firefox */
              -webkit-transform: scale(1,0); /* Safari 和 Chrome */
              -o-transform: scale(1,0); 

              transform-origin: top;
              -ms-transform-origin: top;
              -moz-transform-origin: top;
              -webkit-transform-origin: top;
              -o-transform-origin: top;

              transition: transform .5s ease, height .5s ease;
              -moz-transition: transform .5s ease height.5s ease; /* Firefox 4 */
              -webkit-transition: transform .5s ease, height .5s ease; /* Safari 和 Chrome */
              -o-transition: transform .5s ease height .5s ease; /* Opera */

              a {
                padding-left: 30px;
              }
            }
          }

          li.active {
            ul {
              transform: scale(1,1);
              -ms-transform: scale(1,1); 	/* IE 9 */
              -moz-transform: scale(1,1); 	/* Firefox */
              -webkit-transform: scale(1,1); /* Safari 和 Chrome */
              -o-transform: scale(1,1); 

              transform-origin: top;
              -ms-transform-origin: top;
              -moz-transform-origin: top;
              -webkit-transform-origin: top;
              -o-transform-origin: top;

              transition: transform .5s ease, height .5s ease;
              -moz-transition: transform .5s ease height.5s ease; /* Firefox 4 */
              -webkit-transition: transform .5s ease, height .5s ease; /* Safari 和 Chrome */
              -o-transition: transform .5s ease height .5s ease; /* Opera */
            }
          }


          
        }

        
        ul.small-screen-nav-in {

          height: 0 !important;
          overflow: hidden;

          background: transparent;

          transition: height .5s ease, background 1s ease;
          -moz-transition: height .5s ease, background 1s ease; /* Firefox 4 */
          -webkit-transition: height .5s ease, background 1s ease; /* Safari 和 Chrome */
          -o-transition: height .5s ease, background 1s ease; /* Opera */

          li:nth-child(1) {
            opacity: 0;
            transform: translateY(-10px);
            -webkit-transform:  translateY(-10px);
            -ms-transform: translateY(-10px);
            -moz-transform: translateY(-10px);
            -o-transform: translateY(-10px);


            transition: opacity .35s ease,  transform 0.35s ease;
            -moz-transition: opacity .35s ease,  transform 0.35s ease;
            -webkit-transition: opacity .35s ease,  transform 0.35s ease;
            -o-transition: opacity .35s ease,  transform 0.35s ease;
          }

          li:nth-child(2) {
            opacity: 0;
            transform: translateY(-20px);
            -webkit-transform:  translateY(-20px);
            -ms-transform: translateY(-20px);
            -moz-transform: translateY(-20px);
            -o-transform: translateY(-20px);


            transition: opacity .35s ease,  transform 0.35s ease;
            -moz-transition: opacity .35s ease,  transform 0.35s ease;
            -webkit-transition: opacity .35s ease,  transform 0.35s ease;
            -o-transition: opacity .35s ease,  transform 0.35s ease;
          }

          li:nth-child(3) {
            opacity: 0;
            transform: translateY(-30px);
            -webkit-transform:  translateY(-30px);
            -ms-transform: translateY(-30px);
            -moz-transform: translateY(-30px);
            -o-transform: translateY(-30px);


            transition: opacity .35s ease,  transform 0.35s ease;
            -moz-transition: opacity .35s ease,  transform 0.35s ease;
            -webkit-transition: opacity .35s ease,  transform 0.35s ease;
            -o-transition: opacity .35s ease,  transform 0.35s ease;
          }

          li:nth-child(4) {
            opacity: 0;
            transform: translateY(-40px);
            -webkit-transform:  translateY(-40px);
            -ms-transform: translateY(-40px);
            -moz-transform: translateY(-40px);
            -o-transform: translateY(-40px);


            transition: opacity .35s ease,  transform 0.35s ease;
            -moz-transition: opacity .35s ease,  transform 0.35s ease;
            -webkit-transition: opacity .35s ease,  transform 0.35s ease;
            -o-transition: opacity .35s ease,  transform 0.35s ease;
          }

          li:nth-child(5) {
            opacity: 0;
            transform: translateY(-50px);
            -webkit-transform:  translateY(-50px);
            -ms-transform: translateY(-50px);
            -moz-transform: translateY(-50px);
            -o-transform: translateY(-50px);


            transition: opacity .35s ease,  transform 0.35s ease;
            -moz-transition: opacity .35s ease,  transform 0.35s ease;
            -webkit-transition: opacity .35s ease,  transform 0.35s ease;
            -o-transition: opacity .35s ease,  transform 0.35s ease;
          }
        }

        ul.small-screen-nav-out {

          background: #000;
          height: 1200px;
          overflow: hidden;

          transition: height .5s ease, background 1s ease;
          -moz-transition: height .5s ease, background 1s ease; /* Firefox 4 */
          -webkit-transition: height .5s ease, background 1s ease; /* Safari 和 Chrome */
          -o-transition: height .5s ease, background 1s ease; /* Opera */

          li {
            opacity: 1;

            transform: translateY(0);
            -webkit-transform:  translateY(0);
            -ms-transform: translateY(0);
            -moz-transform: translateY(0);
            -o-transform: translateY(0);

            transition: opacity .35s ease, transform 0.35s ease;
            -moz-transition: opacity .35s ease, transform 0.35s ease;
            -webkit-transition: opacity .35s ease, transform 0.35s ease;
            -o-transition: opacity .35s ease, transform 0.35s ease;
          }

          li:nth-child(1) {
            transition-delay: 100ms;
            -moz-transition-delay: 100ms; /* Firefox 4 */
            -webkit-transition-delay: 100ms; /* Safari 和 Chrome */
            -o-transition-delay: 100ms; /* Opera */
          }

          li:nth-child(2) {
            transition-delay: 150ms;
            -moz-transition-delay: 150ms; /* Firefox 4 */
            -webkit-transition-delay: 150ms; /* Safari 和 Chrome */
            -o-transition-delay: 150ms; /* Opera */
          }

          li:nth-child(3) {
            transition-delay: 200ms;
            -moz-transition-delay: 200ms; /* Firefox 4 */
            -webkit-transition-delay: 200ms; /* Safari 和 Chrome */
            -o-transition-delay: 200ms; /* Opera */
          }

          li:nth-child(4) {
            transition-delay: 250ms;
            -moz-transition-delay: 250ms; /* Firefox 4 */
            -webkit-transition-delay: 250ms; /* Safari 和 Chrome */
            -o-transition-delay: 250ms; /* Opera */
          }

          li:nth-child(5) {
            transition-delay: 300ms;
            -moz-transition-delay: 300ms; /* Firefox 4 */
            -webkit-transition-delay: 300ms; /* Safari 和 Chrome */
            -o-transition-delay: 300ms; /* Opera */
          }

          
        }
        
      }
    }

    .is-small-screen-nav-out {
      background: #000;

      transition:  background 1s ease;
      -moz-transition: background 1s ease;
      -webkit-transition: background 1s ease;
      -o-transition: background 1s ease;
      
    }

    .no-small-screen-nav-out {
      background: transparent;

      transition:  background 1s ease;
      -moz-transition: background 1s ease;
      -webkit-transition: background 1s ease;
      -o-transition: background 1s ease;
      
    }
  }

</style>
