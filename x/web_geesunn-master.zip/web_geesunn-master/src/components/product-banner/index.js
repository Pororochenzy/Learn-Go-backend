import productBanner from './productBanner'

productBanner.install = vue => {
  vue.component(productBanner.name, productBanner)
}

export default productBanner