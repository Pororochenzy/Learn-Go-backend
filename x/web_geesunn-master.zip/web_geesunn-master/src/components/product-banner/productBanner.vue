<template>
  <div class="wrap">
    <g-nav></g-nav>
    <div class="banner-content">
      <div class="banner-left">
        <h2>{{bannerData.bTit}}</h2>
        <p>{{bannerData.sTit}}</p>
      </div>
      <div class="banner-right">
        <img :src="bannerData.image" >
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'productBanner',
    data () {
      return {}
    },
    props: [
      'bannerData'
    ],
    components: {

    }
  }
</script>

<style lang="scss" scoped>
  .wrap {
    padding-top:2.0833333333333rem;
    background: url('../../assets/product-banner-bak.png');
    height: 16rem;

    
    .banner-content {
      padding: 0 0 0 1.25rem;
      max-width: 1200px;
      margin: 0 auto;

      &::before,
      &::after {
        content: '';
        display: table;
        clear: both;
      }

      .banner-left{
        float: left;
        width: 50%;

        h2 {
          color: #FFF;
          font-size: 1.125rem;
          padding-left: .5rem;
          margin-top: 3.3rem;
        }

        p {
          color: #FFF;
          font-size: 14px;
          padding-left: .5rem;
          margin-top: 1rem;
        }

        @media (max-width: 1200px) {

          h2{
            padding-left: 1.75rem;
          }
          p{
            padding-left: 1.75rem;
          }
        }

        @media (max-width: 800px) {
          p{
            font-size: 12px;
          }
        }
      }


      .banner-right{
        float: left;
        width: 50%;
        text-align: center;

        img {
          width: 15rem;
          margin-top: 0;
        }
      }
    }
  }

  @media (max-width: 750px) {
    .wrap {
    height: 29rem;

      .banner-content {
        padding: 1.5rem;

        .banner-left {
          width: 100%;

          h2 {
            padding-left: 0;
            font-size: 18px;
            text-align: center;
            margin-top: 1.5rem;
          }

          p {
            padding-left: 0;
            font-size: 14px;
            text-align: center;
            margin-top: .5rem;
          }
        }

        .banner-right {
          width: 100%;

          img {
            height: 14rem;
            width: auto;
            margin-top: 2.5rem;
          }
        }
      }
    }
  }
</style>
