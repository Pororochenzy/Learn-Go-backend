<template>
  <div class="contact">
    <div class="wrap" @touchstart="contInTouch($event)" @mouseover="contInMousemove($event)" @mouseout="contInMouseout($event)">
      <div class="contact-icon-bg"></div>
      <div class="contact-icon" :class="contData.status ? 'active' : ''">
        <span v-html="contData.hoverText"></span>
        <ul>
          <li v-for="li in contData.lis" @mouseover="checkedliMousemove($event, li.index)" @mouseout="checkedliMouseout($event, li.index)" @touchstart="checkedliTouch($event, li.index)" :class="li.status ? 'on' : ''">
            <a :target="li.index === 0 ? '_blank' : ''" :href="li.link && li.link !== '' ? li.link : 'javascript:void(0)'"><span :style="{backgroundImage: !li.status ?  li.bakb : li.bakw}"></span>{{li.name}}</a>
          </li>
        </ul>
      </div>
      
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'GContact',
    data () {
      return {
        contData: {
          status: false,
          hoverText: '联系<br>我们',
          lis: [
            {
              status: false,
              index: 0,
              bakb: `url(${require('../../assets/contact-cont-li-icon-01.png')})`,
              bakw: `url(${require('../../assets/contact-cont-li-icon-01-white.png')})`,
              name: '在线资料',
              link: 'static/产品文档.pdf'
            },
            // {
            //   status: false,
            //   bak: require('../../assets/contact-cont-li-icon-03.png'),
            //   name: '在线留言'
            // },
            // {
            //   status: false,
            //   index: 1,
            //   bakb: `url(${require('../../assets/contact-cont-li-icon-04.png')})`,
            //   bakw: `url(${require('../../assets/contact-cont-li-icon-04-white.png')})`,
            //   name: '在线咨询',
            //   link: ''
            // },
            {
              status: false,
              index: 1,
              bakb: `url(${require('../../assets/contact-cont-li-icon-02.png')})`,
              bakw: `url(${require('../../assets/contact-cont-li-icon-02-white.png')})`,
              name: '0755-86521101',
              link: 'tel:0755-86521101'
            }
          ]
        }
      }
    },
    components: {},
    mounted () {
      let self = this
      // document.addEventListener('click', function(event) {
      //   self.contData.status = false
      //   for(let item in self.contData.lis) {
      //     self.contData.lis[item].status = false
      //   }
      // })

      document.addEventListener('touchstart', function(event) {
        self.contData.status = false
        if(!self.IsPC()) {
          for(let item in self.contData.lis) {
            self.contData.lis[item].status = false
          }
        }
      })
    },
    methods: {

      contInTouch(event) {
        let self = this
        if(!self.IsPC()) {
          self.contData.status = !self.contData.status
          self.eventStopPropagation(event)
        }
      },


      contInMousemove(event) {
        let self = this
        if(self.IsPC()) {
          self.contData.status = true
          self.eventStopPropagation(event)
        }
      },

      contInMouseout(event) {
        let self = this
        if(self.IsPC()) {
          self.contData.status = false
          self.eventStopPropagation(event)
        }
      },

      checkedliMousemove(event, index) {
        let self = this
        
        if(self.IsPC()) {
          for(let item in self.contData.lis) {
            self.contData.lis[item].status = false
          }
          self.contData.lis[index].status = true
        }
      },

      checkedliMouseout(event, index) {
        let self = this
        if(self.IsPC()) {
          self.contData.lis[index].status = false
        }
      },

      checkedliTouch(event, index) {
        let self = this
        if(!self.IsPC()) {
          for(let item in self.contData.lis) {
            self.contData.lis[item].status = false
          }

          self.contData.lis[index].status = true
          self.eventStopPropagation(event)
        }
      },

      // 禁止冒泡
      eventPreventDefault(event) {
        if (event.cancelable) {
          if (!event.defaultPrevented) {
            event.preventDefault()
          }
        }
      },

      // 禁止冒泡
      eventStopPropagation(event) {
        if (event.cancelable) {
          if (!event.defaultPrevented) {
            event.stopPropagation()
          }
        }
      },


      IsPC() {
        var userAgentInfo = navigator.userAgent
        var Agents = [
          'Android',
          'iPhone',
          'SymbianOS',
          'Windows Phone',
          'iPad',
          'iPod'
        ]
        var flag = true
        for (var v = 0; v < Agents.length; v++) {
          if (userAgentInfo.indexOf(Agents[v]) > 0) {
            flag = false
            break
          }
        }
        return flag
      }


    }
  }
</script>

<style lang="scss" scoped>
  .contact {
    position: fixed;
    bottom: 5rem;
    right: 1rem;
    height: 50px;
    width: 50px;
    z-index: 1000;
    // position: relative

    .wrap {
      position: relative;
      -webkit-tap-highlight-color: rgba(0, 0, 0, 0);

      .contact-icon {
        cursor: pointer;
        position: absolute;
        top: 0;
        left: 0;
        width: 50px;
        height: 50px;
        border-radius: 25px;
        border: 1px solid #0DB8FF;
        background-color: #FFF;
        background-image: url('../../assets/contact-icon-bak.png');
        background-repeat: no-repeat;
        background-position: center center;
        z-index: 1000;
        color: #FFF;
        text-align: center;
        display: table;

        >span {
          display: none;
          vertical-align: middle;
          border-radius: 50%;
          font-size: 12px;
        }

        ul {
          // padding: 5px 10px;
          border: 1px solid #0DB8FF;
          border-radius: 5px;
          background: #FFF;
          position: absolute;
          right: -50px;
          bottom: -15px;
          margin-bottom: 15px;
          width: 180px;
          opacity: 1;

          transform: scale(0, 0);
          -ms-transform: scale(0, 0); 	/* IE 9 */
          -moz-transform: scale(0, 0); 	/* Firefox */
          -webkit-transform: scale(0, 0); /* Safari 和 Chrome */
          -o-transform: scale(0, 0); 	/* Opera */

          transition: opacity .5s ease, right .5s ease, bottom .5s ease, transform .5s ease;
          -moz-transition: opacity .5s ease, right .5s ease, bottom .5s ease, transform .5s ease; /* Firefox 4 */
          -webkit-transition: opacity .5s ease, right .5s ease, bottom .5s ease, transform .5s ease; /* Safari 和 Chrome */
          -o-transition: opacity .5s ease, right .5s ease, bottom .5s ease, transform .5s ease; /* Opera */

          li {
            // border-bottom: 1px solid #FFF;
            padding: 10px 5px 3px 15px;
            opacity: 1;

            transition: opacity .5s ease;
            -moz-transition: opacity .5s ease; /* Firefox 4 */
            -webkit-transition: opacity .5s ease; /* Safari 和 Chrome */
            -o-transition: opacity .5s ease; /* Opera */

            a {
              display: block;
              text-align: left;
              color: #0DB8FF;
              line-height: 25px;
              text-decoration: none;
              outline: none;
              // padding-bottom: 10px;
              font-size: 14px;
              height: 30px;

              span {
                display: inline-block;
                vertical-align: -5px;
                margin-right: 15px;
                width: 25px;
                height: 25px;
              }
            }

            &.on {
              // border-bottom-color: #0DB8FF;
              background: #0DB8FF;
              a {
                color: #FFF;
              }
            }
          }

          li.no-checked {
            opacity: .5;
            transition: opacity .5s ease;
            -moz-transition: opacity .5s ease; /* Firefox 4 */
            -webkit-transition: opacity .5s ease; /* Safari 和 Chrome */
            -o-transition: opacity .5s ease; /* Opera */

          }
        }

        &.active {
          background: #0DB8FF;

          >span {
            display: table-cell;
          }

          ul {
            right: -5px;
            bottom: 50px;
            opacity: 1;

            transform: scale(1, 1);
            -ms-transform: scale(1, 1); 	/* IE 9 */
            -moz-transform: scale(1, 1); 	/* Firefox */
            -webkit-transform: scale(1, 1); /* Safari 和 Chrome */
            -o-transform: scale(1, 1); 	/* Opera */

            transition: opacity .5s ease, right .5s ease, bottom .5s ease, transform .5s ease;;
            -moz-transition: opacity .5s ease, right .5s ease, bottom .5s ease, transform .5s ease;; /* Firefox 4 */
            -webkit-transition: opacity .5s ease, right .5s ease, bottom .5s ease, transform .5s ease;; /* Safari 和 Chrome */
            -o-transition: opacity .5s ease, right .5s ease, bottom .5s ease, transform .5s ease;; /* Opera */

          }

        }
      }


      .contact-icon-bg {
        background: #0DB8FF;
        border-radius: 50%;
        position: absolute;
        z-index: 9;

        animation: luminescence 1s infinite;
        -moz-animation: luminescence 1s infinite;	/* Firefox */
        -webkit-animation: luminescence 1s infinite;	/* Safari 和 Chrome */
        -o-animation: luminescence 1s infinite;	/* Opera */
      }
    }
  }


  @keyframes luminescence
  {
    from {
      top: 0;
      left: 0;
      height: 50px;
      width: 50px;
      opacity: .1;
    }
    
    to {
      top: -25px;
      left: -25px;
      height: 100px;
      width: 100px;
      opacity: 0;
    }
  }

  @-moz-keyframes luminescence /* Firefox */
  {
    from {
      top: 0;
      left: 0;
      height: 50px;
      width: 50px;
      opacity: .1;
    }
    
    to {
      top: -25px;
      left: -25px;
      height: 100px;
      width: 100px;
      opacity: 0;
    }
  }

  @-webkit-keyframes luminescence /* Safari 和 Chrome */
  {
    from {
      top: 0;
      left: 0;
      height: 50px;
      width: 50px;
      opacity: .1;
    }
    
    to {
      top: -25px;
      left: -25px;
      height: 100px;
      width: 100px;
      opacity: 0;
    }
  }

  @-o-keyframes luminescence /* Opera */
  {
    from {
      top: 0;
      left: 0;
      height: 50px;
      width: 50px;
      opacity: .1;
    }
    
    to {
      top: -25px;
      left: -25px;
      height: 100px;
      width: 100px;
      opacity: 0;
    }
  }

</style>
