import GContact from './GContact'

GContact.install = vue => {
  vue.component(GContact.name, GContact)
}

export default GContact