<template>
  <div class="">
    <swiper :options="swiperOption" ref="mySwiper">
      <!-- slides -->
      <swiper-slide>fafa</swiper-slide>
      <swiper-slide>dfads</swiper-slide>
      <swiper-slide>afdas</swiper-slide>
      <swiper-slide>dad</swiper-slide>
      <swiper-slide>adfadsf</swiper-slide>
      <swiper-slide>dafs</swiper-slide>
      <div class="swiper-pagination" slot="pagination">1</div>  
      <div class="swiper-pagination" slot="pagination">2</div>  
      <div class="swiper-pagination" slot="pagination">3</div>  
      <div class="swiper-pagination" slot="pagination">4</div>  
      <div class="swiper-pagination" slot="pagination">5</div>  
      <div class="swiper-pagination" slot="pagination">6</div>  
    </swiper>
  </div>
</template>

<script type="text/ecmascript-6">
  import { swiper, swiperSlide } from 'vue-awesome-swiper'
  export default {
    name: 'indexSwiper',
    data () {
      return {
        swiperOption: {  
          //是一个组件自有属性，如果notNextTick设置为true，组件则不会通过NextTick来实例化swiper，也就意味着你可以在第一时间获取到swiper对象，假如你需要刚加载遍使用获取swiper对象来做什么事，那么这个属性一定要是true  
          notNextTick: true,  
          pagination: '.swiper-pagination',  
          slidesPerView: 'auto',  
          centeredSlides: true,  
          paginationClickable: true,  
          spaceBetween: 30,
          freeMode : true,
          onSlideChangeEnd: swiper => {  
            //这个位置放swiper的回调方法  
            this.page = swiper.realIndex+1
            this.index = swiper.realIndex
          }  
        }  
      }
    },
    computed: {
      swiper() {  
        return this.$refs.mySwiper.swiper
      } 
    },
    mounted () {
      // this.swiper.slideTo(0, 0, false)
    },
    components: {
      swiper,
      swiperSlide
    }
  }
</script>

<style lang="scss" scoped>

</style>
