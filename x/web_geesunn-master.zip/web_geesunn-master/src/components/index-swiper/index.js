import indexSwiper from './indexSwiper'

indexSwiper.install = vue => {
  vue.component(indexSwiper.name, indexSwiper)
}

export default indexSwiper