<template>
  <div class="wrap">
    <g-nav></g-nav>
    <div class="banner-content">
      <h2>自动化、智能化、全流程</h2>
      <h3>由IT监控、ITIL/ITSM流程组成的一站式综合运维平台</h3>
      <div><span></span></div>
      <p>智象科技作为国内一流的企业级IT产品及技术方案提供商，运用丰富的经验和专业的知识，为用户提供最佳的IT平台和服务，以此提高用户的IT服务质量和可用率，降低成本。</p>
      <div>
        <img src="../../assets/index-banner-content.png" class="banner-content-big-img">
        <img src="../../assets/moveClient-index-banner-content.png" class="banner-content-small-img">
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'fullScreenBanner',
    data () {
      return {
      }
    },
    created () {
    },
    components: {

    }
  }
</script>

<style lang="scss" scoped>

  .wrap {
    background-image: url('../../assets/full-screen-banner-bak.png');
    height: 27.5rem;
    background-size: auto 100%; 
    padding-top:2.0833333333333rem;
    position: relative;

    .banner-content  {
      max-width: 1200px;
      margin: 0 auto;

      div {
        margin: 0 auto;
        width: 85.9375%;

        img {
          display: inline-block;
          margin-top: .5rem;
          width: 100%;
        }

        .banner-content-big-img {
          display: inline;
        }
        .banner-content-small-img {
          display: none;
        }


        span {
          display: block;
          width:  2.84375rem;
          height: 2px;
          background: #0DB8FF;
          margin: 0.625rem auto;

        }
      }

      h2 {
        width: 85.9375%;
        text-align: center;
        color: #FFF;
        font-size: 1rem;
        margin: 0 auto;
        font-weight: normal;
        padding-top: 3rem;
      }

      h3 {
        width: 85.9375%;
        text-align: center;
        color: #FFF;
        margin: 0 auto;
        font-size: .8rem;
        font-weight: normal;
        padding-top: .5rem
      }

      p {
        width: 85.9375%;
        margin: 0 auto;
        text-align: center;
        color: #FFF;
        font-size: .5rem;
        // padding: 1.5rem;
      }
    }


  }

  @media (max-width: 750px) {
    .wrap {
      background-image: url('../../assets/full-screen-banner-bak.png');
      padding-top:2.5rem;

      .banner-content {

        h2 {
          font-size: 18px;
        }

        h3 {
          font-size: 14px;
        }

        p {
          font-size: 12px;
        }
      }
    }
  }

  @media (max-width: 450px) {
    .wrap {

      .banner-content {
        h3 {
          padding-top: 1rem;
        }

        div {

          img {
            margin-top: 1.5rem;
          }

          span {
            margin: 1rem auto;
          }
        }
      }
    }
  }

</style>
