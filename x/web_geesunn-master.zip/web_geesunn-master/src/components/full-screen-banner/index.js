import fullScreenBanner from './fullScreenBanner'

fullScreenBanner.install = vue => {
  vue.component(fullScreenBanner.name, fullScreenBanner)
}

export default fullScreenBanner