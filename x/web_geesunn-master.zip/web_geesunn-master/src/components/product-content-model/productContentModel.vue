<template>
  <div class="model-wrap">
    <div class="large-screen-wrap">
      <div v-for="data in tipsData" class="product-tips">
        <div class="tips-left">
          <div>
            <span>
              <span class="tip-logo">
                <img :src="data.logoB" alt="">
              </span>
              <span class="tip-tit">{{data.tit}}</span>
            </span>
          </div>
        </div>
        <div class="tips-right">
          <div>
            <span>{{data.content}}</span>
          </div>
        </div>
      </div>
    </div>
    <div class="small-screen-wrap">
      <ul class="tips-wrap">
        <li v-for="data in tipsData" :class="{on : data.open}">
          <div class="tip-tit-wrap" @click="switchSmallScreenTips(data.index)">
            <span class="tip-logo" :style="{backgroundImage: data.open ? `url(${data.logoB})` : `url(${data.logoW})`}"></span>
            <span class="tip-tit">{{data.tit}}</span>
            <span class="fa fa-angle-down"></span>
            <span class="fa fa-angle-up" ></span>
          </div>
          <div class="tip-content small-tip-content" :style="{height: data.open ? `${data.realheight}px` : ''}">
            <span :id="`tip-${data.index}`">{{data.content}}</span>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'productContentModel',
    data () {
      return {
        tipsData: {}
      }
    },
    props: [
      'productDataTips'
    ],
    components: {
    },
    created () {
      let self = this
      self.tipsData = self.productDataTips
      
    },
    mounted () {
      let self = this
      for(let item in self.tipsData) {
        if(self.tipsData[item].open === true) {
          self.switchSmallScreenTips(self.tipsData[item].index, 'pageOnload')
        }
      }
    },
    methods: {
      switchSmallScreenTips(index, type) {
        let self = this
        let nowHeight = document.getElementById(`tip-${index}`).clientHeight
        if(nowHeight < 150 ) {
          self.tipsData[index].realheight = 150
        } else {
          self.tipsData[index].realheight = nowHeight
        }
        for(let item in self.tipsData) {
          if(item !== `${index}`) {
            self.tipsData[item].open = false
          }
        }

        if(type && type === 'pageOnload') {
        } else {
          self.tipsData[index].open = !self.tipsData[index].open
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .large-screen-wrap {
    display: block;
    width: 90%;
    margin: 0 auto;

    &::before,
    &::after {
      content: '';
      display: table;
      clear: both;
    }

    .product-tips {
      border: 1px solid #0DB8FF;
      width: 44%;
      margin: 1.5rem 3% 0 3%;
      float: left;
      height: 199px;

      &::before,
      &::after {
        content: '';
        display: table;
        clear: both;
      }

      .tips-left {
        float: left;
        width: 38%;
        height: 100%;

        div {
          width: 100%;
          display: table;
          height: 100%;

          >span {
            display: table-cell;
            vertical-align: middle;

            span {
              display: inline-block;
            }

            span.tip-logo {
              width: 100%;
              text-align: center;

              img {
                width: 65%;
              }

            }
            span.tip-tit {
              width: 100%;
              text-align: center;
              font-size: .6875rem;
              margin-top: .2rem;
            }
          }
        }
        

      }

      .tips-right {
        float: left;
        width: 62%;
        height: 100%;
        div {
          height: 100%;
          display: table;

          span{
            display: table-cell;
            vertical-align: middle;
            font-size: .4375rem;
            padding: .4375rem;
            line-height: 24px;
            text-align:justify;
            word-break : normal;
          }
        }
      }


    }

  }

  .small-screen-wrap {
    display: none;

    .tips-wrap {
    border-bottom: 1px solid #e5e5e5;

      li {
        .tip-tit-wrap {
          border-top: 1px solid #e5e5e5;
          position: relative;
          line-height: 2.8rem;
          -webkit-tap-highlight-color: rgba(0, 0, 0, 0);

          span.tip-logo {
            display: inline-block;
            background-size: 100% 100%;
            width: 2.1621621621622rem;
            height: 1.8378378378378rem;
            vertical-align: middle;
            margin: 0 .3rem 0 .7rem;
          }

          span.tip-tit {
            display: inline-block;
            font-size: 1rem;
            vertical-align: middle;
            height: 1.8378378378378rem;
            line-height: 1.8378378378378rem;
            color: #999999;
          }

          span.fa {
            position: absolute;
            right: .5rem;
            top: 0;
            display: inline-block;
            line-height: 2.8rem;
            font-size: 2rem;
          }

          span.fa-angle-down {
            color: #c8c8c8;
            display: inline-block;
          }
          span.fa-angle-up {
            color: #0DB8FF;
            display: none;
          }
        }

        .tip-content {
          background: #f5f5f6;
          color: #222222;
          font-size: .9rem;
          height: 0;
          overflow: hidden;
          border-top: 1px solid #e5e5e5;


          transform-origin: top;
          -ms-transform-origin: top;
          -moz-transform-origin: top;
          -webkit-transform-origin: top;
          -o-transform-origin: top;

          transition: transform .5s ease, height .5s ease,;
          -moz-transition: transform .5s ease height.5s ease,; /* Firefox 4 */
          -webkit-transition: transform .5s ease, height .5s ease,; /* Safari 和 Chrome */
          -o-transition: transform .5s ease height .5s ease; /* Opera */

          span {
            display: block;
            padding: 1.5rem 1.5rem;
          }
        }
      }

      .on {
        .tip-tit-wrap {
          .tip-tit {
            color: #0DB8FF;
          }

          span.fa-angle-down {
            display: none;
          }
          span.fa-angle-up {
            display: inline-block;
          }
        }

        .tip-content {

          // height: 15rem;

          transform: scale(1,1);
          -ms-transform: scale(1,1); 	/* IE 9 */
          -moz-transform: scale(1,1); 	/* Firefox */
          -webkit-transform: scale(1,1); /* Safari 和 Chrome */
          -o-transform: scale(1,1); 

          transform-origin: top;
          -ms-transform-origin: top;
          -moz-transform-origin: top;
          -webkit-transform-origin: top;
          -o-transform-origin: top;

          transition: transform .5s ease, height .5s ease,;
          -moz-transition: transform .5s ease height .5s ease,; /* Firefox 4 */
          -webkit-transition: transform .5s ease, height .5s ease,; /* Safari 和 Chrome */
          -o-transition: transform .5s ease height .5s ease; /* Opera */

          // transition: height .5s ease;
          // -moz-transition: height .5s ease;
          // -webkit-transition: height .5s ease;
          // -o-transition: height .5s ease;
        }
      }
    }
  }

  @media (max-width: 750px) {
    .large-screen-wrap {
      display: none;
    }

    .small-screen-wrap {
      display: block;
    }
  }

</style>
