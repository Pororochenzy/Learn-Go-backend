import productContentModel from './productContentModel'

productContentModel.install = vue => {
  vue.component(productContentModel.name, productContentModel)
}

export default productContentModel