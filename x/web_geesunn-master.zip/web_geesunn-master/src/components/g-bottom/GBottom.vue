<template>
  <div class="bottom-wrap">
    <div class="content-wrap">
      <div class="bottom-nav">
        <ul>
          <li v-for="data in bottomData.nav">
            <h2>{{data.name}}</h2>
            <hr>
            <a v-for="link in data.links" :href="link.link === '' ? 'javascript:void(0)' : link.link">{{link.name}}</a>
          </li>
        </ul>
      </div>
      <div class="bottom-contact-info">
        <div class="contact-left">
          <img class="logo" src="../../assets/geesunn-logo.png">
          <p class="phone">联系电话：0755-86521101<br><span style="margin-left: 2.5rem;">18988791008</span></p>
          <p class="adress">地址：深圳市南山区科技园高新技术产业园R3-B栋5楼508</p>
        </div>
        <div class="contact-right">
          <img class="qrCode" src="../../assets/geesunn-qrCode.png">
        </div>
      </div>
    </div>
    <div class="web-info">Copyright@2016 深圳市智象科技有限公司 | <a href="http://www.miitbeian.gov.cn/" target="_blank">粤ICP备16105870号-1</a></div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'GBottom',
    data () {
      return {
        bottomData: {
          nav: [
            {
              name: '产品服务',
              links: [
                {
                  name: '综合监控运维平台',
                  link: 'product-detail?name=zhjkywpt'
                },
                {
                  name: 'IDC管理控制平台',
                  link: 'product-detail?name=IDCglkzpt'
                },
                {
                  name: '智象数据平台',
                  link: 'product-detail?name=zxsjpt'
                },
                {
                  name: '智象CMDB',
                  link: 'product-detail?name=zxCMDB'
                }
              ]
            },
            {
              name: '解决方案',
              links: [
                {
                  name: '智能监控解决方案',
                  link: ''
                },
                {
                  name: '综合运维解决方案',
                  link: ''
                },
                {
                  name: '数据备份解决方案',
                  link: ''
                },
                {
                  name: 'CMDB管理解决方案',
                  link: ''
                }
              ]
            },
            {
              name: '技术支持',
              links: [
                {
                  name: '下载中心',
                  link: ''
                },
                {
                  name: '常见问题',
                  link: ''
                },
                {
                  name: '使用帮助',
                  link: ''
                }
              ]
            },
            {
              name: '关于我们',
              links: [
                {
                  name: '关于智象',
                  link: ''
                },
                {
                  name: '联系我们',
                  link: 'contact-us'
                }
              ]
            }
          ]
        }
      }
    },
    components: {

    }
  }
</script>

<style lang="scss" scoped>
  .bottom-wrap {
    background-image: url('../../assets/bottom-bak.png');
    background-position: center center;
    background-size: auto 100%;
    height: 10rem;
    position: relative;


    .content-wrap {
      max-width: 1280px;
      padding: 1.5rem 1.25rem 1rem 2rem;
      margin: 0 auto;

      &::before,
      &::after {
        content: '';
        display: table;
        clear: both;
      }

      .bottom-nav {
        width: 55%;
        float: left;
        color: #FFF;


        ul {

          width: 100%;

          &::before,
          &::after {
            content: '';
            display: table;
            clear: both;
          }

          li {
            float: left;
            width: 27%;

            h2 {
              font-size: .5rem;
              font-weight: normal;
            }

            hr {
              border: none;
              border-top: 1px solid #FFF;
              width: 25%;
              margin: .75rem 0;
            }

            a {
              display: block;
              color: #FFF;
              text-decoration: none;
              line-height: 1rem;
              font-size: .4375rem;
              opacity: 1;

              transition: opacity .5s ease;
              -moz-transition: opacity .5s ease; /* Firefox 4 */
              -webkit-transition: opacity .5s ease; /* Safari 和 Chrome */
              -o-transition: opacity .5s ease; /* Opera */
            }

            a:hover {
              // color: #999999;
              opacity: .5;
              transition: opacity .5s ease;
              -moz-transition: opacity .5s ease; /* Firefox 4 */
              -webkit-transition: opacity .5s ease; /* Safari 和 Chrome */
              -o-transition: opacity .5s ease; /* Opera */
            }
          }

          li:nth-child(3) {
            width: 23%;
          }

          li:nth-child(4) {
            width: 23%;
          }

          @media (max-width: 1000px) {
            li {
              width: 33%;
            }

            li:nth-child(4) {
              display: none;
            }
          }
        }



      }

      .bottom-contact-info {
        width: 45%;
        float: left;
        color: #FFF;

        &::before,
        &::after {
          content: '';
          display: table;
          clear: both;
        }

        div {
          width: 50%;
          float: left;
          padding-left: 4%;


          img.logo {
            height: 1.25rem;
          }

          p.phone {
            font-size: .5rem;
            // line-height: 2rem;
            padding: .55rem 0 .45rem 0;

          }

          p.adress {
            font-size: .4375rem;
          }

          img.qrCode {
            height: 4.5rem;
          }
        }
      }

      @media (max-width: 750px) {
        .bottom-nav {
          display: none;
        }
        .bottom-contact-info {
          width: 100%;

          div.contact-left {
            width: 70%;
            // border:1px solid #000;

            img {
              // border: 1px solid #000;
              vertical-align: top;
              display: block;
            }

            p.phone {
              font-size: 12px;
              // border: 1px solid #000;
              padding: .8rem 0 .2rem 0;
            }

            p.adress {
              font-size: 12px;
            }
          }

          @media (max-width: 450px) {
            div.contact-left {
              padding-left: 0;
            }

            div.contact-rgiht {
              padding-right: 0;
            }
          }

          div.contact-right {
            width: 30%;
            text-align: right;
            padding-right: 4%;
            // border: 1px solid #000;

            img.qrCode {
              height: 4rem;
              // margin-top: .5rem;
              // border: 1px solid #000;
              vertical-align: top;
            }
          }
        }
      }

      
    }

    .web-info {
      width: 100%;
      line-height: 1rem;
      position: absolute;
      margin-bottom: .5rem;
      bottom: 0;
      font-size: 12px;
      text-align: center;
      color: #FFF;

      a {
        color: #FFF;
        text-decoration: none;
      }

      a:hover {
        text-decoration: underline;
      }
    }

    @media (max-width: 750px) {
      .web-info {
        font-size: .5rem;
      }
    }
  }

  @media (max-width: 750px) {
    .bottom-wrap {
      padding-top: .5rem;
      .content-wrap {
        // padding: 0 1.25rem 1rem 1.25rem;

        .bottom-contact-info {

          .contact-left {

            p.phone {
              line-height: 1rem;
            }
          }
        }
      }
    }
  }

  @media (min-width: 1000px) {
    .bottom-wrap {
      background-size: 100% 100%;
    }
  }
</style>
