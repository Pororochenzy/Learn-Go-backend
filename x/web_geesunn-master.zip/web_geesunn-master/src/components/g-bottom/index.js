import GBottom from './GBottom'

GBottom.install = vue => {
  vue.component(GBottom.name, GBottom)
}

export default GBottom