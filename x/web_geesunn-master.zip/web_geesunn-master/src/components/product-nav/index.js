import productNav from './productNav'

productNav.install = vue => {
  vue.component(productNav.name, productNav)
}

export default productNav