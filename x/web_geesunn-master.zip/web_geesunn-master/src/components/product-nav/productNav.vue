<template>
  <div class="nav-bak">
    <div class="nav-wrap">
      <div>
        <a v-for="data in productLinks.value" :href="`/product-detail?name=${data.link}`" :class="{on: data.link === onMenu }">{{data.name}}</a>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'productNav',
    data () {
      return {
        productLinks: {
          value: []
        }
      }
    },
    props: [
      'productData',
      'onMenu'
    ],
    created () {
      let self = this
      console.log(self.productData[self.onMenu].name)
      console.log(self.onMenu)
      let productLinks = []
      for(let item in self.productData) {
        productLinks.push({name: self.productData[item].name, link: self.productData[item].Ename})
      }
      self.productLinks.value = productLinks
    },
    components: {

    }
  }
</script>

<style lang="scss" scoped>
  .nav-bak {
    background: #107fd9;
    color: #FFF;
  }

  .nav-wrap {
    max-width: 1280px;
    padding: 0 1.25rem;
    margin: 0 auto;
    font-size: 0;

    div {
      border-left: 1px solid #3493f1; 
    }

    a {
      display: inline-block;
      width: 25%;
      color: #FFF;
      font-size: .5625rem;
      text-decoration: none;
      text-align: center;
      // line-height: 1.875rem;
      padding: .65625rem 0;
      // line-height: 60px;
      border-right: 1px solid #3493f1;
    }

    a:hover {
      background: #358bee;
    }

    a.on {
      background: #358bee;
    }
  }

  @media (max-width: 750px) {
    .nav-bak {
      display: none;
    }
  }
</style>
