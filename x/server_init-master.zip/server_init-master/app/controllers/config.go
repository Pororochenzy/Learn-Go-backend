package controllers

import (
	"encoding/json"
	"fmt"
	gs_define "geesunn.com/define"
	gs_exec "geesunn.com/easyexec"
	"github.com/Unknwon/goconfig"
	"github.com/revel/revel"
	"io/ioutil"
	"os"
	"path/filepath"
	"gsn/server_init/define"
	"gsn/server_init/global"
	"gsn/server_init/logic"
	"strings"
)

var (
	NETWORK_SCRIPTS_PATH = "/etc/sysconfig/network-scripts/"
)

type Config struct {
	GrantBase
}

// 获取本地网卡列表
func networkCardList() ([]map[string]string, error) {

	cardList := []map[string]string{}

	err := filepath.Walk(NETWORK_SCRIPTS_PATH, func(path string, f os.FileInfo, err error) error {
		if f == nil {
			return err
		}
		if strings.HasPrefix(f.Name(), "ifcfg-") {
			tmpArr := strings.Split(f.Name(), "ifcfg-")
			if len(tmpArr) > 0 {
				cardName := tmpArr[len(tmpArr)-1]
				// 获取文件信息
				info, err := ioutil.ReadFile(filepath.Join(NETWORK_SCRIPTS_PATH, f.Name()))
				if err != nil {
					global.Logger.Error(err.Error())
					return err
				}
				c, _ := goconfig.LoadFromData(info)
				ipaddr := strings.Trim(c.MustValue("", "IPADDR"), `"`)
				netmask := strings.Trim(c.MustValue("", "NETMASK"), `"`)
				gateway := strings.Trim(c.MustValue("", "GATEWAY"), `"`)
				dns := strings.Trim(c.MustValue("", "DNS1"), `"`)
				cardList = append(cardList, map[string]string{"name": cardName,
					"ipaddr": ipaddr, "netmask": netmask, "gateway": gateway, "dns": dns})
			}
		}
		return nil
	})

	return cardList, err
}

// 查看当前配置
func (p *Config) NetworkInfo() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	info, err := gs_exec.Command("/sbin/ifconfig")
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}
	global.Logger.Info(info)
	return p.ResponseSuccessOut(map[string]interface{}{"ifconfig": info})
}

// 查看网卡列表
func (p *Config) NetworkCardList() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	cardList, err := networkCardList()
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}

	eth0, eth1 := cardList[0], cardList[1]
	if global.HostType == define.HOST_TYPE_COLLECT {
		return p.ResponseSuccessOut(map[string]interface{}{"list": []map[string]string{eth0}})
	} else {
		return p.ResponseSuccessOut(map[string]interface{}{"list": []map[string]string{eth0, eth1}})
	}
}

type NetworkCardKV struct {
	Key   string `json:"key"`
	Value string `json:"value"`
}

var (
	// 系统脚本允许修改的字段如下： ip, 子网掩码， 网关， dns
	NETWORK_CARD_PROPERTY = []string{"IPADDR", "NETMASK", "GATEWAY", "DNS"}
)

// 修改网卡配置文件
func (p *Config) ResetNetworkCard() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	strParms := map[string]string{
		"name": gs_define.PARMS_MUST_STR,
		"kv":   gs_define.PARMS_MUST_STR,
	}
	intParms := map[string]int{
		"restart": gs_define.PARMS_MUST_INT,
	}

	if !(p.CheckStrParms(strParms) && p.CheckIntParms(intParms)) {
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, p.Out.Data)
	}

	var kv []NetworkCardKV
	if err := json.Unmarshal([]byte(strParms["kv"]), &kv); err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_PARMS_ERR, err.Error(), nil)
	}
	// 检查kv是否在指定属性中
	for _, i := range kv {
		find := false
		for _, property := range NETWORK_CARD_PROPERTY {
			if i.Key == property {
				find = true
			}
		}
		if !find {
			return p.ResponseOut(define.RET_PARMS_ERR, "网卡配置文件参数非法", nil)
		}
	}

	// 开始修改配置文件
	goconfig.PrettyFormat = false
	cardAbsPath := filepath.Join(NETWORK_SCRIPTS_PATH, "ifcfg-"+strParms["name"])
	conf, err := goconfig.LoadConfigFile(cardAbsPath)
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}
	for _, i := range kv {
		if i.Value != "" {
			if i.Key == "DNS" {
				conf.SetValue("", "PEERDNS", "yes")
				conf.SetValue("", "DNS1", i.Value)
			} else {
				conf.SetValue("", i.Key, i.Value)
			}
		}
	}
	// 设置静态ip, 设置开机启动
	conf.SetValue("", "ONBOOT", "yes")
	conf.SetValue("", "BOOTPROTO", "static")

	if err = goconfig.SaveConfigFile(conf, cardAbsPath); err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}

	// 重启生效
	go func() {
		if intParms["restart"] == 1 {
			info, err := gs_exec.Command("/etc/init.d/network restart")
			if err != nil {
				global.Logger.Error(err.Error())
			}
			global.Logger.Info(info)
		}
	}()

	logic.RecordBehaviour(fmt.Sprintf("管理员修改了%v的配置", strParms["name"]))

	return p.ResponseSuccessOut(nil)
}

// 网卡禁用或者开启
func (p *Config) NetworkCardOperate() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	strParms := map[string]string{
		"name": gs_define.PARMS_MUST_STR,
	}
	intParms := map[string]int{
		"cmd": gs_define.PARMS_MUST_INT,
	}

	if !(p.CheckStrParms(strParms) && p.CheckIntParms(intParms)) {
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, p.Out.Data)
	}

	// 检查网卡名称是否合法
	cardList, err := networkCardList()
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}

	findName := false

	for _, i := range cardList {
		if i["name"] == strParms["name"] {
			findName = true
		}
	}

	if !findName {
		return p.ResponseOut(define.RET_PARMS_ERR, "网卡不存在", nil)
	}

	switch intParms["cmd"] {
	case 0:
		// 关闭网卡
		info, err := gs_exec.Command(fmt.Sprintf("/sbin/ifconfig %v down", strParms["name"]))
		if err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
		global.Logger.Info(info)
		logic.RecordBehaviour(fmt.Sprintf("管理员禁用了%v", strParms["name"]))
	case 1:
		// 开启网卡
		info, err := gs_exec.Command(fmt.Sprintf("/sbin/ifconfig %v up", strParms["name"]))
		if err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
		global.Logger.Info(info)
		logic.RecordBehaviour(fmt.Sprintf("管理员开启了%v", strParms["name"]))
	default:
		return p.ResponseOut(define.RET_PARMS_ERR, "cmd参数错误", nil)
	}

	return p.ResponseSuccessOut(nil)
}

// 获取系统类型
func (p *Config) GetSystemType() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	return p.ResponseSuccessOut(map[string]interface{}{"system": global.HostType})
}

// 设置上传
func (p *Config) SetCollectUploadIP() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	strParms := map[string]string{
		"ip": gs_define.PARMS_MUST_STR,
	}

	if !p.CheckStrParms(strParms) {
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, p.Out.Data)
	}

	if global.HostType == define.HOST_TYPE_COLLECT || global.HostType == define.HOST_TYPE_ALLINONE {
		conf, err := goconfig.LoadConfigFile(global.CollectConfPath)
		if err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
		// 设置静态ip, 设置开机启动
		conf.SetValue("MONITOR", "ip", strParms["ip"])

		if err = goconfig.SaveConfigFile(conf, global.CollectConfPath); err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
	} else {
		p.Out.Ret = define.RET_DATA_VALUE_ERR
		p.Out.Msg = "此机型未运行有采集器程序"
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, nil)
	}

	logic.RecordBehaviour(fmt.Sprintf("管理员设置了采集器的上传IP：%v", strParms["ip"]))

	return p.ResponseSuccessOut(nil)
}
