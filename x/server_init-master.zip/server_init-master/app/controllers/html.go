package controllers

import (
	"github.com/revel/revel"
)

type Html struct {
	GrantBase
}

func (p *Html) Index() revel.Result {
	return p.Render()
}

func (p *Html) Network() revel.Result {
	return p.Render()
}

func (p *Html) Monitor() revel.Result {
	return p.Render()
}

func (p *Html) Log() revel.Result {
	return p.Render()
}

func (p *Html) User() revel.Result {
	return p.Render()
}

type GuestHtml struct {
	Base
}

func (p *GuestHtml) Login() revel.Result {
	return p.Render()
}
