package controllers

import (
	"fmt"
	"gsn/server_init/define"
	"gsn/server_init/global"
	"gsn/server_init/logic"

	gs_define "geesunn.com/define"
	gs_exec "geesunn.com/easyexec"
	"geesunn.com/lib/mysql"
	gs_tool "geesunn.com/tool"
	"github.com/Unknwon/goconfig"
	"github.com/revel/revel"
)

type Monitor struct {
	GrantBase
}

// 重启服务器
func (p *Monitor) RestartServer() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	strParms := map[string]string{
		"password": gs_define.PARMS_MUST_STR,
	}

	if !p.CheckStrParms(strParms) {
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, nil)
	}

	// 校对密码
	conf, err := goconfig.LoadConfigFile(global.AuthFilePath)
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, "查询Auth文件错误", nil)
	}
	if strParms["password"] != conf.MustValue("user", "password") {
		return p.ResponseOut(define.RET_DATA_VALUE_ERR, "密码错误", nil)
	}

	// 重启
	info, err := gs_exec.Command("/sbin/init 6")
	if err != nil {
		global.Logger.Error("%v %v", info, err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}
	global.Logger.Info(info)

	logic.RecordBehaviour("管理员重启了智象服务器")

	return p.ResponseSuccessOut(nil)
}

// 重启智象服务
func (p *Monitor) RestartProcess() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	info, err := gs_exec.Command("/etc/init.d/geesunn restart")
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}
	global.Logger.Info(info)
	logic.RecordBehaviour("管理员重启了智象服务")
	return p.ResponseSuccessOut(nil)
}

// 获取系统时间和运行时长
func (p *Monitor) ServerTime() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	return p.ResponseSuccessOut(map[string]interface{}{"servertime": gs_tool.CurrentTimeStr()})
}

// 获取系统操作日志
func (p *Monitor) Log() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	strParms := map[string]string{
		"start_time": gs_define.PARMS_MUST_STR,
		"end_time":   gs_define.PARMS_MUST_STR,
	}
	intParms := map[string]int{
		"skip": gs_define.PARMS_MUST_INT,
		"take": gs_define.PARMS_MUST_INT,
	}
	if !(p.CheckIntParms(intParms) && p.CheckStrParms(strParms)) {
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, p.Out.Data)
	}

	sql := fmt.Sprintf(`SELECT action, time FROM server_init_log WHERE "%v"<time AND time<"%v" ORDER BY time DESC LIMIT %v, %v;`, strParms["start_time"], strParms["end_time"], intParms["skip"], intParms["take"])
	global.Logger.Info(sql)
	rows, err := mysql.Query(global.DB, sql)
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}

	sql = fmt.Sprintf(`SELECT COUNT(*) AS num FROM server_init_log WHERE "%v"<time AND time<"%v"`, strParms["start_time"], strParms["end_time"])
	countInfo, _ := mysql.QueryOne(global.DB, sql)
	return p.ResponseSuccessOut(map[string]interface{}{"list": rows, "count": countInfo["num"]})
}

// 设置服务器时间
func (p *Monitor) SetServerTime() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	strParms := map[string]string{
		"date":    gs_define.PARMS_MUST_STR,
		"ntpdate": gs_define.PARMS_MUST_STR,
	}
	intParms := map[string]int{
		"flag": gs_define.PARMS_MUST_INT,
	}

	if !(p.CheckStrParms(strParms) && p.CheckIntParms(intParms)) {
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, p.Out.Data)
	}

	switch intParms["flag"] {
	case 0:
		info, err := gs_exec.Command(fmt.Sprintf(`/bin/date -s "%v"`, strParms["date"]))
		if err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
		global.Logger.Info(info)
	case 1:
		info, err := gs_exec.Command(fmt.Sprintf(`/usr/sbin/ntpdate %v`, strParms["ntpdate"]))
		if err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
		global.Logger.Info(info)
	}

	logic.RecordBehaviour(fmt.Sprintf("管理员重新设置了服务器时间%v", strParms["name"]))

	return p.ResponseSuccessOut(nil)
}

// 查看智象进程的状态
func (p *Monitor) ProcessStatus() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	mysqlInfo, err := gs_exec.Command("monit status mysql")
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}

	data := map[string]interface{}{
		"mysql": mysqlInfo,
	}

	switch global.HostType {
	case define.HOST_TYPE_MONITOR:
		monitorInfo, err := gs_exec.Command("monit status monitor")
		if err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
		data["monitor"] = monitorInfo
	case define.HOST_TYPE_COLLECT:
		collectInfo, err := gs_exec.Command("monit status collect")
		if err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
		data["collect"] = collectInfo
	case define.HOST_TYPE_ALLINONE:
		monitorInfo, err := gs_exec.Command("monit status monitor")
		if err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
		collectInfo, err := gs_exec.Command("monit status collect")
		if err != nil {
			global.Logger.Error(err.Error())
			return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
		}
		data["monitor"] = monitorInfo
		data["collect"] = collectInfo
	default:
		return p.ResponseOut(define.RET_SYSTEM_ERR, "配置文件sys->system参数未知", nil)
	}

	return p.ResponseSuccessOut(data)
}

// 获取系统状态
func (p *Monitor) DeviceStatus() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	// 获取服务器的运行时长
	// date -d "$(awk -F. '{print $1}' /proc/uptime) second ago" +"%Y-%m-%d %H:%M:%S"
	restartTime, err := gs_exec.Command("/bin/date -d \"`cut -f1 -d. /proc/uptime` seconds ago\" \"+%Y-%m-%d %H:%M:%S\"")
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	}
	global.Logger.Info(restartTime)

	// cpuInfo, err := gs_exec.Command("/usr/bin/mpstat")
	// if err != nil {
	// 	global.Logger.Error(err.Error())
	// 	return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	// }
	// global.Logger.Info(cpuInfo)

	// memInfo, err := gs_exec.Command("/usr/bin/free")
	// if err != nil {
	// 	global.Logger.Error(err.Error())
	// 	return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	// }
	// global.Logger.Info(memInfo)

	// diskInfo, err := gs_exec.Command("/bin/df -h")
	// if err != nil {
	// 	global.Logger.Error(err.Error())
	// 	return p.ResponseOut(define.RET_SYSTEM_ERR, err.Error(), nil)
	// }
	// global.Logger.Info(diskInfo)

	return p.ResponseSuccessOut(map[string]interface{}{
		"restart_time": restartTime,
		"system":       global.HostType,
	})
}
