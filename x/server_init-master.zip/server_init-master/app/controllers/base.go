package controllers

import (
	gs_define "geesunn.com/define"
	gs_tool "geesunn.com/tool"
	"github.com/revel/revel"
	"net/url"
	"gsn/server_init/define"
	"gsn/server_init/global"
	"strconv"
	"strings"
)

type Base struct {
	*revel.Controller
	In            url.Values
	Out           define.Out
	Cookie        map[string]string
	StartUnixTime int64
	EndUnixTime   int64
}

func (p *Base) ResponseOut(ret int, msg string, data map[string]interface{}) revel.Result {
	p.Out.Ret = ret
	p.Out.Msg = msg
	if data == nil {
		p.Out.Data = map[string]interface{}{}
	} else {
		p.Out.Data = data
	}
	return p.RenderJson(p.Out)
}

func (p *Base) ResponseSuccessOut(data map[string]interface{}) revel.Result {
	return p.ResponseOut(define.RET_SUCCESS, "请求成功", data)
}

// 检查上传参数
func (p *Base) CheckStrParms(strParms map[string]string) bool {
	lossKey := []string{}
	for key, value := range strParms {
		if _, ok := p.In[key]; !ok {
			if value != gs_define.PARMS_MUST_STR {
				delete(strParms, key)
			} else {
				lossKey = append(lossKey, key)
			}
		} else {
			strParms[key] = p.In[key][0]
		}
	}

	if len(lossKey) > 0 {
		p.Out.Ret = define.RET_PARMS_ERR
		p.Out.Msg = "缺少参数：" + strings.Join(lossKey, ",")
		p.Out.Data = map[string]interface{}{}
		return false
	}

	return true
}

func (p *Base) CheckIntParms(intParms map[string]int) bool {
	lossKey := []string{}
	typeErrKey := []string{}
	for key, value := range intParms {
		if _, ok := p.In[key]; !ok {
			if value != gs_define.PARMS_MUST_INT {
				delete(intParms, key)
			} else {
				lossKey = append(lossKey, key)
			}
		} else {
			var err error
			intParms[key], err = strconv.Atoi(p.In[key][0])
			if err != nil {
				typeErrKey = append(typeErrKey, key)
			}
		}
	}

	if len(lossKey) > 0 || len(typeErrKey) > 0 {
		p.Out.Ret = define.RET_PARMS_ERR
		p.Out.Msg = ""
		if len(lossKey) > 0 {
			p.Out.Msg = "缺少参数：" + strings.Join(lossKey, ",")
		}
		if len(typeErrKey) > 0 {
			p.Out.Msg = p.Out.Msg + "参数类型错误：" + strings.Join(typeErrKey, ",")
		}

		p.Out.Data = map[string]interface{}{}
		return false
	}

	return true
}

func (p *Base) CheckFloatParms(floatParms map[string]float64) bool {
	lossKey := []string{}
	typeErrKey := []string{}
	for key, value := range floatParms {
		if _, ok := p.In[key]; !ok {
			if value != gs_define.PARMS_MUST_FLOAT64 {
				delete(floatParms, key)
			} else {
				lossKey = append(lossKey, key)
			}
		} else {
			var err error
			floatParms[key], err = strconv.ParseFloat(p.In[key][0], 64)
			if err != nil {
				typeErrKey = append(typeErrKey, key)
			}
		}
	}

	if len(lossKey) > 0 || len(typeErrKey) > 0 {
		p.Out.Ret = define.RET_PARMS_ERR
		p.Out.Msg = ""
		if len(lossKey) > 0 {
			p.Out.Msg = "缺少参数：" + strings.Join(lossKey, ",")
		}
		if len(typeErrKey) > 0 {
			p.Out.Msg = p.Out.Msg + "参数类型错误：" + strings.Join(typeErrKey, ",")
		}

		p.Out.Data = map[string]interface{}{}
		return false
	}

	return true
}

func (p *Base) Before() revel.Result {
	p.StartUnixTime = gs_tool.CurrentTimeNanoSecond()
	switch p.Request.Method {
	case "GET":
		p.In = p.Params.Query
	case "POST":
		p.In = p.Params.Form
	}
	p.Cookie = map[string]string{}
	for _, item := range p.Request.Cookies() {
		p.Cookie[item.Name] = item.Value
	}

	if p.Request.RequestURI == "/monitor/server-time" {
		return nil
	}

	global.Logger.Info(strings.Repeat("*", 100))
	global.Logger.Info("%v  %v  %v  %v", p.Request.Proto, p.Request.Method, p.Request.RequestURI, p.Request.Host)
	global.Logger.Info("%v", p.Request.Header)
	global.Logger.Info("传入参数:%v", p.In)
	return nil
}

func (p *Base) After() revel.Result {
	if p.Request.RequestURI == "/monitor/server-time" {
		return nil
	}
	p.EndUnixTime = gs_tool.CurrentTimeNanoSecond()
	global.Logger.Info("返回：%v", p.Result)
	global.Logger.Info("耗时：%v ms", (p.EndUnixTime-p.StartUnixTime)/1000/1000)
	return p.Result
}

type GrantBase struct {
	Base
}

func (p *GrantBase) isLogin() bool {
	if _, ok := p.Cookie["account"]; !ok {
		return false
	}
	if _, ok := p.Cookie["token"]; !ok {
		return false
	}

	if _, ok := global.Session[p.Cookie["account"]]; !ok {
		return false
	} else {
		if global.Session[p.Cookie["account"]]["token"] == p.Cookie["token"] {
			return true
		}
	}

	return false
}

func (p *GrantBase) Before() revel.Result {
	routeArr := []string{"/", "/user", "/network"}
	if !p.isLogin() {
		for _, i := range routeArr {
			if p.Request.RequestURI == i {
				return p.Redirect("/login")
			}
		}

		return p.ResponseOut(define.RET_RELOGIN, "请先登录", nil)
	}
	return nil
}

func init() {
	revel.InterceptMethod((*Base).After, revel.AFTER)
	revel.InterceptMethod((*Base).Before, revel.BEFORE)
	revel.InterceptMethod((*GrantBase).Before, revel.BEFORE)
}
