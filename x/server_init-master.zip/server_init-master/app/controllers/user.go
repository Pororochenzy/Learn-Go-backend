package controllers

import (
	"fmt"

	gs_define "geesunn.com/define"
	"github.com/Unknwon/goconfig"
	"github.com/revel/revel"
	// "io/ioutil"
	"gsn/server_init/define"
	"gsn/server_init/global"
	"gsn/server_init/logic"

	"geesunn.com/lib/mysql"
	// "strings"
	"net/http"

	gs_tool "geesunn.com/tool"
)

type GuestUser struct {
	Base
}

// 登陆验证
func (p *GuestUser) Login() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	strParms := map[string]string{
		"account":  gs_define.PARMS_MUST_STR,
		"password": gs_define.PARMS_MUST_STR,
	}

	if !p.CheckStrParms(strParms) {
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, p.Out.Data)
	}

	conf, err := goconfig.LoadConfigFile(global.AuthFilePath)
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, "查询Auth文件错误", nil)
	}
	if strParms["account"] != conf.MustValue("user", "account") || strParms["password"] != conf.MustValue("user", "password") {
		logic.RecordBehaviour("管理员试图登陆智象后台系统，但是账号或密码错误")
		return p.ResponseOut(define.RET_DATA_VALUE_ERR, "账号或密码错误", nil)
	}

	// 保留session
	// token := gs_tool.GetMD5String(gs_tool.CurrentTimeStr() + strParms["account"] + "geesunn.com")
	token := gs_tool.GetMD5String(strParms["account"] + "geesunn.com")
	global.Session[strParms["account"]] = map[string]string{"token": token}
	// 设置cookie
	p.SetCookie(&http.Cookie{Name: "account", Value: strParms["account"]})
	p.SetCookie(&http.Cookie{Name: "token", Value: token})

	logic.RecordBehaviour("管理员登陆智象后台系统")

	return p.ResponseSuccessOut(nil)
}

type User struct {
	GrantBase
}

func (p *User) GetSystemUser() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	conf, err := goconfig.LoadConfigFile(global.AuthFilePath)
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, "查询Auth文件错误", nil)
	}

	return p.ResponseSuccessOut(map[string]interface{}{"user": conf.MustValue("user", "account")})
}

// 重置密码
func (p *User) ResetPassword() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	strParms := map[string]string{
		"old_password": gs_define.PARMS_MUST_STR,
		"new_password": gs_define.PARMS_MUST_STR,
	}

	if !p.CheckStrParms(strParms) {
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, p.Out.Data)
	}

	conf, err := goconfig.LoadConfigFile(global.AuthFilePath)
	if err != nil {
		global.Logger.Error(err.Error())
		return p.ResponseOut(define.RET_SYSTEM_ERR, "查询Auth文件错误", nil)
	}
	if strParms["old_password"] != conf.MustValue("user", "password") {
		return p.ResponseOut(define.RET_DATA_VALUE_ERR, "账号或密码错误", nil)
	}

	// 修改密码
	conf.SetValue("user", "password", strParms["new_password"])
	goconfig.SaveConfigFile(conf, global.AuthFilePath)

	logic.RecordBehaviour("管理员重置了智象管理后台的登陆密码")

	return p.ResponseSuccessOut(nil)
}

// 注销
func (p *User) Logout() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	// 删除session
	delete(global.Session, p.Cookie["account"])
	// 浏览器本地cookie清不清除都无所谓

	logic.RecordBehaviour("管理员退出了系统")

	return p.ResponseSuccessOut(nil)
}

// 修改monitor管理员登陆账号密码
func (p *User) ResetMonitorAccount() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	strParms := map[string]string{
		"user":     gs_define.PARMS_MUST_STR,
		"account":  gs_define.PARMS_MUST_STR,
		"password": gs_define.PARMS_MUST_STR,
	}

	if !p.CheckStrParms(strParms) {
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, p.Out.Data)
	}

	password := gs_tool.GetMD5String(strParms["password"] + "geesunn")
	sql := `UPDATE user SET password=? WHERE id=1`
	_, err := mysql.Update(global.DB, sql, password)
	if err != nil {
		global.Logger.Error(err.Error())
		p.Out.Ret = define.RET_SYSTEM_ERR
		p.Out.Msg = err.Error()
		return p.ResponseOut(p.Out.Ret, p.Out.Msg, p.Out.Data)
	}

	logic.RecordBehaviour("管理员设置了智象运维系统的初始登陆账号")

	return p.ResponseSuccessOut(nil)
}

// 获取monitor初始化管理员登陆的账号
func (p *User) GetMonitorAccount() revel.Result {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("%v", r)
			logic.PrintTrace()
			p.Out.Ret = define.RET_SYSTEM_ERR
			p.Out.Msg = fmt.Sprintf("%v", r)
		}
	}()

	sql := `SELECT tel, name FROM user WHERE id=1`
	rows, _ := mysql.Query(global.DB, sql)
	if len(rows) > 0 {
		return p.ResponseSuccessOut(map[string]interface{}{"user": rows[0]["name"], "account": rows[0]["tel"]})
	}
	return p.ResponseOut(define.RET_DATA_NOT_EXIST_ERR, "未找到系统初始化管理员", nil)
}
