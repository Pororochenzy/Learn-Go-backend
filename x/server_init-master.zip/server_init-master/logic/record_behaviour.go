package logic

import (
	"gsn/server_init/global"

	"geesunn.com/lib/mysql"
	gs_tool "geesunn.com/tool"
)

// 记录用户行为
func RecordBehaviour(action string) {
	mysql.InsertTR(global.DB, "server_init_log", map[string]interface{}{
		"action": action,
		"time":   gs_tool.CurrentTimeStr(),
	})
}
