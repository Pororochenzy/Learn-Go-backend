package logic

import "runtime"
import "gsn/server_init/global"

const LINE_NUM = 16

func PrintTrace() {
	for i := 0; i < LINE_NUM; i++ {
		funcName, file, line, ok := runtime.Caller(i)
		if ok {
			global.Logger.Error("frame %v:[func:%v,file:%v,line:%v]", i, runtime.FuncForPC(funcName).Name(), file, line)
		}
	}
}
