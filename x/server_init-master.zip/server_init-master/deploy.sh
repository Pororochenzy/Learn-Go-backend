gitdir=/data/geesunn_fedel/code/src/gsn/server_init
build=/root/geesunn/build/geesunn-server_init
pro=/geesunn/app/geesunn-server_init
cd $gitdir
git checkout dev
git pull

cd ../../geesunn.com
git checkout dev
git pull

cd -

./pack.sh build "test"
if [[ $? -gt 0 ]];
then
    exit 1
fi 

rm -fr $pro
mkdir -p $pro
cp -fr $build/* $pro

cd $pro/src
./control.sh restart
if [[ $? -gt 0 ]];
then
    exit 1
fi 
