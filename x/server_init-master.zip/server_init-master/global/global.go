package global

import (
	"database/sql"
	"fmt"
	"gsn/server_init/define"
	"io/ioutil"
	"path/filepath"
	"strings"

	"geesunn.com/encrypt"
	"geesunn.com/lib/mysql"
	"geesunn.com/logs"
	"geesunn.com/tool"
	"github.com/Unknwon/goconfig"
)

var (
	ConfigFile      = "gsn/server_init/conf"
	Config          *goconfig.ConfigFile
	Logger          = logs.NewLogger()
	HostType        = ""
	Session         = map[string]map[string]string{}
	AuthFilePath    = ""
	CollectConfPath = ""
	// mysql对象
	DB *sql.DB
)

func GlobalInit() {
	for _, f := range []string{"geesunn.conf", "geesunn.conf.test", "geesunn.conf.pro", "geesunn.conf.enc"} {
		newPath := filepath.Join(ConfigFile, f)
		if strings.HasSuffix(newPath, ".enc") {
			bytes, err := ioutil.ReadFile(newPath)
			if err != nil {
				panic(err)
			}
			decBytes, err := encrypt.AesDecrypt(bytes, []byte(encrypt.EncryptFLKey))
			if err != nil {
				panic(err)
			}
			Config, _ = goconfig.LoadFromData(decBytes)
		} else {
			if tool.IsFileExist(newPath) {
				c, err := goconfig.LoadConfigFile(newPath)
				if err != nil {
					panic(err)
				}
				Config = c
			}
		}
		if Config != nil {
			break
		}
	}
	fileSwitch := Config.MustValue("log", "fileswitch")
	level := Config.MustValue("log", "level")
	if fileSwitch == "on" {
		fileName := Config.MustValue("log", "filename")
		daily := Config.MustValue("log", "daily")
		maxdays := Config.MustValue("log", "maxdays")
		Logger.SetLogger(logs.AdapterFile,
			fmt.Sprintf(`{"filename": "%v", "daily": %v, "maxdays": %v, "level": %v}`, fileName, daily, maxdays, level))
	} else {
		Logger.SetLogger(logs.AdapterConsole)
	}
	// 设置日志输出文件名和文件行号
	Logger.EnableFuncCallDepth(true)
	// 设置日志是否异步输出
	if Config.MustValue("log", "async") == "true" {
		// 设置异步输出日志，并且设置缓存大小1e3
		Logger.Async(1e3)
	}

	HostType = Config.MustValue("sys", "system")
	AuthFilePath = Config.MustValue("sys", "auth_file_path")

	user := Config.MustValue("db", "user")
	password := Config.MustValue("db", "password")
	host := Config.MustValue("db", "host")
	port := Config.MustValue("db", "port")
	db := Config.MustValue("db", "database")
	maxOpenConns := Config.MustInt("db", "max_open_conn")
	maxIdleConns := Config.MustInt("db", "max_idle_conn")
	dataSourceName := fmt.Sprintf("%v:%v@tcp(%v:%v)/%v?charset=utf8&loc=Local", user, password, host, port, db)
	conn, err := mysql.NewConnection(dataSourceName, maxOpenConns, maxIdleConns)
	if err != nil {
		panic(err)
	}
	DB = conn

	if HostType == define.HOST_TYPE_COLLECT || HostType == define.HOST_TYPE_ALLINONE {
		CollectConfPath = Config.MustValue("collect", "conf_path")
	}

	Logger.Info("系统初始化完成~")
}
