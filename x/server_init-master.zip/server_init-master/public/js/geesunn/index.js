

$(function(){

    //获取设备状态==========

    //获取机型 服务器重启时间

    $.ajax({
        url:'/monitor/device-status',
        type:'get',
        success:function(rBody){
            // 机型 
            if (rBody.ret != 0) {
                if (rBody.ret == 7) {
                    location.href = "/login";
                }else{
                    alert(rBody.msg);
                }
            }else{
                // console.log(rBody.data);
                $('#content-device-model').html(rBody.data.system);
                $('#restart-time').html(rBody.data.restart_time);     
                $('#system_cpu_status').html(rBody.data.system_cpu_status);   
                $('#system_mem_status').html(rBody.data.system_mem_status);
                $('#system_disk_status').html(rBody.data.system_disk_status);

                device_model = rBody.data.system;
            }
        }
    }) ;

   

    $('<div id="restart-server-popup"><div class="tip">请输入密码</div>'
        +'<input type="password" class="login-pwd"/>'
        +'<span class="err-tip">* 密码不能为空</span>'
        +'<button class="cancel radio">取消</button>'
        +'<button class="save radio">确定</button></div>').appendTo('body');
    $('#restart-server-popup').hide();

    //重启服务器按钮
    $('#restart-server').click(function(){

        $('#restart-server-popup').show();
    })

    //重启服务器弹窗 确定按钮
    $('#restart-server-popup .save').click(function(){
        

        var password = $('#restart-server-popup .login-pwd').val();

        if(password.length>0){


            $.ajax({
                url: "/monitor/restart-server",
                type: "post",
                data: {
                   "password": password
                },
                success: function(rBody){
                    $('#restart-server-popup').hide();

                    if (rBody.ret != 0) {
                        if (rBody.ret == 7) {
                            location.href = "/login";
                        }else{
                             $('#common-popup').fadeIn(500).delay(2000).fadeOut(500);
                             $('#common-popup .content-tip').html(rBody.msg).addClass('fail');
                        }
                    }
                    else{
                        $('#common-popup').fadeIn(500).delay(2000).fadeOut(500);
                        $('#common-popup .content-tip').html('设置成功！').addClass('pass');
                    }
                }
            })
        }
        else{
            $('#restart-server-popup .err-tip').show();
        }

        
    })

    //重启服务器弹窗 输入框聚焦
    $('#restart-server-popup .login-pwd').focus(function(){
        $('#restart-server-popup .err-tip').hide();
    })

    //重启服务器弹窗 取消按钮
    $('#restart-server-popup .cancel').click(function(){
        $('#restart-server-popup').hide();
    })
        
        
    


})