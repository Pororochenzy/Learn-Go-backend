
$(function(){

	// 日历初始化设置
	(function (){
	
		var start = {
		    format: 'YYYY-MM-DD hh:mm:ss',
		    minDate: '1970-01-01 00:00:00', //设定最小日期为当前日期
		    festival: false,
		    //isinitVal:true,
		    maxDate: $.nowDate(0), //最大日期
		    choosefun: function(elem,datas){
		        end.minDate = datas; //开始日选好后，重置结束日的最小日期
		    }
		};
		var end = {
		    format: 'YYYY-MM-DD hh:mm:ss',
		    minDate: $.nowDate(0), //设定最小日期为当前日期
		    festival: false,
		    //isinitVal:true,
		    maxDate: '2038-01-19 03:14:07', //最大日期
		    choosefun: function(elem,datas){
		        start.maxDate = datas; //将结束日的初始值设定为开始日的最大日期
		    }
		};


		$("#start-time").jeDate(start);
		$("#end-time").jeDate(start);
	

	})()




	//默认选择开始/结束时间


	$("#start-time").val(formatDate(-1,0));

	$("#end-time").val(formatDate(0,0));

	//获取当前时间并格式化
	function formatDate(MMchange,hhChange) {
		var now = new Date();
		var year=now.getFullYear(); 
		var month= to2Byte(now.getMonth()+1+MMchange) ; 
		var date= to2Byte(now.getDate()); 
		var hour= to2Byte(now.getHours()+hhChange); 
		var minute= to2Byte(now.getMinutes());
		var second= to2Byte(now.getSeconds()); 

		return year+"-"+month+"-"+date+" "+hour+":"+minute+":"+second; 
	} 

	//1位转成2位
	function to2Byte(val){
		val = val<10 ? ('0'+val) : val;
		return val;
	}

	// console.log(to2Byte(2))


	//默认显示前十条内容/默认显示按钮
	var startTime = $('#start-time').val();
	var endTime = $('#end-time').val();
	var skip = 0;

	// console.log(startTime)
	searchData(startTime,endTime,skip);
	

	//点击查询按钮按范围查询
	$('#search-btn').click(function(){
		startTime = $('#start-time').val();
		endTime = $('#end-time').val();
		skip = 0;
		searchData(startTime,endTime,0);
	})


// =========公用的封装函数============


//页码按钮刷新数据
function refreshData(page,startTime,endTime){
	
	if(page<1){
		return;
	}else{
		// 根据页数计算从第几条开始显示
		var min = (page-1)*10;
		console.log('min',min)
		
		$.ajax({
			url : '/monitor/log' ,
			type : 'get' ,
			data : {
				start_time : startTime ,
				end_time   : endTime  ,
				skip       : min,
				take       : 10
			},
			success: function(rBody){
				
				if(rBody.ret != 0 ){
					if (rBody.ret == 7) {
	                    location.href = "/login";
	                } else {
	                    alert(rBody.msg);   
	                }
				}else{


					//清空原有日志
					$('#log-detail-list').empty();

					var list = rBody.data.list;
					//显示对应页日志
					
					//最后一页可能不足10条，故显示返回数据长度
					for(var i=0;i<list.length;i++){
						var action = list[i].action;
						var time = list[i].time;
						var logItem = $('<li><span class="user-operation">'+action+'</span>'
						   +'<span class="detail-time">'+time+'</span></li>');
						$('#log-detail-list').append(logItem);
					}	
				}
			}

		});
		
	}
}


//查询按钮刷新数据
function searchData(startTime,endTime,skip){

	$.ajax({
		url : '/monitor/log' ,
		type : 'get' ,
		data : {
			start_time : startTime ,
			end_time   : endTime  ,
			skip       : skip,
			take       : 10
		},
		success: function(rBody){
			
			if(rBody.ret != 0 ){
				if (rBody.ret == 7) {
                    location.href = "/login";
                } else {
                    alert(rBody.msg);   
                }
			}
			else{


				$('#log-detail-list').empty();

				var list = rBody.data.list;
				var len = skip+list.length;
				console.log(rBody.ret)
				console.log(rBody.data)
				console.log(rBody.data.list);
				// console.log(len);
				//显示系统日志
				//最后一页可能不足10条，故显示返回数据长度
				for(var i=skip;i<len;i++){
					var logItem = $('<li><span class="user-operation">'+rBody.data.list[i].action+'</span>'
					   +'<span class="detail-time">'+rBody.data.list[i].time+'</span></li>');
					$('#log-detail-list').append(logItem);
				}

				//把条数转成页数，显示成按钮
				// console.log(rBody.data.count);
				var test = rBody.data.count%10;
				var page = test==0 ? rBody.data.count/10 : Math.ceil(rBody.data.count/10);
				
				// console.log(page) 

				//清空已有按钮
				$('#log-btn-group').empty();


				//根据页数选择不同显示方案
				//页数小于等于10
				

				if(page<=10){
					for(var i=0;i<page;i++){
						$('<li class="page-btn">'+(i+1)+'</li>').appendTo($('#log-btn-group'));
					};
					$('.page-btn').last().css('marginRight','10px');
					$('<li id="sum-page-lt10">共<span>'+page+'</span>页</li>').appendTo($('#log-btn-group'));
					

					//页码按钮添加点击事件,显示该页对应条信息
					//默认设定当前页码为1;
					var curPage = 1;
					$('#log-btn-group>.page-btn').eq(0).addClass('active');

					//页码按钮添加点击事件,显示该页对应条信息
					$('#log-btn-group .page-btn').click(function(){
						curPage = parseInt($(this).html());
						console.log(curPage);
						//选中按钮加样式
						$(this).addClass('active').siblings('.page-btn').removeClass('active');	

						refreshData(curPage,startTime,endTime);
					})					

				}
				else{
					//页数大于10

					$('<li class="first-btn">首页</li>').appendTo($('#log-btn-group'));
					$('<li class="prev-btn">上一页</li>').appendTo($('#log-btn-group'));
					$('<li id="page-btn-group"></li>').appendTo($('#log-btn-group'));
					for(var i=0;i<7;i++){
						$('<span class="page-btn">'+(i+1)+'</span>').appendTo($('#page-btn-group'));
					};

					$('<li class="next-btn">下一页</li>').appendTo($('#log-btn-group'));
					$('<li class="end-btn">尾页</li>').appendTo($('#log-btn-group'));

					$('<li class="sum">共&nbsp;&nbsp;<span id="sum-page">'+page+'</span>&nbsp;&nbsp;页</li>').appendTo($('#log-btn-group'));

					
					//默认设定当前页码为1;
					var curPage = 1;
					//第一页按钮样式
					$('#log-btn-group .page-btn').eq(0).addClass('active').siblings('.page-btn').removeClass('active');
					
					//首页按钮/上一页按钮 失效样式
					$('#log-btn-group .first-btn').prop('disabled',true).addClass('disabled');
					$('#log-btn-group .prev-btn').prop('disabled',true).addClass('disabled');

					//页码按钮添加点击事件,显示该页对应条信息
					$('#log-btn-group .page-btn').click(function(){
						curPage = parseInt($(this).html());
						// console.log(curPage);
						//选中按钮加样式
						$(this).addClass('active').siblings('.page-btn').removeClass('active');

						if(curPage==1){
							$('#log-btn-group .first-btn').prop('disabled',true).addClass('disabled');
							$('#log-btn-group .prev-btn').prop('disabled',true).addClass('disabled');
						}else{
							$('#log-btn-group .first-btn').prop('disabled',false).removeClass('disabled');
							$('#log-btn-group .prev-btn').prop('disabled',false).removeClass('disabled');
						}

						if(curPage==page){
							$('#log-btn-group .next-btn').prop('disabled',true).addClass('disabled');
							$('#log-btn-group .end-btn').prop('disabled',true).addClass('disabled');
						}else{
							$('#log-btn-group .next-btn').prop('disabled',false).removeClass('disabled');
							$('#log-btn-group .end-btn').prop('disabled',false).removeClass('disabled');
						}


						refreshData(curPage,startTime,endTime);
					});


					// 特定按钮添加点击事件
					//首页按钮
					$('#log-btn-group .first-btn').click(function(){
						curPage = 1;

						$('#log-btn-group .first-btn').prop('disabled',true).addClass('disabled');
						$('#log-btn-group .prev-btn').prop('disabled',true).addClass('disabled');
						$('#log-btn-group .next-btn').prop('disabled',false).removeClass('disabled');
						$('#log-btn-group .end-btn').prop('disabled',false).removeClass('disabled');


						//重新生成按钮
						$('#log-btn-group #page-btn-group').empty();

						var temp = 0;

						for(var i=0; i<7; i++){

							temp++; 
							// console.log(temp);
							var pageBtn = $('<span class="page-btn">'+temp+'</span>');
							$('#log-btn-group #page-btn-group').append(pageBtn);
							
						}

						//第1页选中按钮样式
						$('#log-btn-group .page-btn').eq(0).addClass('active').siblings('.page-btn').removeClass('active');

						//页码按钮添加点击事件,显示该页对应条信息
						$('#log-btn-group .page-btn').click(function(){
							clickRefreshData($(this));
						})

						refreshData(curPage,startTime,endTime);

					});
					//尾页按钮
					$('#log-btn-group .end-btn').click(function(){
						
						curPage = page;


						$('#log-btn-group .end-btn').prop('disabled',true).addClass('disabled');
						$('#log-btn-group .next-btn').prop('disabled',true).addClass('disabled');
						$('#log-btn-group .first-btn').prop('disabled',false).removeClass('disabled');
						$('#log-btn-group .prev-btn').prop('disabled',false).removeClass('disabled');

						//重新生成按钮
						$('#log-btn-group #page-btn-group').empty();
						//改变按钮显示页码
						var temp = page;

						//判断尾页是否被7整除
						var test7devide = curPage%7; 

						if(test7devide==0){
							temp++;
							for(var i=6; i>=0; i--){
								temp--; 
								var pageBtn = $('<span class="page-btn">'+temp+'</span>');
								$('#log-btn-group #page-btn-group').append(pageBtn);							
							}
							//页码按钮添加点击事件,显示该页对应条信息
							$('#log-btn-group .page-btn').click(function(){
								clickRefreshData($(this));
							})
							//第page页选中按钮样式
							$('#log-btn-group .page-btn').eq(6).addClass('active').siblings('.page-btn').removeClass('active');
						
						}
						else{

							var length = test7devide;
							temp = temp - length;
							for(var i=0; i<length; i++){
								temp++; 
								var pageBtn = $('<span class="page-btn">'+temp+'</span>');
								$('#log-btn-group #page-btn-group').append(pageBtn);							
							}
							//页码按钮添加点击事件,显示该页对应条信息
							$('#log-btn-group .page-btn').click(function(){
								clickRefreshData($(this));
							})
							//第page页选中按钮样式
							$('#log-btn-group .page-btn').eq(length-1).addClass('active').siblings('.page-btn').removeClass('active');

						}

						//页码按钮添加点击事件,显示该页对应条信息
						$('#log-btn-group .page-btn').click(function(){
							$(this).addClass('active').siblings('.page-btn').removeClass('active');
							curPage = parseInt($(this).html());
							refreshData(curPage,startTime,endTime);
						})

						refreshData(curPage,startTime,endTime);
					});
					//上一页按钮
					$('#log-btn-group .prev-btn').click(function(){

						if(curPage>1){
							curPage = --curPage;

							// console.log(curPage);
							if(curPage<=1){
								$('#log-btn-group .first-btn').prop('disabled',true).addClass('disabled');
								$('#log-btn-group .prev-btn').prop('disabled',true).addClass('disabled');
							}else{
								$('#log-btn-group .first-btn').prop('disabled',false).removeClass('disabled');
								$('#log-btn-group .prev-btn').prop('disabled',false).removeClass('disabled');
							}
						
																	
							var temp = curPage;

						
							if(curPage%7==0){	

								//清空原有按钮
								$('#page-btn-group').empty();	

								temp = temp - 7;
								for(var i=0; i<7; i++){
									temp++; 
									var pageBtn = $('<span class="page-btn">'+temp+'</span>');
									$('#log-btn-group #page-btn-group').append(pageBtn);
								}
								//页码按钮添加点击事件,显示该页对应条信息
								$('#log-btn-group .page-btn').click(function(){
									clickRefreshData($(this));
								})
							}

							//选中样式
							checkedBtnStyle();

							refreshData(curPage,startTime,endTime);

						}	

						
					});
					//下一页按钮
					$('#log-btn-group .next-btn').click(function(){


						if(curPage<page){
							curPage = ++curPage;

							// console.log(curPage)

							if(curPage>=page){
								$('#log-btn-group .next-btn').prop('disabled',true).addClass('disabled');
								$('#log-btn-group .end-btn').prop('disabled',true).addClass('disabled');
							}else{
								$('#log-btn-group .next-btn').prop('disabled',false).removeClass('disabled');
								$('#log-btn-group .end-btn').prop('disabled',false).removeClass('disabled');
							}


							//记录当前页
							var temp = curPage;
							//上一页
							var prevPage = curPage - 1;


							if(prevPage%7==0){
								$('#page-btn-group').empty();

								//判断剩余页数是否小于7
								var remainderPage = page - curPage + 1;
								if(remainderPage<7){
									temp--;
									for(var i=0; i<remainderPage; i++){
										temp++;
										var pageBtn = $('<span class="page-btn">'+temp+'</span>');
										$('#log-btn-group #page-btn-group').append(pageBtn);
									}
									//页码按钮添加点击事件,显示该页对应条信息
									$('#log-btn-group .page-btn').click(function(){
										clickRefreshData($(this));
									})
								}
								else{
									temp--;
									for(var i=0; i<7; i++){
										temp++;
										var pageBtn = $('<span class="page-btn">'+temp+'</span>');
										$('#log-btn-group #page-btn-group').append(pageBtn);		
									}
									//页码按钮添加点击事件,显示该页对应条信息
									$('#log-btn-group .page-btn').click(function(){
										clickRefreshData($(this));
									})
								}
			
								
							}
							//选中样式
							checkedBtnStyle();

								
							refreshData(curPage,startTime,endTime);
						}
						
						
					});	

					//=======函数封装========

					//新创建节点页码点击功能
					function clickRefreshData(self){
						self.addClass('active').siblings('.page-btn').removeClass('active');
						curPage = parseInt(self.html());
						if(curPage<=1){
							$('#log-btn-group .first-btn').prop('disabled',true).addClass('disabled');
							$('#log-btn-group .prev-btn').prop('disabled',true).addClass('disabled');
						}else{
							$('#log-btn-group .first-btn').prop('disabled',false).removeClass('disabled');
							$('#log-btn-group .prev-btn').prop('disabled',false).removeClass('disabled');
						}

						if(curPage>=page){
							$('#log-btn-group .next-btn').prop('disabled',true).addClass('disabled');
							$('#log-btn-group .end-btn').prop('disabled',true).addClass('disabled');
						}else{
							$('#log-btn-group .next-btn').prop('disabled',false).removeClass('disabled');
							$('#log-btn-group .end-btn').prop('disabled',false).removeClass('disabled');
						}

						refreshData(curPage,startTime,endTime);
					}
					//上下翻页的页码选中按钮样式
					function checkedBtnStyle(){
						for(var j=0; j<7; j++){
							var txt = parseInt($('#log-btn-group .page-btn').eq(j).html());
							if(curPage==txt){
								$('#log-btn-group .page-btn').eq(j).addClass('active').siblings('.page-btn').removeClass('active');
							}
						}
					}

				}
				//页数>10 ends 
			}
			//reg=0 ends
		}
		//success ends
	})
	//ajax ends
}




// ========================================================

// 	var domObj =  (function (){
// 		var obj = {
// 			btnSearch : $('#btn-search') ,
// 			fliterStartTime : $('#fliter-start-time') ,
// 			fliterEndTime : $('#fliter-end-time') ,
// 			tbody         : $('#tbody') ,
// 		}
// 		return obj

// 	})() ;
// 	domObj.btnSearch.click(function(){
// 		var startTime = domObj.fliterStartTime.val() ;
// 		var endTime  = domObj.fliterEndTime.val() ;
// 		console.log(startTime) ;
// 		$.ajax({
// 			url : '/monitor/log' ,
// 			type : 'get' ,

// 			data : {
// 				start_time : startTime ,
// 				end_time   : endTime  ,
// 				skip       : '1' ,
// 				take       : '0'

// 			},
// 			success: function(data){
// 				console.log(data) ;
// 				if(!data){
// 					alert('无数据！')
// 				}
// 				for(var i = 0 ; i < data.data.list.length ; i++) {
// 					console.log(1)
// 						var str  = ['<tr class="odd">',
// '								<td class="  sorting_1 trAction"></td>',
// '								<td class="center trTime"></td>',
// '							</tr>'].join("");
// 				domObj.tbody.append(str) ;
				
				
// 				$('#tbody .trAction').eq(i).html(data.data.list[i].action) ;
// 				$('#tbody .trTime').eq(i).html(data.data.list[i].time) ;

// 				}
// 				// 分页插件调用
// 				$(".tcdPageCode").createPage({
//        				pageCount:6,
//         			current:1,
//         			backFn:function(p){
//             		console.log(p);
//         			}
//     			});
// 			}
// 		})

// 	}) ;
	
	
	 // setInterval(function(){
  //               $.ajax({
  //               url:'/monitor/server-time',
  //               type:'get',
  //               processData:true,
  //               success:function(data){
  //                   // 服务器运行时间 服务器时间 ；
  //                   console.log(data)
  //                   var rBody = eval(data);
  //                   console.log(rBody)
  //                   if(rBody.ret != 0){
                        
  //                       if (rBody.ret == 7) {
  //                           location.href = "/login";
  //                           } else {
  //                           alert(rBody.msg)    
  //                           }
  //                   }else{
  //                       $('#serverTime').html(data.data.servertime) ;
  //                       $('#runningTime').html(data.data.runtime) ;
  //                   }
  //               }
  //           }) ;

  //           },3000)
            
            // $.ajax({
            //     url:'/config/system',
            //     type:'get',
            //     processData:true,
            //     success:function(data){
            //         // 版本号 
            //         if (data.ret != 0) {
            //             if (rBody.ret == 7) {
            //                 location.href = "/login";
            //                 } else {
            //                 alert(rBody.msg)    
            //                 }
            //         }else{
            //             $('#edition').html(data.data.system)
            //         }
            //     }
            // }) ;

})
