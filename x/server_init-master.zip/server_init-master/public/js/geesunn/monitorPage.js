	(function(){
		// 时间版本请求
	setInterval(function(){
                $.ajax({
                url:'/monitor/server-time',
                type:'get',
                processData:true,
                success:function(data){
                    // 服务器运行时间 服务器时间 ；
                    console.log(data)
                    var rBody = eval(data);
                    console.log(rBody)
                    if(rBody.ret != 0){
                        
                        if (rBody.ret == 7) {
                            location.href = "/login";
                            } else {
                            alert(rBody.msg)    
                            }
                    }else{
                        $('#serverTime').html(data.data.servertime) ;
                        $('#runningTime').html(data.data.runtime) ;
                    }
                }
            }) ;

            },3000)
            
            $.ajax({
                url:'/config/system',
                type:'get',
                processData:true,
                success:function(data){
                    // 版本号 
                    if (data.ret != 0) {
                        if (rBody.ret == 7) {
                            location.href = "/login";
                            } else {
                            alert(rBody.msg)    
                            }
                    }else{
                        $('#edition').html(data.data.system)
                    }
                }
            }) ;
	})()
	var objDom = (function(){
		var rebootRrompt = document.getElementById('rebootRrompt') ;

		var obj = {
			mysql : $('#mysql') ,
			monitor : $('#monitor') ,
			collect : $('#collect') ,
			rebootRrompt : rebootRrompt ,
			userPasswordPrompt : $('#user_password_prompt') ,
			userPasswordBox : $('#user_password_box') ,
			iframe       : $('#iframe') ,
			confirm      : $('#confirm') ,
			undo         : $('#undo') ,
			result       : $('#result')
		} ;
		return obj ;
	})()
	// 进程状态
	$.ajax({
		url:'/monitor/process-status' ,
		type:'get' ,
		success:function(data){
			console.log(data) ;
			if (data.ret != 0) {
				alert('数据请求失败')
				if (data.ret == 7) {
					location.href = '/login'
				}
			}else{
				var mysql = data.data.mysql ? data.data.mysql:' - - ' ;
				var monitor = data.data.monitor ? data.data.monitor:' - - ' ;
				var collect = data.data.collect ? data.data.collect:' - - ' ;
				objDom.mysql.html(mysql) ;
				objDom.monitor.html(monitor) ;
				objDom.collect.html(collect) ;
			}
		}
	}) 

	
	// 重启服务器

	
	function reboot(){
	objDom.iframe.show()
	objDom.userPasswordBox.show() ;
	objDom.confirm.click(function(){
		// 重启服务器
		var password = 	objDom.userPasswordPrompt.val().trim() ;
		console.log(password) ;
		$.ajax({
			url:'/monitor/restart-server',
			type:'post',
			data:{
				password:password
			},
			success:function(data){
				if (data.ret != 0) {
					if(data.ret == 7){
						location.href = '/login' ;
					}else{
						alert(data.msg)
					}
					
				}else{
					objDom.result.html('正在重启中...') ;
					objDom.rebootRrompt.style.color = 'red'
					setInterval(function(){
						
						objDom.rebootRrompt.style.color = 'green' ;
						objDom.iframe.hide() ;
						objDom.userPasswordBox.hide() ;
					},2000)
				}
			}
		})
	}) ;
	objDom.undo.click(function(){
		objDom.iframe.hide()
		objDom.userPasswordBox.hide() ;
	})
	
	// 重启进程状
	$.ajax({
		url:'/monitor/restart-process',
		type:'post',
		success:function(data){
			if(data.ret != 0){
				if (data.ret == 7) {
					location.href = '/login' ;
				}else{
					alert('请求数据失败')
				}
			}else{
				console.log(data.data)	
			    objDom.rebootRrompt.innerHTML = '进程正在重启中...'	;
				objDom.rebootRrompt.style.color = 'red'
				setInterval(function(){
				
				objDom.rebootRrompt.style.color = 'green' ;
				},2000)	
			}
		}
	})	;

	} ;
