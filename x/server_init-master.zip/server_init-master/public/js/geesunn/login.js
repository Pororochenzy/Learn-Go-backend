function login() {
    var account = $("#account").val();
    var password = $("#password").val();

    if ((!account) || (!password)) {
        return false;
    }
    $('.form-horizontal #account,.form-horizontal #password').focus(function() {
        $('#login-tips').html('')
    })

    $.ajax({
        url: "/login",
        type: "post",
        data: {
            "account": account,
            "password": password
        },
        processData: true,
        contentType: "application/x-www-form-urlencoded",
        success: function(data) {
            var rBody = eval(data);
            if (rBody.ret != 0) {
                // document.getElementById("login-tip").innerHTML = rBody.msg;
                $('#login-tips').html(rBody.msg)
            } else {
                location.href = "/";

                // //把用户名和密码存入localStorage
                // var userList = [];
                // var loginUser = {
                //     "account": account,
                //     "password": password
                // };
                // userList.push(loginUser);
                // var val = encodeURIComponent(JSON.stringify(userList));
                // localStorage.setItem("userList", val);
            }
        }
    });



}