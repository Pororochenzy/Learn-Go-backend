function logout() {
    $.ajax({
        url: "/logout",
        type: "post",
        success: function(data) {
            var rBody = eval(data);
            if (rBody.ret != 0) {
                if (rBody.ret == 7) {
                    location.href = "/login";    
                }
                document.getElementById("login-tip").innerHTML = rBody.msg;
            } else {
                location.href = "/login";
            }
        }
    });
}




$(function(){

    //头部导航栏功能=============
   // 获取服务器时间
   
    

    $.ajax({
        url:'/monitor/server-time', 
        type:'get',
        processData:true,
        success:function(data){
            if (data.ret != 0) {
                if (data.ret == 7) {
                    location.href = "/login";
                }
            }else{
                // console.log(data.data.servertime)
                $('#serverTime').html(data.data.servertime);
            }
        }
    }) ;

    // 每秒刷新 服务器时间 服务器运行时间 ；
     setInterval(function(){
        $.ajax({
        url:'/monitor/server-time',
        type:'get',
        processData:true,
        success:function(data){
            // console.log(data)
            var rBody = eval(data);
            // console.log(rBody)
            if(rBody.ret != 0){
                
                if (rBody.ret == 7) {
                    location.href = "/login";
                } else {
                    alert(rBody.msg)    
                }
            }else{
                // console.log(rBody.data.servertime)
                $('#serverTime').html(rBody.data.servertime) ;
                // $('#runningTime').html(data.data.runtime) ;
            }
        }
    }) ;
    },1000)
            
    //获取机型
    $.ajax({
        url:'/config/system',
        type:'get',
        success:function(rBody){
            // 机型 
            if (rBody.ret != 0) {
                if (rBody.ret == 7) {
                    location.href = "/login";
                } else {
                    alert(rBody.msg)    
                }
            }else{
              if (rBody.data.system == "All-In-One") {
                $('#header-device-model').html("GS-CM-50");
              } else {
                $('#header-device-model').html(rBody.data.system);
              }
            }
        }
    });

    //获取用户名
    $.ajax({
        url: '/user/get-system-user',
        type: 'get',
        success: function(rBody){
            if(rBody.ret !=0 ){
                if(rBody.ret == 7){
                    location.href = "/login";
                }else{
                    $('#common-popup').fadeIn(500).delay(2000).fadeOut(500);
                    $('#common-popup .content-tip').html(rBody.msg).addClass('fail');
                }
            }else{
                $('#user-entry .data-user').html(rBody.data.user);
            }
        }
    })
     
     //获取服务器上次重启时间
     $.get('/monitor/device-status',function(ret){
         $("#restart-time").text(ret.data.restart_time);
     });

   
     //显示重启系统的遮罩层
     $("#system-restart").click(function(){
        var tpl=[
            '<div class="app-modal">',
			'	<div class="app-box">',
			'		<h5>服务器重启</h5>',
			'		<form action="" method="post">',
			'			<div class="form-group">',
			'				<input type="password" name="password" placeholder="请输入密码" required="required" class="form-control input-xlarge">',
			'			</div>',
			'			<div class="form-group text-right">',
			'				<button type="reset" class="btn btn-default">取消重启</button>',
			'				<button type="submit" class="btn btn-default">确定重启</button>',
			'			</div>',
			'		</form>',
			'	</div>',
			'</div>',
        ].join('');
        $("body .app-modal").remove();
        $("body").append(tpl);
        $(".app-modal").fadeIn();
     });
     //关闭遮罩层
     $(document).on("click",".app-box [type=reset]",function(){
        $(".app-modal").fadeOut();
     });
    $(document).on("click",".app-modal",function(e){
        if(e.target==$(".app-modal")[0]) $(".app-modal [type=reset]").trigger("click");
     });
     //服务器重启提交
      $(document).on("click",".app-modal [type=submit]",function(e){
          e.preventDefault();
          var form=$(".app-modal form"),pwd=form.find("[name=password]"),value=pwd.val();
          if(value==""){
              pwd.focus();
              return;
          }else{
              $.post("/monitor/restart-server",{password:value},function(data){
                  if(data.ret==0){
                    tips_alert("success",data.msg,location.href);
                  }else{
                    tips_alert("danger",data.msg,"");
                  }
              });
          }
     });

     function tips_alert(cls,msg,url){
         $("body .alert").remove();
         var html=[
            '<div class="alert alert-'+cls+'">',
            '  <a href="#" class="close" data-dismiss="alert">&times;</a>',
            '   <span>'+msg+'</span>',
            '</div>',
         ].join('');
         $("body").append(html);
         $(".alert").fadeIn();
         setTimeout(function() {
            if(url){
                location.href=url;
            }else{
                $(".alert").fadeOut();
            }
         }, 2000);
        
     }

    //详细内容功能===============


    //侧边栏功能=============


    //按钮点击后变色
    // var tabIndex;
    $('#sidebar-menu li').click(function(){
       $(this).addClass('active').siblings().removeClass('active');
    })




    
    //公用弹窗功能=============
     $('<div id="common-popup">'
        +'<div class="content-tip"></div>'
        +'</div>').appendTo('body');



})


// =========公用函数封装==============

