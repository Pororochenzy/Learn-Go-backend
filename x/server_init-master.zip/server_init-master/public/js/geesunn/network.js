$(function(){



	var device_model = '';
	$.ajax({
        url:'/config/system',
        type:'get',
        success:function(rBody){
            // 机型 
            if (rBody.ret != 0) {
                if (rBody.ret == 7) {
                    location.href = "/login";
                } else {
                    alert(rBody.msg)    
                }
            }
            else{

            	device_model = rBody.data.system;
            	

            	$.ajax({
					url:'/config/networkcard-list',
					type:'get',
					processData:true,
					success:function(data){
						// 服务器运行时间 服务器时间 ;
						
						var rBody = eval(data);
						
						if(rBody.ret != 0){
							
							if (rBody.ret == 7) {
	                            location.href = "/login";
	               				} else {
		                    		$('#common-popup').fadeIn(500).delay(2000).fadeOut(500);
		                    		$('#common-popup .content-tip').html(rBody.msg).addClass('fail');   
	               				}
						}
						else{

							var ip_reset_form = $('#ip-reset-form') ;

			            	var dataList = rBody.data.list;

			            	console.log(dataList);

			            	//第一步先渲染内网网卡eth0，不用判断机型
			            	var eth0HTML = $('<form class="form-horizontal" action="javascript:void(0)"><fieldset><div class="control-group "><label class="control-label networkName-key" for="">网卡名称:</label><div class="controls"><input class="input-xlarge data-networkName disabled" required="required" id="" type="text" disabled/></div></div>'+
								'<div class="control-group"><label class="control-label " for=""><span class="star_required">*</span>IP</label><div class="controls"><input class="input-xlarge data-ip disabled focus-input" required="required" id="" type="text" ><span class="ip_errTip errTip"></span></div></div>'+
								'<div class="control-group"><label class="control-label " for="mask"><span class="star_required">*</span>子网掩码</label><div class="controls"> <input class="input-xlarge data-mask focused focus-input" id="" type="text" placeholder="" required="required"><span class="mask_errTip errTip"></span></div></div>'+
								'<div class="control-group"><label class="control-label" for="geteway">网关</label><div class="controls"> <input class="input-xlarge focused  data-gateway" id="" type="text" placeholder=""></div></div>'+
								'<div class="control-group"><label class="control-label " for="dns">DNS</label><div class="controls"><input class="input-xlarge focused data-dns" id="" type="text" placeholder="" ></div></div>'+
								'	<div class="control-group"><div class="controls"><button class="btn keep">保存修改</button></div> </div></fieldset></form>') ;
							ip_reset_form.append(eth0HTML);

							
							for(var i=0;i<dataList.length;i++){
								if(dataList[i].name=='eth0'){
									$('.networkName-key').eq(i).html('网卡名称');
									$('.data-networkName').eq(i).val("LAN") ;
									$('.data-ip').eq(i).val((rBody.data.list[i].ipaddr).replace(/\"/g,"")) ;
									$('.data-mask').eq(i).val((rBody.data.list[i].netmask).replace(/\"/g,"")) ;
									$('.data-gateway').eq(i).val((rBody.data.list[i].gateway).replace(/\"/g,"")) ;
									$('.data-dns').eq(i).val((rBody.data.list[i].dns).replace(/\"/g,"")) ;
								}
							}
						

							//第二步，渲染外网网卡eth1，判断机型不为采集器
							if(device_model != 'Collect'){
								var eth1HTML = $('<form class="form-horizontal" action="javascript:void(0)"><fieldset><div class="control-group "><label class="control-label networkName-key" for="">网卡名称:</label><div class="controls"><input class="input-xlarge data-networkName disabled" required="required" id="" type="text" disabled/></div></div>'+
								'<div class="control-group"><label class="control-label " for=""><span class="star_required">*</span>IP</label><div class="controls"><input class="input-xlarge data-ip disabled focus-input" required="required" id="" type="text" ><span class="ip_errTip errTip"></span></div></div>'+
								'<div class="control-group"><label class="control-label " for="mask"><span class="star_required">*</span>子网掩码</label><div class="controls"> <input class="input-xlarge data-mask focused focus-input" id="" type="text" placeholder="" required="required"><span class="mask_errTip errTip"></span></div></div>'+
								'<div class="control-group"><label class="control-label" for="geteway">网关</label><div class="controls"> <input class="input-xlarge focused  data-gateway" id="" type="text" placeholder=""></div></div>'+
								'<div class="control-group"><label class="control-label " for="dns">DNS</label><div class="controls"><input class="input-xlarge focused data-dns" id="" type="text" placeholder="" ></div></div>'+
								'	<div class="control-group"><div class="controls"><button class="btn keep">保存修改</button></div> </div></fieldset></form>') ;
								ip_reset_form.append(eth1HTML);

								for(var i=0;i<dataList.length;i++){
									if(dataList[i].name=='eth1'){
										$('.networkName-key').eq(i).html('网卡名称');
										$('.data-networkName').eq(i).val("WAN") ;
										$('.data-ip').eq(i).val((rBody.data.list[i].ipaddr).replace(/\"/g,"")) ;
										$('.data-mask').eq(i).val((rBody.data.list[i].netmask).replace(/\"/g,"")) ;
										$('.data-gateway').eq(i).val((rBody.data.list[i].gateway).replace(/\"/g,"")) ;
										$('.data-dns').eq(i).val((rBody.data.list[i].dns).replace(/\"/g,"")) ;
									}
								}
							}

							//输入框聚焦后提示信息消失
							$('#ip-reset-form .focus-input').focus(function(){
								$(this).siblings('.errTip').hide();
							})

							//内网卡/外网卡 保存修改
							$('#ip-reset-form .keep').click(function(){
							    var name = $(this).parents().siblings('.control-group').find('.data-networkName').val() ;
							    if (name=="LAN") {
							    	name = "eth0"
							    } else if (name=="WAN") {
							    	name = "eth1"
							    }
							    var ip =   $(this).parents().siblings('.control-group').find('.controls').find('.data-ip').val() 
							    var mask    =   $(this).parents().siblings('.control-group').find('.data-mask').val() 
							    var gateway =   $(this).parents().siblings('.control-group').find('.data-gateway').val() 
							    var dns     =   $(this).parents().siblings('.control-group').find('.data-dns').val() 

							    var pattern = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/;
								var testIP = pattern.test(ip);
								var testMask = pattern.test(mask);
								if(testIP && testMask){
									var left=($("body")[0].clientWidth-500)/2;
									$('#common-popup').css({left:left+"px"});
									var kv = [{'key':'IPADDR','value':ip},{'key':'NETMASK','value':mask},{'key':'GATEWAY','value':gateway},{'key':'DNS','value':dns}];
									$.ajax({
								    	url:'/config/reset-networkcard',
								    	type:'post',
								    	data:{
								    		name:name,
								    		kv: JSON.stringify(kv),
								    		restart: 0	    		
								    		},
								    	success:function(data){
								    		if(data.ret != 0){
								    			if(data.ret == 7){
								    				location.href = "/login";
								    			}else{
								    				$('#common-popup').fadeIn(500).delay(1000).fadeOut(500);
                                 					$('#common-popup .content-tip').html(rBody.msg).addClass('fail');
								    			}
								    		}else{
								    			$('#common-popup').fadeIn(500).delay(1000).fadeOut(500);
                                 				$('#common-popup .content-tip').html('修改成功，重启系统生效！').addClass('pass');
								    		}
								    	}
							    	})
								}else{
									if(!testIP && testMask){
										$(this).parents().siblings('.control-group').find('.ip_errTip').show().html('* 格式错误');
									}
									else if( testIP && !testMask){
										$(this).parents().siblings('.control-group').find('.mask_errTip').show().html('* 格式错误');
									}
									else{
										$(this).parents().siblings('.control-group').find('.ip_errTip').show().html('* 格式错误');
										$(this).parents().siblings('.control-group').find('.mask_errTip').show().html('* 格式错误');
									}								
								}


							})

							//第三步, 渲染采集器上传IP, 判断机型不为控制器
							if(device_model == 'Collect'){
								var collectHTML = $('<div class="box" id="collectBox">'
			                		+'<div class="box-header well" data-original-title>'
			                	    +'<h2><i class="icon-edit"></i>采集器数据上传IP设置</h2>'
			                	    +'</div>'
			                	    +'<form class="form-horizontal" action="javascript:void(0)">'
			                		+'<div class="control-group"><label class="control-label " for=""><span class="star_required">*</span>IP</label><div class="controls"><input class="input-xlarge data-ip disabled" id="collect-ip" type="text" /><span id="collect-ip-errTip"></span></div></div>'
			                		+'<div class="control-group"><div class="controls"><button class="btn keep" id="save-ip">保存设置</button></div></div>'
			                		+'</form></div>');
			                	
			                	$('#content').append(collectHTML);

	                			//聚焦后错误提示消失
			                	$('#content #collect-ip').focus(function(){
			                		$('#collect-ip-errTip').hide();
			                	})


			                	//采集器IP设置按钮
			                	$('#content #save-ip').click(function(){


									var collectIP = $('#collect-ip').val();
									var pattern = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/;
									var testIP = pattern.test(collectIP);


									if(testIP){
										$.ajax({
											url:'/config/set-collect-upload-ip',
								        	type:'Post',
								        	data: {
								        		"ip": collectIP
								        	},
								        	success: function(){

									        	if (rBody.ret != 0) {
									        		if (rBody.ret == 7) {
									                    location.href = "/login";
									                } else {
									                    $('#common-popup').fadeIn(500).delay(1000).fadeOut(500);
                                 						$('#common-popup .content-tip').html(rBody.msg).addClass('fail');  
									                }
									        	}else{
									        		$('#common-popup').fadeIn(500).delay(1000).fadeOut(500);
                                 					$('#common-popup .content-tip').html('修改成功!').addClass('pass');
									        	}
									        }
										})
									}else{
										$('#collect-ip-errTip').show().html('* 格式错误');
									}
									
								})
							}
						}
					}
					//success ends
				
				})
            }
        }
	
	})
})
	  

