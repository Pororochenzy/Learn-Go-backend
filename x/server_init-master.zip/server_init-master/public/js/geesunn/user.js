
$(function(){

    var test_oldpwd = false;
    var test_pwd = false;
    var test_pwd2 = false;
    var test_monitor_pwd = false;
    var test_monitor_pwd2 = false;

    var reg = /^(?![\d]+$)(?![a-zA-Z]+$)(?![!#$%^&*.]+$)[\da-zA-Z!#$%^&*.]{8,16}$/;

    //根据机型显示密码重置类型

    var device_model = '';
    $.ajax({
        url:'/config/system',
        type:'get',
        success:function(rBody){
            // 机型 
            if (rBody.ret != 0) {
                if (rBody.ret == 7) {
                    location.href = "/login";
                } else {
                    alert(rBody.msg)    
                }
            }else{
                device_model = rBody.data.system;
                if(device_model!='Collect'){
                    var monitorHTML = $('<form class="form-horizontal reset-form" action="javascript:void(0)">'
                            +'<fieldset id="reset-monitor-form">'
                            +'    <h5 class="form-title">设置智象运维初始密码</h5>'
                            +'    <div class="control-group">'
                            +'        <label class="control-label" for="monitor_username">用户名</label>'
                            +'        <div class="controls">'
                            +'          <input class="input-xlarge disabled username" id="monitor_username" type="text" disabled>'
                            +'        </div>'
                            +'    </div>'
                            +'    <div class="control-group">'
                            +'        <label class="control-label" for="monitor_account">账号</label>'
                            +'        <div class="controls">'
                            +'          <input class="input-xlarge disabled" id="monitor_account" type="text" disabled>'
                            +'        </div>'
                            +'    </div>'
                            +'    <div class="control-group">'
                            +'        <label class="control-label" for="monitor_new_password" id="new_passwordFirst"><span class="star_required">*</span>新密码</label>'
                                    
                            +'        <div class="controls">'
                            +'          <input class="input-xlarge focused" id="monitor_new_password" type="password" placeholder="请输入新密码" required="required">'
                            +'          <span id="monitor_new_password_prompt" class="pwd-errTip"></span>'
                            +'        </div>'
                            +'    </div>'
                            +'    <div class="control-group">'
                            +'        <label class="control-label" for="monitor_new_password_confirm"><span class="star_required">*</span>新密码确认</label>'
                            +'        <div class="controls">'
                            +'          <input class="input-xlarge focused" id="monitor_new_password_confirm" type="password" placeholder="确认密码" required="required">'
                            +'        </div>'
                            +'    </div>'
                            +'    <div class="control-group">'
                            +'        <div class="controls">'
                            +'            <button class="btn btn-primary" id="reset_monitor_btn" >保存修改</button>'
                            +'        </div>'
                            +'     </div>'

                            +'</fieldset>'
                        +'</form>');

                    $('#content .box-content').append(monitorHTML);

                    //默认获取monitor初始管理员用户名和账户,并自动填入
                    $.ajax({
                        url:'/user/get-monitor-account',
                        type:'get',
                        success:function(rBody){
                            // 机型 
                            if (rBody.ret != 0) {
                                if (rBody.ret == 7) {
                                    location.href = "/login";
                                } else {
                                    alert(rBody.msg)    
                                }
                            }else{
                                // console.log(rBody.data)
                                $('#monitor_username').val(rBody.data.user).css('color','#999');             
                                $('#monitor_account').val(rBody.data.account).css('color','#999'); 
                            }
                        }
                    });

                    //验证monitor初始管理员新密码
                    $('#monitor_new_password').change(function(){
                        test_monitor_pwd = reg.test($('#monitor_new_password').val());
                        if(test_monitor_pwd){
                            $('#monitor_new_password_prompt').html('输入正确').css('color','green');
                        }else{
                            $('#monitor_new_password_prompt').html('* 新密码至少包括字母数字特殊字符两种组合8到16位').css({'color':'red'});
                        }
                    })

                    //验证monitor两次密码是否一致
                    $('#monitor_new_password_confirm').change(function(){
                       fn_test_monitorpwd();
                       
                    })

                    //保存monitor密码修改
                    $('#reset_monitor_btn').click(function(){

                        fn_test_monitorpwd();

                        test_monitor_pwd = reg.test($('#monitor_new_password').val());
                        test_monitor_pwd2 = $('#monitor_new_password').val() == $('#monitor_new_password_confirm').val() ? true : false;
                        

                        if ((!test_monitor_pwd) || (!test_monitor_pwd2)) {
                            // alert('moniotor输入有误，请重新输入！');
                            return false;
                        }

                        if(test_monitor_pwd && test_monitor_pwd2){

                            $('#monitor_new_password_prompt').html('');

                            var monitor_username = $('#monitor_username').val();
                            var monitor_account = $('#monitor_account').val();
                            var monitor_new_password = $("#monitor_new_password").val();


                            $.ajax({
                                url: "/user/reset-monitor-account",
                                type: "post",
                                data: {
                                    "user": monitor_username,
                                    "account": monitor_account,
                                    "password": monitor_new_password
                                },
                                processData: true,
                                contentType: "application/x-www-form-urlencoded",
                                success: function(data) {
                                    var rBody = eval(data);
                                    console.log(rBody.data);
                                    if (rBody.ret != 0) {
                                         if (rBody.ret == 7) {
                                            location.href = "/login";
                                        } else {
                                            $('#common-popup').fadeIn(500).delay(2000).fadeOut(500);
                                            $('#common-popup .content-tip').html(rBody.msg).addClass('fail');   
                                        }
                                    } else {
                                        $('#common-popup').fadeIn(500).delay(2000).fadeOut(500);
                                        $('#common-popup .content-tip').html('初始密码设置成功').addClass('pass');

                                        $("#monitor_new_password").val("");
                                        $("#monitor_new_password_confirm").val("");
                                    }
                                }
                            });    
                        }
                    })

                    // ======monitor函数封装========

                    //验证两次密码是否一致，包含前提条件验证
                    function fn_test_monitorpwd(){
                        test_monitor_pwd = reg.test($('#monitor_new_password').val());
                        if(test_monitor_pwd){
                            test_monitor_pwd2 = $('#monitor_new_password').val() == $('#monitor_new_password_confirm').val() ? true : false;
                            // console.log(test_monitor_pwd2,11111)
                            if(!test_monitor_pwd2) $('#monitor_new_password_prompt').html('两次密码输入不一致').css({'color':'red'});
                            return false;
                        }else{
                            $('#monitor_new_password_prompt').html('新密码至少包括字母数字特殊字符两种组合8到16位').css({'color':'red'});
                            return false;
                        }
                    }
                }
            }
        }
    });

    //默认获取用户名,并自动填入
   $.ajax({
        url:'/user/get-system-user',
        type:'get',
        success:function(rBody){
            // 机型 
            if (rBody.ret != 0) {
                if (rBody.ret == 7) {
                    location.href = "/login";
                } else {
                    alert(rBody.msg)    
                }
            }else{
                $('#username').val(rBody.data.user).css('color','#999');             
            }
        }
    });

   
    
    $('#old_password').change(function(){
        test_oldpwd = $('#old_password').val().length>0 ? true : false;
        if(test_oldpwd){
            $('#old_password_prompt').html('');
        }
    })

    
           
     //验证用户新密码
    $('#new_password').change(function(){

        test_oldpwd = $('#old_password').val().length>0 ? true : false;

        if(test_oldpwd){
            $('#old_password_prompt').html('');
            test_pwd = reg.test($('#new_password').val());
            if(test_pwd){
                $('#new_password_prompt').html('新密码输入正确').css('color','green');

            }else{
               $('#new_password_prompt').html('* 新密码至少包括字母数字特殊字符两种组合8到16位').css({'color':'red'});
            }
        }else{
            $('#old_password_prompt').html('* 密码不能为空').css('color','red');
        }

        
    })
 
    //验证两次密码是否一致
    $('monitor_new_password_confirm').change(function(){

       fn_testpwd();
    })
    



    //保存修改
    $('#reset_password_btn').click(function(){
        
        fn_testpwd(); 

        test_oldpwd = $('#old_password').val().length>0 ? true : false;
        test_pwd = reg.test($('#new_password').val());
        test_pwd2 = $('#new_password').val() == $('#new_password_confirm').val() ? true : false;


        if ((!test_oldpwd) || (!test_pwd) || (!test_pwd2)) {
            return false;
        }
        

        if(test_oldpwd && test_pwd && test_pwd2){
            var old_password = $("#old_password").val();
            var new_password = $("#new_password").val();


            $('#new_password_prompt').html('');

            $.ajax({
                url: "/user/reset-password",
                type: "post",
                data: {
                    "old_password": old_password,
                    "new_password": new_password
                },
                processData: true,
                contentType: "application/x-www-form-urlencoded",
                success: function(data) {
                    var rBody = eval(data);
                    if (rBody.ret != 0) {
                         if (rBody.ret == 7) {
                            location.href = "/login";
                        } else {
                            $('#common-popup').fadeIn(500).delay(2000).fadeOut(500);
                            $('#common-popup .content-tip').html(rBody.msg).addClass('fail');   
                        }
                    } else {
                        $('#common-popup').fadeIn(500).delay(2000).fadeOut(500);
                        $('#common-popup .content-tip').html('修改成功!').addClass('pass');
                        $("#old_password").val("");
                        $("#new_password").val("");
                        $("#new_password_confirm").val("");
                    }
                }
            });
        }
    })


// ==========密码修改函数封装===============

// 验证两次密码是否一致，包含前提条件验证
function fn_testpwd(){
   test_oldpwd = $('#old_password').val().length>0 ? true : false;

    if(test_oldpwd){
        $('#old_password_prompt').html('');
        test_pwd = reg.test($('#new_password').val());
        if(test_pwd){
            test_pwd2 = $('#new_password').val() == $('#new_password_confirm').val() ? true : false;
            // console.log(test_pwd2,11111)
            if(test_pwd2){
                 $('#new_password_prompt').html('两次密码输入一致').css('color','green');
            }else{
                $('#new_password_prompt').html('* 两次密码输入不一致').css({'color':'red'});
            }
            return false;
        }else{
            $('#new_password_prompt').html('* 新密码至少包括字母数字特殊字符两种组合8到16位').css({'color':'red'});
            return false;
        }

    }else{
        $('#old_password_prompt').html('* 密码不能为空').css('color','red');
        return false;
    }  
}


})//$ ends








