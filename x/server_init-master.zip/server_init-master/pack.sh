#!/bin/bash

WORKSPACE=$(cd $(dirname $0)/; pwd)
cd $WORKSPACE

app=geesunn-server_init
src=gsn/server_init
build_dir=~/geesunn/build
targz_dir=~/geesunn/targz

function build() {
    mkdir -p $build_dir
    rm -fr $build_dir/$app/
    revel build $src $build_dir/$app
    if [[ $? -gt 0 ]];
    then
        echo "build falid"
        return 1
    fi    
	echo "===================以上为编译信息======================"
    cp -fr control.sh $build_dir/$app/src/
    # 删除多余的信息
    mkdir -p $build_dir/$app/src/tmp/app
    cp -fr $build_dir/$app/src/$src/conf $build_dir/$app/src/tmp/
    cp -fr $build_dir/$app/src/$src/public $build_dir/$app/src/tmp/
    cp -fr $build_dir/$app/src/$src/app/views $build_dir/$app/src/tmp/app
    rm -fr $build_dir/$app/src/$src/
    mv $build_dir/$app/src/tmp/ $build_dir/$app/src/$src/

    case "$1" in
        "test")
            cd $build_dir/$app/src/$src/conf
            rm -fr geesunn.conf geesunn.conf.pro
            mv geesunn.conf.test geesunn.conf
            /usr/local/bin/gmo encf geesunn.conf
            rm -fr geesunn.conf
        ;;
        "pro")
            cd $build_dir/$app/src/$src/conf
            rm -fr geesunn.conf geesunn.conf.test
            mv geesunn.conf.pro geesunn.conf
            /usr/local/bin/gmo encf geesunn.conf
            rm -fr geesunn.conf
        ;;
        *)
        ;;
    esac

    if [ -d $build_dir/$app ]; then  
        echo "1) build: $build_dir/$app"
        return 0
    else
        echo "2) build: failed" 
        return 1
    fi
}

function targz() {
	mkdir -p $targz_dir
    build "$1"
	cd $build_dir
	tar -zcf $targz_dir/$app.tar.gz $app
    if [ -f $targz_dir/$app.tar.gz ]; then  
        echo "2) targz: $targz_dir/$app.tar.gz" 
        return 0
    else
        echo "2) targz: failed" 
        return 1
    fi
}

function help() {
    echo "$0 build|targz"
}

case "$1" in 
    "build")
        build "$2"
        exit $?
        ;;
    "targz")
        targz "$2"
        exit $?
        ;;
    *)
        help
        exit 1
        ;;
esac
