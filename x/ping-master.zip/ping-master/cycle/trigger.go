package cycle

import (
	"gsn/ping/global"
	"gsn/ping/logic"
	"strings"
	"time"

	gs_define "geesunn.com/define"
)

// 缓存设置过期时间
func SetCycleKeyExpire(db int, key string, monitor_cycle int) {
	if !strings.HasPrefix(key, "collect:") {
		key = "collect:" + key
	}
	key = "cycle:" + key
	global.CCacheDB.SET(db, key, 1)
	global.CCacheDB.SetExpire(db, key, monitor_cycle)
}

const (
	IPPrefix   = "ip:"
	PortPrefix = "collect:port:"
)

// 需要执行的任务
func CycleTask() []string {
	start := time.Now()
	defer func(start time.Time) {
		use := time.Since(start)
		if use > time.Millisecond*500 {
			global.Logger.Info("cycle task 耗时:%v", use)
		}
	}(start)
	taskKeys := []string{}
	// 需要检测的IP列表
	{
		keys, _ := global.CCacheDB.RegularKeys(gs_define.REDIS_COLLECT_DB, IPPrefix+"*")
		for _, key := range keys {
			exist, err := global.CCacheDB.IsKeyExist(gs_define.REDIS_COLLECT_DB, "cycle:collect:"+key)
			if exist == 0 && err == nil {
				taskKeys = append(taskKeys, key)
			}
		}
	}
	// 需要检测的端口列表
	{
		keys, _ := global.CCacheDB.RegularKeys(gs_define.REDIS_COLLECT_DB, PortPrefix+"*")
		for _, key := range keys {
			exist, err := global.CCacheDB.IsKeyExist(gs_define.REDIS_COLLECT_DB, "cycle:"+key)
			if exist == 0 && err == nil {
				taskKeys = append(taskKeys, key)
			}
		}
	}

	return taskKeys
}

// 防止短期内重复采集
func PrevCycleAgain(key string) {
	// 先设置一个60分钟,运行的时候会重新设置过期时间
	SetCycleKeyExpire(gs_define.REDIS_COLLECT_DB, key, 3600)
}

// 采集触发器
// 检查是否监控指标是否需要进行采集了
func CollectTrigger() {
	defer logic.HanderPanic()
	global.CCacheDB.DelRegularKeys(gs_define.REDIS_COLLECT_DB, "cycle:collect:ping:*")
	global.CCacheDB.DelRegularKeys(gs_define.REDIS_COLLECT_DB, "cycle:collect:port:*")
	for {
		func() {
			defer logic.HanderPanic()
			// 检查需要采集的内容
			keys := CycleTask()
			if len(keys) > 0 {
				global.Logger.Info("Redis拉取到即将采集的指标：%v", keys)
				for _, key := range keys {
					if strings.HasPrefix(key, IPPrefix) {
						if len(global.PingTaskQueue) < cap(global.PingTaskQueue) {
							PrevCycleAgain(key)
							global.PingTaskQueue <- gs_define.TaskQueueUnit{
								Type: gs_define.COLLECT_TYPE_CYCLE,
								Data: map[string]interface{}{"key": key},
							}
						}
					} else if strings.HasPrefix(key, PortPrefix) {
						if len(global.PortTaskQueue) < cap(global.PortTaskQueue) {
							PrevCycleAgain(key)
							global.PortTaskQueue <- gs_define.TaskQueueUnit{
								Type: gs_define.COLLECT_TYPE_CYCLE,
								Data: map[string]interface{}{"key": key},
							}
						}
					}
				}
			}
		}()
		time.Sleep(time.Second * 2)
	}
}

func StartCollect() {
	go pingIP()
	go pingPort()
	go CollectTrigger()
}
