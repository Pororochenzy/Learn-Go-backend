package cycle

import (
	"encoding/json"
	"fmt"
	"gsn/ping/global"
	"gsn/ping/logic"
	"gsn/ping/mq"

	"geesunn.com/gpool"

	gs_define "geesunn.com/define"
	gs_ping "geesunn.com/ping"
	gs_tool "geesunn.com/tool"
)

type pingCache struct {
	DeviceID     int64  `json:"device_id"`
	Flag         int64  `json:"flag"`
	IP           string `json:"ip"`
	MonitorCycle int64  `json:"monitor_cycle"`
}

func getPingFromCache(key string) *pingCache {
	info, err := global.CCacheDB.GetString(gs_define.REDIS_COLLECT_DB, key)
	if err != nil {
		global.Logger.Error("%v %v", key, err.Error())
		return nil
	}

	data := pingCache{}
	if err := json.Unmarshal([]byte(info), &data); err != nil {
		global.Logger.Error(err.Error())
		return nil
	}
	return &data
}

var (
	checkIPPool = gpool.NewGoPool(1000)
)

// Ping IP 采集程序
func pingIP() {
	for {
		tqu := <-global.PingTaskQueue
		checkIPPool.GetGo()

		go func(tqu gs_define.TaskQueueUnit) {
			defer logic.HanderPanic()
			defer checkIPPool.ReleaseGo()

			switch tqu.Type {
			case gs_define.COLLECT_TYPE_CYCLE:
				key := tqu.Data["key"].(string)
				data := getPingFromCache(key)
				if data != nil {
					global.Logger.Info("%v %v", key, data.MonitorCycle)
					SetCycleKeyExpire(gs_define.REDIS_COLLECT_DB, key, int(data.MonitorCycle))

					m := getPingInfo(data)

					dataBytes, _ := json.Marshal(m)

					if err := mq.Push2Collect(gs_define.MQMsg{
						MQType:   gs_define.MQ_TYPE_PING_COLLECT,
						UUID:     gs_tool.NewUUID(),
						From:     "ping",
						To:       gs_define.M_CACHE_CCHANDLER_RECV_QUEUE,
						Unixtime: gs_tool.CurrentTimeSecond(),
						Data:     string(dataBytes),
					}); err != nil {
						global.Logger.Error(err.Error())
					}
				} else {
					global.CCacheDB.DELKey(gs_define.REDIS_COLLECT_DB, "cycle:collect:"+key)
				}
			case gs_define.COLLECT_TYPE_INSPECT:
				key := fmt.Sprintf("ip:%v", tqu.Data["ip"])
				data := getPingFromCache(key)
				if data != nil {
					m := getPingInfo(data)
					dataBytes, _ := json.Marshal(m)

					if err := mq.Push2Collect(gs_define.MQMsg{
						MQType:   gs_define.MQ_TYPE_PING_INSPECT,
						UUID:     tqu.Data["uuid"].(string),
						From:     "ping",
						To:       gs_define.M_CACHE_MCENTER_RECV_QUEUE,
						Unixtime: gs_tool.CurrentTimeSecond(),
						Data:     string(dataBytes),
					}); err != nil {
						global.Logger.Error(err.Error())
					}
				}
			}
		}(tqu)
	}
}

func getPingInfo(data *pingCache) map[string]interface{} {
	m := map[string]interface{}{
		"device_id":    data.DeviceID,
		"flag":         data.Flag,
		"ip":           data.IP,
		"unixtime":     gs_tool.CurrentTimeSecond(),
		"ping_connect": "off",
	}

	// 是否存活
	lostpercent, timeout := gs_ping.Ping(data.IP, 5)
	// lostpercent, timeout := 80, 12
	m["ping_lost_percent"] = lostpercent
	m["ping_timeout"] = timeout
	if lostpercent < 100 {
		m["ping_connect"] = "on"
	} else {
		m["ping_connect"] = "off"
	}
	global.Logger.Info("采集到%v，状态：%v", data.IP, m["ping_connect"])
	global.Logger.Debug("%v, 其他%v", data.IP, m)
	return m
}
