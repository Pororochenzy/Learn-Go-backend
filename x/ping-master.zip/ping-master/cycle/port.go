package cycle

import (
	"encoding/json"
	"fmt"
	"gsn/ping/global"
	"gsn/ping/logic"
	"gsn/ping/mq"
	"net"
	"time"

	gs_define "geesunn.com/define"
	"geesunn.com/gpool"
	gs_tool "geesunn.com/tool"
)

type portCache struct {
	ObjectID      int64  `json:"object_id"`
	ObjectType    string `json:"object_type"`
	IP            string `json:"ip"`
	Port          int64  `json:"port"`
	MonitorItemID int64  `json:"monitor_item_id"`
	MonitorCycle  int64  `json:"monitor_cycle"`
}

func getPortFromCache(key string) *portCache {
	info, err := global.CCacheDB.GetString(gs_define.REDIS_COLLECT_DB, key)
	if err != nil {
		global.Logger.Error("%v %v", key, err.Error())
		return nil
	}

	data := portCache{}
	if err := json.Unmarshal([]byte(info), &data); err != nil {
		global.Logger.Error(err.Error())
		return nil
	}
	return &data
}

var (
	checkPortPool = gpool.NewGoPool(1000)
	timeout       = time.Second * 3
)

// Ping采集程序
func pingPort() {
	for {
		tqu := <-global.PortTaskQueue
		checkPortPool.GetGo()

		go func(tqu gs_define.TaskQueueUnit) {
			defer logic.HanderPanic()
			defer checkPortPool.ReleaseGo()

			switch tqu.Type {
			case gs_define.COLLECT_TYPE_CYCLE:
				key := tqu.Data["key"].(string)
				data := getPortFromCache(key)
				if data != nil {
					global.Logger.Info("%v %v", key, data.MonitorCycle)
					SetCycleKeyExpire(gs_define.REDIS_COLLECT_DB, key, int(data.MonitorCycle))

					m := getPortCheckInfo(data)
					global.Logger.Debug("端口检测情况：%v", m)

					dataBytes, _ := json.Marshal(m)

					if err := mq.Push2Collect(gs_define.MQMsg{
						MQType:   gs_define.MQ_TYPE_PORT_COLLECT,
						UUID:     gs_tool.NewUUID(),
						From:     "ping",
						To:       gs_define.M_CACHE_CCHANDLER_RECV_QUEUE,
						Unixtime: gs_tool.CurrentTimeSecond(),
						Data:     string(dataBytes),
					}); err != nil {
						global.Logger.Error(err.Error())
					}
				} else {
					global.CCacheDB.DELKey(gs_define.REDIS_COLLECT_DB, "cycle:collect:"+key)
				}
				// case gs_define.COLLECT_TYPE_INSPECT:
				// 	key := tqu.Data["key"].(string)
				// 	data := getPortFromCache(key)
				// 	if data != nil {
				// 		m := getPortCheckInfo(data)
				// 		global.Logger.Debug("端口检测情况：%v", m)
				// 		dataBytes, _ := json.Marshal(m)

				// 		if err := mq.Push2Collect(gs_define.MQMsg{
				// 			MQType:   gs_define.MQ_TYPE_PORT_COLLECT,
				// 			UUID:     tqu.Data["uuid"].(string),
				// 			From:     "ping",
				// 			To:       gs_define.M_CACHE_MCENTER_RECV_QUEUE,
				// 			Unixtime: gs_tool.CurrentTimeSecond(),
				// 			Data:     string(dataBytes),
				// 		}); err != nil {
				// 			global.Logger.Error(err.Error())
				// 		}
				// 	}
			}
		}(tqu)
	}
}

// 检测端口的状态
func getPortCheckInfo(data *portCache) map[string]interface{} {
	m := map[string]interface{}{
		"object_id":       data.ObjectID,
		"object_type":     data.ObjectType,
		"monitor_item_id": data.MonitorItemID,
		"ip":              data.IP,
		"port":            data.Port,
		"status":          "off",
		"err_msg":         "",
		"monitor_cycle":   data.MonitorCycle,
		"unixtime":        gs_tool.CurrentTimeSecond(),
	}

	if net.ParseIP(data.IP) == nil {
		m["errmsg"] = "IP格式错误"
		return m
	}
	address := fmt.Sprintf("%v:%v", data.IP, data.Port)
	conn, err := net.DialTimeout("tcp", address, timeout)

	defer func() {
		if conn != nil {
			conn.Close()
		}
	}()

	if err != nil {
		m["errmsg"] = err.Error()
		m["status"] = "off"
		return m
	}
	m["status"] = "on"
	return m
}
