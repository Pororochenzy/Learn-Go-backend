// 本包存放全局变量
package global

import (
	"fmt"
	"io/ioutil"
	"path/filepath"

	"geesunn.com/lib/redis"

	"strings"

	gs_define "geesunn.com/define"
	"geesunn.com/encrypt"
	"geesunn.com/logs"
	"geesunn.com/tool"
	"github.com/Unknwon/goconfig"
)

var (
	// Collect 缓存对象
	CCacheDB redis.Redis
	// 工程全局配置对象
	Config *goconfig.ConfigFile
	// 日志对象
	Logger = logs.NewLogger()
	// 任务队列
	TaskQueue = make(chan gs_define.TaskQueueUnit, 10000)
	// mib库路径
	MibBasePath string
)

func InitSystem(path string) {
	// 加载配置
	for _, f := range []string{"app.conf", "app.conf.test", "app.conf.pro", "app.conf.enc"} {
		newPath := filepath.Join(path, f)
		if strings.HasSuffix(newPath, ".enc") {
			bytes, err := ioutil.ReadFile(newPath)
			if err != nil {
				panic(err)
			}
			decBytes, err := encrypt.AesDecrypt(bytes, []byte(encrypt.EncryptFLKey))
			if err != nil {
				panic(err)
			}
			Config, _ = goconfig.LoadFromData(decBytes)
		} else {
			if tool.IsFileExist(newPath) {
				c, err := goconfig.LoadConfigFile(newPath)
				if err != nil {
					panic(err)
				}
				Config = c
			}
		}
		if Config != nil {
			break
		}
	}
	// 日志
	fileSwitch := Config.MustValue("log", "fileswitch")
	fileName := Config.MustValue("log", "filename")
	level := Config.MustValue("log", "level")
	daily := Config.MustValue("log", "daily")
	maxdays := Config.MustValue("log", "maxdays")
	if fileSwitch == "on" {
		if err := Logger.SetLogger(logs.AdapterFile, fmt.Sprintf(`{"filename": "%v", "daily": %v, "maxdays": %v, "level": %v}`, fileName, daily, maxdays, level)); err != nil {
			panic(err)
		}
	} else {
		if err := Logger.SetLogger(logs.AdapterConsole); err != nil {
			panic(err)
		}
	}
	// 设置日志输出文件名和文件行号
	Logger.EnableFuncCallDepth(true)

	if err := CCacheDB.Init(Config.MustValue("redis", "host"), Config.MustInt("redis", "port"),
		Config.MustValue("redis", "password"), Config.MustInt("redis", "max_conn"), Config.MustInt("redis", "max_idle_conn")); err != nil {
		panic(err)
	}

	MibBasePath = Config.MustValue("static", "snmp_template_path")
}
