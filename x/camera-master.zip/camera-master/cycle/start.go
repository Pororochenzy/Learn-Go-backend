package cycle

import (
	"camera/global"
	"camera/logic"
	"camera/mq"
	"encoding/json"
	"io/ioutil"
	"path"
	"strings"
	"sync"

	"geesunn.com/gpool"
	yaml "gopkg.in/yaml.v2"

	gs_define "geesunn.com/define"
	gs_tool "geesunn.com/tool"
)

type cache struct {
	ID                int64  `json:"id"`
	Brand             string `json:"brand"`
	IP                string `json:"ip"`
	SnmpAuthPro       string `json:"snmp_auth_pro"`
	SnmpAuthPassword  string `json:"snmp_auth_password"`
	SnmpDataPro       string `json:"snmp_data_pro"`
	SnmpDataPassword  string `json:"snmp_data_password"`
	SnmpPort          int64  `json:"snmp_port"`
	SnmpReadComunity  string `json:"snmp_read_comunity"`
	SnmpSecurityLevel string `json:"snmp_security_level"`
	SnmpUser          string `json:"snmp_user"`
	SnmpVersion       string `json:"snmp_version"`
	MonitorCycle      int64  `json:"monitor_cycle"`
}

func getFromCache(key string) *cache {
	info, err := global.CCacheDB.GetString(gs_define.REDIS_COLLECT_DB, key)
	if err != nil {
		global.Logger.Error("%v %v", key, err.Error())
		return nil
	}

	data := cache{}
	if err := json.Unmarshal([]byte(info), &data); err != nil {
		global.Logger.Error(err.Error())
		return nil
	}
	return &data
}

var (
	checkIPPool = gpool.NewGoPool(100)
	running     = struct {
		sync.Mutex
		M map[string]bool
	}{
		M: map[string]bool{},
	}
)

// 采集程序
func start() {
	for {
		tqu := <-global.TaskQueue

		checkIPPool.GetGo()

		key := tqu.Data["key"].(string)
		// 在采集的设备，避免重复采集
		{
			running.Lock()
			if v, ok := running.M[key]; ok && v {
				running.Unlock()
				continue
			}
			running.Unlock()
		}

		go func(tqu gs_define.TaskQueueUnit) {

			defer logic.HanderPanic()

			defer func() {
				running.Lock()
				running.M[key] = false
				running.Unlock()
				// 释放协程
				checkIPPool.ReleaseGo()
			}()
			// 设置设备正在采集中
			{
				running.Lock()
				running.M[key] = true
				running.Unlock()
			}

			switch tqu.Type {
			case gs_define.COLLECT_TYPE_CYCLE:
				data := getFromCache(key)
				if data != nil {
					global.Logger.Info("%v %v", key, data.MonitorCycle)
					SetCycleKeyExpire(gs_define.REDIS_COLLECT_DB, key, int(data.MonitorCycle))

					m := getInfo(data)

					dataBytes, _ := json.Marshal(m)

					if err := mq.Push2Collect(gs_define.MQMsg{
						MQType:   gs_define.MQ_TYPE_CAMERA_COLLECT,
						UUID:     gs_tool.NewUUID(),
						From:     "camera",
						To:       gs_define.M_CACHE_CCHANDLER_RECV_QUEUE,
						Unixtime: gs_tool.CurrentTimeSecond(),
						Data:     string(dataBytes),
					}); err != nil {
						global.Logger.Error(err.Error())
					}
				} else {
					global.CCacheDB.DELKey(gs_define.REDIS_COLLECT_DB, "cycle:"+key)
				}
			case gs_define.COLLECT_TYPE_INSPECT:
			}
		}(tqu)
	}
}

var (
	mibTemplate = struct {
		sync.Mutex
		M map[string][]gs_define.OidInfo
	}{
		M: map[string][]gs_define.OidInfo{},
	}
)

func getMIBTemplate(brand string) []gs_define.OidInfo {

	brand = strings.ToUpper(brand)

	mibTemplate.Lock()
	defer mibTemplate.Unlock()
	if v, ok := mibTemplate.M[brand]; ok {
		return v
	} else {
		oids := []gs_define.OidInfo{}

		mibPath := path.Join(global.MibBasePath, brand, brand+"_default.yml")
		if gs_tool.IsFileExist(mibPath) {
			bytes, err := ioutil.ReadFile(mibPath)
			if err != nil {
				global.Logger.Error(err.Error())
			} else {
				if err := yaml.Unmarshal(bytes, &oids); err != nil {
					global.Logger.Error(err.Error())
				} else {
					mibTemplate.M[brand] = oids
					return oids
				}
			}
		}
	}
	return nil
}

func getInfo(data *cache) map[string]interface{} {
	m := map[string]interface{}{
		"id":            data.ID,
		"brand":         data.Brand,
		"unixtime":      gs_tool.CurrentTimeSecond(),
		"monitor_cycle": data.MonitorCycle,
		"msg":           "",
	}

	if data.SnmpVersion == "" {
		m["msg"] = "snmp为空"
		return m
	}

	global.Logger.Info("开始采集摄像头: %+v", data)

	oids := getMIBTemplate(data.Brand)
	snmpObject, err := logic.GetSNMPObject(gs_define.SNMP_Auth{
		IP:            data.IP,
		Version:       data.SnmpVersion,
		Port:          data.SnmpPort,
		ReadComunity:  data.SnmpReadComunity,
		User:          data.SnmpUser,
		SecurityLevel: data.SnmpSecurityLevel,
		AuthPro:       data.SnmpAuthPro,
		AuthPassword:  data.SnmpAuthPassword,
		DataPro:       data.SnmpDataPro,
		DataPassword:  data.SnmpDataPassword,
	})
	if err != nil {
		global.Logger.Error("%+v", err)
		m["msg"] = err.Error()
		return m
	}

	defer snmpObject.Close()

	for i, oid := range oids {
		switch strings.ToLower(oid.Method) {
		case "get":
			vars, err := logic.SnmpGet(snmpObject, oid.Oid)
			if err != nil {
				global.Logger.Error(err.Error())
			}
			for _, v := range vars {
				oids[i].Value = v.Variable.String()
				break
			}
		case "walk":
			vars, err := logic.SnmpWalk(snmpObject, oid.Oid)
			if err != nil {
				global.Logger.Error(err.Error())
			}
			values := []string{}
			for _, v := range vars {
				values = append(values, v.Variable.String())
			}
			t, _ := json.Marshal(values)
			oids[i].Value = string(t)
		default:
			global.Logger.Warn("暂不支持的此方法：%+v", oid)
		}
	}
	m["oids"] = oids
	return m
}
