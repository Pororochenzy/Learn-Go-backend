package logic

import (
	"camera/global"

	gs_define "geesunn.com/define"
	gs_snmp "geesunn.com/snmp"
	"geesunn.com/snmpgo"
)

func GetSNMPObject(auth gs_define.SNMP_Auth) (*snmpgo.SNMP, error) {
	client, err := gs_snmp.InitClient(auth)
	if err != nil {
		return nil, err
	}
	return client.SNMP, nil
}

func SnmpGet(obj *snmpgo.SNMP, oid string, args ...string) (snmpgo.VarBinds, error) {
	oids, _ := snmpgo.NewOids([]string{oid})
	pdu, err := obj.GetRequest(oids)
	if pdu != nil {
		if len(pdu.VarBinds()) == 0 {
			global.Logger.Warn("设备:%v 不支持 此oid: %v", args, oid)
			return nil, nil
		} else if pdu.VarBinds()[0].Variable.Type() == "NoSucheObject" {
			global.Logger.Warn("设备:%v NoSucheObject 此oid: %v", args, oid)
			return nil, nil
		} else {
			return pdu.VarBinds(), err
		}
	}
	return nil, err
}

func SnmpWalk(obj *snmpgo.SNMP, oid string, args ...string) (snmpgo.VarBinds, error) {
	oids, _ := snmpgo.NewOids([]string{oid})
	pdu, err := obj.GetBulkWalk(oids, 0, 1)
	if pdu != nil {
		if len(pdu.VarBinds()) == 0 {
			global.Logger.Warn("设备:%v 不支持 此oid: %v", args, oid)
			return nil, nil
		} else if pdu.VarBinds()[0].Variable.Type() == "NoSucheObject" {
			global.Logger.Warn("设备NoSucheObject 此oid: %v", oid)
			return nil, nil
		} else {
			return pdu.VarBinds(), err
		}
	}
	return nil, err
}
