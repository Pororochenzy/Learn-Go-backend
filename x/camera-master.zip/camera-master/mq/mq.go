package mq

import (
	"camera/global"
	"camera/logic"
	"encoding/json"
	"fmt"
	"time"

	gs_define "geesunn.com/define"
	go_redis "github.com/go-redis/redis"
)

// 缓存对象
var SubRedis *go_redis.Client

// 订阅
func InitMQ() {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("初始化MQ异常：%v", r)
			logic.PrintTrace()
		}
	}()
	global.Logger.Info("初始化MQ开始")

	SubRedis = go_redis.NewClient(&go_redis.Options{
		Addr:     fmt.Sprintf("%v:%v", global.Config.MustValue("redis", "host"), global.Config.MustInt("redis", "port")),
		Password: global.Config.MustValue("redis", "password"),
		DB:       gs_define.REDIS_MQ_DB,
		PoolSize: 1,
	})

	var pubSub *go_redis.PubSub
	channel := gs_define.C_CACHE_TO_CAMERA
	for {
		_, err := SubRedis.Ping().Result()
		if err == nil {
			break
		} else {
			global.Logger.Error("Redis通道连接异常：%v", err.Error())
		}
		time.Sleep(time.Second * 10)
	}

	pubSub = SubRedis.Subscribe(channel)
	global.Logger.Info("订阅成功: %v", channel)

	for {
		msg, err := pubSub.ReceiveMessage()
		if err != nil {
			global.Logger.Error("接受数据%v异常： %v", msg, err.Error())
			continue
		}
		reqData := gs_define.MQMsg{}
		if err := json.Unmarshal([]byte(msg.Payload), &reqData); err != nil {
			global.Logger.Error("接受数据%v异常： %v", msg, err.Error())
			continue
		}

		global.Logger.Info("%v, %v %v To %v BackTo %v", reqData.MQType, reqData.UUID, reqData.From, reqData.To, reqData.BackTo)
		global.Logger.Debug("%v 请求数据：%v", reqData.UUID, reqData.Data)

		go handleMsg(reqData)
	}
}

func handleMsg(reqData gs_define.MQMsg) {
	defer func() {
		if r := recover(); r != nil {
			global.Logger.Error("数据处理异常：%v", r)
			logic.PrintTrace()
		}
	}()

	start := time.Now()
	defer func() {
		global.Logger.Info("%v 完成请求, 开始时间: %v, 耗时： %v", reqData.UUID, start, time.Since(start))
	}()

	// var result interface{}
	switch reqData.MQType {
	// case gs_define.MQ_TYPE_PING_INSPECT:
	// 	// result = handlePing(reqData.UUID, reqData.Data)
	// 	jumpToQueueChan(gs_define.TaskQueueUnit{
	// 		Type: gs_define.COLLECT_TYPE_INSPECT,
	// 		Data: map[string]interface{}{
	// 			"ip":      reqData.Data,
	// 			"uuid":    reqData.UUID,
	// 			"back_to": reqData.BackTo,
	// 			"mq_type": reqData.MQType,
	// 		},
	// 	})
	default:
		global.Logger.Warn("暂不支持该消息类型: %v", reqData)
	}

	return
}

func jumpToQueueChan(taskUnit gs_define.TaskQueueUnit) {
	list := []gs_define.TaskQueueUnit{}
	isReturn := true
	for {
		if !isReturn {
			break
		}
		select {
		case v := <-global.TaskQueue:
			list = append(list, v)
		default:
			isReturn = false
			global.TaskQueue <- taskUnit
			break
		}
	}
	for _, tempTask := range list {
		global.TaskQueue <- tempTask
	}
}
