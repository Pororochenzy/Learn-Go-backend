package easyexec

import (
	"fmt"
	"os/exec"
	"runtime"

	"github.com/pkg/errors"
)

func execCommand(name string, args ...string) (string, error) {
	commandObj := exec.Command(name, args...)
	out, err := commandObj.CombinedOutput()
	return string(out), err
}

// Command 执行命令，带参数
func Command(cmd string) (string, error) {
	var shell, arg string
	if runtime.GOOS == "windows" {
		shell, arg = "cmd", "/C"
	} else {
		shell, arg = "bash", "-c"
	}
	return execCommand(shell, arg, cmd)
}

// NativeCommand 执行原生命令
func NativeCommand(cmd, args string) (string, error) {
	return execCommand(cmd, args)
}

// JMXClientCommand JMX命令行工具使用
func JMXClientCommand(host string, port int64, userName, password, bean, command, jmxClientPathName string) (string, error) {
	if len(jmxClientPathName) == 0 {
		return "", errors.New("JMXClient JAR文件的路径不能为空")
	}

	if len(host) == 0 {
		return "", errors.New("JMXClientCommand执行失败，host不能为空")
	}

	shell, arg := "java", "-jar"
	account := "-"
	if len(userName) != 0 {
		account = fmt.Sprintf("%v:%v", userName, password)
	}
	hostName := fmt.Sprintf("%v:%v", host, port)

	return execCommand(shell, arg, jmxClientPathName, account, hostName, bean, command)
}
