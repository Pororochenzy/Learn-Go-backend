package misc

import (
	"fmt"
	"time"

	go_uuid "github.com/satori/go.uuid"
)

// GetUUID 获取UUID
func GetUUID() string {

	uuid, err := go_uuid.NewV4()
	if err != nil {
		fmt.Println(err)
		return fmt.Sprintf("%v", time.Now().UnixNano())
	}

	return uuid.String()
}
