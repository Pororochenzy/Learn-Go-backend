package misc

import (
	"errors"
	"io"
	"os"
	"path/filepath"
)

// 级联创建文件夹
func MakeDir(path string) bool {
	if !IsDirExist(path) {
		err := os.MkdirAll(path, 0777)
		return err == nil
	}
	return true
}

// 检查文件夹是否存在
func IsDirExist(path string) bool {
	f, err := os.Stat(path)
	if err == nil {
		return f.IsDir()
	}
	if os.IsNotExist(err) {
		return false
	}
	return true
}

// 检查文件是否存在
func IsFileExist(path string) bool {
	f, err := os.Stat(path)
	if err == nil {
		return !f.IsDir()
	}
	if os.IsNotExist(err) {
		return false
	}
	return true
}

// 删除所有文件
func RemoveAll(path string) error {
	return os.RemoveAll(path)
}

// 获取文件夹
func GetDirs(dirpath string) ([]string, error) {
	var dir_list []string
	dir_err := filepath.Walk(dirpath,
		func(path string, f os.FileInfo, err error) error {
			if f == nil {
				return err
			}
			if f.IsDir() {
				dir_list = append(dir_list, path)
				return nil
			}

			return nil
		})
	return dir_list, dir_err
}

// 移动文件
func MoveFile(src, dst string) error {
	if err := os.Rename(src, dst); err != nil {
		// copy file when cross-device link
		if err := CopyFile(src, dst); err != nil {
			return err
		}
		if err := os.Remove(src); err != nil {
			return err
		}
	}
	return nil
}

// 拷贝文件
func CopyFile(src, dst string) error {
	r, err := os.Open(src)
	if err != nil {
		return err
	}
	defer r.Close()

	w, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer w.Close()

	_, err = io.Copy(w, r)
	return err
}

// 删除文件
func RemoveFile(src string) error {
	return os.Remove(src)
}

func SaveFile(fileName string, data []byte) error {

	// 如果目录不存在
	if ok := MakeDir(filepath.Dir(fileName)); !ok {
		return errors.New("创建目录失败")
	}

	w, err := os.Create(fileName)
	if err != nil {
		return err
	}
	defer w.Close()

	_, err = w.Write(data)
	return err
}
