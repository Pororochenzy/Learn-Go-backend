package orm

import (
	"errors"

	"github.com/go-xorm/xorm"
)

func NewOrm(driver string, dataSourceName string, maxOpenConn, maxIdleConn, maxLifeSec int) (*xorm.Engine, error) {

	switch driver {
	case "mysql":
		return NewMysqlXorm(dataSourceName, maxOpenConn, maxIdleConn, maxLifeSec)
	case "mariadb":
		return NewMariadbXorm(dataSourceName, maxOpenConn, maxIdleConn, maxLifeSec)
	default:
		return nil, errors.New("暂不支持该驱动")
	}

}
