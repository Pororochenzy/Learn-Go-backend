package orm

import (
	"time"

	_ "github.com/go-sql-driver/mysql"
	"github.com/go-xorm/xorm"
)

func NewMysqlXorm(dataSourceName string, maxOpenConns, maxIdleConns, maxLifeSec int) (*xorm.Engine, error) {

	xorm, err := xorm.NewEngine("mysql", dataSourceName)
	if err != nil {
		return xorm, err
	}

	if err := xorm.Ping(); err != nil {
		defer xorm.Close()
		return nil, err
	}

	xorm.SetConnMaxLifetime(time.Second * time.Duration(maxLifeSec))
	xorm.SetMaxOpenConns(maxOpenConns)
	xorm.SetMaxIdleConns(maxIdleConns)

	return xorm, nil
}
