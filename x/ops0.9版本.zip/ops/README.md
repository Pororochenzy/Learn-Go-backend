**说明**

center: 各业务模块管理端代码

    cmdb: 首页、资源管理、系统设置、用户模块
    monitor: 监控中心、告警中心、网络设备日志
    task: 任务管理、巡检、备份
    fortress: 堡垒机
    report: 报表
-----
depend: 管理端依赖组件

    cproxy: 采集代理 策略分组
    cplugin: 采集组件
    data_handler: 数据处理
    alarm: 告警处理
    notify: 通知处理
    scheduler: 定时任务
-----    
common: 工具类方法函数

-----
module: 公共业务逻辑封装

-----
tool: 部署、维护相关工具
    gmo: 工程启动管理工具
    sqlpatch: 数据库补丁管理工具
    
-----    
vendor: govendor管理的第三方包(禁止手动拷贝进来)
    govendor安装
        go get -u github.com/kardianos/govendor
    
    govendor使用
        govendor help

doc: 文档说明，设计思路