package table

type SysUserCustomSetting struct {
	Id         int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	TypeId     int64  `json:"type_id" xorm:"not null default 0 comment('自定义类型id') BIGINT(20)"`
	UserId     int64  `json:"user_id" xorm:"not null default 0 comment('关联用户的id') BIGINT(20)"`
	Content    string `json:"content" xorm:"comment('设置的内容') JSON"`
	UpdateTime string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	CreateTime string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
}
