package table

type SysUserDepartment struct {
	Id           int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	ParentId     int64  `json:"parent_id" xorm:"not null default 0 comment('父部门id') BIGINT(20)"`
	PathName     string `json:"path_name" xorm:"not null default '' comment('全路径名称') VARCHAR(256)"`
	Name         string `json:"name" xorm:"not null default '' comment('部门名称') VARCHAR(64)"`
	Level        int    `json:"level" xorm:"not null default 0 comment('级别') TINYINT(1)"`
	CreateUserId int64  `json:"create_user_id" xorm:"not null default 0 BIGINT(20)"`
	UpdateTime   string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	CreateTime   string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
}
