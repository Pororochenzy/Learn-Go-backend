package table

type SysSettingInform struct {
	Id         int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	Name       string `json:"name" xorm:"not null default '' comment('系统配置项名称') VARCHAR(64)"`
	Switch     int    `json:"switch" xorm:"not null default 0 comment('开关设置') TINYINT(4)"`
	Content    string `json:"content" xorm:"comment('配置内容') JSON"`
	Remark     string `json:"remark" xorm:"not null default '' VARCHAR(256)"`
	UpdateTime string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	CreateTime string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
}
