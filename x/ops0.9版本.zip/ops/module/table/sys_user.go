package table

type SysUser struct {
	Id              int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	Account         string `json:"account" xorm:"not null default '' comment('用户') VARCHAR(64)"`
	Name            string `json:"name" xorm:"not null default '' comment('真实姓名') VARCHAR(64)"`
	Tel             string `json:"tel" xorm:"not null default '' comment('电话号码') VARCHAR(11)"`
	Password        string `json:"password" xorm:"not null default '' comment('密码') VARCHAR(256)"`
	Salt            string `json:"salt" xorm:"not null default '' VARCHAR(128)"`
	Email           string `json:"email" xorm:"not null default '' comment('邮箱') VARCHAR(64)"`
	Avatar          string `json:"avatar" xorm:"not null default '/monitor/resource/header/default.jpg' comment('头像') VARCHAR(256)"`
	Status          int    `json:"status" xorm:"not null default 0 comment('0.正常 1.冻结') TINYINT(1)"`
	IsDelete        int    `json:"is_delete" xorm:"not null default 0 comment('0.正常 1.删除') TINYINT(1)"`
	Remark          string `json:"remark" xorm:"not null default '' comment('备注') VARCHAR(256)"`
	CreateUserId    int64  `json:"create_user_id" xorm:"not null default 0 BIGINT(20)"`
	UpdateTime      string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	CreateTime      string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	WrongTimes      int    `json:"wrong_times" xorm:"not null default 0 comment('连续错误次数') TINYINT(4)"`
	FrozenTimestamp int64  `json:"frozen_timestamp" xorm:"not null default 0 INT(11) comment('冻结时间戳')"`
}
