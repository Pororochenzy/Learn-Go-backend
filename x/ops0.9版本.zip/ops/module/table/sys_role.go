package table

type SysRole struct {
	Id           int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	Name         string `json:"name" xorm:"not null default '' comment('角色名称') VARCHAR(64)"`
	Remark       string `json:"remark" xorm:"not null default '' comment('备注') VARCHAR(256)"`
	CreateUserId int64  `json:"create_user_id" xorm:"not null default 0 comment('创建人id') BIGINT(20)"`
	UpdateTime   string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	CreateTime   string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
}
