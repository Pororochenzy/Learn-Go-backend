package table

type SysOperatorLog struct {
	Id         int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	Type       string `json:"type" xorm:"not null default '' comment('关联类型 system cmdb monitor task report fortress') index VARCHAR(32)"`
	UserId     int64  `json:"user_id" xorm:"not null default 0 comment('操作人id') BIGINT(20)"`
	Token      string `json:"token" xorm:"not null default '0' comment('登录token') index VARCHAR(128)"`
	ObjectType string `json:"object_type" xorm:"not null default '' comment('操作对象类别') index(idx_sys_operator_log_object_type_object_id) VARCHAR(32)"`
	ObjectId   int64  `json:"object_id" xorm:"not null default 0 comment('操作对象id') index(idx_sys_operator_log_object_type_object_id) BIGINT(20)"`
	Content    string `json:"content" xorm:"not null default '' comment('操作内容') VARCHAR(1024)"`
	UpdateTime string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	CreateTime string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
}
