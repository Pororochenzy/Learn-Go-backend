package table

type SysUploadFile struct {
	Id           int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	Name         string `json:"name" xorm:"not null default '' VARCHAR(64)"`
	Namespace    string `json:"namespace" xorm:"not null default '' index(idx_file_ns_md5) VARCHAR(64)"`
	Md5          string `json:"md5" xorm:"not null default '' index(idx_file_ns_md5) VARCHAR(32)"`
	Path         string `json:"path" xorm:"not null default '' VARCHAR(256)"`
	CreateUserId int64  `json:"create_user_id" xorm:"not null default 0 BIGINT(20)"`
	CreateTime   string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	UpdateTime   string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
}
