package table

type SysDbUpgradeLog struct {
	Id         int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	Version    string `json:"version" xorm:"not null default '' comment('版本号') VARCHAR(64)"`
	UpdateTime string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	CreateTime string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
}
