package table

type SysUserDepartmentRelation struct {
	Id               int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	UserId           int64  `json:"user_id" xorm:"not null default 0 comment('用户id') BIGINT(20)"`
	UserDepartmentId int64  `json:"user_department_id" xorm:"not null default 0 comment('部门id') BIGINT(20)"`
	CreateUserId     int64  `json:"create_user_id" xorm:"not null default 0 BIGINT(20)"`
	UpdateTime       string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	CreateTime       string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
}
