package table

type HistorySysUserLoginLog struct {
	Id         int64  `json:"id" xorm:"pk autoincr BIGINT(20)"`
	UserId     int64  `json:"user_id" xorm:"not null default 0 comment('用户id') BIGINT(20)"`
	Status     int    `json:"status" xorm:"not null default 0 comment('状态：0.成功 1.失败') TINYINT(1)"`
	Msg        string `json:"msg" xorm:"not null default '' comment('状态描述') VARCHAR(128)"`
	Ip         string `json:"ip" xorm:"not null default '' comment('ip') VARCHAR(32)"`
	Token      string `json:"token" xorm:"not null default '' comment('登录token') index VARCHAR(128)"`
	LoginTime  string `json:"login_time" xorm:"not null default 'CURRENT_TIMESTAMP' comment('登录时间') TIMESTAMP"`
	LogoutTime string `json:"logout_time" xorm:"not null default 'CURRENT_TIMESTAMP' comment('登出时间') TIMESTAMP"`
	LogoutMsg  string `json:"logout_msg" xorm:"not null default '' comment('登出描述') VARCHAR(128)"`
	UpdateTime string `json:"update_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
	CreateTime string `json:"create_time" xorm:"not null default 'CURRENT_TIMESTAMP' TIMESTAMP"`
}
