package common

import (
	"fmt"
	"ops/center/cmdb/log"
	"runtime"
)

const LINE_NUM = 32

// 异常捕获，打印堆栈
func HandlerRecover(msg ...string) bool {
	if r := recover(); r != nil {
		log.Error(r, msg)
		for i := 0; i < LINE_NUM; i++ {
			funcName, file, line, ok := runtime.Caller(i)
			if ok {
				errmsg := fmt.Sprintf("frame %v:[func:%v,file:%v,line:%v]", i, runtime.FuncForPC(funcName).Name(), file, line)
				log.Error(errmsg)
			}
		}
		return true
	}
	return false
}
