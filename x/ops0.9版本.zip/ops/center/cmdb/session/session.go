package session

import (
	"errors"
	"fmt"
	"ops/center/cmdb/common"
	"ops/center/cmdb/db"
	"ops/center/cmdb/global"
	"ops/center/cmdb/log"
	"ops/common/db/redis"
	"ops/common/misc"
	"ops/module/table"
	"time"

	"github.com/bitly/go-simplejson"
)

var REDIS_INFO_DB = 0

var sessionEffect = struct {
	Switch    bool  `json:"switch"`
	EffectSec int64 `json:"effect_sec"`
}{EffectSec: -1}

var logoutCallBack func(token, msg string) error

// Session session信息
type Session struct {
	IP             string `redis:"ip"`
	Token          string `redis:"token"`
	EffectSec      int64  `redis:"effect_sec"`
	LoginTimestamp int64  `redis:"login_timestamp"`
	LastTimestamp  int64  `redis:"last_timestamp"`
	UserID         int64  `redis:"user_id"`
	Logout         bool   `redis:"logout"`
}

// IsTimeOut session是否超时
func (p *Session) IsTimeOut() bool {

	if p.EffectSec == -1 {
		return false
	}

	if time.Now().Unix()-p.LastTimestamp > p.EffectSec {
		return true
	}
	return false
}

// RefreshExpired 刷新有效时间
func (p *Session) RefreshExpired() error {

	return global.CacheDB.HMSet(REDIS_INFO_DB, getSessionKey(p.Token), map[string]interface{}{
		"last_timestamp": time.Now().Unix(),
	})
}

// Validation 验证session
func Validation(token string, cacheDB *redis.Redis) (*Session, error) {

	session := &Session{}
	exist, err := cacheDB.HGetAll(REDIS_INFO_DB, fmt.Sprintf("session:%v", token), session)
	if err != nil {
		return nil, err
	}
	if !exist || session.IsTimeOut() {
		return nil, errors.New("会话过期，请重新登录")
	}

	if session.Logout {
		return nil, errors.New("账号异地登录")
	}

	return session, nil
}

// Init session参数初始化
func Init(minute int64, f func(token, msg string) error) error {

	defer common.HandlerRecover("session初始化异常！")

	setting := new(table.SysSetting)
	session := db.NewSession()
	exists, err := session.ID(1).Get(setting)
	if err != nil {
		panic(err)
	}
	if exists {
		if err := LoadSessionEffect(setting.Content); err != nil {
			panic(err)
		}
	}

	logoutCallBack = f

	// 定时清理session
	time.AfterFunc(time.Duration(minute)*time.Minute, func() {
		defer common.HandlerRecover("session定时异常！")

		releaseSession()
	})

	return nil
}

// 提出其他用户
func takeoutSession(userID int64) error {

	userKey := getSessionUserKey(userID)
	exists, err := global.CacheDB.IsKeyExist(REDIS_INFO_DB, userKey)
	if err != nil {
		return err
	}
	if exists <= 0 {
		return nil
	}

	token, _ := global.CacheDB.GetString(REDIS_INFO_DB, getSessionUserKey(userID))
	if token == "" {
		return nil
	}

	session, err := GetSession(token)
	if err != nil {
		return err
	}

	log.Info("账号异地登录", session.Token, session.UserID, session.IP)

	if session != nil {
		if err := global.CacheDB.HMSet(REDIS_INFO_DB, getSessionKey(token), map[string]interface{}{
			"logout": true,
		}); err != nil {
			return err
		}
		logoutCallBack(session.Token, "账号异地登录")
	}

	return nil
}

// CreateSession 产生session
func CreateSession(userID int64, loginIP string) (string, error) {

	if err := takeoutSession(userID); err != nil {
		log.Error(err)
	}

	logicTimestamp := time.Now().Unix()
	token := createToken()

	sessparm := map[string]interface{}{
		"token":           token,
		"login_timestamp": logicTimestamp,
		"last_timestamp":  logicTimestamp,
		"effect_sec":      -1,
		"user_id":         userID,
		"ip":              loginIP,
		"logout":          false,
	}
	if err := global.CacheDB.HMSet(REDIS_INFO_DB, getSessionKey(token), sessparm); err != nil {
		return "", err
	}
	// 记录用户sessionId信息
	if err := global.CacheDB.SET(REDIS_INFO_DB, getSessionUserKey(userID), token); err != nil {
		return "", err
	}

	return token, nil
}

func createToken() string {

	return misc.GetUUID()
}

// LoadSessionEffect 加载session配置信息
func LoadSessionEffect(content string) error {

	if content != "" {
		sJSON, err := simplejson.NewJson([]byte(content))
		if err != nil {
			return err
		}

		if sJSON.Get("switch").MustInt64() > 0 {
			sessionEffect.Switch = true
			sessionEffect.EffectSec = sJSON.Get("effect_minute").MustInt64() * 60
		}
	} else {
		sessionEffect.Switch = false
		sessionEffect.EffectSec = -1
	}

	return nil
}

// releaseSession 释放session
func releaseSession() {

	log.Info("session释放")

	sessionKeys, err := global.CacheDB.RegularKeys(REDIS_INFO_DB, "session:token:*")
	if err != nil {
		return
	}

	for _, sessionKey := range sessionKeys {
		session, _ := getSession(sessionKey)
		if session != nil {
			//  用户被挤出，删除session
			if session.Logout {
				// 产品要求，不立即删除
				// 开启session，大于等于session有效期删除
				// 未开启, 大于等于半个小时删除
				if sessionEffect.Switch {
					if time.Now().Unix()-session.LastTimestamp >= sessionEffect.EffectSec {
						DelSession(session.Token)
					}
				} else {
					if time.Now().Unix()-session.LastTimestamp > 1800 {
						DelSession(session.Token)
					}
				}
			} else {
				// 若动态设置了session有效期，更新缓存里的有效期
				if session.EffectSec != sessionEffect.EffectSec {
					global.CacheDB.HMSet(REDIS_INFO_DB, getSessionKey(session.Token), map[string]interface{}{
						"effect_sec": sessionEffect.EffectSec,
					})
					session.EffectSec = sessionEffect.EffectSec
				}

				// 用户未登出，若超时，记录日志，删除session
				if sessionEffect.Switch {
					if session.IsTimeOut() {
						if err := logoutCallBack(session.Token, "会话超时"); err != nil {
							log.Error("会话超时登出异常：", err)
						} else {
							DelSession(session.Token)
						}
					}
				}

			}
		}
	}
}

// GetSession 获取session
func GetSession(token string) (*Session, error) {

	return getSession(getSessionKey(token))
}

// DelSession 删除session
func DelSession(token string) error {

	session, err := GetSession(token)

	if err != nil || session == nil {
		return err
	}

	if err := global.CacheDB.DELKey(REDIS_INFO_DB, getSessionKey(session.Token)); err != nil {
		return err
	}

	uToken, _ := global.CacheDB.GetString(REDIS_INFO_DB, getSessionUserKey(session.UserID))
	if uToken == session.Token {
		if err := global.CacheDB.DELKey(REDIS_INFO_DB, getSessionUserKey(session.UserID)); err != nil {
			return err
		}
	}

	return nil
}

// GetSessionByUserID 获取用户session
func GetSessionByUserID(userID int64) (*Session, error) {

	exist, err := global.CacheDB.IsKeyExist(REDIS_INFO_DB, getSessionUserKey(userID))
	if err != nil || exist <= 0 {
		return nil, err
	}

	//通过"session:user" + userId ->找到token
	token, err := global.CacheDB.GetString(REDIS_INFO_DB, getSessionUserKey(userID))
	if err != nil {
		return nil, err
	}

	{
		session := &Session{}
		//通过"session" + token -> 找到session对象
		exist, err := global.CacheDB.HGetAll(REDIS_INFO_DB, getSessionKey(token), session)
		if err != nil || !exist {
			return nil, err
		}
		return session, nil
	}

}

func getSession(key string) (*Session, error) {
	session := &Session{}
	exist, err := global.CacheDB.HGetAll(REDIS_INFO_DB, key, session)
	if err != nil || !exist {
		return nil, err
	}

	return session, err
}

func getSessionKey(token string) string {
	return fmt.Sprintf("session:token:%v", token)
}

func getSessionUserKey(userID int64) string {
	return fmt.Sprintf("session:user:%v", userID)
}
