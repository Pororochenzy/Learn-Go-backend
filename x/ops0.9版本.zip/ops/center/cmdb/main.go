package main

import (
	"ops/center/cmdb/global"
	"ops/center/cmdb/log"
	"ops/center/cmdb/session"
	"ops/center/cmdb/web"
	"ops/center/cmdb/web/model"
	"os"
	"os/signal"
	"syscall"
)

func main() {
	defer global.Close()

	session.Init(10, (model.Log{}).WriteLogoutLog)

	go web.StartServer(global.Addr)

	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)

	<-sigs

	log.Info("exit")
	os.Exit(0)

}
