package controller

import (
	"ops/center/cmdb/log"
	"ops/center/cmdb/web/model"
)

type Department struct {
	md model.Department
}

func (p Department) Add(c *Context) {
	parameter := struct {
		ParentId int64  `json:"parent_id,required"`
		Name     string `json:"name,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	lastid, err := p.md.Add(model.DeparmentAddParameter{
		ParentId: parameter.ParentId,
		Name:     parameter.Name,
	}, c.GetUID())
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(map[string]interface{}{"id": lastid})
	return
}

// 删除部门小组
func (p Department) Delete(c *Context) {
	parameter := struct {
		Id    int64 `json:"id,required"`
		Force int64 `json:"force,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}

	if parameter.Force > 0 {
		err := p.md.Delete(parameter.Id, c.GetUID())
		if err != nil {
			log.Error(err)
			c.OutSysErr(err.Error())
			return
		}
	} else {
		// 检查部门下是否有小组或者人员
		exist, err := p.md.CheckSubExist(parameter.Id)
		if err != nil {
			log.Error(err)
			c.OutSysErr(err.Error())
			return
		}
		if exist {
			c.OutSysErr("此部门下存在子级部门小组，请先删除子部门小组")
			return
		}
		exist, err = p.md.CheckUserExist(parameter.Id)
		if err != nil {
			log.Error(err)
			c.OutSysErr(err.Error())
			return
		}
		if exist {
			c.OutSysErr("此部门下存在用户，请先移除相关用户")
			return
		}
	}

	c.OutSuccess(nil)
	return
}

// 企业组织架构
func (p Department) List(c *Context) {
	deps, err := p.md.List()
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(map[string]interface{}{
		"list": deps,
	})
	return
}

// 更新部门小组
func (p Department) Update(c *Context) {
	parameter := struct {
		Id   int64  `json:"id,required"`
		Name string `json:"name,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	if err := p.md.Update(parameter.Id, map[string]interface{}{
		"name": parameter.Name,
	}, c.GetUID()); err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}

	c.OutSuccess(nil)
	return
}
