package controller

import (
	"encoding/json"
	"errors"
	"fmt"
	"ops/center/cmdb/db"
	"reflect"
	"strings"
)

var (
	PARAM_INT64_UNREQUIRED   int64   = -123456789
	PARAM_STRING_UNREQUIRED  string  = `geesunngeesunngeesunn`
	PARAM_FLOAT64_UNREQUIRED float64 = -123456789.00
)

// Param2SimpleSQLCondition 请求结构体转简单SQL条件
func Param2SimpleSQLCondition(bean interface{}, columns map[string]string) (*db.SimpleSQLCondition, error) {

	bValue := reflect.ValueOf(bean).Elem()
	bType := reflect.TypeOf(bean).Elem()

	ssc := &db.SimpleSQLCondition{}

	for i := 0; i < bType.NumField(); i++ {
		field := bType.Field(i)
		k, ok := columns[field.Name]
		if !ok {
			continue
		}
		v := bValue.Field(i).Interface()
		switch field.Type.Kind() {
		case reflect.Int64:
			if v.(int64) == PARAM_INT64_UNREQUIRED {
				continue
			}
		case reflect.String:
			if v.(string) == PARAM_STRING_UNREQUIRED {
				continue
			}
		case reflect.Float64:
			if v.(float64) == PARAM_FLOAT64_UNREQUIRED {
				continue
			}
		default:
			return nil, fmt.Errorf("暂不支持该类型: %v", field.Type.Kind())
		}

		switch field.Tag.Get("sql") {
		case "IN":
			is := []interface{}{}
			if err := json.Unmarshal(([]byte)(v.(string)), &is); err != nil {
				return nil, err
			}
			ssc.AddIN(k, is)
		case "EQ":
			ssc.AddEQ(k, v)
		case "LIKE":
			ssc.AddLIKE(k, v)
		case "GT":
			ssc.AddGT(k, v)
		case "LT":
			ssc.AddLT(k, v)
		case "GE":
			ssc.AddGE(k, v)
		case "LE":
			ssc.AddLE(k, v)
		case "SORT":
			sorts := []db.ColumnSortUnit{}
			if err := json.Unmarshal(([]byte)(v.(string)), &sorts); err != nil {
				return nil, err
			}
			if len(sorts) > 0 {
				ssc.AddSORT(sorts...)
			}
		case "JOIN":
			jTags := strings.Split(field.Tag.Get("join"), "|")
			if len(jTags) != 4 {
				return nil, errors.New("tag配置错误")
			}
			alias := ""
			if strings.HasPrefix(jTags[2], "[") {
				tableName := []string{}
				if err := json.Unmarshal([]byte(jTags[2]), &tableName); err != nil {
					return nil, err
				}
				ssc.AddJOIN(db.JoinUnit{Operator: jTags[1], TableName: tableName, Condition: jTags[3]})
				alias = tableName[1]
			} else {
				ssc.AddJOIN(db.JoinUnit{Operator: jTags[1], TableName: jTags[2], Condition: jTags[3]})
			}

			if k == "-" {
				continue
			}

			switch jTags[0] {
			case "IN":
				is := []interface{}{}
				if err := json.Unmarshal(([]byte)(v.(string)), &is); err != nil {
					return nil, err
				}
				ssc.AddIN(alias+"."+k, is)
			case "EQ":
				ssc.AddEQ(alias+"."+k, v)
			case "LIKE":
				ssc.AddLIKE(alias+"."+k, v)
			case "GT":
				ssc.AddGT(alias+"."+k, v)
			case "LT":
				ssc.AddLT(alias+"."+k, v)
			case "GE":
				ssc.AddGE(alias+"."+k, v)
			case "LE":
				ssc.AddLE(alias+"."+k, v)
			}
		default:
			return nil, fmt.Errorf("暂不支持该条件 %v", field.Tag.Get("ssc"))
		}

	}
	return ssc, nil
}
