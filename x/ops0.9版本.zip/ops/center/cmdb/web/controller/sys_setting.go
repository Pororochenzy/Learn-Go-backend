package controller

import (
	"encoding/json"
	"github.com/gin-gonic/gin"
	"ops/center/cmdb/web/model"
	"ops/module/table"
)

type SysSetting struct {
	ms model.SysSetting
}

//企业信息查询
func (p SysSetting) Detail(c *Context) {

	entInfo, err := p.ms.GetEnterpriseInfo("enterprise_info")
	if err != nil {
		c.OutSysErr(err.Error())
		return
	}
	if entInfo != nil {
		c.OutSuccess(gin.H{
			"content": entInfo.Content,
			//"remark":  entInfo.Remark,
		})
		return
	}
	c.OutSysErr("找不到数据")
	return

}

// EditEnterprise 企业信息编辑

func (p SysSetting) EditEnterprise(c *Context) {

	parameter := struct {
		Logo      string `json:"logo,required"`
		Logosmall string `json:"logosmall,required"`
		Sysname   string `json:"sysname,required"`
		Entname   string `json:"entname,required"`
		Web       string `json:"web,required"`
		Tel       string `json:"tel,required"`
		Favicon   string `json:"favicon,required"`
		Qrcode    string `json:"qrcode,required"`
		Desc      string `json:"desc,required"`
		Version   string `json:"version,required"`
	}{}
	if err := c.ShouldBindJSON(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}

	bytes, _ := json.Marshal(parameter)
	contentStr := string(bytes)

	sys := &table.SysSetting{Content: contentStr}

	i, _ := p.ms.UpdateEnterpriseInfo(sys)
	if i == 0 {
		c.OutSysErr("企业信息更新失败")
		//c.OutSysErr(e.Error())
		return
	}

	c.OutSuccess("")
}
