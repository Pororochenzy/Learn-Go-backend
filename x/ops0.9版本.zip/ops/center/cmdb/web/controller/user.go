package controller

import (
	"encoding/json"
	"errors"
	"net/http"
	"ops/center/cmdb/log"
	"ops/center/cmdb/web/model"
	"ops/common/misc"
	"ops/common/tools"
	"ops/module/table"
	"time"
)

type User struct {
	mu model.User
	ml model.Log
	mc model.Code
	mr model.Role
	ms model.Sys
}

func (p User) loginBefore(account string, typ int64) (interface{}, error) {

	// 校验登录方式
	policy := new(model.LoginPolicy)
	{
		iPolicy, err := p.ms.SettingContentDetail(model.SYS_TYPE_LOGIN_POLICY)
		if err != nil {
			log.Error("登录策略异常: ", err.Error())
			return nil, err
		}

		policy = iPolicy.(*model.LoginPolicy)
	}

	// 获取用户信息
	u, err := p.mu.GetInfoByAccount(account)
	if err != nil {
		log.Error("获取用户信息异常: ", err.Error())
		return nil, err
	}

	isAdmin, err := p.mu.IsAdmin(u.Id)
	if err != nil {
		log.Error("是否管理员异常: ", err)
		return nil, err
	}

	// sso登录
	if policy.Type == model.LOGIN_TYPE_SSO {
		if typ != 1 {
			return nil, errors.New("非超级管理员，请普通登录")
		}

		if !isAdmin {
			return nil, errors.New("非超级管理员，请普通登录")
		}

		// todo 重定向SSO登录
		return nil, errors.New("302")
	}

	if typ == 1 && !isAdmin {
		return nil, errors.New("非超级管理员，请普通登录")
	}

	// 校验用户状态
	if u.Status == model.USER_LOGIN_STATUS_FROZEN {
		return nil, errors.New("账号已冻结，请联系管理员")
	}

	return u, nil
}

/*
Login 用户登录
1.校验登录方式： 内部登录、SSO登录， SSO登录非管理员重定向SSO登录页面
2.获取用户信息
3.校验用户状态
4.校验用户密码策略
5.产生token
6.记录登录日志
7.登录成功
*/
func (p User) Login(c *Context) {

	parameter := struct {
		Account  string `json:"account,required"`
		Password string `json:"password,required"`
		Type     int64  `json:"type,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}

	// 登录前校验
	iu, err := p.loginBefore(parameter.Account, parameter.Type)
	if err != nil {
		log.Error("登录前校验异常", err.Error())

		// todo 第三方登录
		if err.Error() == "302" {
			c.Redirect(http.StatusFound, "")
			return
		}

		c.OutSysErr(err.Error())
		return
	}

	// 登录认证
	u := iu.(*table.SysUser)

	token, err := p.mu.InternalLogin(u, parameter.Password, c.GetRequestIP())
	if err != nil {
		log.Error("内部登录异常：", err)
		c.OutSysErr(err.Error())
		return
	}

	c.Header("token", token)
	c.OutSuccess(map[string]interface{}{"token": token})
	return
}

// Logout 用户登出
func (p User) Logout(c *Context) {

	token := c.GetToken()
	if token == "" {
		log.Warn("用户未登录")
		c.OutSuccess(nil)
		return
	}

	if err := p.mu.Logout(token); err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	if err := p.ml.WriteLogoutLog(token, "正常退出"); err != nil {
		log.Error("记录登出日志异常: ", err)
	}

	c.OutSuccess(nil)
	return
}

// Detail 用户详情
func (p User) Detail(c *Context) {
	parameter := struct {
		Id int64 `query:"id"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	var uid int64 = 0
	if parameter.Id == PARAM_INT64_UNREQUIRED {
		uid = c.GetUID()
	} else {
		uid = parameter.Id
	}

	user, err := p.mu.GetInfo(uid)
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	// 获取部门id和部门全名
	departmentId := int64(0)
	departmentPathName := ""
	if department, _ := p.mu.GetDepartment(uid); department != nil {
		departmentPathName = department.PathName
		departmentId = department.Id
	}
	// 获取角色名和角色id
	roleId := int64(0)
	roleName := ""
	if role, _ := p.mu.GetRole(uid); role != nil {
		roleId = role.Id
		roleName = role.Name
	}
	c.OutSuccess(map[string]interface{}{
		"id":            user.Id,
		"account":       user.Account,
		"name":          user.Name,
		"tel":           user.Tel,
		"email":         user.Email,
		"avatar":        user.Avatar,
		"status":        user.Status,
		"remark":        user.Remark,
		"create_time":   user.CreateTime,
		"department_id": departmentId,
		"department":    departmentPathName,
		"role":          roleName,
		"role_id":       roleId,
	})
	return
}

// Add 新增用户
func (p User) Add(c *Context) {
	parameter := struct {
		Account      string `json:"account,required"`
		Name         string `json:"name,required"`
		Tel          string `json:"tel"`
		Email        string `json:"email"`
		Avatar       string `json:"avatar"`
		Password     string `json:"password"`
		Status       int64  `json:"status,required"`
		Remark       string `json:"remark"`
		RoleId       int64  `json:"role_id,required"`
		DepartmentId int64  `json:"department_id"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	now := tools.GetTimeString(time.Now())
	user := &table.SysUser{
		Account:      parameter.Account,
		Name:         parameter.Name,
		Status:       int(parameter.Status),
		CreateUserId: c.GetUID(),
		CreateTime:   now,
		UpdateTime:   now,
		IsDelete:     0,
	}
	// 初始化选传数据
	if parameter.Tel != PARAM_STRING_UNREQUIRED {
		user.Tel = parameter.Tel
	}
	if parameter.Email != PARAM_STRING_UNREQUIRED {
		user.Email = parameter.Email
	}
	if parameter.Avatar != PARAM_STRING_UNREQUIRED {
		user.Avatar = parameter.Avatar
	}
	if parameter.Avatar != PARAM_STRING_UNREQUIRED {
		user.Avatar = parameter.Avatar
	}
	if parameter.Password != PARAM_STRING_UNREQUIRED {
		user.Password = parameter.Password
	}
	if parameter.Remark != PARAM_STRING_UNREQUIRED {
		user.Remark = parameter.Remark
	}
	if parameter.DepartmentId == PARAM_INT64_UNREQUIRED {
		parameter.DepartmentId = 0
	}

	lastid, err := p.mu.Add(user, parameter.RoleId, parameter.DepartmentId)
	if err != nil {
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(map[string]interface{}{
		"id": lastid,
	})
	return
}

// 个人信息修改
func (p User) Update(c *Context) {
	parameter := struct {
		Id           int64  `json:"id,required"`
		Account      string `json:"account"`
		Name         string `json:"name"`
		Tel          string `json:"tel"`
		Password     string `json:"password"`
		Email        string `json:"email"`
		Avatar       string `json:"avatar"`
		Status       int64  `json:"status"`
		Remark       string `json:"remark"`
		RoleId       int64  `json:"role_id"`
		DepartmentId int64  `json:"department_id"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		log.Error(err)
		c.OutParamsErr(err.Error())
		return
	}
	uid := c.GetUID()
	updateInfo := map[string]interface{}{}
	{
		if parameter.Account != PARAM_STRING_UNREQUIRED {
			updateInfo["account"] = parameter.Account
		}
		if parameter.Name != PARAM_STRING_UNREQUIRED {
			updateInfo["name"] = parameter.Name
		}
		if parameter.Tel != PARAM_STRING_UNREQUIRED {
			updateInfo["tel"] = parameter.Tel
		}
		if parameter.Password != PARAM_STRING_UNREQUIRED {
			updateInfo["password"] = parameter.Password
		}
		if parameter.Email != PARAM_STRING_UNREQUIRED {
			updateInfo["email"] = parameter.Email
		}
		if parameter.Avatar != PARAM_STRING_UNREQUIRED {
			updateInfo["avatar"] = parameter.Avatar
		}
		if parameter.Status != PARAM_INT64_UNREQUIRED {
			updateInfo["status"] = parameter.Status
		}
		if parameter.Remark != PARAM_STRING_UNREQUIRED {
			updateInfo["remark"] = parameter.Remark
		}
		if parameter.RoleId != PARAM_INT64_UNREQUIRED {
			updateInfo["role_id"] = parameter.RoleId
		}
		if parameter.DepartmentId != PARAM_INT64_UNREQUIRED {
			updateInfo["department_id"] = parameter.DepartmentId
		}
	}
	if len(updateInfo) > 0 {
		if _, err := p.mu.UpdateInfo(parameter.Id, updateInfo, uid); err != nil {
			log.Error(err)
			c.OutSysErr(err.Error())
			return
		}
	}
	c.OutSuccess(nil)
	return
}

// CustomList 用户自定义习惯 查询
func (p User) CustomList(c *Context) {
	parameter := struct {
		TypID int64 `query:"typeID,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	custom, err := p.mu.GetCustom(c.GetUID(), parameter.TypID)
	if err != nil {
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(map[string]interface{}{
		"list": custom,
	})
}

// CustomSave 用户自定义习惯保存
func (p User) CustomSave(c *Context) {
	parameter := struct {
		TypID   int64  `json:"typeID,required"`
		Content string `json:"content,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}

	flag, err := p.mu.SaveUserCustom(c.GetUID(), parameter.TypID, parameter.Content)
	if err != nil {
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(map[string]interface{}{
		"result": flag,
	})
}

// BatchDelete 批量删除用户
func (p User) BatchDelete(c *Context) {
	parameter := struct {
		IdList string `json:"id_list,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	ids := []int64{}
	if err := json.Unmarshal([]byte(parameter.IdList), &ids); err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	if err := p.mu.BatchDelete(ids, c.GetUID()); err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(nil)
	return

}

// LoginLog 用户登录日志
func (p User) LoginLog(c *Context) {
	parameter := struct {
		Mode            int64  `query:"mode, required"`
		Limit           int64  `query:"limit, required"`
		Offset          int64  `query:"offset, required"`
		UserID          int64  `query:"user_id" sql:"EQ"`
		Duration        int64  `query:"duration" sql:"EQ"`
		IP              string `query:"ip" sql:"LIKE"`
		StartLoginTime  string `query:"start_login_time"  sql:"GE"`
		EndLoginTime    string `query:"end_login_time" sql:"LE"`
		StartLogoutTime string `query:"start_logout_time" sql:"GE"`
		EndLogoutTime   string `query:"end_logout_time" sql:"LE"`
		SortUnitList    string `query:"sort_unit_list" sql:"SORT"`
	}{}

	if err := c.Bind(&parameter); err != nil {
		log.Error(err)
		c.OutParamsErr(err.Error())
		return
	}

	ssc, err := Param2SimpleSQLCondition(&parameter, map[string]string{
		"UserID":          "user_id",
		"Duration":        "duration",
		"IP":              "ip",
		"StartLoginTime":  "login_time",
		"EndLoginTime":    "login_time",
		"StartLogoutTime": "logout_time",
		"EndLogoutTime":   "logout_time",
		"SortUnitList":    "-",
	})
	if err != nil {
		log.Error(err)
		c.OutParamsErr(err.Error())
		return
	}

	userID := c.GetUID()
	isAdmin, err := p.mu.IsAdmin(userID)
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	// 非管理员智能查询自己的日志
	if !isAdmin {
		if parameter.UserID == PARAM_INT64_UNREQUIRED {
			ssc.AddEQ("user_id", userID)
		} else if parameter.UserID != userID {
			c.OutSuccess(map[string]interface{}{
				"count": 0,
				"list":  []map[string]interface{}{},
			})
			return
		}
	}

	count, list, err := p.ml.GetLoginLog(parameter.Mode, ssc, parameter.Limit, parameter.Offset)
	if err != nil {
		log.Error(err.Error())
		c.OutSysErr(err.Error())
		return
	}

	c.OutSuccess(map[string]interface{}{
		"count": count,
		"list":  list,
	})

}

// SysOperatorLog 系统操作日志
func (p User) SysOperatorLog(c *Context) {

	parameter := struct {
		Token        string `query:"token, required" sql:"EQ"`
		Limit        int64  `query:"limit, required"`
		Offset       int64  `query:"offset, required"`
		UserID       int64  `query:"user_id" sql:"EQ"`
		StartTime    string `query:"start_time" sql:"GE"`
		EndTime      string `query:"end_time" sql:"LE"`
		Content      string `query:"content" sql:"LIKE"`
		SortUnitList string `query:"sort_unit_list" sql:"SORT"`
	}{}

	if err := c.Bind(&parameter); err != nil {
		log.Error(err.Error())
		c.OutParamsErr()
		return
	}

	ssc, err := Param2SimpleSQLCondition(&parameter, map[string]string{
		"Token":        "token",
		"UserID":       "user_id",
		"StartTime":    "create_time",
		"EndTime":      "create_time",
		"Content":      "content",
		"SortUnitList": "-",
	})
	if err != nil {
		log.Error(err)
		c.OutParamsErr(err.Error())
		return
	}

	count, list, err := p.ml.GetOperatorLog(ssc, parameter.Limit, parameter.Offset)
	if err != nil {
		log.Error(err.Error())
		c.OutSysErr(err.Error())
		return
	}

	c.OutSuccess(map[string]interface{}{
		"count": count,
		"list":  list,
	})
}

// 人员查询
func (p User) Search(c *Context) {
	parameter := struct {
		Limit        int64  `query:"limit, required"`
		Offset       int64  `query:"offset, required"`
		SortUnitList string `query:"sort_unit_list" sql:"SORT"`
	}{}

	if err := c.Bind(&parameter); err != nil {
		log.Error(err.Error())
		c.OutParamsErr()
		return
	}

	ssc, err := Param2SimpleSQLCondition(&parameter, map[string]string{
		"SortUnitList": "-",
	})
	if err != nil {
		log.Error(err)
		c.OutParamsErr(err.Error())
		return
	}
	count, users, err := p.mu.Search(ssc, parameter.Limit, parameter.Offset)
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(map[string]interface{}{
		"count": count,
		"list":  users,
	})
}

// 个人密码修改
func (p User) UpdatePassword(c *Context) {
	parameter := struct {
		OldPassword string `json:"old_password,required"`
		NewPassword string `json:"new_password,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	user, err := p.mu.GetInfo(c.GetUID())
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	if (misc.Encrypt{}).NewSHA256(parameter.OldPassword+user.Salt) != user.Password {
		c.OutParamsErr("原密码不匹配")
		return
	}

	salt := misc.GetUUID()
	password := (misc.Encrypt{}).NewSHA256(parameter.NewPassword + salt)
	if _, err := p.mu.UpdateInfo(c.GetUID(), map[string]interface{}{
		"password": password,
		"salt":     salt,
	}, c.GetUID()); err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(nil)
	return
}

// 个人手机号修改
func (p User) UpdateTel(c *Context) {
	parameter := struct {
		Tel  string `json:"tel,required"`
		Code string `json:"code,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	isValid, err := p.mc.IsValid(parameter.Tel, parameter.Code)
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	if !isValid {
		c.OutParamsErr("验证码无效")
		return
	}
	if _, err := p.mu.UpdateInfo(c.GetUID(), map[string]interface{}{
		"tel": parameter.Tel,
	}, c.GetUID()); err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(nil)
	return
}
