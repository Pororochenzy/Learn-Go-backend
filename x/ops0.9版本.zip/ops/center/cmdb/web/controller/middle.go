package controller

import (
	"fmt"
	"net/http"
	"ops/center/cmdb/common"
	"ops/center/cmdb/log"
	s "ops/center/cmdb/session"
	"runtime"
	"time"

	"github.com/gin-gonic/gin"
)

func NewMiddle() *Middle {
	return &Middle{}
}

// Middle 中间件
type Middle struct{}

// Excetion 异常捕获处理
func (p *Middle) Excetion() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if r := recover(); r != nil {
				log.Error(r)
				for i := 0; i < common.LINE_NUM; i++ {
					funcName, file, line, ok := runtime.Caller(i)
					if ok {
						errmsg := fmt.Sprintf("frame %v:[func:%v,file:%v,line:%v]", i, runtime.FuncForPC(funcName).Name(), file, line)
						log.Error(errmsg)
					}
				}
				c.JSON(http.StatusInternalServerError, out{
					Code: CODE_SYSTEM_ERR,
					Msg:  "内部异常",
					Data: map[string]interface{}{},
				})
			}
		}()

		c.Next()
	}
}

// Life 生命周期
func (p *Middle) Life() gin.HandlerFunc {
	return func(c *gin.Context) {

		{
			token := c.Request.Header.Get("token")
			if token == "" {
				token = c.Query("token")
			}
			if token != "" {
				c.Set("token", token)
			}
		}

		start := time.Now()

		// 每个请求设置一个全局id，即此刻纳秒
		uuid := fmt.Sprintf("%v", start.UnixNano())
		c.Set("uuid", uuid)
		log.FInfo("[%v] %v: %v  From: %v", uuid, c.Request.Method, c.Request.RequestURI, getRequestIP(c))
		log.FInfo("[%v] Header: %v", uuid, c.Request.Header)
		queParms := c.Request.URL.Query()
		c.Request.ParseForm()
		formParms := c.Request.Form
		mutiParms, _ := c.MultipartForm()
		log.FInfo("[%v] Parms: %v, %v, %v", uuid, queParms, formParms, mutiParms)

		c.Next() //处理请求

		if value, ok := c.Get("out"); ok {
			log.FInfo("[%v] Back：%v", uuid, value)
		}

		log.FInfo("[%v] Time: %v Status: %v", uuid, time.Since(start), c.Writer.Status())
	}
}

// CheckAuth 权限校验
func (p *Middle) CheckAuth() gin.HandlerFunc {
	return func(c *gin.Context) {
		token, exists := c.Get("token")
		if !exists || token == "" {
			c.JSON(http.StatusOK, out{
				Code: CODE_LOGIN_ERR,
				Msg:  "请先登录",
				Data: map[string]interface{}{},
			})
			c.Abort()
			return
		}

		session, err := s.GetSession(token.(string))

		if err != nil {
			c.JSON(http.StatusInternalServerError, out{
				Code: CODE_SYSTEM_ERR,
				Msg:  "内部异常",
				Data: map[string]interface{}{},
			})
			c.Abort()
			return
		}

		if session == nil || session.IsTimeOut() {
			c.JSON(http.StatusOK, out{
				Code: CODE_LOGIN_ERR,
				Msg:  "会话过期，请重新登录",
				Data: map[string]interface{}{},
			})
			c.Abort()
			return
		}

		if session.Logout {
			c.JSON(http.StatusOK, out{
				Code: CODE_LOGIN_ERR,
				Msg:  "账号异地登录",
				Data: map[string]interface{}{},
			})
			c.Abort()
			return
		}

		if session.IP != getRequestIP(c) {
			c.JSON(http.StatusOK, out{
				Code: CODE_LOGIN_ERR,
				Msg:  "非法请求",
				Data: map[string]interface{}{},
			})
			c.Abort()
			return
		}

		// 刷新session有效期
		if !passURL(c) {
			session.RefreshExpired()
		}

		c.Set("uid", session.UserID)
		c.Next()
	}
}

func passURL(c *gin.Context) bool {
	return false
}

func getRequestIP(c *gin.Context) string {

	remoteAddr := c.Request.RemoteAddr
	if value, ok := c.Request.Header["X-Real-Ip"]; ok {
		if len(value) > 0 {
			remoteAddr = value[0]
		}
	}
	return remoteAddr
}
