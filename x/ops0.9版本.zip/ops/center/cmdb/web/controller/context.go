package controller

import (
	"net/http"
	"ops/module/table"
	"reflect"
	"strings"

	"github.com/bytedance/go-tagexpr/binding"
	"github.com/gin-gonic/gin"
)

const (
	// http业务返回码
	CODE_SUCCESS           = 0
	CODE_SYSTEM_ERR        = 1
	CODE_PARAMS_ERR        = 2
	CODE_NO_GRANT_ERR      = 3
	CODE_DATA_EXIST_ERR    = 4
	CODE_DATA_NOT_EXIT_ERR = 5
	CODE_DATA_VALUE_ERR    = 6
	CODE_LOGIN_ERR         = 7
)

// Out  返回
type out struct {
	Code int64       `json:"code"`    // 返回码
	Msg  string      `json:"message"` // 返回信息
	Data interface{} `json:"data"`    // 返回数据
}

// Context 仅仅用来处理http的请求和返回，以及维护一个http请求生命周期里面所有的数据
type Context struct {
	*gin.Context
	// 返回的格式数据
	back *out
	user *table.SysUser
}

// 传入参数获取
func (p *Context) Parameters(parmas interface{}) error {

	return nil
}

// RespSucc 成功
func (p *Context) OutSuccess(data interface{}) {
	p.Out(CODE_SUCCESS, "", data)
}

func (p *Context) OutParamsErr(msg ...string) {
	if len(msg) > 0 {
		p.Out(CODE_PARAMS_ERR, msg[0], nil)
		return
	}
	p.Out(CODE_PARAMS_ERR, "参数错误", nil)
}

// RespSysErr 失败
func (p *Context) OutSysErr(msg ...string) {
	if len(msg) > 0 {
		p.Out(CODE_SYSTEM_ERR, msg[0], nil)
		return
	}
	p.Out(CODE_SYSTEM_ERR, "系统内部异常", nil)
}

// 统一返回调用
func (p *Context) Out(code int64, msg string, data interface{}) {
	if data == nil {
		data = map[string]interface{}{}
	}
	p.back = &out{
		Code: code,
		Msg:  msg,
		Data: data,
	}
	p.JSON(http.StatusOK, *p.back)
}

// 反射给参数设置默认值
func (p *Context) reflectValueChange(content string, field *reflect.StructField, value *reflect.Value) {
	if content != "" {
		if !strings.Contains(content, "required") {
			switch field.Type.Kind() {
			case reflect.Int64:
				value.FieldByName(field.Name).Set(reflect.ValueOf(PARAM_INT64_UNREQUIRED))
			case reflect.String:
				value.FieldByName(field.Name).Set(reflect.ValueOf(PARAM_STRING_UNREQUIRED))
			case reflect.Float64:
				value.FieldByName(field.Name).Set(reflect.ValueOf(PARAM_FLOAT64_UNREQUIRED))
			}

		}
	}
}

// 重新绑定实现
func (p *Context) Bind(obj interface{}) error {
	objTypeElem := reflect.TypeOf(obj).Elem()
	objValueElem := reflect.ValueOf(obj).Elem()
	structLen := objValueElem.NumField()
	for i := 0; i < structLen; i++ {
		field := objTypeElem.Field(i)
		jsonContent := field.Tag.Get("json")
		queryContent := field.Tag.Get("query")
		p.reflectValueChange(jsonContent, &field, &objValueElem)
		p.reflectValueChange(queryContent, &field, &objValueElem)
	}

	binder := binding.New(nil)
	if err := binder.BindAndValidate(obj, p.Request, nil); err != nil {
		return err
	}
	return nil
}

func (p *Context) GetUID() int64 {
	v, ok := p.Get("uid")
	if !ok {
		return 0
	}
	return v.(int64)
}

func (p *Context) GetToken() string {
	v, ok := p.Get("token")
	if !ok {
		return ""
	}
	return v.(string)
}

// GetReqIP 获取请求IP
func (p *Context) GetRequestIP() string {

	return getRequestIP(p.Context)
}
