package controller

import (
	"ops/center/cmdb/log"
	"ops/center/cmdb/web/model"
)

// Role 角色
type Role struct {
	mr model.Role
}

// List 角色列表
func (p Role) List(c *Context) {

	parameter := struct {
		Limit           int64  `query:"limit, required"`
		Offset          int64  `query:"offset, required"`
		Name            string `query:"name" sql:"LIKE"`
		CreateUserID    int64  `query:"create_user_id" sql:"EQ"`
		CreateUserName  string `query:"create_user_name" sql:"JOIN" join:"LIKE|LEFT|[\"sys_user\",\"su\"]|su.id=sr.create_user_id"`
		StartCreateTime string `query:"start_create_time" sql:"GE"`
		EndCreateTime   string `query:"end_create_time" sql:"LE"`
		Remark          string `query:"remark" sql:"LIKE"`
		SortUnitList    string `query:"sort_unit_list" sql:"SORT"`
	}{}

	if err := c.Bind(&parameter); err != nil {
		log.Error(err.Error())
		c.OutParamsErr()
		return
	}

	ssc, err := Param2SimpleSQLCondition(&parameter, map[string]string{
		"Name":            "name",
		"CreateUserID":    "create_user_id",
		"StartCreateTime": "create_time",
		"EndCreateTime":   "create_time",
		"Remark":          "remark",
		"CreateUserName":  "name",
		"SortUnitList":    "-",
	})
	if err != nil {
		log.Error(err)
		c.OutParamsErr(err.Error())
		return
	}
	count, users, err := p.mr.List(ssc, parameter.Limit, parameter.Offset)
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(map[string]interface{}{
		"count": count,
		"list":  users,
	})
}
