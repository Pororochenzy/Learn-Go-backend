package controller

import (
	"crypto/md5"
	"fmt"
	"io/ioutil"
	"ops/center/cmdb/global"
	"ops/center/cmdb/log"
	"ops/center/cmdb/web/model"
	"ops/common/misc"
	"path"
)

type Sys struct {
	ms model.Sys
}

func (p Sys) InformUpdate(c *Context) {
	parameter := struct {
		Name    string `json:"name,required"`
		Switch  int64  `json:"switch,required"`
		Content string `json:"content,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	if err := p.ms.ResetInformSetting(parameter.Name, parameter.Switch, parameter.Content); err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(nil)
	return
}

// 通知方式详情
func (p Sys) InformDetail(c *Context) {
	details, err := p.ms.InformDetail()
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(map[string]interface{}{
		"list": details,
	})
	return
}

// 通知测试
func (p Sys) InformTest(c *Context) {
	parameter := struct {
		Name    string `json:"name,required"`
		Content string `json:"content,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		c.OutParamsErr(err.Error())
		return
	}
	// todo

	c.OutSuccess(map[string]interface{}{
		"msg": "测试通过！",
	})
	return
}

func (p Sys) SettingUpdate(c *Context) {
	param := struct {
		SettingType    string `json:"setting_type,required"`
		SettingContent string `json:"setting_content,required"`
	}{}
	if err := c.Bind(&param); err != nil {
		log.Error(err)
		c.OutParamsErr(err.Error())
		return
	}

	if err := p.ms.SettingUpdate(param.SettingType, param.SettingContent); err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(nil)
	return
}

func (p Sys) SettingDetail(c *Context) {

	details, err := p.ms.SettingDetail()
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}

	c.OutSuccess(details)
	return
}

func (p Sys) FileUpload(c *Context) {

	err := c.Request.ParseMultipartForm(31457280) // limit 30MB
	if err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}

	fileList := []*model.FileDesc{}

	formdata := c.Request.MultipartForm
	for fNs, fhs := range formdata.File {
		for _, fh := range fhs {
			f, err := fh.Open()
			if err != nil {
				log.Error(err)
				c.OutSysErr(err.Error())
				return
			}
			defer f.Close()

			// 计算文件md5
			body, err := ioutil.ReadAll(f)
			if err != nil {
				log.Error(err)
				c.OutSysErr(err.Error())
				return
			}
			fMD5 := fmt.Sprintf("%x", md5.Sum(body))
			fName := fh.Filename
			fPath := path.Join(global.ResourceRoot, fNs, fMD5, fName)

			// 判断文件是否已存在
			// desc, err := p.ms.FileDetail(fMD5)
			// if err != nil {
			// 	log.Error(err)
			// 	c.OutSysErr(err.Error())
			// 	return
			// }

			// 如果文件不存在，则保存文件
			// if desc == nil {
			if err := misc.SaveFile(fPath, body); err != nil {
				log.Error(err)
				c.OutSysErr(err.Error())
				return
			}
			// } else {
			// 	fPath = desc.Path
			// }

			// 插入记录到数据库
			{
				desc, err := p.ms.AddFile(fName, fNs, fMD5, fPath, c.GetUID())
				if err != nil {
					log.Error(err)
					c.OutSysErr(err.Error())
					return
				}
				fileList = append(fileList, desc)
			}
		}
	}

	c.OutSuccess(map[string]interface{}{
		"list": fileList,
	})
	return
}

// 发送手机验证码
func (p Sys) GetTelCode(c *Context) {
	parameter := struct {
		Tel string `query:"tel,required"`
	}{}
	if err := c.Bind(&parameter); err != nil {
		log.Error(err)
		c.OutParamsErr(err.Error())
		return
	}

	if err := new(model.Code).SendTelCode(parameter.Tel); err != nil {
		log.Error(err)
		c.OutSysErr(err.Error())
		return
	}
	c.OutSuccess(nil)
	return
}
