package model

import (
	"fmt"
	"ops/center/cmdb/db"
	"ops/module/table"
)

type Role struct{}

// 获取角色
func (p Role) GetInfo(id int64) (*table.SysRole, error) {
	session := db.NewSession()
	defer session.Close()
	role := new(table.SysRole)
	exists, err := session.ID(id).Get(role)
	if err != nil {
		return nil, err
	}
	if !exists {
		return nil, fmt.Errorf("角色不存在")
	}
	return role, nil
}

// 检查角色是否存在
func (p Role) CheckIsExist(id int64) (bool, error) {
	session := db.NewSession()
	defer session.Close()
	return session.ID(id).Exist(new(table.SysRole))
}

// List 角色列表查询
func (p Role) List(ssc *db.SimpleSQLCondition, args ...int64) (int64, []table.SysRole, error) {

	sr := new([]table.SysRole)
	count, err := db.SearchAndCount([]string{"sys_role", "sr"}, sr, ssc, args...)
	if err != nil {
		return 0, nil, err
	}
	return count, *sr, nil
}
