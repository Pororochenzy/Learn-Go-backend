package model

import (
	"encoding/json"
	"errors"
	"ops/center/cmdb/db"
	req_session "ops/center/cmdb/session"
	"ops/common/misc"
	"ops/module/table"
)

type Sys struct {
}

// 重置通方式知设置
func (p Sys) ResetInformSetting(name string, swit int64, content string) error {
	// 查询系统设置表中是否有此信息
	setting := new(table.SysSettingInform)
	session := db.NewSession()
	defer session.Close()

	exist, err := session.Where("name=?", name).Exist(setting)
	if err != nil {
		return err
	}
	if exist {
		if _, err := session.UpdateTable("sys_setting_inform", map[string]interface{}{
			"name": name,
		}, map[string]interface{}{
			"switch":  swit,
			"content": content,
		}); err != nil {
			return err
		}
	} else {
		if _, err := session.InsertTable("sys_setting_inform", map[string]interface{}{
			"name":    name,
			"switch":  swit,
			"content": content,
		}); err != nil {
			return err
		}
	}
	return nil
}

// 通知方式详情
func (p Sys) InformDetail() ([]table.SysSettingInform, error) {

	session := db.NewSession()
	defer session.Close()

	rows := []table.SysSettingInform{}
	if err := session.Find(&rows); err != nil {
		return nil, err
	}
	return rows, nil
}

func (p Sys) SettingUpdate(settingType, settingcontent string) error {

	session := db.NewSession()
	defer session.Close()

	setting := new(table.SysSetting)
	has, err := session.Where("name=?", settingType).Get(setting)
	if err != nil {
		return err
	}

	if has {
		setting.Content = settingcontent
		effectID, err := session.Id(setting.Id).Cols("content").Update(setting)
		if err != nil {
			return err
		}

		// session策略更新成功，刷新系统session信息
		if effectID > 0 && settingType == string(SYS_TYPE_SESSION_POLICY) {
			req_session.LoadSessionEffect(setting.Content)
		}
	}

	return nil
}

func (p Sys) SettingDetail() (map[string]interface{}, error) {

	out := make(map[string]interface{})

	session := db.NewSession()
	defer session.Close()

	rows := []*table.SysSetting{}
	if err := session.Find(&rows); err != nil {
		return nil, err
	}

	for _, row := range rows {
		out[row.Name] = row.Content
	}

	return out, nil
}

type FileDesc struct {
	Id           int64  `json:"id"`
	Name         string `json:"name"`
	NameSpace    string `json:"namespace"`
	MD5          string `json:"md5"`
	Path         string `json:"path"`
	CreateUserId int64
}

func (p Sys) AddFile(name, namespace, md5, path string, createUserId int64) (*FileDesc, error) {

	sf := &table.SysUploadFile{
		Name:         name,
		Namespace:    namespace,
		Md5:          md5,
		Path:         path,
		CreateUserId: createUserId,
		CreateTime:   misc.CurrentTimeStr(),
		UpdateTime:   misc.CurrentTimeStr(),
	}
	session := db.NewSession()
	defer session.Close()

	_, err := session.Insert(sf)
	if err != nil {
		return nil, err
	}

	return &FileDesc{
		Id:           sf.Id,
		Name:         name,
		NameSpace:    namespace,
		MD5:          md5,
		Path:         path,
		CreateUserId: sf.CreateUserId,
	}, nil
}

func (p Sys) FileDetail(md5 string) (*FileDesc, error) {

	session := db.NewSession()
	defer session.Close()

	sf := new(table.SysUploadFile)
	has, err := session.Where("md5=?", md5).Get(sf)
	if err != nil {
		return nil, err
	}

	if !has {
		return nil, nil
	}

	return &FileDesc{
		Id:           sf.Id,
		Name:         sf.Name,
		NameSpace:    sf.Namespace,
		MD5:          sf.Md5,
		Path:         sf.Path,
		CreateUserId: sf.CreateUserId,
	}, nil
}

// SysSettingType 系统配置类型
type SysSettingType string

var (
	SYS_TYPE_LOGIN_POLICY   = SysSettingType("login_policy")   // 登录策略
	SYS_TYPE_SESSION_POLICY = SysSettingType("session_policy") // session策略
	SYS_TYPE_ACCOUNT_POLICY = SysSettingType("account_policy") // 账户策略

	LOGIN_TYPE_INTERNAL = "internal" // 内部登录
	LOGIN_TYPE_SSO      = "sso"      // SSO登录
)

// LoginPolicy 登录策略
type LoginPolicy struct {
	Type  string                            `json:"login_type"`
	Param map[string]map[string]interface{} `json:"login_param"`
}

// SessionPolicy session策略
type SessionPolicy struct {
	Switch     int64 `json:"switch"`
	EffectTime int64 `json:"effect_time"` //单位 分钟
}

// AccountPolicy 账户策略
type AccountPolicy struct {
	ErrorMsg   string `json:"error_msg"`
	RetryTimes int64  `json:"retry_times"`
}

// IsAdapt 是否满足策略 true.满足 超过错误次数
func (p *AccountPolicy) IsAdapt(times int64) bool {
	if times >= p.RetryTimes {
		return true
	}
	return false
}

// SettingContentDetail 系统配置内存详情
// 返回对应系统配置类型对象指针信息
func (p Sys) SettingContentDetail(settingType SysSettingType) (interface{}, error) {

	setting := &table.SysSetting{}

	session := db.NewSession()
	defer session.Close()

	exists, err := session.Where("name=?", settingType).Get(setting)
	if err != nil {
		return nil, err
	}

	if !exists {
		return nil, errors.New("配置不存在")
	}

	var bean interface{}

	switch settingType {
	case SYS_TYPE_LOGIN_POLICY:
		bean = &LoginPolicy{}
	case SYS_TYPE_SESSION_POLICY:
		bean = &SessionPolicy{}
	case SYS_TYPE_ACCOUNT_POLICY:
		bean = &AccountPolicy{}
	default:
		return setting, nil
	}

	if err := json.Unmarshal([]byte(setting.Content), bean); err != nil {
		return nil, err
	}

	return bean, nil
}
