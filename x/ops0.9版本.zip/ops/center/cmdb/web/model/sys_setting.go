package model

import (
	"ops/center/cmdb/global"
	"ops/module/table"
)

type SysSetting struct{}

// 获取企业信息
func (p SysSetting) GetEnterpriseInfo(name string) (*table.SysSetting, error) {
	row := table.SysSetting{}
	exist, err := global.DBEngine.Table("sys_setting").Where("name=?", name).Get(&row)
	if !exist {
		return nil, err
	}
	return &row, err
}

//  编辑企业信息
func (p SysSetting) UpdateEnterpriseInfo(data *table.SysSetting) (int64, error) {
	result, err := global.DBEngine.Exec(`
		update
			sys_setting	
		set
			content = ?
		where
			id = 4 
		`, data.Content)
	if err != nil {
		return 0, err
	}

	return result.RowsAffected()
}
