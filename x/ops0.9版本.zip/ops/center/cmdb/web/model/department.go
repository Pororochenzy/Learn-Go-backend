package model

import (
	"fmt"
	"ops/center/cmdb/db"
	"ops/common/tools"
	"ops/module/table"
	"strings"
	"time"
)

// 操作日志type定义
const (
	SYS_OPERATOR_LOG_TYPE_SYSTEM  = "system"
	SYS_OPERATOR_LOG_TYPE_CMDB    = "cmdb"
	SYS_OPERATOR_LOG_TYPE_MONITOR = "monitor"
)

const (
	OBJECT_TYPE_DEPARTMENT = "department"
	DEPARTMENT_JOIN_FLAG   = "/"
)

type Department struct{}

// 检查部门是否存在
func (p Department) checkNameExist(parentID int64, name string) (bool, error) {
	session := db.NewSession()
	defer session.Close()

	return session.SQL("SELECT id FROM sys_user_department WHERE parent_id=? AND name=?", parentID, name).Exist()
}

type DeparmentAddParameter struct {
	ParentId int64
	Name     string
}

// 获取部门小组的层级数
func (p Department) GetLevel(id int64) (int, error) {
	sud := new(table.SysUserDepartment)

	session := db.NewSession()
	defer session.Close()

	_, err := session.ID(id).Get(sud)
	return sud.Level, err
}

// 新增部门小组
func (p Department) Add(dep DeparmentAddParameter, userId int64) (int64, error) {
	// 检查是否部门重复
	if exist, err := p.checkNameExist(dep.ParentId, dep.Name); err != nil {
		return 0, err
	} else if exist {
		return 0, fmt.Errorf("部门或小组已存在，无法重复添加")
	}

	// 插入信息
	session := db.NewSession()
	defer session.Close()

	if err := session.Begin(); err != nil {
		return 0, err
	}
	defer session.Rollback()

	partInfo, err := p.GetInfo(dep.ParentId)
	if err != nil {
		return 0, err
	}
	if partInfo == nil {
		return 0, fmt.Errorf("父级部门不存在")
	}

	now := tools.GetTimeString(time.Now())
	sud := &table.SysUserDepartment{
		ParentId:     dep.ParentId,
		Name:         dep.Name,
		PathName:     partInfo.PathName + DEPARTMENT_JOIN_FLAG + partInfo.Name,
		Level:        partInfo.Level + 1,
		CreateUserId: userId,
		UpdateTime:   now,
		CreateTime:   now,
	}

	effect, err := session.InsertOne(sud)
	if err != nil {
		session.Rollback()
		return sud.Id, err
	}

	if effect > 0 {
		// 写日志
		if err := WriteOperLog(LogParameter{
			Type:       SYS_OPERATOR_LOG_TYPE_SYSTEM,
			UserID:     userId,
			ObjectType: OBJECT_TYPE_DEPARTMENT,
			ObjectID:   sud.Id,
			Content:    "新增部门小组：" + dep.Name,
		}, session); err != nil {
			session.Rollback()
			return sud.Id, err
		}
	}
	session.Commit()
	return sud.Id, nil
}

// 检查部门下是否存在人
func (p Department) CheckUserExist(id int64) (bool, error) {
	return true, nil
}

// 检查部门是否存在子部门
func (p Department) CheckSubExist(id int64) (bool, error) {
	return true, nil
}

// 移除部门下所有的用户
func (p Department) RemoveAllUser(id int64, args ...*db.Session) (int64, error) {
	session := db.NewSession(args...)
	defer session.Close(args...)

	relation := new(table.SysUserDepartmentRelation)
	return session.Where("user_department_id=?", id).Delete(relation)
}

// 级联删除部门小组
func (p Department) cascadeDelete(id, userId int64, args ...*db.Session) error {
	session := db.NewSession(args...)
	defer session.Close(args...)

	{
		suds := []table.SysUserDepartment{}
		err := session.Where("parent_id=?", id).Find(&suds)
		if err != nil {
			return err
		}
		for _, sud := range suds {
			if err := p.cascadeDelete(sud.Id, userId, session); err != nil {
				return err
			}
		}
	}

	sud := new(table.SysUserDepartment)
	effect, err := session.ID(id).Delete(sud)
	if err != nil {
		return err
	}
	if effect > 0 {
		// 解除部门小组关联的用户
		if _, err := p.RemoveAllUser(id, session); err != nil {
			return err
		}
		// 写日志
		if err := WriteOperLog(LogParameter{
			Type:       SYS_OPERATOR_LOG_TYPE_SYSTEM,
			UserID:     userId,
			ObjectType: OBJECT_TYPE_DEPARTMENT,
			ObjectID:   id,
			Content:    "删除部门小组",
		}, session); err != nil {
			return err
		}
	}
	return nil
}

// 删除部门小组
func (p Department) Delete(id, userId int64) error {
	// 插入信息
	session := db.NewSession()
	defer session.Close()

	if err := session.Begin(); err != nil {
		return err
	}
	defer session.Rollback()

	if err := p.cascadeDelete(id, userId, session); err != nil {
		return err
	}

	session.Commit()
	return nil
}

type DeparmentList struct {
	Id           int64       `json:"id"`
	ParentId     int64       `json:"parent_id"`
	Name         string      `json:"name"`
	Level        int64       `json:"level"`
	CreateUserId int64       `json:"create_user_id"`
	List         interface{} `json:"list"`
}

func (p Department) cascadeList(parentId int64) ([]*DeparmentList, error) {

	out := []*DeparmentList{}

	session := db.NewSession()
	defer session.Close()

	rows := []table.SysUserDepartment{}
	if err := session.Where("parent_id=?", parentId).Find(&rows); err != nil {
		return nil, err
	}
	for _, row := range rows {
		dep := new(DeparmentList)
		var err error
		dep.Id = row.Id
		dep.Level = int64(row.Level)
		dep.Name = row.Name
		dep.ParentId = row.ParentId
		dep.CreateUserId = row.CreateUserId
		dep.List, err = p.cascadeList(row.Id)
		if err != nil {
			return nil, err
		}
		out = append(out, dep)
	}
	return out, nil
}

// 获取部门小组
func (p Department) List() ([]*DeparmentList, error) {
	return p.cascadeList(0)
}

// 获取部门的全路径名称
func (p Department) GetInfo(id int64) (*table.SysUserDepartment, error) {

	session := db.NewSession()
	defer session.Close()

	sud := new(table.SysUserDepartment)
	exist, err := session.ID(id).Get(sud)
	if err != nil {
		return nil, err
	}
	if !exist {
		return nil, nil
	}
	return sud, nil
}

// 检查部门是否存在
func (p Department) CheckIsExist(id int64) (bool, error) {
	session := db.NewSession()
	defer session.Close()
	return session.ID(id).Exist(new(table.SysUserDepartment))
}

// 更新部门信息
func (p Department) Update(id int64, set map[string]interface{}, userId int64) error {
	session := db.NewSession()
	defer session.Close()

	if err := session.Begin(); err != nil {
		return err
	}
	defer session.Rollback()

	oldInfo, err := p.GetInfo(id)
	if err != nil {
		return err
	}
	if oldInfo == nil {
		return fmt.Errorf("部门小组不存在")
	}

	if len(set) > 0 {
		effect, err := session.UpdateTable("sys_user_department", map[string]interface{}{
			"id": id,
		}, set)
		if err != nil {
			return err
		}
		if effect > 0 {
			if v, ok := set["name"]; ok {
				// 修改子部门的path_name字段
				newName := v.(string)
				if oldInfo.Name != newName {
					oldSubPathName := oldInfo.PathName + DEPARTMENT_JOIN_FLAG + oldInfo.Name
					newSubPathName := oldInfo.PathName + DEPARTMENT_JOIN_FLAG + newName
					subs := []table.SysUserDepartment{}
					if err := session.Where("parent_id=?", id).Find(&subs); err != nil {
						return err
					}
					for _, sub := range subs {
						if sub.PathName == oldSubPathName || strings.Contains(sub.PathName, oldSubPathName+DEPARTMENT_JOIN_FLAG) {
							sub.PathName = strings.Replace(sub.PathName, oldSubPathName, newSubPathName, 1)
							if _, err := session.ID(sub.Id).Update(sub); err != nil {
								return err
							}
						}
					}
				}
			}
			// 写日志
			if err := WriteOperLog(LogParameter{
				Type:       SYS_OPERATOR_LOG_TYPE_SYSTEM,
				UserID:     userId,
				ObjectType: OBJECT_TYPE_DEPARTMENT,
				ObjectID:   id,
				Content:    "修改了部门信息",
			}, session); err != nil {
				return err
			}
		}
	}

	return session.Commit()
}
