package model

type Code struct{}

// 发送手机验证码
func (p Code) SendTelCode(tel string) error {
	return nil
}

// 判断验证码是否可以
func (p Code) IsValid(tel, code string) (bool, error) {
	return true, nil
}
