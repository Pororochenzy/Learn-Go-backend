package model

import (
	"fmt"
	"ops/center/cmdb/db"
	"ops/center/cmdb/log"
	"ops/common/tools"
	"ops/module/table"
	"time"
)

const (
	LOGIN_LOG_MODE_RECENT  = 0
	LOGIN_LOG_MODE_HISTORY = 1

	LOGIN_LOG_STATUS_SUCCESS = 0
	LOGIN_LOG_STATUS_FAILED  = 1
)

type Log struct{}

type LogParameter struct {
	Type       string
	UserID     int64
	ObjectType string
	ObjectID   int64
	Content    string
}

// 写操作日志
func (p Log) WriteOperLog(data LogParameter, args ...*db.Session) error {

	user := User{}

	now := tools.GetTimeString(time.Now())
	row := table.SysOperatorLog{
		Type:       data.Type,
		UserId:     data.UserID,
		Token:      user.GetToken(data.UserID),
		ObjectType: data.ObjectType,
		ObjectId:   data.ObjectID,
		Content:    data.Content,
		UpdateTime: now,
		CreateTime: now,
	}

	session := db.NewSession(args...)
	defer session.Close(args...)

	_, err := session.InsertOne(row)
	return err
}

// 写操作日志
func WriteOperLog(data LogParameter, args ...*db.Session) error {
	log := Log{}
	return log.WriteOperLog(data, args...)
}

// OperatorLog 操作日志
type OperatorLog struct {
	table.SysOperatorLog `xorm:"extends"`
	UserName             string `json:"user_name" xorm:"-"`
}

// GetOperatorLog 获取操作日志
func (p Log) GetOperatorLog(ssc *db.SimpleSQLCondition, args ...int64) (int64, []OperatorLog, error) {

	list := []OperatorLog{}
	count, err := db.SearchAndCount("sys_operator_log", &list, ssc, args...)
	if err != nil {
		log.Error(err)
		return 0, nil, err
	}

	for i, item := range list {
		if u, err := (User{}).GetInfo(item.UserId); err != nil || u == nil {
			log.Error("用户不存在: ", err)
		} else {
			list[i].UserName = u.Name
		}
	}

	return count, list, nil
}

// UserLoginLog 用户登录日志
type UserLoginLog struct {
	table.SysUserLoginLog `xorm:"extends"`
	UserName              string `json:"user_name" xorm:"-"`
}

// GetLoginLog 获取用户登录日志列表
func (p Log) GetLoginLog(mode int64, ssc *db.SimpleSQLCondition, args ...int64) (int64, []UserLoginLog, error) {

	tableName := "sys_user_login_log"
	if mode > LOGIN_LOG_MODE_RECENT {
		tableName = "history_sys_user_login_log"
	}

	list := []UserLoginLog{}
	count, err := db.SearchAndCount(tableName, &list, ssc, args...)
	if err != nil {
		log.Error(err)
		return 0, nil, err
	}

	for i, item := range list {
		if u, err := (User{}).GetInfo(item.UserId); err != nil || u == nil {
			log.Error("用户不存在: ", err)
		} else {
			list[i].UserName = u.Name
		}
		if item.Duration == 0 {
			list[i].LogoutTime = ""
		}
	}

	return count, list, nil
}

/*<<<<<<< HEAD
type UserLogParameter struct {
	UserId     int64
	Status     int
	Msg        string
	Ip         string
	Token      string
	LoginTime  time.Time
	LogoutTime time.Time
}

//  用户登录日志设置
func (p Log) SetLoginLog(data *table.SysUserLoginLog, args ...*db.Session) error {
	//user_id ,status, msg , ip,token ,login_time,logout_time, duration,
	//user := &User{}
	session := db.NewSession(args...)
	defer session.Close(args...)

	session.InsertOne(data)
=======*/
// WriteLoginLog 用户登录日志设置
func (p Log) WriteLoginLog(ip string, userID, status int64, msg, token string, args ...*db.Session) error {

	session := db.NewSession(args...)
	defer session.Close(args...)

	now := tools.GetTimeString(time.Now())

	_, err := session.Insert(&table.SysUserLoginLog{
		UserId:     userID,
		Status:     int(status),
		Msg:        msg,
		Ip:         ip,
		Token:      token,
		LoginTime:  now,
		LogoutTime: now,
		Duration:   0,
		UpdateTime: now,
		CreateTime: now,
	})

	return err
}

// WriteLogoutLog 登出日志
func (p Log) WriteLogoutLog(token, msg string) error {

	session := db.NewSession()
	defer session.Close()

	loginLog := new(table.SysUserLoginLog)
	exists, err := session.Where("token=?", token).Get(loginLog)
	if err != nil {
		return err
	}
	if !exists {
		return fmt.Errorf("token: %v 不存在", token)
	}

	now := time.Now()
	loginLog.LogoutTime = tools.GetTimeString(now)
	loginLog.LogoutMsg = msg

	loginTime, err := time.ParseInLocation(tools.TimeFormat, loginLog.LoginTime, time.Local)
	if err != nil {
		log.Error(err)
	} else {
		loginLog.Duration = int(now.Unix() - loginTime.Unix())
	}

	if _, err := session.Id(loginLog.Id).Cols("duration", "logout_time", "logout_msg").Update(loginLog); err != nil {
		log.Error(err)
	}

	return nil

}
