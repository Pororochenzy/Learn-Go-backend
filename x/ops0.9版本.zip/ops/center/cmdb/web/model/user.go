package model

import (
	"errors"
	"fmt"
	"ops/center/cmdb/db"
	"ops/center/cmdb/global"
	"ops/center/cmdb/log"
	req_session "ops/center/cmdb/session"
	"ops/common/misc"
	"ops/common/tools"
	"ops/module/table"
	"time"
)

const (
	OBJECT_TYPE_USER         = "user"
	USER_LOGIN_STATUS_NORMAL = 0
	USER_LOGIN_STATUS_FROZEN = 1
)

type User struct{}

// 获取用户信息
func (p User) GetInfo(uid int64) (*table.SysUser, error) {
	session := db.NewSession()
	defer session.Close()

	user := new(table.SysUser)
	exist, err := session.ID(uid).Get(user)
	if err != nil {
		return nil, err
	}
	if !exist {
		return nil, fmt.Errorf("用户不存在")
	}
	return user, nil
}

// GetInfoByAccount 通过账户获取用户信息
func (p User) GetInfoByAccount(account string) (*table.SysUser, error) {
	session := db.NewSession()
	defer session.Close()

	su := new(table.SysUser)

	exist, err := session.Where("account=? AND is_delete=0", account).Get(su)
	if err != nil {
		return nil, err
	}
	if !exist {
		return nil, fmt.Errorf("账号不存在")
	}

	return su, nil
}

// 根据条件获取用户信息
func (p User) GetUserInfoCondition(m map[string]interface{}) ([]table.SysUser, error) {
	if len(m) == 0 {
		return nil, fmt.Errorf("未带查询条件")
	}

	session := db.NewSession().Where("1=1")
	defer session.Close()
	for k, v := range m {
		session = session.And(k+"=?", v)
	}
	rows := []table.SysUser{}
	err := session.Find(&rows)

	return rows, err
}

// GetUserCustom db 获取
func (p User) GetCustom(uid, typ int64) (*table.SysUserCustomSetting, error) {
	session := db.NewSession()
	defer session.Close()
	custom := &table.SysUserCustomSetting{}
	_, err := session.Where("user_id=? and type_id = ?", uid, typ).Get(custom)
	if err != nil {
		return nil, err
	}
	return custom, nil
}

// SaveUserCustom save custom

func (p User) SaveUserCustom(uid int64, typeID int64, content string) (bool, error) {
	custom, err := p.GetCustom(uid, typeID)
	if err != nil {
		return false, err
	}
	var (
		result int64
	)
	data := &table.SysUserCustomSetting{
		UserId:  uid,
		TypeId:  typeID,
		Content: content,
	}
	// insert
	if custom.TypeId <= 0 {
		result, err = p.AddUserCustom(data)
	} else {
		// update
		result, err = p.UpdateUserCustom(data)
	}
	if err != nil {
		return false, err
	}
	if result > 0 {
		return true, nil
	}
	return false, nil
}

// AddUserCustom 添加用户习惯
func (p User) AddUserCustom(data *table.SysUserCustomSetting) (int64, error) {
	session := db.NewSession()
	defer session.Close()
	return session.InsertTable("sys_user_custom_setting", map[string]interface{}{
		"type_id": data.TypeId,
		"user_id": data.UserId,
		"content": data.Content,
	})
}

// UpdateUserCustom 修改用户习惯
func (p User) UpdateUserCustom(data *table.SysUserCustomSetting) (int64, error) {
	session := db.NewSession()
	defer session.Close()
	return session.UpdateTable("sys_user_custom_setting", map[string]interface{}{
		"user_id": data.UserId,
		"type_id": data.TypeId,
	}, map[string]interface{}{
		"content": data.Content,
	})
}

// 修改用户信息
func (p User) UpdateInfo(uid int64, info map[string]interface{}, updateUser int64) (int64, error) {

	session := db.NewSession()
	defer session.Close()

	if err := session.Begin(); err != nil {
		return 0, err
	}
	defer session.Rollback()

	// 先修改部门和角色
	if roleId, ok := info["role_id"].(int64); ok {
		if err := p.SetRole(uid, roleId, updateUser, session); err != nil {
			session.Rollback()
			return 0, err
		}
		delete(info, "role_id")
	}
	if departmentId, ok := info["department_id"].(int64); ok {
		if err := p.SetDepartment(uid, departmentId, updateUser, session); err != nil {
			session.Rollback()
			return 0, err
		}
		delete(info, "department_id")
	}

	// 检查名称是否冲突
	for _, col := range []string{"account", "tel", "email"} {
		if v, ok := info[col]; ok {
			exist, err := p.CheckExist(col, v, uid)
			if err != nil {
				return 0, err
			}
			if exist {
				return 0, fmt.Errorf(col + "冲突")
			}
		}
	}

	effect := int64(0)
	if len(info) > 0 {
		effect, err := session.UpdateTable("sys_user", map[string]interface{}{
			"id": uid,
		}, info)
		if err != nil {
			log.Error(err)
			session.Rollback()
			return effect, err
		}
	}

	if effect > 0 {
		if err := WriteOperLog(LogParameter{
			Type:       SYS_OPERATOR_LOG_TYPE_SYSTEM,
			UserID:     updateUser,
			ObjectType: OBJECT_TYPE_USER,
			ObjectID:   uid,
			Content:    fmt.Sprintf("修改用户信息"),
		}, session); err != nil {
			session.Rollback()
			return 0, err
		}
	}

	session.Commit()
	return effect, nil
}

// 判断用户是否为管理员
func (p User) IsAdmin(uid int64) (bool, error) {
	session := db.NewSession()
	defer session.Close()
	sql := `
		SELECT 
			sr.name 
		FROM 
			sys_role AS sr 
		LEFT JOIN
			sys_user_role_relation AS surr ON surr.role_id=sr.id
		WHERE
			surr.user_id=?
		`
	sysRole := new(table.SysRole)
	if _, err := session.SQL(sql, uid).Get(sysRole); err != nil {
		return false, err
	}
	return sysRole.Name == "admin", nil
}

// 获取部门
func (p User) GetDepartment(uid int64) (*table.SysUserDepartment, error) {
	session := db.NewSession()
	defer session.Close()

	// 先找出department_id
	sudr := new(table.SysUserDepartmentRelation)
	exist, err := session.Where("user_id=?", uid).Get(sudr)
	if err != nil {
		return nil, err
	}
	if !exist {
		return nil, nil
	}
	return (Department{}).GetInfo(sudr.UserDepartmentId)
}

// InternalLogin 内部登录
func (p User) InternalLogin(su *table.SysUser, password, loginIP string) (string, error) {

	// 用户密码策略
	if err := p.ValidatorPass(su, password); err != nil {
		if err := (&Log{}).WriteLoginLog(loginIP, su.Id, LOGIN_LOG_STATUS_FAILED, err.Error(), ""); err != nil {
			log.Error("登录日志记录异常：", err)
		}
		log.Error("验证密码策略异常：", err)
		return "", err
	}

	// 产生token
	token, err := req_session.CreateSession(su.Id, loginIP)
	if err != nil {
		if err := (&Log{}).WriteLoginLog(loginIP, su.Id, LOGIN_LOG_STATUS_FAILED, err.Error(), ""); err != nil {
			log.Error("登录日志记录异常：", err)
		}
		log.Error("session生成异常: ", err)
		return "", err
	}

	if su.WrongTimes > 0 {
		su.WrongTimes = 0 //
		su.FrozenTimestamp = 0

		session := db.NewSession()
		defer session.Close()

		_, err := session.Id(su.Id).Cols("wrong_times", "frozen_timestamp").Update(su)
		if err != nil {
			log.Error("更新密码错误次数异常: ", err)
		}
	}

	// 记录登录成功日志
	if err := (&Log{}).WriteLoginLog(loginIP, su.Id, LOGIN_LOG_STATUS_SUCCESS, "登录成功", token); err != nil {
		log.Error("登录日志记录异常：", err)
	}
	return token, nil
}

// ValidatorPass 校验密码
func (p User) ValidatorPass(u *table.SysUser, password string) error {

	// 账户策略
	policy, err := (Sys{}).SettingContentDetail(SYS_TYPE_ACCOUNT_POLICY) //返回sys_setting里的content总字段
	if err != nil {
		log.Error("获取账户登录策略异常: ", err)
		return err
	}
	ap := policy.(*AccountPolicy)
	if ap.IsAdapt(int64(u.WrongTimes)) {
		log.Warn("超过设置的错误次数", ap.RetryTimes, u.WrongTimes)
		return errors.New(ap.ErrorMsg)
	}

	var resErr error
	// 校验密码
	if (misc.Encrypt{}).NewSHA256(password+u.Salt) != u.Password {

		u.WrongTimes++
		session := db.NewSession()
		defer session.Close()

		columns := []string{"wrong_times"}

		if ap.IsAdapt(int64(u.WrongTimes)) {
			u.Status = USER_LOGIN_STATUS_FROZEN
			u.FrozenTimestamp = time.Now().Unix()
			columns = append(columns, "status", "frozen_timestamp")
			resErr = errors.New(ap.ErrorMsg)
		} else {
			resErr = errors.New("账户或密码错误")
		}

		_, tmpErr := session.Id(u.Id).Cols(columns...).Update(u)
		if tmpErr != nil {
			log.Error("更新密码错误次数异常: ", tmpErr)
		}
	}

	return resErr
}

// Logout 用户登出
func (p User) Logout(token string) error {
	return req_session.DelSession(token)
}

// UserLogin 检查用户名是否存在
func (p User) CheckUsernameExit(name string) (bool, error) {
	/*sysUser := &table.SysUser{}
	return global.DB.Where("name=?", name).Get(sysUser)*/
	return global.DBEngine.SQL("SELECT id FROM sys_user WHERE username=?", name).Exist()
}

// 获取用户的会话token
func (p User) GetToken(uid int64) string {
	session, e := req_session.GetSessionByUserID(uid)
	if session == nil || e != nil {
		return ""
	}
	return session.Token
}

// 生成默认密码
func (p User) defaultPassword() (string, string) {

	salt := misc.GetUUID()
	return (misc.Encrypt{}).NewSHA256("8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92" + salt), salt
}

// 检查是否冲突
func (p User) CheckExist(key string, value interface{}, args ...int64) (bool, error) {
	session := db.NewSession()

	defer session.Close()

	user := new(table.SysUser)
	exist, err := session.Where(key+"=?", value).Where("is_delete=0").Get(user)

	if len(args) == 0 {
		return exist, err
	} else {
		if user.Id == args[0] {
			return false, nil
		}
		return exist, err
	}
}

// 新增用户
func (p User) Add(user *table.SysUser, roleId int64, departmentId int64) (int64, error) {
	if user.Password == "" {
		user.Password, user.Salt = p.defaultPassword()
	} else {
		user.Salt = misc.GetUUID()
		user.Password = (misc.Encrypt{}).NewSHA256(user.Password + user.Salt)
	}

	{
		if user.Account != "" {
			exist, err := p.CheckExist("account", user.Account)
			if err != nil {
				return 0, err
			}
			if exist {
				return 0, fmt.Errorf("账号已存在")
			}
		}
		if user.Tel != "" {
			exist, err := p.CheckExist("tel", user.Tel)
			if err != nil {
				return 0, err
			}
			if exist {
				return 0, fmt.Errorf("手机号码已存在")
			}
		}
		if user.Email != "" {
			exist, err := p.CheckExist("email", user.Email)
			if err != nil {
				return 0, err
			}
			if exist {
				return 0, fmt.Errorf("邮箱已存在")
			}
		}
	}

	session := db.NewSession()
	defer session.Close()

	if err := session.Begin(); err != nil {
		return 0, err
	}
	defer session.Rollback()

	if _, err := session.InsertOne(user); err != nil {
		return user.Id, err
	}
	if user.Id > 0 {
		if err := WriteOperLog(LogParameter{
			Type:       SYS_OPERATOR_LOG_TYPE_SYSTEM,
			UserID:     user.CreateUserId,
			ObjectType: OBJECT_TYPE_USER,
			ObjectID:   user.Id,
			Content:    "新增用户：" + user.Account,
		}, session); err != nil {
			return user.Id, err
		}
		if roleId > 0 {
			if err := p.SetRole(user.Id, roleId, user.CreateUserId, session); err != nil {
				return user.Id, err
			}
		}
		if departmentId > 0 {
			if err := p.SetDepartment(user.Id, departmentId, user.CreateUserId, session); err != nil {
				return user.Id, err
			}
		}
	}

	session.Commit()

	return user.Id, nil
}

// SetRole 设置角色
func (p User) SetRole(uid, roleId, createUserId int64, args ...*db.Session) error {
	session := db.NewSession(args...)
	defer session.Close(args...)
	// 检查角色是否存在
	exist, err := new(Role).CheckIsExist(roleId)
	if err != nil {
		return err
	}
	if !exist {
		return fmt.Errorf("角色不存在")
	}
	t := new(table.SysUserRoleRelation)
	exist, err = session.Where("user_id=?", uid).Exist(t)
	if err != nil {
		return err
	}

	if roleId == 0 {
		if exist {
			// 删除
			if _, err := session.ID(t.Id).Delete(t); err != nil {
				return err
			}
		}
	} else {
		if exist {
			if _, err := session.Exec("UPDATE sys_user_role_relation SET role_id=?, create_user_id=? WHERE user_id=?", roleId, createUserId, uid); err != nil {
				return err
			}
		} else {
			now := tools.GetTimeString(time.Now())
			t.RoleId = roleId
			t.UserId = uid
			t.CreateUserId = createUserId
			t.CreateTime = now
			t.UpdateTime = now
			if _, err := session.InsertOne(t); err != nil {
				return err
			}
		}
	}
	return nil
}

// SetDepartment 设置部门小组
func (p User) SetDepartment(uid, departmentId, createUserId int64, args ...*db.Session) error {
	session := db.NewSession(args...)
	defer session.Close(args...)
	// 检查部门是否存在
	exist, err := new(Department).CheckIsExist(departmentId)
	if err != nil {
		return err
	}
	if !exist {
		return fmt.Errorf("部门不存在")
	}
	t := new(table.SysUserDepartmentRelation)
	exist, err = session.Where("user_id=?", uid).Exist(t)
	if err != nil {
	}

	if departmentId == 0 {
		if exist {
			// 删除
			if _, err := session.ID(t.Id).Delete(t); err != nil {
				return err
			}
		}
	} else {
		if exist {
			if _, err := session.Exec("UPDATE sys_user_department_relation SET user_department_id=?, create_user_id=? WHERE user_id=?", departmentId, createUserId, uid); err != nil {
				return err
			}
		} else {
			now := tools.GetTimeString(time.Now())
			t.UserDepartmentId = departmentId
			t.UserId = uid
			t.CreateUserId = createUserId
			t.CreateTime = now
			t.UpdateTime = now
			if _, err := session.InsertOne(t); err != nil {
				return err
			}
		}
	}
	return nil
}

// 批量删除人员
func (p User) BatchDelete(idList []int64, userID int64) error {
	session := db.NewSession()
	defer session.Close()

	if err := session.Begin(); err != nil {
		return err
	}
	defer session.Rollback()

	for _, id := range idList {
		if _, err := session.Exec("UPDATE sys_user SET is_delete=0 WHERE id=?", id); err != nil {
			return err
		}
		t := new(table.SysUser)
		if exist, err := session.ID(id).Get(t); err != nil {
			return err
		} else {
			if exist {
				if err := WriteOperLog(LogParameter{
					Type:       SYS_OPERATOR_LOG_TYPE_SYSTEM,
					UserID:     userID,
					ObjectType: OBJECT_TYPE_USER,
					ObjectID:   id,
					Content:    "删除用户：" + t.Account,
				}, session); err != nil {
					return err
				}
			}
		}
	}

	session.Commit()
	return nil
}

type UserInfo struct {
	table.SysUser
	Department   string `json:"department"`
	DepartmentID int64  `json:"department_id"`
	Role         string `json:"role"`
	RoleID       int64  `json:"role_id"`
}

// Search 获取操作日志
func (p User) Search(ssc *db.SimpleSQLCondition, args ...int64) (int64, []UserInfo, error) {
	users := []table.SysUser{}
	count, err := db.SearchAndCount("sys_user", &users, ssc, args...)
	if err != nil {
		log.Error(err)
		return 0, nil, err
	}

	uis := []UserInfo{}
	for _, user := range users {
		ui := UserInfo{SysUser: user}
		if depInfo, _ := p.GetDepartment(user.Id); depInfo != nil {
			ui.Department = depInfo.PathName
			ui.DepartmentID = depInfo.Id
		}
		if roleInfo, _ := p.GetRole(user.Id); roleInfo != nil {
			ui.Role = roleInfo.Name
			ui.RoleID = roleInfo.Id
		}

		uis = append(uis, ui)
	}

	return count, uis, nil
}

// 获取角色
func (p User) GetRole(uid int64) (*table.SysRole, error) {
	session := db.NewSession()
	defer session.Close()

	surr := new(table.SysUserRoleRelation)
	exist, err := session.Where("user_id=?", uid).Get(surr)
	if err != nil {
		return nil, err
	}
	if !exist {
		return nil, nil
	}
	return (Role{}).GetInfo(surr.RoleId)
}
