package web

import (
	"ops/center/cmdb/web/controller"

	"github.com/gin-gonic/gin"
)

// StartServer 开启服务
func StartServer(addr string) {
	s := &Server{}
	s.start(addr)
	defer s.close()
}

// Server web服务
type Server struct {
	engine *gin.Engine
	m      *controller.Middle
}

// web应用启动
func (p *Server) start(addr string) {
	p.engine = gin.Default()
	// 注册中间件
	p.registMiddle()
	// 注册路由
	p.registRoute()

	p.engine.Run(addr)
}

func (p *Server) registMiddle() {
	p.m = controller.NewMiddle()
	p.engine.Use(p.m.Excetion(), p.m.Life())
}

func (p *Server) close() {
	// TODO
}
