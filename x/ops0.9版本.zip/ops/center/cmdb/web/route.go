package web

import (
	"ops/center/cmdb/web/controller"

	"github.com/gin-gonic/gin"
)

func decorator(fun func(c *controller.Context)) func(c *gin.Context) {
	return func(c *gin.Context) {
		fun(&controller.Context{Context: c})
	}
}

func (p *Server) registRoute() {

	guestGroup := p.engine.Group("/api/cmdb/")

	{
		user := controller.User{}
		guestGroup.POST("user/login", decorator(user.Login))

		sysSetting := controller.SysSetting{}

		guestGroup.GET("enterprise/detail", decorator(sysSetting.Detail))

		sys := controller.Sys{}
		guestGroup.GET("sys/setting/detail", decorator(sys.SettingDetail))

	}

	authGroup := p.engine.Group("/api/cmdb/", p.m.CheckAuth())
	{
		group := authGroup.Group("user/")
		user := controller.User{}
		group.GET("detail", decorator(user.Detail))
		group.POST("add", decorator(user.Add))
		group.POST("update", decorator(user.Update))
		group.POST("password/update", decorator(user.UpdatePassword))
		group.POST("tel/update", decorator(user.UpdateTel))
		group.POST("batch/delete", decorator(user.BatchDelete))
		group.GET("custom/list", decorator(user.CustomList))
		group.POST("custom/save", decorator(user.CustomSave))
		group.GET("login/log/list", decorator(user.LoginLog))
		group.GET("operator/log/list", decorator(user.SysOperatorLog))
		group.POST("logout", decorator(user.Logout))
		group.GET("search", decorator(user.Search))
	}

	{
		group := authGroup.Group("department/")
		department := controller.Department{}
		group.POST("add", decorator(department.Add))
		group.POST("delete", decorator(department.Delete))
		group.POST("update", decorator(department.Update))
		group.GET("list", decorator(department.List))
	}

	{
		group := authGroup.Group("sys/")
		sys := controller.Sys{}

		group.POST("inform/update", decorator(sys.InformUpdate))
		group.GET("inform/detail", decorator(sys.InformDetail))
		group.POST("inform/test", decorator(sys.InformTest))
		group.POST("setting/update", decorator(sys.SettingUpdate))
		group.POST("resource/upload", decorator(sys.FileUpload))
		group.GET("code/get", decorator(sys.GetTelCode))

		sysSetting := controller.SysSetting{}

		group.POST("enterprise/update", decorator(sysSetting.EditEnterprise))
	}

	{
		group := authGroup.Group("role/")
		role := controller.Role{}
		group.GET("list", decorator(role.List))
	}
}
