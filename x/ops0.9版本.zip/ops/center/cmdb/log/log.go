package log

import (
	"ops/center/cmdb/global"
	"strings"
)

// 日志打印

// FDebug FDebug
func FDebug(format string, args ...interface{}) {
	global.Logger.Debug(format, args...)
}

// FInfo 打印Info信息
func FInfo(format string, args ...interface{}) {
	global.Logger.Info(format, args...)
}

// FWarn FWarn
func FWarn(format string, args ...interface{}) {
	global.Logger.Warn(format, args...)
}

// FNotice FNotice
func FNotice(format string, args ...interface{}) {
	global.Logger.Notice(format, args...)
}

// FError 打印Error信息
func FError(format string, args ...interface{}) {
	global.Logger.Error(format, args...)
}

// FCritical FCritical
func FCritical(format string, args ...interface{}) {
	global.Logger.Critical(format, args...)
}

// FAlert FAlert
func FAlert(format string, args ...interface{}) {
	global.Logger.Alert(format, args...)
}

// Debug Debug
func Debug(args ...interface{}) {
	FDebug(getFormat(len(args)), args...)
}

// Info 打印Info信息
func Info(args ...interface{}) {
	FInfo(getFormat(len(args)), args...)
}

// Warn Warn
func Warn(args ...interface{}) {
	FWarn(getFormat(len(args)), args...)
}

// Notice Notice
func Notice(args ...interface{}) {
	FNotice(getFormat(len(args)), args...)
}

// Error 打印Error信息
func Error(args ...interface{}) {
	FError(getFormat(len(args)), args...)
}

// Critical Critical
func Critical(args ...interface{}) {
	FCritical(getFormat(len(args)), args...)
}

// Alert Alert
func Alert(args ...interface{}) {
	FAlert(getFormat(len(args)), args...)
}

func getFormat(size int) string {

	formats := make([]string, size)
	for i := 0; i < size; i++ {
		formats = append(formats, "%v")
	}
	return strings.Join(formats, " ")
}
