package global

import (
	"flag"
	"fmt"
	"io/ioutil"
	"path/filepath"
	"strings"

	"ops/common/db/redis"
	"ops/common/logs"
	"ops/common/misc"
	"ops/common/orm"
	"ops/module/encrypt"

	"github.com/Unknwon/goconfig"
	"github.com/gin-gonic/gin"
	"github.com/go-xorm/xorm"
)

const (
	// 版本
	VERSION = "V0.1R001"
	// 作者
	AUTHOR = "GEESUNN OPS"
)

var (
	DBEngine *xorm.Engine
	// 缓存
	CacheDB *redis.Redis
	// elasticsearch 数据库

	// 配置对象
	Config *goconfig.ConfigFile
	// 日志对象
	Logger = logs.NewLogger()
	// Resp

	// http地址
	Addr string

	// 资源文件路径
	ResourceRoot = ""
)

// 初始化系统
func init() {

	var conf *string = flag.String("c", "./config/", "指定配置文件路径")

	flag.Parse()

	// 加载配置
	for _, fileName := range []string{"app.conf", "app.conf.test", "app.conf.pro", "app.conf.enc"} {
		newPath := filepath.Join(*conf, fileName)
		if strings.HasSuffix(newPath, ".enc") {
			bytes, err := ioutil.ReadFile(newPath)
			if err != nil {
				panic(err)
			}
			decBytes, err := encrypt.AesDecrypt(bytes, []byte(encrypt.EncryptFLKey))
			if err != nil {
				panic(err)
			}
			Config, _ = goconfig.LoadFromData(decBytes)
		} else {
			if misc.IsFileExist(newPath) {
				c, err := goconfig.LoadConfigFile(newPath)
				if err != nil {
					panic(err)
				}
				Config = c
			}
		}
		if Config != nil {
			break
		}
	}

	// 初始化缓存
	initCache()
	// 初始化DB
	initDB()
	// 初始化日志
	initLog()
	// 初始化资源目录
	initResource()

	Addr = Config.MustValue("system", "addr")

	gin.SetMode(Config.MustValue("system", "run_mode", "release"))
	if gin.Mode() != gin.ReleaseMode {
		DBEngine.ShowSQL(true)
	}

	Logger.Info("%v %v", VERSION, AUTHOR)

}

// db初始化
func initDB() {

	user := Config.MustValue("db", "user")
	password := Config.MustValue("db", "password")
	host := Config.MustValue("db", "host")
	port := Config.MustValue("db", "port")
	db := Config.MustValue("db", "database")
	maxOpenConns := Config.MustInt("db", "max_open_conn")
	maxIdleConns := Config.MustInt("db", "max_idle_conn")
	maxLifeSec := Config.MustInt("db", "max_life_sec")
	dataSourceName := fmt.Sprintf("%s:%s@tcp(%s:%s)/%s?charset=utf8&loc=Local", user, password, host, port, db)
	engine, err := orm.NewOrm(Config.MustValue("db", "driver"), dataSourceName, maxOpenConns, maxIdleConns, maxLifeSec)
	if err != nil {
		panic(err)
	}
	DBEngine = engine
}

// 缓存
func initCache() {

	CacheDB = &redis.Redis{}
	if err := CacheDB.Init(Config.MustValue("redis", "host"), Config.MustInt("redis", "port"),
		Config.MustValue("redis", "password"), Config.MustInt("redis", "max_conn"), Config.MustInt("redis", "max_idle_conn")); err != nil {
		panic(err)
	}
}

// 初始化日志
func initLog() {

	fileSwitch := Config.MustValue("log", "fileswitch")
	fileName := Config.MustValue("log", "filename")
	level := Config.MustValue("log", "level")
	daily := Config.MustValue("log", "daily")
	maxdays := Config.MustValue("log", "maxdays")
	if fileSwitch == "on" {
		if err := Logger.SetLogger(logs.AdapterFile, fmt.Sprintf(`{"filename": "%v", "daily": %v, "maxdays": %v, "level": %v}`, fileName, daily, maxdays, level)); err != nil {
			panic(err)
		}
	} else {
		if err := Logger.SetLogger(logs.AdapterConsole); err != nil {
			panic(err)
		}
	}
	// 设置日志输出文件名和文件行号
	Logger.EnableFuncCallDepth(true)
	Logger.SetLogFuncCallDepth(4)
	Logger.Info("日志系统正常启动")
}

// 初始化资源目录
func initResource() {

	ResourceRoot = Config.MustValue("resource", "root_dir")
	if !misc.IsDirExist(ResourceRoot) {
		misc.MakeDir(ResourceRoot)
	}
}

// Close 关闭应用
func Close() {

	if DBEngine != nil {
		DBEngine.Close()
	}
	if CacheDB != nil {
		CacheDB.Close()
	}
	if Logger != nil {
		Logger.Close()
	}
}
