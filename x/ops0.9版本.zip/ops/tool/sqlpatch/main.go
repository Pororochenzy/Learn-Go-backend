package main

import (
	"flag"
	"fmt"
	"io/ioutil"
	"strings"
	"time"

	"ops/common/easyexec"
	"ops/common/misc"
	"ops/common/orm"
	"ops/module/table"

	"github.com/go-xorm/xorm"
)

var (
	backupDir = "/geesunn/backup/" + time.Now().Format("20060102150405") + "/"
	dbEngine  *xorm.Engine
)

func tips() bool {
	for {
		fmt.Print(`
		-----------------------------------------------------------------------------------------
		【 可选参数：-h 主机地址 | -P 端口号 | -u 用户名 | -p 密码 | -D 数据库 | -backup 是否备份yes/no 】
		-----------------------------------------------------------------------------------------
		说明：
		1）此程序将按照order.txt里的补丁顺序升级数据库，并将补丁版本记录到数据库中，已安装的补丁会被忽略
		2）默认行为：-h 127.0.0.1 -P 3306 -u root -p{默认密码} -D ops_center -backup yes

		-----------------------------------------------------------------------------------------
		是否继续? (y/n) `)
		var choice string
		fmt.Scanf("%s\n", &choice)
		switch strings.ToLower(choice) {
		case "y":
			return true
		case "n":
			return false
		}
	}
}

func main() {
	// 提示语
	if !tips() {
		return
	}

	// 参数解析
	user := flag.String("u", "root", "数据库用户名")
	password := flag.String("p", "geesunn", "数据库密码")
	host := flag.String("h", "127.0.0.1", "数据库地址")
	port := flag.String("P", "3306", "数据库端口")
	backup := flag.String("backup", "yes", "是否数据库备份 yes/no")
	database := flag.String("D", "ops_center", "数据库名称")
	flag.Parse()

	// 初始化数据库连接
	{
		dsn := fmt.Sprintf(`%v:%v@tcp(%v:%v)/%v?charset=utf8&loc=Local`, *user, *password, *host, *port, *database)
		fmt.Println(dsn)
		var err error
		dbEngine, err = orm.NewOrm("mysql", dsn, 1, 1, 180)
		if err != nil {
			panic(err)
		}
		defer dbEngine.Close()
		if err := dbEngine.Ping(); err != nil {
			panic(err)
		}
	}

	// 停止服务
	{
		for _, cmd := range []string{
			"/geesunn/tool/gmo/gmo stop ops_cmdb",
		} {
			msg, err := easyexec.Command(cmd)
			if err != nil {
				fmt.Println(cmd, msg)
				panic(err)
			}
		}
	}

	// 备份数据库
	{
		if *backup != "no" {
			if misc.MakeDir(backupDir) {
				fmt.Println("生成备份文件夹：" + backupDir)
			} else {
				fmt.Println("生成备份文件夹失败：" + backupDir)
				return
			}

			// todo
			skiptb := []string{}
			for i, tb := range skiptb {
				skiptb[i] = fmt.Sprintf(`--ignore-table=%v.%v`, *database, tb)
			}
			backupCMD := fmt.Sprintf(`
				/usr/local/mysql/bin/mysqldump -h%v -u%v -P%v -p%v --skip-extended-insert %v %v  > %v/ops_center.sql
			`, *host, *user, *port, *password, strings.Join(skiptb, " "), *database, backupDir)
			fmt.Println("备份数据库...")
			_, err := easyexec.Command(backupCMD)
			if err != nil {
				fmt.Println("备份数据库失败：", err.Error())
				return
			}
			fmt.Println("已完成数据库备份")
		}
	}

	// 更新补丁
	{

		order := "./order.txt"
		if !misc.IsFileExist(order) {
			fmt.Println("未发现", order)
			return
		}

		// 更新数据库
		f, err := ioutil.ReadFile(order)
		if err != nil {
			panic(err)
		}

		patches := strings.Split(string(f), "\n")
		for _, patch := range patches {
			patch = strings.TrimSpace(patch)
			if len(patch) > 0 && patch != "init.sql" {
				// 检查数据库是否已经升级过补丁，如果升级过则忽略
				if exist, _ := dbEngine.Exist(&table.SysDbUpgradeLog{
					Version: patch,
				}); exist {
					continue
				}

				fmt.Println("升级数据库补丁", patch)
				cmd := fmt.Sprintf(`
					/usr/local/mysql/bin/mysql -h%v -P%v -u%v -p%v -D%v -e "source %v"
				`, *host, *port, *user, *password, *database, patch)
				msg, err := easyexec.Command(cmd)
				if err != nil {
					fmt.Println(cmd, msg)
					panic(err)
				} else {
					if _, err := dbEngine.Insert(table.SysDbUpgradeLog{
						Version:    patch,
						UpdateTime: misc.CurrentTimeStr(),
						CreateTime: misc.CurrentTimeStr(),
					}); err != nil {
						panic(err)
					}
				}
			}
		}
	}

	// 重新启动服务
	{
		for _, cmd := range []string{
			"/geesunn/tool/gmo/gmo stop ops_cmdb",
		} {
			msg, err := easyexec.Command(cmd)
			if err != nil {
				fmt.Println(cmd, msg)
				panic(err)
			}
		}
	}

	fmt.Println("升级完成！")
}
