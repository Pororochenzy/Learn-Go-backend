package main

import (
	"bufio"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"syscall"
	"time"

	"ops/common/easyexec"
	"ops/common/misc"
	"ops/module/encrypt"

	"github.com/howeyc/gopass"
	"gopkg.in/yaml.v2"
)

// 支持的命令
const (
	START      = "start"
	STOP       = "stop"
	RESTART    = "restart"
	STATUS     = "status"
	CHECK_DOWN = "check-down"
	ENCRYPT    = "enc"
	DECRYPT    = "dec"
	ENCRYPTF   = "encf"
	DECRYPTF   = "decf"
)

var CMDSlice = []string{START, STOP, RESTART, STATUS, CHECK_DOWN}

// 工程状态
type proStatus int

const (
	PRO_DOWN       = proStatus(0)
	PRO_UP         = proStatus(1)
	PRO_RESTARTING = proStatus(2)
	PRO_UNKNOW     = proStatus(3)
)

// 配置文件单对象
type gmoUnit struct {
	Name       string `yaml:"name"`
	StartCmd   string `yaml:"start"`
	StopCmd    string `yaml:"stop"`
	RestartCmd string `yaml:"restart"`
	PidPath    string `yaml:"pid"`
}
type gmoUnitStatus struct {
	Status     proStatus
	PID        int
	PPID       int
	Uptime     string
	Memory     string
	CpuPercent float64
	OpenFile   int
	Threads    int
}

var gunits = []gmoUnit{}
var gunitsMap = map[string]gmoUnit{}

// 程序启动
func start(name string) error {
	gus, err := checkStatus(name)
	if err != nil {
		return err
	}
	if gus.Status == PRO_UP {
		return fmt.Errorf("已经在运行中")
	}
	exitCode, err := execCommand(gunitsMap[name].StartCmd)
	if exitCode != 0 && err == nil {
		return fmt.Errorf("exit code: %v", exitCode)
	}
	return err
}

// 程序停止
func stop(name string) error {
	exitCode, err := execCommand(gunitsMap[name].StopCmd)
	if exitCode != 0 && err == nil {
		return fmt.Errorf("exit code: %v", exitCode)
	}
	return err
}

// 程序重启
func restart(name string) error {
	if strings.TrimSpace(gunitsMap[name].RestartCmd) == "" {
		gus, err := checkStatus(name)
		if err != nil {
			return err
		}
		if gus.Status == PRO_UP {
			if err := stop(name); err != nil {
				return err
			}
		}
		time.Sleep(1 * time.Second)
		return start(name)
	}
	exitCode, err := execCommand(gunitsMap[name].RestartCmd)
	if exitCode != 0 && err == nil {
		return fmt.Errorf("exit code: %v", exitCode)
	}
	return err
}

// 打印程序状态
func status(name string) {
	gus, err := checkStatus(name)
	if err != nil {
		fmt.Println(err)
	}
	m := map[proStatus]string{
		PRO_DOWN:       "Down",
		PRO_UP:         "Running",
		PRO_RESTARTING: "Restarting",
		PRO_UNKNOW:     "Unknow",
	}
	fmt.Println(fmt.Sprintf("Process '%v' ", name))
	fmt.Println(fmt.Sprintf("	status    %v", m[gus.Status]))
	fmt.Println(fmt.Sprintf("	pid       %v", gus.PID))
	fmt.Println(fmt.Sprintf("	ppid      %v", gus.PPID))
	fmt.Println(fmt.Sprintf("	memory    %v", gus.Memory))
	fmt.Println(fmt.Sprintf("	threads   %v", gus.Threads))
	fmt.Println(fmt.Sprintf("	uptime    %v", gus.Uptime))
	fmt.Println("")
}

// 检查程序是否down，如果down拉起
func check_down(name string) error {
	gus, err := checkStatus(name)
	if err != nil {
		return err
	}

	switch gus.Status {
	case PRO_DOWN:
		start(name)
	case PRO_UNKNOW:
		restart(name)
	default:
		return nil
	}

	gus, err = checkStatus(name)
	if err != nil {
		return err
	}
	if gus.Status == PRO_UP {
		fmt.Println(fmt.Sprintf("check_down：此次启动了 %v", name))
	}
	return nil
}

func main() {
	// 先检查参数是否正确
	if len(os.Args) < 3 {
		fmt.Println("格式：gmo start|stop|restart|status|check-down  all|工程名")
		return
	}
	aimAction, aimProj := os.Args[1], os.Args[2]

	if ENCRYPT == aimAction || DECRYPT == aimAction || ENCRYPTF == aimAction || DECRYPTF == aimAction {
		aesEncrypt(aimAction, os.Args)
		return
	}

	find := false
	for _, action := range CMDSlice {
		if aimAction == action {
			find = true
			break
		}
	}
	if !find {
		fmt.Println(aimAction + " 命令不存在")
		return
	}

	// 加载配置文件
	config := ""
	for _, fileName := range []string{"gmo.yml", "/geesunn/tool/gmo/gmo.yml", "/etc/gmo.yml"} {
		if misc.IsFileExist(fileName) {
			config = fileName
			break
		}
	}

	if len(config) == 0 {
		panic("gmo.yml文件不存在")
	}

	confBytes, err := ioutil.ReadFile(config)
	if err != nil {
		panic(err.Error())
	}

	if err := yaml.Unmarshal(confBytes, &gunits); err != nil {
		panic(err.Error())
	}
	for _, gunit := range gunits {
		gunitsMap[gunit.Name] = gunit
	}

	switch aimAction {
	case START:
		if aimProj == "all" {
			for _, gunit := range gunits {
				if err := start(gunit.Name); err != nil {
					fmt.Println(gunit.Name + " 启动失败, 原因：" + err.Error())
				}
			}
		} else {
			if err := start(aimProj); err != nil {
				fmt.Println(aimProj + " 启动失败, 原因：" + err.Error())
			}
		}
	case STOP:
		if aimProj == "all" {
			for i, _ := range gunits {
				if err := stop(gunits[len(gunits)-1-i].Name); err != nil {
					fmt.Println(gunits[len(gunits)-1-i].Name + " 停止失败, 原因：" + err.Error())
				}
			}
		} else {
			if err := stop(aimProj); err != nil {
				fmt.Println(aimProj + " 停止失败, 原因：" + err.Error())
			}
		}
	case RESTART:
		if aimProj == "all" {
			for _, gunit := range gunits {
				if err := restart(gunit.Name); err != nil {
					fmt.Println(gunit.Name + " 重启失败, 原因：" + err.Error())
				}
			}
		} else {
			if err := restart(aimProj); err != nil {
				fmt.Println(aimProj + " 重启失败, 原因：" + err.Error())
			}
		}
	case STATUS:
		if aimProj == "all" {
			for _, gunit := range gunits {
				status(gunit.Name)
			}
		} else {
			status(aimProj)
		}
	case CHECK_DOWN:
		if aimProj == "all" {
			for _, gunit := range gunits {
				if err := check_down(gunit.Name); err != nil {
					fmt.Println(gunit.Name + " chkdown失败, 原因：" + err.Error())
				}
			}
		} else {
			if err := check_down(aimProj); err != nil {
				fmt.Println(aimProj + " chkdown失败, 原因：" + err.Error())
			}
		}
	default:
		panic(aimAction + " 命令暂未支持")
	}
}

// 检查文件状态
func checkStatus(name string) (gmoUnitStatus, error) {
	x := gmoUnitStatus{}
	if gunit, ok := gunitsMap[name]; ok {
		pid := ""
		if strings.Contains(gunit.PidPath, "pidof") {
			output, err := easyexec.Command(gunit.PidPath)
			if err != nil && !strings.Contains(err.Error(), "exit status 1") {
				return x, err
			}
			pid = strings.TrimSpace(string(output))
			if pid != "" {
				pids := strings.Split(pid, " ")
				pid = pids[len(pids)-1]
			}
		} else {
			if !misc.IsFileExist(gunit.PidPath) {
				// pid文件不存在，一般是进程未启动
				x.Status = PRO_DOWN
				return x, nil
			}
			pidBytes, err := ioutil.ReadFile(gunit.PidPath)
			if err != nil {
				x.Status = PRO_UNKNOW
				return x, err
			}
			pid = string(pidBytes)
		}
		pid = strings.TrimSpace(pid)
		if pid != "" && misc.IsDirExist(fmt.Sprintf("/proc/%v", pid)) {
			x.Status = PRO_UP
			// 读取/proc/pid获取进程各项指标
			m := readKVFile(fmt.Sprintf("/proc/%v/status", pid))
			if v, ok := m["Pid"]; ok {
				x.PID, _ = strconv.Atoi(v)
			}
			if v, ok := m["PPid"]; ok {
				x.PPID, _ = strconv.Atoi(v)
			}
			if v, ok := m["Threads"]; ok {
				x.Threads, _ = strconv.Atoi(v)
			}
			if v, ok := m["VmRSS"]; ok {
				x.Memory = v
			}
			uptime, err := easyexec.Command(fmt.Sprintf("ps -p %v -o etime=", pid))
			if err != nil {
				return x, err
			}
			x.Uptime = strings.TrimSpace(uptime)
			return x, nil
		}
		x.Status = PRO_DOWN
		return x, nil
	}
	x.Status = PRO_UNKNOW
	return x, fmt.Errorf(name + "不存在")
}

// 执行命令
func execCommand(cmd string) (int, error) {
	msg, err := easyexec.Command(cmd)
	if err != nil {
		if exiterr, ok := err.(*exec.ExitError); ok {
			if waitStatus, ok := exiterr.Sys().(syscall.WaitStatus); ok {
				exitCode := waitStatus.ExitStatus()
				return exitCode, fmt.Errorf("%v, %v", msg, err.Error())
			}
		}
	}
	return 0, err
}

// 读取key:value格式的文件
func readKVFile(path string) map[string]string {
	m := map[string]string{}
	f, err := os.Open(path)
	if err != nil {
		fmt.Println(err)
		return m
	}
	defer f.Close()
	reader := bufio.NewReader(f)
	for {
		lineBytes, _, err := reader.ReadLine()
		if err == io.EOF {
			break
		}
		line := strings.TrimSpace(string(lineBytes))
		items := strings.Split(line, ":")
		if len(items) == 2 {
			m[strings.TrimSpace(items[0])] = strings.TrimSpace(items[1])
		}
	}
	return m
}

// 加解密
func aesEncrypt(aimAction string, args []string) {
	key := encrypt.EncryptDBKey
	if ENCRYPTF == aimAction || DECRYPTF == aimAction {
		key = encrypt.EncryptFLKey
	}
	switch aimAction {
	case ENCRYPT:
		encryptData, err := encrypt.AesEncryptBase64(args[2], key)
		if err != nil {
			fmt.Printf("异常: %v \n", err.Error())
		} else {
			fmt.Println(encryptData)
		}
	case DECRYPT:
		if !permission() {
			return
		}
		decryptData, err := encrypt.AesDecryptBase64(args[2], key)
		if err != nil {
			fmt.Printf("异常: %v \n", err.Error())
		} else {
			fmt.Println(decryptData)
		}
	case ENCRYPTF:
		for _, filepath := range args[2:] {
			bytes, err := ioutil.ReadFile(filepath)
			if err != nil {
				fmt.Printf("文件读取异常: %v \n", err.Error())
				return
			}
			data, err := encrypt.AesEncrypt(bytes, []byte(key))
			if err != nil {
				fmt.Printf("异常: %v \n", err.Error())
				return
			}
			if err := ioutil.WriteFile(fmt.Sprintf("%v.enc", filepath), data, 0644); err != nil {
				fmt.Printf("文件写入异常: %v \n", err.Error())
			}
		}
	case DECRYPTF:
		if !permission() {
			return
		}
		for _, filepath := range args[2:] {
			if !strings.HasSuffix(filepath, ".enc") {
				fmt.Printf("暂不支持该文件：%v \n", filepath)
				return
			}
		}
		for _, filepath := range args[2:] {
			bytes, err := ioutil.ReadFile(filepath)
			if err != nil {
				fmt.Printf("文件读取异常: %v \n", err.Error())
				return
			}
			data, err := encrypt.AesDecrypt(bytes, []byte(key))
			if err != nil {
				fmt.Printf("异常: %v \n", err.Error())
				return
			}
			if err := ioutil.WriteFile(strings.TrimSuffix(filepath, ".enc"), data, 0644); err != nil {
				fmt.Printf("文件写入异常: %v \n", err.Error())
			}
		}
	default:
		panic(aimAction + " 命令暂未支持")
	}
}

func permission() bool {
	encryptFile := "/tmp/a73ce3a4c9ce4fbe2fadb397e2d6bdd5"

	if !misc.IsFileExist(encryptFile) {
		if !verifyPass() {
			return false
		}
		if err := ioutil.WriteFile(encryptFile, []byte(fmt.Sprintf("%v", time.Now().Unix())), 0644); err != nil {
			fmt.Printf("文件写入异常: %v \n", err.Error())
			return false
		}
	}

	bytes, err := ioutil.ReadFile(encryptFile)
	if err != nil {
		fmt.Printf("文件读取异常: %v \n", err.Error())
		return false
	}
	lastTime, err := strconv.ParseInt(string(bytes), 10, 64)
	if err != nil || time.Now().Unix()-lastTime > 300 {
		if !verifyPass() {
			return false
		}
		if err := ioutil.WriteFile(encryptFile, []byte(fmt.Sprintf("%v", time.Now().Unix())), 0644); err != nil {
			fmt.Printf("文件写入异常: %v \n", err.Error())
			return false
		}
	}
	return true
}

func verifyPass() bool {
	for i := 0; i < 3; i++ {
		fmt.Print("password: ")
		pass, err := gopass.GetPasswd()
		if err != nil {
			panic(err)
		}
		if string(pass) == "geesunnhsfish" {
			return true
		}
	}
	return false
}
