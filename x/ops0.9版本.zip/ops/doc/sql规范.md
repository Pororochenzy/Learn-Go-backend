### sql 使用规范

#### 强制要求
* 数据库、数据表、字符型字段的编码统一使用 utf8mb4, SQL语句中必须显式指定

* 数据表的存储引擎使用 InnoDB, SQL语句中必须显式指定

* 事务级别 repeatable-read

* 命名规范:
 * 统一使用小写
 * 名词不要使用复数
 * 长度控制在32个字符以内
 * 数据库、数据表命名约定: 业务(功能)模块前缀_库(表)的作用
 * 索引命名约定: uk_表名_字段名、idx_表名_字段名
 * 临时表命名: tmp_表名
 * 备份表命名: bak_表名
 * 废弃表命名: del_表名
 * 表达是否概念的字段，必须使用is_xxx的方式命名，数据类型为 unsigned tinyint(1)，1表示是，0表示否
 * 关联表中关联对象的主键命名: 关联对象的表名_主键名称，如: object_id

* 业务性强的字段必须要有注释，当字段含义变化时需同步更新

* 数据表必须具备的3个字段:
 * id  unsinged bigint  单表时自增、步长为1
 * create_time timestatmp DEFAULT CURRENT_TIMESTAMP
 * update_time timestatmp DEFAULT CURRENT_TIMESTAMP

* 除语法限制的字段外(blob、text等)，其他字段类型必须设置 NOT NULL 属性

* 除id外，其他 NOT NULL 字段必须设置默认值

* 整数类型字段，如果业务上为非负的，必须指定 unsigned

* 小数类型字段，必须使用 decimal，禁止使用 float 和 double

* 涉及到金钱等精度敏感的字段时，放大一定倍数后使用整型存储

* varchar 类型字段长度应为2的次方，最大不超过1024，超过长度时使用text等字段

* 枚举值不允许使用enum类型，必须使用 unsigned tinyint(1)

* 频繁使用的where查询字段必须建立索引，组合索引必须注意字段顺序

* 频繁使用的多表join场景，on条件字段必须建立索引

* 单表索引不要超过10个

* 原生SQL中禁止 SELECT * 的写法

* INSERT 时必须指定明确的字段

* 单次 INSERT 记录数不应该超过2000行

* 索引列不要使用函数或表达式

* 禁止使用外键与级联，一切外键概念必须在应用层解决

* 禁止使用存储过程

* 禁止超过3个表的 JOIN 

* 多表JOIN时必须使用别名

* 禁止在UPDATE操作中使用JOIN

* 使用 COUNT(*) 而不是 COUNT(某列)


#### 建议做法
* varchar字段建立索引时，如果字段较长，注意指定索引的长度，一般取20字符长度

* 多使用EXPLAIN分析SQL语句的性能

* 当 IN 一个很大范围的集合时, 使用 EXISTS 代替 IN

* 使用 NOT EXISTS 代替 NOT IN

* 将 OR 语句优化为 UNION

* 分页查询时，先查询数量，如果数量为0，则不需要进行后面的分页查询

* 多表JOIN时必须使用别名