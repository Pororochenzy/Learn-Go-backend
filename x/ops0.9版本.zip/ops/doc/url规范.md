### url 使用规范


#### 允许使用的method

* GET 只获取资源不能对资源产生任何影响的操作 安全
* POST 对资源进行增删改的操作

#### 请求参数

* **content-type**  
* GET url
* POST json

#### url 

* 单词之间使用/ 隔开 
  * host/api/1/user/login
  * 统一小写，不允许使用下划线

``` 
URL命名建议
https://域名/api/业务模块/业务功能.../操作
业务功能命名根据具体功能来命名 至少一个 可多个

新增 业务功能/add
更新 业务功能/update
详情 业务功能/detail    
查询 业务功能/search    # 用来全量搜索查询的数据   
列表 业务功能/list      # list用來表示可数据分页接口   分页参数：limit  offset
删除 业务功能/delete
绑定 业务功能/bind
解绑 业务功能/unbind
执行 业务功能/do

批量新增 业务功能/batch/add
批量更新 业务功能/batch/update
批量删除 业务功能/batch/delete
批量绑定 业务功能/batch/bind 
批量解绑 业务功能/batch/unbind
批量执行 业务功能/batch/do

上传 业务功能/resource/upload # 针对全局 # 一般都是这个吧

```

### 题外话

* 返回结构体必然是确定的

  ``` 
  {
  	"code": 0, // 业务错误码
  	"message": "ok", // 错误提示信息
  	"data": { 
  	   key: value
       ...
  	}
  }
  ```

* 返回的http status code 遵循本身的定义 (并不赞同 统一返回200)

  * 1xx 持续请求 (101 websocket)
  * 2xx 资源请求成功 (200 请求成功)
  * 3xx 重定向 (301 永久重定向)
  * 4xx 客户端方面的错误 (错误比较多, 非常重要 建议查看wiki 理解清楚)
    * 429 是个彩蛋状态码,  现在很多open api 用来提示被限制的请求速率
  * 5xx 服务端方面的错误 (500 服务端内部错误, 重要 建议理解清楚)

