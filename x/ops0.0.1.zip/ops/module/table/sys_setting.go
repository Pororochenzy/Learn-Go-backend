package table

type SysSetting struct {
	Id      int64  `json:"id" xorm:"not null pk autoincr INT(11)"`
	Name    string `json:"name" xorm:"not null default '' comment('系统配置项名称') VARCHAR(64)"`
	Content string `json:"content" xorm:"not null default '' comment('配置内容') VARCHAR(256)"`
	Remark  string `json:"remark" xorm:"not null default '' VARCHAR(256)"`
}
