package session

import (
	"auth/global"
	"errors"
	"fmt"
	"time"
)

var REDIS_INFO_DB = 3

type Session struct {
	Token          string `redis:"token"`
	LoginTimestamp int64  `redis:"login_timestamp"`
	LastTimestamp  int64  `redis:"last_timestamp"`
	EffectSec      int64  `redis:"effect_sec"`
	UserID         int64  `redis:"user_id"`
	Logout         bool   `redis:"logout"`
}

// IsTimeOut session是否超时
func (p *Session) IsTimeOut() bool {

	if p.EffectSec == -1 {
		return false
	}

	if time.Now().Unix()-p.LastTimestamp > p.EffectSec {
		return true
	}
	return false
}

// Validation 验证session
func Validation(token string) (*Session, error) {

	session := &Session{}
	exist, err := global.CacheDB.HGetAll(3, fmt.Sprintf("session:%v", token), session)
	if err != nil {
		return nil, err
	}
	if !exist {
		return nil, errors.New("用户未登录")
	}

	if session.Logout {
		return nil, errors.New("用户已重新登录")
	}

	if session.IsTimeOut() {
		return nil, errors.New("长时间未操作")
	}

	return session, nil

}
