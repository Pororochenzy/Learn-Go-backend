GeesunnOPS
center: 各业务模块管理端代码
    cmdb: 首页、资源管理、系统设置、用户模块
    monitor: 监控中心、告警中心、网络设备日志
    task: 任务管理、巡检、备份
    fortress: 堡垒机
    report: 报表

depend: 管理端依赖组件
    cproxy: 采集代理 策略分组
    cplugin: 采集组件
    data_handler: 数据处理
    alarm: 告警处理
    notify: 通知处理
    scheduler: 定时任务
    
common: 各业务模块通用业务函数

cmd: 解决方案
    code: 源码
    release: 脚本、二进制文件

vendor:
    公共代码库、第三方
    