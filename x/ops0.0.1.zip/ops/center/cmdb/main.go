package main

import (
	"ops/center/cmdb/global"
	"ops/center/cmdb/log"
	"ops/center/cmdb/web"
	"os"
	"os/signal"
	"syscall"
)

func main() {

	go web.StartServer(global.Addr)

	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)

	<-sigs
	global.Close()

	log.Info("exit")
	os.Exit(0)

}
