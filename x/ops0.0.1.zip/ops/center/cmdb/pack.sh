#!/bin/bash

WORKSPACE=$(cd $(dirname $0)/; pwd)
cd $WORKSPACE

# 生成的程序名称
app=ops_cmdb
appexe=ops_cmdb
# main.go文件路径
src=main.go

build_dir=~/geesunn/build
targz_dir=~/geesunn/targz

function build() {
    mkdir -p $build_dir
    rm -fr $build_dir/$app/
    go build -o $build_dir/$app/$appexe $src
    if [[ $? -gt 0 ]];
    then
        echo "build falid"
        return 1
    fi

    cp -fr config $build_dir/$app
    cp -fr control.sh $build_dir/$app 

    case "$1" in
        "test")
            cd $build_dir/$app/config
            rm -fr app.conf app.conf.pro
            mv app.conf.test app.conf
            /usr/local/bin/gmo encf app.conf
            rm -fr app.conf
        ;;
        "pro")
            cd $build_dir/$app/config
            rm -fr app.conf  app.conf.test
            mv app.conf.pro app.conf
            /usr/local/bin/gmo encf app.conf
            rm -fr app.conf
        ;;
        *)
        ;;
    esac

    if [ -d $build_dir/$app ]; then  
        echo "1) build: $build_dir/$app"
        return 0
    else
        echo "2) build: failed" 
        return 1
    fi
}

function targz() {
	mkdir -p $targz_dir
    build "$1"
	cd $build_dir
	tar -zcf $targz_dir/$app.tar.gz $app
    if [ -f $targz_dir/$app.tar.gz ]; then  
        echo "2) targz: $targz_dir/$app.tar.gz" 
        return 0
    else
        echo "2) targz: failed" 
        return 1
    fi
}

function protoc() {
    cmd=$(which  protoc)
    if [ $? -gt 0 ];then
        echo "please install protoc"
        return 1
    fi

    $cmd --go_out=plugins=grpc:rpc/proto_authsvr rpc/proto/*.proto
    if [ $? -eq 0 ];then
        echo "protoc success"
        return 0
    fi
    echo "protoc fail"
    return 1
}

function help() {
    echo "$0 build|targz|protoc"
}

case "$1" in 
    "build")
        build "$2"
        exit $?
        ;;
    "targz")
        targz "$2"
        exit $?
        ;;
    "protoc")
        protoc
        exit $?
        ;;
    *)
        help
        exit 1
        ;;
esac
