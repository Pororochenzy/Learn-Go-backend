package sys_setting

import (
	"ops/center/cmdb/global"
	"ops/module/table"
)

// GetSysSetting 获取系统配置
func GetSysSetting(ID int64) (*table.SysSetting, error) {

	model := &table.SysSetting{Id: 1}
	exists, err := global.DB.Get(model)
	if !exists {
		return nil, err
	}

	return model, err
}
