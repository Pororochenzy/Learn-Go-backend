package user

func Logout(token string) error {

	return nil
}
