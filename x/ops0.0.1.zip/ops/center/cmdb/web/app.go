package web

import (
	"github.com/gin-gonic/gin"
)

// StartServer 开启服务
func StartServer(addr string) {
	s := &Server{}
	s.start(addr)
}

// Server web服务
type Server struct {
	engine *gin.Engine
}

// web应用启动
func (p *Server) start(addr string) {
	p.engine = gin.Default()
	// 注册中间件
	p.registMiddle()
	// 注册路由
	p.registRoute()

	defer p.close()

	p.engine.Run(addr)
}

func (p *Server) close() {
	// TODO
}
