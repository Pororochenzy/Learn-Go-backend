package web

import (
	"fmt"
	"ops/center/cmdb/common"
	"ops/center/cmdb/log"
	"time"

	"github.com/gin-gonic/gin"
)

func (p *Server) registMiddle() {
	p.engine.Use(p.excetion(), p.life())
}

func (p *Server) excetion() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if common.HandlerRecover() {
				// controller.RespSysErr(c)
			}
		}()
	}
}

func (p *Server) life() gin.HandlerFunc {
	return func(c *gin.Context) {

		{
			token := ""
			// 请求头里获取token
			ts, ok := c.Request.Header["token"]
			if ok && len(ts) > 0 {
				token = ts[0]
			}

			// url里获取token
			if token == "" {
				Parms := c.Request.URL.Query()
				ts, ok := Parms["token"]
				if ok && len(ts) > 0 {
					token = ts[0]
				}
			}
			c.Set("token", token)
		}

		remoteAddr := c.Request.RemoteAddr
		if value, ok := c.Request.Header["X-Real-Ip"]; ok {
			if len(value) > 0 {
				remoteAddr = value[0]
			}
		}
		start := time.Now()

		// 每个请求设置一个全局id，即此刻纳秒
		uuid := fmt.Sprintf("%v", start.UnixNano())
		c.Set("uuid", uuid)
		log.FInfo("[%v] %v: %v  From: %v", uuid, c.Request.Method, c.Request.RequestURI, remoteAddr)
		log.FInfo("[%v] Header: %v", uuid, c.Request.Header)
		queParms := c.Request.URL.Query()
		c.Request.ParseForm()
		formParms := c.Request.Form
		mutiParms, _ := c.MultipartForm()
		log.FInfo("[%v] Parms: %v, %v, %v", uuid, queParms, formParms, mutiParms)

		c.Next() //处理请求

		if value, ok := c.Get("out"); ok {
			log.FInfo("[%v] Back：%v", uuid, value)
		}

		log.FInfo("[%v] Time: %v Status: %v", uuid, time.Since(start), c.Writer.Status())
	}
}

func (p *Server) checkToken() gin.HandlerFunc {

	return func(c *gin.Context) {

		// token := c.GetString("token")
		// if token == "" {
		// 	resp.RespOut(c, resp.CODE_LOGIN_ERR, "用户未登录，请先登录", nil)
		// 	c.Abort()
		// 	return
		// }

		// session, err := session.Validation(token)
		// if err != nil {
		// 	log.Error(err.Error())
		// 	if strings.Contains(err.Error(), "connection refused") {
		// 		resp.RespSysErr(c, "系统繁忙,请稍后再试")
		// 		c.Abort()
		// 		return
		// 	}
		// 	resp.RespOut(c, resp.CODE_LOGIN_ERR, err.Error(), nil)
		// 	return
		// }

		// c.Set("ID", session.UserID)
		c.Set("ID", 1)
		c.Next()
	}
}

func (p *Server) checkAuth() gin.HandlerFunc {

	return func(c *gin.Context) {

		// 权限校验

		c.Next()
	}
}
