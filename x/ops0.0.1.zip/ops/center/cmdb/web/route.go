package web

import (
	"ops/center/cmdb/web/controller"

	"github.com/gin-gonic/gin"
)

func decorator(fun func(c *controller.Context)) func(c *gin.Context) {
	return func(c *gin.Context) {
		fun(&controller.Context{Context: c})
	}
}

func (p *Server) registRoute() {
	p.engine.GET("/", decorator(controller.Index))

	// 校验权限
	authGroup := p.engine.Group("/", p.checkToken(), p.checkAuth())
	authGroup.GET("user/info", decorator(controller.UserInfo))
}
