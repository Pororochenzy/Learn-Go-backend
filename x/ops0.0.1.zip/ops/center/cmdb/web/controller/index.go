package controller

func Index(c *Context) {
	c.OutSuccess("hello world!")
	return
}
