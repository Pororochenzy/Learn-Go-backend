package controller

func UserLogin(c *Context) {

	user := struct {
		Tel      string `json:"tel"  validate:"required"`
		Password string `json:"password" validate:"required"`
	}{}

	if err := c.ShouldBind(&user); err != nil {
		// c.OutParmErr("参数错误")
		return
	}

}

func UserInfo(c *Context) {
	c.OutSuccess(map[string]interface{}{})
}
