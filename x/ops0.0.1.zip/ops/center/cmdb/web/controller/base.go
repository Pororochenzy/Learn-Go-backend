package controller

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

const (
	// 返回Code码
	CODE_SUCCESS    = 0
	CODE_SYSTEM_ERR = 1
	CODE_PARMS_ERR  = 2
	CODE_LOGIN_ERR  = 7
)

// Out  返回
type out struct {
	Code int64       `json:"code"` // 返回码
	Msg  string      `json:"msg"`  // 返回信息
	Data interface{} `json:"data"` // 返回数据
}

type Context struct {
	*gin.Context
}

// RespSucc 成功
func (c *Context) OutSuccess(data interface{}) {
	c.Out(CODE_SUCCESS, "", data)
}

func (c *Context) OutParmsErr(msg ...string) {
	if len(msg) > 0 {
		c.Out(CODE_PARMS_ERR, msg[0], nil)
	}
	c.Out(CODE_PARMS_ERR, "参数错误", nil)
}

// RespSysErr 失败
func (c *Context) OutSysErr(msg ...string) {
	if len(msg) > 0 {
		c.Out(CODE_SYSTEM_ERR, msg[0], nil)
	}
	c.Out(CODE_SYSTEM_ERR, "系统内部异常", nil)
}

// RespOut 设置返回
func (c *Context) Out(code int64, msg string, data interface{}) {

	if data == nil {
		data = map[string]interface{}{}
	}
	o := out{
		Code: code,
		Msg:  msg,
		Data: data,
	}
	c.Set("out", o)
	c.JSON(http.StatusOK, o)
}
