package session

import (
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"io"
	"ops/center/cmdb/common"
	"ops/center/cmdb/global"
	"ops/center/cmdb/log"
	"ops/center/cmdb/module/sys_setting"
	ms "ops/module/session"
	"time"

	"github.com/bitly/go-simplejson"
)

var SessionEffect = struct {
	onOff     bool  `json:"switch"`
	effectSec int64 `json:"effect_sec"`
}{effectSec: -1}

// SessionInit session参数初始化
func SessionInit(minute int, f func(token string) error) error {

	model, err := sys_setting.GetSysSetting(1)
	if err != nil {
		return err
	}

	if model != nil {
		if err := LoadSessionEffect(model.Content); err != nil {
			log.Error(err.Error())
			return err
		}
	}

	// 定时清理session
	time.AfterFunc(time.Duration(minute)*time.Minute, func() {
		defer common.HandlerRecover("session定时异常！")

		releaseSession(f)
	})

	return nil
}

// CreateSession 产生session
func CreateSession(userID int64) (*ms.Session, error) {

	logicTimestamp := time.Now().Unix()
	session := &ms.Session{
		Token:          createToken(userID),
		LoginTimestamp: logicTimestamp,
		LastTimestamp:  logicTimestamp,
		EffectSec:      SessionEffect.effectSec,
		UserID:         userID,
		Logout:         false,
	}

	// 记录session
	if _, err := global.CacheDB.Do(ms.REDIS_INFO_DB, "HMSET", getCacheSessionKey(session.Token), session); err != nil {
		return nil, err
	}

	// 记录用户sessionId信息
	if err := global.CacheDB.SET(ms.REDIS_INFO_DB, getCacheSessionUserKey(userID), session.Token); err != nil {
		return nil, err
	}

	return session, nil
}

func createToken(userID int64) string {
	b := make([]byte, 32)
	if _, err := io.ReadFull(rand.Reader, b); err != nil {
		return fmt.Sprintf("%v", userID, time.Now().UnixNano())
	}
	//加密
	return base64.URLEncoding.EncodeToString(b)
}

// 加载session配置信息
func LoadSessionEffect(content string) error {

	if content != "" {
		sJson, err := simplejson.NewJson([]byte(content))
		if err != nil {
			return err
		}

		if sJson.Get("switch").MustInt64() > 0 {
			SessionEffect.onOff = true
			SessionEffect.effectSec = sJson.Get("effect_minute").MustInt64() * 60
		}
	} else {
		SessionEffect.onOff = false
		SessionEffect.effectSec = -1
	}

	return nil
}

// releaseSession 释放session
func releaseSession(f func(token string) error) {

	if !SessionEffect.onOff {
		return
	}

	sessionKeys, err := global.CacheDB.RegularKeys(ms.REDIS_INFO_DB, "session:*")
	if err != nil {
		return
	}

	for _, sessionKey := range sessionKeys {
		session, _ := getSession(sessionKey)
		if session != nil {
			//  用户已登出，删除session
			if session.Logout {
				DelSession(session.Token)
				// 用户未登出，若超时，记录日志，删除session
			} else if SessionEffect.onOff && session.IsTimeOut() {
				if err := f(session.Token); err != nil {
					DelSession(session.Token)
				}
			}
		}
	}
}

// GetSession 获取session
func GetSession(token string) (*ms.Session, error) {

	return getSession(getCacheSessionKey(token))
}

// DelSession 删除session
func DelSession(token string) error {

	session, err := GetSession(token)
	if err != nil || session == nil {
		return err
	}

	if err := global.CacheDB.DELKey(ms.REDIS_INFO_DB, getCacheSessionUserKey(session.UserID)); err != nil {
		return err
	}

	if err := global.CacheDB.DELKey(ms.REDIS_INFO_DB, getCacheSessionKey(session.Token)); err != nil {
		return err
	}

	return nil
}

// GetSessionByUserID 获取用户session
func GetSessionByUserID(userID int64) (*ms.Session, error) {

	exist, err := global.CacheDB.IsKeyExist(ms.REDIS_INFO_DB, getCacheSessionUserKey(userID))
	if err != nil || exist <= 0 {
		return nil, err
	}

	token, err := global.CacheDB.GetString(ms.REDIS_INFO_DB, getCacheSessionUserKey(userID))
	if err != nil {
		return nil, err
	}

	{
		session := &ms.Session{}
		exist, err := global.CacheDB.HGetAll(ms.REDIS_INFO_DB, getCacheSessionKey(token), session)
		if err != nil || !exist {
			return nil, err
		}
		return session, nil
	}

}

func getSession(key string) (*ms.Session, error) {

	session := &ms.Session{}
	exist, err := global.CacheDB.HGetAll(ms.REDIS_INFO_DB, key, session)
	if err != nil || !exist {
		return nil, err
	}

	return session, err
}

func getCacheSessionKey(token string) string {
	return fmt.Sprintf("session.", token)
}

func getCacheSessionUserKey(userID int64) string {
	return fmt.Sprintf("session:user:%v", userID)
}
