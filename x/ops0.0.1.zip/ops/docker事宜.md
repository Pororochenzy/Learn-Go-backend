### docker 使用过程说明文档

* 使用docker前 需要掌握linux常用命令
* 官网: www.docker.com
* 开放的镜像仓库: hub.docker.com (常用软件工具类 可以直接pull非常方便 国内需要增加镜像加速 阿里云有)
* docker有CE(社区) 和 EE(企业, 安全增强, 付费)  我们使用社区 免费, 方便
* install  <https://docs.docker.com/install/linux/docker-ce/centos/>
* docker 版本: centos7以上 建议使用CE18.09(建议17.3以上) 其他os 暂未确定
* web管理: portainer 
  * ip: 192.168.1.56 试用
  * user: admin
  * pass: geesunn@123
  * 可管理集群(未来功能  但建议集群管理 交给kubernetes)
* docker-compose 编写docker编排文件  可以帮你快速搭建整套运行环境(篇幅过长(懒)文档暂时不介绍)



### 指令 (常用, 完整版建议查看官方文档 docs.docker.com)

* docker 指令类似linux的命令
* 镜像是指 通过拉取或文件构建的东东
  * 镜像格式 name:version (名字: 版本号. latest 代表最新)
  * 每一个版本建议都构建指定的版本镜像出来(线上好回滚)
* 容器是指 运行着镜像的东东
  * 运行态的内容 非运维或开发 可不了解
* docker -h 查看帮助 (这是个好习惯)
* docker login (登陆到指定的镜像仓库)
  * docker login -u username 镜像仓库域名地址 (回车后 有密码 则输入密码也可以-p指定密码 但不建议)
* docker 
* docker pull xxxx (从可获取的镜像仓库 拉取一个镜像, 不指定版本号 将默认为latest)
* docker push xxxx (上传镜像 id 或tag)
* docker run xxxx (运行镜像 id 或tag)
* docker ps (查看当前运行中的容器)
* docker images (查看当前所有镜像)
* docker tag (为镜像设置标签)
  * docker tag 镜像名称或id xxxx:xxx

* docker build (构建镜像 强烈推荐Dockerfile 文件构造, 或docker-compose.yml构造)

  * 常用命令 docker build -t helloworld .  (-t 指定构造出来的镜像名字,  . 代表当前dockerfile文件路径, 可以是绝对路径)

  * 这是一个Dockerfile文件内容, 建议将此文件放在项目根目录下 (写的不好 见谅)

    ``` 
    FROM golang:1.12  -- 基础镜像 (后端使用golang)
    MAINTAINER yxy <a791540852@gmail.com> -- 消息通知的昵称, 邮箱
     
    RUN mkdir -p $GOPATH/src/baseWeb/ -- run 代表执行指令 这里创建一个目录
    WORKDIR $GOPATH/src/baseWeb/ -- 指定工作目录
     
    ADD . * $GOPATH/src/baseWeb/ -- 讲当前目录文件拷贝至镜像目录下
     
    ENV PORT 8080 
    EXPOSE 8080 -- 暴露端口
     
    ENTRYPOINT ["go", "run" , "/go/src/baseWeb/main.go"] -- docker run 执行的命令
    ```

    