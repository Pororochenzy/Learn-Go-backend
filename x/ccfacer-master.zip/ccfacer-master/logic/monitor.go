package logic

import (
	"ccfacer/define"
	"ccfacer/global"
	"fmt"
	"io/ioutil"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"geesunn.com/lib/redis"
	gs_tool "geesunn.com/tool"
	go_redis "github.com/go-redis/redis"
)

var (
	processingFiles = struct {
		*sync.RWMutex
		M map[string]int64
	}{M: make(map[string]int64, 200), RWMutex: &sync.RWMutex{}}
	redisContentQueue = make(chan *RedisContent, 200)
	redisFileQueue    = make(chan string, 200)
	httpReqFileQueue  = make(chan string, 200)
	httpRespFileQueue = make(chan string, 200)
)

// AddProcessingFiles 添加文件
func AddProcessingFiles(fName string) {
	processingFiles.Lock()
	defer processingFiles.Unlock()
	processingFiles.M[fName] = time.Now().Unix()
}

// DelProcessingFile 删除文件
func DelProcessingFile(fName string) {
	processingFiles.Lock()
	defer processingFiles.Unlock()
	delete(processingFiles.M, fName)
}

// HasProcessingFile 是否存在
func HasProcessingFile(fName string) bool {
	processingFiles.RLock()
	defer processingFiles.RUnlock()
	_, ok := processingFiles.M[fName]
	return ok
}

func RedisChannelMonitor(cli *go_redis.Client, channels ...string) {
	defer CatchException()

	global.Logger.Info("开始订阅Redis：%v", channels)
	pubSub := cli.PSubscribe(channels...)
	for {
		msg, err := pubSub.ReceiveMessage()
		if err != nil {
			global.Logger.Error("接收数据异常：%v", err.Error())
			continue
		}
		global.Logger.Debug("[%v]收到消息：%v", msg.Channel, msg.Payload)

		if len(redisContentQueue) < cap(redisContentQueue) {
			redisContentQueue <- &RedisContent{
				Channel:  msg.Channel,
				Data:     msg.Payload,
				Unixtime: time.Now().Unix(),
			}
			continue
		}
		global.Logger.Error("RedisContentQueue max than %v, drop data %v", cap(redisContentQueue), msg)
	}
}

func RedisKeyMonitor(cache *redis.Redis, db int, key string, timeout int) {
	defer CatchException()

	global.Logger.Info("开始监听Redis：%v", key)
	for {
		data, err := cache.BRPOP(db, key, timeout)
		if err != nil {
			if !strings.Contains(err.Error(), "nil returned") {
				global.Logger.Error("消息队列接收异常: %v", err.Error())
			}
			continue
		}
		global.Logger.Debug("[%v][%v]收到数据：%v", db, key, data)

		if len(redisContentQueue) < cap(redisContentQueue) {
			redisContentQueue <- &RedisContent{
				DB:       db,
				Key:      key,
				Data:     data,
				Unixtime: time.Now().Unix(),
			}
			continue
		}
		global.Logger.Error("RedisContentQueue max than %v, drop data %v", cap(redisContentQueue), data)
	}
}

func common(fName string) {
	// 判断文件后缀
	if strings.HasSuffix(fName, define.FILE_SUFFIX_HTTP_REQ) {
		if len(httpReqFileQueue) >= cap(httpReqFileQueue) {
			global.Logger.Warn("消息队列满了")
			return
		}
		if !HasProcessingFile(fName) {
			AddProcessingFiles(fName)
			httpReqFileQueue <- fName
		}
		return
	} else if strings.HasSuffix(fName, define.FILE_SUFFIX_HTTP_RESP) {
		// todo 对应http响应，暂时在请求处单独处理
		// processingFiles.Lock()
		// if _, ok := processingFiles.M[fName]; !ok {
		// 	processingFiles.M[fName] = time.Now().Unix()
		// 	httpRespFileQueue <- fName
		// }
		// processingFiles.Unlock()
	} else if strings.HasSuffix(fName, define.FILE_SUFFIX_REDIS) {
		if len(redisFileQueue) >= cap(redisFileQueue) {
			global.Logger.Warn("消息队列满了")
			return
		}

		if !HasProcessingFile(fName) {
			AddProcessingFiles(fName)
			redisFileQueue <- fName
		}
		return
	} else {
		global.Logger.Info("删除后缀不一致的文件: %v", fName)
		switch global.FacerGapType {
		case define.FACER_GAP_TYPE_FILE:
			DeleteFile(filepath.Join(global.DataRecvDir, fName))
		case define.FACER_GAP_TYPE_DB:
			DeleteDBInfo(fName)
		}
	}
}

func RecvMonitor() {
	defer CatchException()

	switch global.FacerGapType {
	case define.FACER_GAP_TYPE_FILE:
		global.Logger.Info("开始监听文件夹：%v", global.DataRecvDir)
		for {
			fs, err := ioutil.ReadDir(global.DataRecvDir)
			if err != nil {
				global.Logger.Error(err.Error())
			}
			for _, f := range fs {
				fName := f.Name()

				// 先确认是智象的文件
				if strings.HasPrefix(fName, "gsn_") {
					// 如果是采集端，判断文件是否属于当前隔离区
					if global.Facer == define.FACER_TYPE_COLLECT {
						if !strings.HasPrefix(fName, fmt.Sprintf("gsn_%v_", global.TerminalUUID)) {
							DeleteFile(filepath.Join(global.DataRecvDir, fName))
							global.Logger.Info("删除非当前区的文件: %v", fName)
							continue
						}
					}

					// 删除过期的文件
					if time.Since(f.ModTime()) > 1*time.Hour {
						DeleteFile(filepath.Join(global.DataRecvDir, fName))
						global.Logger.Warning("删除长时间未处理文件: %v", fName)
						continue
					}
					common(fName)
				}
			}
			time.Sleep(50 * time.Millisecond)
		}
	case define.FACER_GAP_TYPE_DB:
		global.Logger.Info("开始监听数据表")
		for {
			rows, err := ReadDBAll()
			// global.Logger.Debug("%v", rows)
			if err != nil {
				global.Logger.Error(err.Error())
			}
			// 如果没有可读取的数据
			if len(rows) == 0 {
				time.Sleep(time.Second)
				continue
			}
			for _, row := range rows {
				fName := row["filename"].(string)
				createTime := row["create_time"].(string)
				t, _ := gs_tool.Str2Time("2006-01-02 15:04:05", createTime)

				// 先确认是智象的文件
				if strings.HasPrefix(fName, "gsn_") {
					// 如果是采集端，判断文件是否属于当前隔离区
					if global.Facer == define.FACER_TYPE_COLLECT {
						if !strings.HasPrefix(fName, fmt.Sprintf("gsn_%v_", global.TerminalUUID)) {
							continue
						}
					}
					// 删除过期的文件
					if time.Since(t) > 1*time.Hour {
						global.Logger.Warning("删除长时间未处理文件: %v", fName)
						if err := DeleteDBInfo(fName); err != nil {
							global.Logger.Error(err.Error())
						}
						continue
					}
					common(fName)
				}
			}
			time.Sleep(50 * time.Millisecond)
		}
	}
}
