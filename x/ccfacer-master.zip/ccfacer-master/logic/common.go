package logic

import (
	"ccfacer/define"
	"ccfacer/global"
	"encoding/json"
	"io/ioutil"
	"net"
	"net/http"
	"net/url"
	"path/filepath"
	"strings"
	"time"
)

func NewUUID() int64 {
	return time.Now().UnixNano()
}

type HttpContent struct {
	URL      string `json:"url"`
	Method   string `json:"method"`
	Body     []byte `json:"body"`
	Unixtime int64  `json:"unixtime"`
}

func HttpContentFromByte(s []byte) (c *HttpContent, err error) {
	err = json.Unmarshal(s, &c)
	return
}

func (c *HttpContent) ToByte() []byte {
	s, _ := json.Marshal(c)
	return s
}

type RedisContent struct {
	Channel  string `json:"channel,omitempty"`
	DB       int    `json:"db,omitempty"`
	Key      string `json:"key,omitempty"`
	Data     string `json:"data"`
	Unixtime int64  `json:"unixtime"`
}

func RedisContentFromByte(s []byte) (c *RedisContent, err error) {
	err = json.Unmarshal(s, &c)
	return
}

func (c *RedisContent) ToByte() []byte {
	s, _ := json.Marshal(c)
	return s
}

// 转发http请求
func RewriteRequest(requuid, sendPath string, content *HttpContent) error {
	client := &http.Client{
		Transport: &http.Transport{
			Dial: func(netw, addr string) (net.Conn, error) {
				deadline := time.Now().Add(5 * time.Second)
				c, err := net.DialTimeout(netw, addr, 3*time.Second)
				if err != nil {
					return nil, err
				}
				c.SetDeadline(deadline)
				return c, nil
			},
		},
	}
	req, err := http.NewRequest(content.Method, "http://"+global.RequestAddr+content.URL, strings.NewReader(string(content.Body)))
	if err != nil {
		global.Logger.Error(err.Error())
		return err
	}
	req.Header.Set("Content-Type", map[string]string{
		"GET":  "text/plain; charset=utf-8",
		"POST": "application/x-www-form-urlencoded",
	}[content.Method])

	resp, err := client.Do(req)
	if err != nil {
		global.Logger.Error(err.Error())
		return err
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		global.Logger.Error(err.Error())
		return err
	}
	global.Logger.Info("requuid:%v	文件转请求返回：%v %v", requuid, resp.Status, string(body))
	c := HttpContent{
		URL:      content.URL,
		Method:   content.Method,
		Body:     body,
		Unixtime: time.Now().Unix(),
	}
	if global.FacerGapType == define.FACER_GAP_TYPE_FILE {
		if err := WriteFile(sendPath, c.ToByte()); err != nil {
			global.Logger.Error(err.Error())
			return err
		}
	} else if global.FacerGapType == define.FACER_GAP_TYPE_DB {
		_, fName := filepath.Split(sendPath)
		if err := WriteDB(fName, c.ToByte()); err != nil {
			global.Logger.Error(err.Error())
			return err
		}
	}

	return nil
}

func GetTerminalUUID(ip string) string {
	for _, term := range global.TerminalList {
		if term.IP == ip {
			return term.UUID
		}
	}
	return ""
}

func GetTerminalUUIDFromURI(uri string) string {
	u, _ := url.Parse(uri)
	values, _ := url.ParseQuery(u.RawQuery)
	if v, ok := values["terminal_uuid"]; ok {
		return v[0]
	}
	return ""
}

func GetTerminalSendDir(uuid string) string {
	if term, ok := global.TerminalList[uuid]; ok {
		return term.SendDir
	}
	return ""
}
