package logic

import (
	"ccfacer/define"
	"ccfacer/global"
	"fmt"
	"io/ioutil"
	"net/http"
	"path/filepath"
	"strings"
	"time"

	"geesunn.com/gpool"
	gs_tool "geesunn.com/tool"
	"github.com/gin-gonic/gin"
)

func HttpServer() {
	defer CatchException()

	router := gin.Default()
	router.NoRoute(httpProxyToSharedArea)
	if err := router.Run("0.0.0.0:" + global.LocalPort); err != nil {
		panic(fmt.Sprintf("http路由启动出错：%v", err.Error()))
	}
}

func httpProxyToSharedArea(c *gin.Context) {
	defer CatchException()

	requuid := NewUUID()
	global.Logger.Info("requuid:%v，收到请求：%v", requuid, c.Request.RequestURI)

	body, _ := ioutil.ReadAll(c.Request.Body)
	c1 := HttpContent{
		URL:      c.Request.RequestURI,
		Method:   c.Request.Method,
		Body:     body,
		Unixtime: time.Now().Unix(),
	}

	var terminalUUID string
	switch global.Facer {
	case define.FACER_TYPE_CCHANDLER:
		terminalUUID = GetTerminalUUIDFromURI(c.Request.RequestURI)
	case define.FACER_TYPE_COLLECT:
		terminalUUID = global.TerminalUUID
	}

	if len(terminalUUID) == 0 {
		global.Logger.Error("TerminalUUID为空")
		return
	}

	fName := fmt.Sprintf("gsn_%v_%v_%v", terminalUUID, requuid, define.FILE_SUFFIX_HTTP_REQ)
	respfName := fmt.Sprintf("gsn_%v_%v_%v", terminalUUID, requuid, define.FILE_SUFFIX_HTTP_RESP)

	switch global.FacerGapType {
	case define.FACER_GAP_TYPE_FILE:
		tmpPath := filepath.Join(global.DataSendDirTmp, fName)
		path := filepath.Join(global.DataSendDir, fName)

		if global.Facer == define.FACER_TYPE_CCHANDLER {
			dir := GetTerminalSendDir(terminalUUID)
			if len(dir) == 0 {
				global.Logger.Error(fmt.Sprintf("未配置采集端(%v)对应的SendDir", terminalUUID))
				return
			}
			path = filepath.Join(dir, fName)
		}
		if err := WriteFile(tmpPath, c1.ToByte()); err != nil {
			global.Logger.Error(err.Error())
			return
		}
		Move(tmpPath, path)
	case define.FACER_GAP_TYPE_DB:
		if err := WriteDB(fName, c1.ToByte()); err != nil {
			global.Logger.Error(err.Error())
			return
		}
	}

	// 等待获取返回数据
	timeout := time.After(time.Duration(global.Timeout) * time.Second)
	for {
		select {
		case <-timeout:
			global.Logger.Warning("requuid：%v，未找到返回文件：%v", requuid, respfName)
			c.Data(http.StatusOK, "text/plain", []byte("no response file"))
			return
		default:
			time.Sleep(500 * time.Millisecond)
			switch global.FacerGapType {
			case define.FACER_GAP_TYPE_FILE:
				respPath := filepath.Join(global.DataRecvDir, respfName)
				if gs_tool.IsFileExist(respPath) {
					c2b, err := ReadAndDeleteFile(respPath)
					if err != nil {
						global.Logger.Error(err.Error())
						c.Data(http.StatusOK, "text/plain", []byte("ccfacer read response file error"))
						return
					}
					c2, err := HttpContentFromByte(c2b)
					if err != nil {
						global.Logger.Error("requuid：%v，返回数据格式错误：%v", requuid, string(c2b))
						c.Data(http.StatusOK, "text/plain", []byte("ccfacer parse response data error"))
						return
					}
					global.Logger.Info("requuid：%v，请求返回：%v", requuid, string(c2.Body))
					c.Data(http.StatusOK, "application/json; charset=utf-8", c2.Body)
					return
				}
			case define.FACER_GAP_TYPE_DB:
				if IsDBInfoExist(respfName) {
					c2b, err := ReadDB(respfName)
					if err != nil {
						global.Logger.Error(err.Error())
						c.Data(http.StatusOK, "text/plain", []byte("ccfacer read response file error"))
						return
					}
					c2, err := HttpContentFromByte(c2b)
					if err != nil {
						global.Logger.Error("requuid：%v，返回数据格式错误：%v", requuid, string(c2b))
						c.Data(http.StatusOK, "text/plain", []byte("ccfacer parse response data error"))
						return
					}
					global.Logger.Info("requuid：%v，请求返回：%v", requuid, string(c2.Body))
					c.Data(http.StatusOK, "application/json; charset=utf-8", c2.Body)
					return
				}
			}
		}
	}
}

func HttpProxyFromSharedArea() {
	defer CatchException()
	gp := gpool.NewGoPool(10)

	worker := func(fName string) {
		defer CatchException()
		defer gp.ReleaseGo()

		requuid := strings.TrimLeft(fName, fmt.Sprintf("gsn_"))
		teruuid := strings.Split(fName, "_")[1] // gsn_TerminalUUID_uuid_suffix.db

		var cb []byte

		switch global.FacerGapType {
		case define.FACER_GAP_TYPE_FILE:
			fPath := filepath.Join(global.DataRecvDir, fName)
			if gs_tool.IsFileExist(fPath) {
				var err error
				cb, err = ReadAndDeleteFile(fPath)
				if err != nil {
					global.Logger.Error(err.Error())
					return
				}
			} else {
				return
			}
		case define.FACER_GAP_TYPE_DB:
			if IsDBInfoExist(fName) {
				var err error
				cb, err = ReadDB(fName)
				if err != nil {
					global.Logger.Error(err.Error())
					return
				}
			} else {
				return
			}
		}

		DelProcessingFile(fName)

		c, err := HttpContentFromByte(cb)
		if err != nil {
			global.Logger.Error(err.Error())
			return
		}

		timeout := time.Now().Unix() - c.Unixtime
		if timeout > int64(global.Timeout) {
			global.Logger.Warning("文件%v已过期，延迟：%v s", fName, timeout)
			return
		}

		if global.Facer == define.FACER_TYPE_COLLECT {
			if !strings.Contains(c.URL, global.TerminalUUID) {
				global.Logger.Warning("文件转请求：%v，缺少终端UUID", c.URL)
				return
			}
		}

		fName = strings.TrimSuffix(fName, define.FILE_SUFFIX_HTTP_REQ)
		fName = fmt.Sprintf("%v%v", fName, define.FILE_SUFFIX_HTTP_RESP)

		sendPath := filepath.Join(global.DataSendDir, fName)
		if global.Facer == define.FACER_TYPE_CCHANDLER {
			dir := GetTerminalSendDir(teruuid)
			if len(dir) == 0 {
				global.Logger.Warn(fmt.Sprintf("未配置采集端(%v)对应的SendDir", teruuid))
				return
			}
			sendPath = filepath.Join(dir, fName)
		}

		global.Logger.Info("requuid：%v，文件转请求：%v", requuid, c.URL)
		if err := RewriteRequest(requuid, sendPath, c); err != nil {
			global.Logger.Error(err.Error())
			return
		}
	}

	for {
		fName := <-httpReqFileQueue
		gp.GetGo()
		go worker(fName)
	}
}

func RedisProxyToSharedArea() {
	defer CatchException()

	gp := gpool.NewGoPool(10)
	worker := func(content *RedisContent) {
		defer CatchException()
		defer gp.ReleaseGo()

		var terminalUUID string
		switch global.Facer {
		case define.FACER_TYPE_CCHANDLER:
			// M端下发只有订阅发布方式，所以这里不处理监听键值的情况
			chInfo := strings.Split(content.Channel, ":")
			if len(chInfo) > 1 {
				terminalUUID = GetTerminalUUID(chInfo[1])
			}
		case define.FACER_TYPE_COLLECT:
			terminalUUID = global.TerminalUUID
		}

		if len(terminalUUID) == 0 {
			global.Logger.Error("TerminalUUID为空")
			return
		}

		fName := fmt.Sprintf("gsn_%v_%v_%v", terminalUUID, NewUUID(), define.FILE_SUFFIX_REDIS)

		switch global.FacerGapType {
		case define.FACER_GAP_TYPE_FILE:
			tmpPath := filepath.Join(global.DataSendDirTmp, fName)
			path := filepath.Join(global.DataSendDir, fName)
			if global.Facer == define.FACER_TYPE_CCHANDLER {
				dir := GetTerminalSendDir(terminalUUID)
				if len(dir) == 0 {
					global.Logger.Warn(fmt.Sprintf("未配置采集端(%v)对应的SendDir", terminalUUID))
					return
				}
				path = filepath.Join(dir, fName)
			}
			if err := WriteFile(tmpPath, content.ToByte()); err != nil {
				global.Logger.Error(err.Error())
				return
			}
			Move(tmpPath, path)
		case define.FACER_GAP_TYPE_DB:
			if err := WriteDB(fName, content.ToByte()); err != nil {
				global.Logger.Error(err.Error())
				return
			}
		}
	}

	for {
		content := <-redisContentQueue
		gp.GetGo()
		go worker(content)
	}
}

func RedisProxyFromSharedArea() {
	defer CatchException()

	gp := gpool.NewGoPool(10)
	worker := func(fName string) {
		defer CatchException()
		defer gp.ReleaseGo()

		var cb []byte

		switch global.FacerGapType {
		case define.FACER_GAP_TYPE_FILE:
			fPath := filepath.Join(global.DataRecvDir, fName)
			if gs_tool.IsFileExist(fPath) {
				var err error
				cb, err = ReadAndDeleteFile(fPath)
				if err != nil {
					global.Logger.Error(err.Error())
					return
				}
			} else {
				return
			}
		case define.FACER_GAP_TYPE_DB:
			if IsDBInfoExist(fName) {
				var err error
				cb, err = ReadDB(fName)
				if err != nil {
					global.Logger.Error(err.Error())
					return
				}
			} else {
				return
			}
		}

		DelProcessingFile(fName)

		c, err := RedisContentFromByte(cb)
		if err != nil {
			global.Logger.Error(err.Error())
			return
		}

		timeout := time.Now().Unix() - c.Unixtime
		if timeout > int64(global.Timeout) {
			global.Logger.Warning("文件%v已过期，延迟：%v s", fName, timeout)
			return
		}

		// 这里M端、C端都支持处理两种内容(订阅发布、监听键值)的文件
		if len(c.Channel) > 0 {
			if err := global.CacheDB.PUBLISH(0, c.Channel, c.Data); err != nil {
				global.Logger.Error("[通道]%v发布异常：%v", c.Channel, err.Error())
				return
			}
			global.Logger.Info("[通道]%v发布消息：%v", c.Channel, c.Data)
		}

		if len(c.Key) > 0 {
			if err := global.CacheDB.CheckToLPUSH(c.DB, c.Key, c.Data); err != nil {
				global.Logger.Error("[缓存]%v插入异常：%v", c.Key, err.Error())
				return
			}
			global.Logger.Info("[缓存]%v插入数据：%v", c.Key, c.Data)
		}
	}

	for {
		fName := <-redisFileQueue
		gp.GetGo()
		go worker(fName)
	}
}
