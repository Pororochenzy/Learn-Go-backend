package logic

import (
	"ccfacer/define"
	"ccfacer/global"
	"fmt"

	"geesunn.com/lib/mysql"
)

// 写数据库
func WriteDB(filename string, content []byte) error {

	table := ""
	switch global.Facer {
	case define.FACER_TYPE_CCHANDLER:
		table = "ccfacer_m2c"
	case define.FACER_TYPE_COLLECT:
		table = "ccfacer_c2m"
	default:
		return fmt.Errorf("错误的facer")
	}
	_, err := mysql.InsertTR(global.DB, table, map[string]interface{}{
		"filename": filename,
		"content":  string(content),
	})
	return err
}

// 从DB中读取信息
func ReadDB(filename string) (content []byte, err error) {

	table := ""
	switch global.Facer {
	case define.FACER_TYPE_CCHANDLER:
		table = "ccfacer_c2m"
	case define.FACER_TYPE_COLLECT:
		table = "ccfacer_m2c"
	default:
		return []byte{}, fmt.Errorf("错误的facer")
	}

	info, _ := mysql.GetOneTRInfo(global.DB, table, map[string]interface{}{
		"filename": filename,
	})
	if info != nil {
		err := DeleteDBInfo(filename)
		return []byte(info["content"].(string)), err
	}

	return []byte{}, nil
}

func DeleteDBInfo(filename string) error {

	table := ""
	switch global.Facer {
	case define.FACER_TYPE_CCHANDLER:
		table = "ccfacer_c2m"
	case define.FACER_TYPE_COLLECT:
		table = "ccfacer_m2c"
	default:
		return fmt.Errorf("错误的facer")
	}

	_, err := mysql.DeleteTR(global.DB, table, map[string]interface{}{
		"filename": filename,
	})
	return err
}

// 从DB中读取所有待读的记录
func ReadDBAll() ([]map[string]interface{}, error) {
	table := ""
	switch global.Facer {
	case define.FACER_TYPE_CCHANDLER:
		table = "ccfacer_c2m"
	case define.FACER_TYPE_COLLECT:
		table = "ccfacer_m2c"
	default:
		return nil, fmt.Errorf("错误的facer")
	}
	rows, err := mysql.GetTRInfo(global.DB, table, nil)
	return rows, err
}

func IsDBInfoExist(filename string) bool {
	table := ""
	switch global.Facer {
	case define.FACER_TYPE_CCHANDLER:
		table = "ccfacer_c2m"
	case define.FACER_TYPE_COLLECT:
		table = "ccfacer_m2c"
	default:
		return false
	}
	info, _ := mysql.GetOneTRInfo(global.DB, table, map[string]interface{}{
		"filename": filename,
	})
	return info != nil
}
