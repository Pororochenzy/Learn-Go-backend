package logic

import (
	"ccfacer/global"
	"io"
	"io/ioutil"
	"os"
)

// 写文件
func WriteFile(path string, content []byte) error {
	file, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY, 0755)
	if err != nil {
		return err
	}
	defer file.Close()
	n, err := file.Write(content)
	if err != nil {
		return err
	}
	global.Logger.Info("写文件：%v, %v", path, n)
	return nil
}

// 移动到共享区
func Move(src, dst string) {
	global.Logger.Debug("移动文件:%v => %v", src, dst)
	if err := os.Rename(src, dst); err != nil {
		// copy file when cross-device link
		if err := CopyFile(src, dst); err != nil {
			global.Logger.Error(err.Error())
		}
		if err := os.Remove(src); err != nil {
			global.Logger.Error(err.Error())
		}
	}
}

// 读文件
func ReadFile(path string) (content []byte, err error) {
	file, err := os.OpenFile(path, os.O_RDONLY, 0755)
	if err != nil {
		return
	}
	defer file.Close()

	content, err = ioutil.ReadAll(file)
	return
}

func ReadAndDeleteFile(path string) (content []byte, err error) {
	file, err := os.OpenFile(path, os.O_RDONLY, 0755)
	if err != nil {
		return
	}
	defer file.Close()

	content, err = ioutil.ReadAll(file)
	if err = os.Remove(path); err != nil {
		global.Logger.Error(err.Error())
		return
	}
	global.Logger.Info("删除文件：%v", path)
	return
}

func DeleteFile(path string) {
	if err := os.Remove(path); err != nil {
		global.Logger.Error(err.Error())
		return
	}
	global.Logger.Info("删除文件：%v", path)
}

func CopyFile(src, dst string) error {
	r, err := os.Open(src)
	if err != nil {
		return err
	}
	defer r.Close()

	w, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer w.Close()

	_, err = io.Copy(w, r)
	return err
}
