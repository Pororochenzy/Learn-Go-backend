package define

import (
	gs_define "geesunn.com/define"
)

const (
	REDIS_MQ_DB = gs_define.REDIS_MQ_DB

	C_CACHE_MCENTER_RECV_QUEUE   = gs_define.M_CACHE_MCENTER_RECV_QUEUE
	C_CACHE_CCHANDLER_RECV_QUEUE = gs_define.M_CACHE_CCHANDLER_RECV_QUEUE

	M_CACHE_TO_COLLECT_PREFIX = gs_define.M_CACHE_TO_COLLECT_PREFIX
)

const (
	FACER_TYPE_COLLECT   = "collect"
	FACER_TYPE_CCHANDLER = "cc_handler"

	FACER_GAP_TYPE_FILE = "file"
	FACER_GAP_TYPE_DB   = "db"
)

const (
	FILE_SUFFIX_HTTP_REQ  = "http_req.db"
	FILE_SUFFIX_HTTP_RESP = "http_resp.db"
	FILE_SUFFIX_REDIS     = "redis.db"
)
