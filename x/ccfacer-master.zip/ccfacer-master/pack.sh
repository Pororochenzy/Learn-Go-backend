#!/bin/bash

WORKSPACE=$(cd $(dirname $0)/; pwd)
cd $WORKSPACE

# 生成的程序名称
app=geesunn-ccfacer
appexe=ccfacer
# main.go文件路径
src=main.go

build_dir=~/geesunn/build
targz_dir=~/geesunn/targz

function build() {
    mkdir -p $build_dir
    rm -fr $build_dir/$app/
    go build -o $build_dir/$app/$appexe $src
    cp -fr config $build_dir/$app
    cp -fr control.sh $build_dir/$app

    case "$1" in
        "test")
            cd $build_dir/$app/config
            rm -fr app.conf app.conf.pro
            mv app.conf.test app.conf
            /usr/local/bin/gmo encf app.conf
            rm -fr app.conf
            ;;
        "pro")
            cd $build_dir/$app/config
            rm -fr app.conf app.conf.test
            mv app.conf.pro app.conf
            /usr/local/bin/gmo encf app.conf
            rm -fr app.conf
        ;;
        *)
        ;;
    esac

    if [ -d $build_dir/$app ]; then  
        echo "1) build: $build_dir/$app"
        return 0
    else
        echo "2) build: failed" 
        return 1
    fi
}

function targz() {
	mkdir -p $targz_dir
    build
	cd $build_dir
	tar -zcf $targz_dir/$app.tar.gz $app
    if [ -f $targz_dir/$app.tar.gz ]; then  
        echo "2) targz: $targz_dir/$app.tar.gz" 
        return 0
    else
        echo "2) targz: failed" 
        return 1
    fi
}

function secret() {
	targz
	cd $targz_dir
	key="geesunninstall2017"
	tar -zcf - $app.tar.gz | openssl des3 -salt -k $key > /dev/null 2>&1 | dd of=$app.gsn  >/dev/null 2>&1
    if [ -f $targz_dir/$app.gsn ]; then  
        echo "3) secret: $targz_dir/$app.gsn"
        return 0
    else
        echo "3) secret: failed" 
        return 1
    fi
}

function help() {
    echo "$0 build|targz|secret"
}

case "$1" in 
    "build")
        build "$2"
        exit $?
        ;;
    "targz")
        targz
        exit $?
        ;;
    "secret")
        secret
        exit $?
        ;;
    *)
        help
        exit 1
        ;;
esac