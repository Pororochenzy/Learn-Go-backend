m_driver = "sgcc.nds.jdbc.driver.NdsDriver"
m_url = "jdbc:nds://127.0.0.1:13311/gsn_mcenter?appname=xxxx"
m_jar_path = "./SqlProxyCfg_Jdbc.jar"
m_user = "geesunn"
m_password = "FxwK95_@1a"

c_host = "127.0.0.1"
c_port = 13311
c_database = "gsn_mcenter"
c_user = "geesunn"
c_password = "FxwK95_@1a"
