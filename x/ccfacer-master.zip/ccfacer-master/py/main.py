# -*-coding:utf8-*-
import conf
import jaydebeapi
import MySQLdb
import time


if __name__ == "__main__":

    m_conn = jaydebeapi.connect(conf.m_driver,conf.m_url, [conf.m_user, conf.m_password], conf.m_jar_path)
    c_conn = MySQLdb.connect(host=conf.c_host, port=conf.c_port, user=conf.c_user, passwd=conf.c_password, db=conf.c_database, charset='utf8' )

    while True:
        try:
            m = m_conn.cursor()
            c = c_conn.cursor()
            c.execute("select * from ccfacer_c2m")
            rows = c.fetchall()

            for row in rows:
                if len(row) == 4: 
                    try:
                        m.execute("insert into ccfacer_c2m(id, filename, content, create_time) value(%s, '%s', '%s', '%s') " % (row[0], row[1], row[2], row[3]))
                        m_conn.commit()
                    except Exception as e:
                        m_conn.rollback()
                        print e

            m.execute("select * from ccfacer_m2c")
            rows = m.fetchall()
            for row in rows:
                if len(row) == 4: 
                    try:
                        c.execute("insert into ccfacer_m2c(id, filename, content, create_time) value(%s, '%s', '%s', '%s') " % (row[0], row[1], row[2], row[3]))
                        c_conn.commit()
                    except Exception as e:
                        c_conn.rollback()
                        print e

        except Exception as e:
            print e

        time.sleep(0.1)

    m_conn.close()
    c_conn.close()


# try:
#     c = conn.cursor()
#     c.execute("INSERT INTO ccfacer_c2m(filename, content, unixtime) VALUE(?, ?, ?)", [filename, content, unixtime])
#     print c.fetchall()
# except Exception as result:
#     print result
# finally:
#     c.close()

