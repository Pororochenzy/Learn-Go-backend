package global

import (
	"ccfacer/define"
	"database/sql"
	"encoding/json"
	"flag"
	"fmt"
	"path/filepath"

	"geesunn.com/lib/mysql"
	"geesunn.com/lib/redis"
	"geesunn.com/logs"
	gs_tool "geesunn.com/tool"
	"github.com/Unknwon/goconfig"
)

type RedisConfig struct {
	Host     string
	Port     int
	Password string
	MaxConn  int
	MaxIdle  int
}

type TerminalConfig struct {
	UUID    string `json:"uuid"`
	IP      string `json:"ip"`
	SendDir string `json:"send_dir"`
}

var (
	// 工程全局配置对象
	Config       *goconfig.ConfigFile
	Facer        = ""
	FacerGapType = ""
	LocalPort    = ""
	TerminalUUID = ""
	RequestAddr  = ""
	Timeout      = 5
	HttpEnable   = "false"
	RedisEnable  = "false"
	CacheDB      redis.Redis
	RedisConf    RedisConfig
	DB           *sql.DB

	DataSendDir    = ""
	DataSendDirTmp = ""
	DataRecvDir    = ""
	TerminalList   = map[string]*TerminalConfig{}
	// 日志对象
	Logger = logs.NewLogger()
)

func init() {
	configPath := flag.String("c", "config/app.conf", "配置文件路径")
	flag.Parse()
	c, err := goconfig.LoadConfigFile(*configPath)
	if err != nil {
		panic(err)
	}
	Config = c

	fileSwitch := Config.MustValue("log", "fileswitch")
	level := Config.MustValue("log", "level")
	if fileSwitch == "on" {
		fileName := Config.MustValue("log", "filename")
		daily := Config.MustValue("log", "daily")
		maxdays := Config.MustValue("log", "maxdays")
		if err := Logger.SetLogger(logs.AdapterFile,
			fmt.Sprintf(`{"filename": "%v", "daily": %v, "maxdays": %v, "level": %v}`, fileName, daily, maxdays, level)); err != nil {
			panic(err)
		}
	} else {
		if err := Logger.SetLogger(logs.AdapterConsole); err != nil {
			panic(err)
		}
	}
	// 设置日志输出文件名和文件行号
	Logger.EnableFuncCallDepth(true)
	// 设置日志是否异步输出
	if Config.MustValue("log", "async") == "true" {
		// 设置异步输出日志，并且设置缓存大小1e3
		Logger.Async(1e3)
	}

	Facer = Config.MustValue("sys", "facer")
	FacerGapType = Config.MustValue("sys", "gap_type")
	Timeout = Config.MustInt("sys", "timeout_sec")
	HttpEnable = Config.MustValue("sys", "http_enable")
	RedisEnable = Config.MustValue("sys", "redis_enable")

	switch Facer {
	default:
		panic("facer值错误")
	case define.FACER_TYPE_COLLECT:
		LocalPort = Config.MustValue("collect", "local_port")
		RequestAddr = Config.MustValue("collect", "request_addr")
		TerminalUUID = Config.MustValue("collect", "terminal_uuid")
		switch FacerGapType {
		case define.FACER_GAP_TYPE_DB:
			user := Config.MustValue("c_db", "user")
			password := Config.MustValue("c_db", "password")
			host := Config.MustValue("c_db", "host")
			port := Config.MustValue("c_db", "port")
			db := Config.MustValue("c_db", "database")
			maxOpenConns := Config.MustInt("c_db", "max_open_conn")
			maxIdleConns := Config.MustInt("c_db", "max_idle_conn")
			dataSourceName := fmt.Sprintf("%v:%v@tcp(%v:%v)/%v?charset=utf8&loc=Local", user, password, host, port, db)
			conn, err := mysql.NewConnection(dataSourceName, maxOpenConns, maxIdleConns)
			if err != nil {
				panic(err)
			}
			DB = conn
		case define.FACER_GAP_TYPE_FILE:
			DataSendDir, _ = filepath.Abs(Config.MustValue("collect", "data_send_dir"))
			DataSendDirTmp, _ = filepath.Abs(Config.MustValue("collect", "data_send_dir_tmp"))
			DataRecvDir, _ = filepath.Abs(Config.MustValue("collect", "data_recv_dir"))
		default:
			panic("sys->facer_type不允许为空")
		}

		RedisConf.Host = Config.MustValue("c_redis", "host")
		RedisConf.Port = Config.MustInt("c_redis", "port")
		RedisConf.Password = Config.MustValue("c_redis", "password")
		RedisConf.MaxConn = Config.MustInt("c_redis", "max_conn")
		RedisConf.MaxIdle = Config.MustInt("c_redis", "max_idle")

	case define.FACER_TYPE_CCHANDLER:
		LocalPort = Config.MustValue("cc_handler", "local_port")
		RequestAddr = Config.MustValue("cc_handler", "request_addr")
		switch FacerGapType {
		case define.FACER_GAP_TYPE_DB:
			user := Config.MustValue("m_db", "user")
			password := Config.MustValue("m_db", "password")
			host := Config.MustValue("m_db", "host")
			port := Config.MustValue("m_db", "port")
			db := Config.MustValue("m_db", "database")
			maxOpenConns := Config.MustInt("m_db", "max_open_conn")
			maxIdleConns := Config.MustInt("m_db", "max_idle_conn")
			dataSourceName := fmt.Sprintf("%v:%v@tcp(%v:%v)/%v?charset=utf8&loc=Local", user, password, host, port, db)
			conn, err := mysql.NewConnection(dataSourceName, maxOpenConns, maxIdleConns)
			if err != nil {
				panic(err)
			}
			DB = conn
		case define.FACER_GAP_TYPE_FILE:
			DataSendDirTmp, _ = filepath.Abs(Config.MustValue("cc_handler", "data_send_dir_tmp"))
			DataRecvDir, _ = filepath.Abs(Config.MustValue("cc_handler", "data_recv_dir"))
		default:
			panic("sys->facer_type不允许为空")
		}

		arr := Config.MustValue("cc_handler", "terminal_list")
		var termConfArr []*TerminalConfig
		if err := json.Unmarshal([]byte(arr), &termConfArr); err != nil {
			Logger.Error(err.Error())
			panic("terminal_list格式错误")
		}
		for _, conf := range termConfArr {
			TerminalList[conf.UUID] = conf
		}
		Logger.Debug("%v", TerminalList)

		RedisConf.Host = Config.MustValue("m_redis", "host")
		RedisConf.Port = Config.MustInt("m_redis", "port")
		RedisConf.Password = Config.MustValue("m_redis", "password")
		RedisConf.MaxConn = Config.MustInt("m_redis", "max_conn")
		RedisConf.MaxIdle = Config.MustInt("m_redis", "max_idle")
	}

	if FacerGapType == define.FACER_GAP_TYPE_FILE {
		InitDir()
	}
}

func InitDir() {
	// 创建临时目录
	if !gs_tool.IsDirExist(DataSendDirTmp) {
		gs_tool.MakeDir(DataSendDirTmp)
	}
	// 检查数据目录
	if Facer == define.FACER_TYPE_COLLECT {
		if !gs_tool.IsDirExist(DataSendDir) {
			panic("data_send_dir文件夹不存在")
		}
	} else if Facer == define.FACER_TYPE_CCHANDLER {
		for _, term := range TerminalList {
			if !gs_tool.IsDirExist(term.SendDir) {
				panic("data_send_dir文件夹不存在")
			}
		}
	}

	if !gs_tool.IsDirExist(DataRecvDir) {
		panic("data_recv_dir文件夹不存在")
	}
}
