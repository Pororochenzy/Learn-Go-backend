package main

import (
	"ccfacer/define"
	"ccfacer/global"
	"ccfacer/logic"
	"fmt"
	"time"

	go_redis "github.com/go-redis/redis"
)

/*
采集器端流程:
	1. 接收采集器的请求
	2. 将请求数据写共享区
	3. 读共享区数据，返回给采集器、或者主动推给采集器

处理端流程:
	1. 接收mcenter的请求
	2. 将请求数据写共享区
	3. 读共享区数据，返回给mcenter、或者主动推给mcenter
*/

func main() {
	go logic.RecvMonitor()

	if global.HttpEnable == "true" {
		go logic.HttpServer()
		go logic.HttpProxyFromSharedArea()
	}

	if global.RedisEnable == "true" {
		if err := global.CacheDB.Init(
			global.RedisConf.Host,
			global.RedisConf.Port,
			global.RedisConf.Password,
			global.RedisConf.MaxConn,
			global.RedisConf.MaxIdle,
		); err != nil {
			panic(fmt.Sprintf("Redis初始化异常:%v", err.Error()))
		}

		switch global.Facer {
		case define.FACER_TYPE_CCHANDLER:
			cli := go_redis.NewClient(&go_redis.Options{
				Addr:     fmt.Sprintf("%v:%v", global.RedisConf.Host, global.RedisConf.Port),
				Password: global.RedisConf.Password,
				PoolSize: 2,
			})
			for {
				_, err := cli.Ping().Result()
				if err == nil {
					break
				} else {
					global.Logger.Error("Redis通道连接异常：%v", err.Error())
				}
				time.Sleep(20 * time.Second)
			}

			for _, term := range global.TerminalList {
				go logic.RedisChannelMonitor(cli, define.M_CACHE_TO_COLLECT_PREFIX+term.IP)
			}

		case define.FACER_TYPE_COLLECT:
			go logic.RedisKeyMonitor(&global.CacheDB, define.REDIS_MQ_DB, define.C_CACHE_MCENTER_RECV_QUEUE, 60)
			go logic.RedisKeyMonitor(&global.CacheDB, define.REDIS_MQ_DB, define.C_CACHE_CCHANDLER_RECV_QUEUE, 60)
		}

		go logic.RedisProxyFromSharedArea()
		go logic.RedisProxyToSharedArea()
	}

	select {}
}
