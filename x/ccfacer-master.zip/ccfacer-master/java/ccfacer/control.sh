#!/bin/bash
WORKSPACE=$(cd $(dirname $0)/; pwd)
cd $WORKSPACE

export LANG=zh_TW.UTF-8
export LC_ALL=zh_TW.UTF-8

JAVA_HOME=/usr/local/jdk1.8.0_181
export JAVA_HOME
PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$PATH
export PATH

APP_NAME=ccfacer-db
GREP_KEY="Diname="${APP_NAME}  
##APP_OPTS="-Xrs -Xms512m -Xmx1024m"
APP_OPTS="-XX:PermSize=256m -XX:MaxPermSize=256m -Xms256m -Xmx512m"
pidfile=/var/run/ccfacer-db.pid

function check_pid() {
    if [ -f $pidfile ];then
        pid=`cat $pidfile`
        if [ -n $pid ]; then
            running=`ps -p $pid|grep -v "PID TTY" |wc -l`
            return $running
        fi
    fi
    return 0
}

function start() {
    check_pid
    running=$?
    if [ $running -gt 0 ];then
        echo -n "$app now is running already, pid="
        cat $pidfile
        return 1
    fi

    if ! [ -f $conf ];then
        echo "Config file $conf doesn't exist."
        return 1
    fi
    nohup $JAVA_HOME/bin/java -${GREP_KEY} ${APP_OPTS} -jar ccfacer-db.jar config/config_pro.properties > /dev/null 2>&1 &  
    echo $! > $pidfile
    echo "$app started..., pid=$!"
}

function stop() {
    pid=`cat $pidfile`
    kill $pid
    echo "$app stoped..."
}

function restart() {
    stop
    sleep 1
    start
}

function status() {
    check_pid
    running=$?
    if [ $running -gt 0 ];then
        echo started
    else
        echo stoped
    fi
}


function help() {
    echo "$0 start|stop|restart|status"
}

if [ "$1" == "" ]; then
    help
elif [ "$1" == "stop" ];then
    stop
elif [ "$1" == "start" ];then
    start
elif [ "$1" == "restart" ];then
    restart
elif [ "$1" == "status" ];then
    status
else
    help
fi
