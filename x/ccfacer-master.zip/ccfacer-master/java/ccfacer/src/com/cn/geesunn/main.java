package com.cn.geesunn;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class main {

	private static Connection mconn = null;
	private static Connection cconn = null;
	private static Logger log = Logger.getLogger(main.class);

	public static void main(String[] args) throws Exception {

		String configPath = "config/config.properties";
		if (args.length > 0) {
			configPath = args[0];
		}
		System.out.println("加载配置文件" + configPath);
		Properties properties = new Properties();
		try {
			InputStream input = new FileInputStream(new File(configPath));
			properties.load(input);
			input.close();
			PropertyConfigurator.configure(properties.getProperty("log4j"));// 装入log4j配置信息
		} catch (IOException e) {
			System.out.println("加载配置文件出错");
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		System.out.println("服务启动成功");
		log.info("服务启动成功");

		String mDirver = properties.getProperty("m_driver");
		String mUrl = properties.getProperty("m_url");
		String mUser = properties.getProperty("m_user");
		String mPass = properties.getProperty("m_password");
		String cDriver = properties.getProperty("c_driver");
		String cUrl = properties.getProperty("c_url");
		String cUser = properties.getProperty("c_user");
		String cPass = properties.getProperty("c_password");

		int duration = 1;
		try {
			duration = Integer.valueOf(properties.getProperty("duration"));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("", e);
		}

		loadMConn(mDirver, mUrl, mUser, mPass);
		loadCConn(cDriver, cUrl, cUser, cPass);

		while (true) {
			log.debug("迁移开始");

			Statement cstat = null;
			Statement mstat = null;
			try {
				cstat = cconn.createStatement();
				mstat = mconn.createStatement();

				Statement cstat2 = cconn.createStatement();
				// C To M
				try {
					ResultSet rs = cstat.executeQuery("SELECT * FROM ccfacer_c2m");
					PreparedStatement ps = mconn.prepareStatement(
							"INSERT INTO ccfacer_c2m(id, filename, content, create_time) value(?, ?, ?, ?)");
					while (rs.next()) {

						int id = rs.getInt("id");
						String filename = rs.getString("filename");
						String content = rs.getString("content");
						Timestamp createTime = rs.getTimestamp("create_time");
						if (log.isDebugEnabled()) {
							log.debug("移动c2m: " + id + "|" + filename + "|" + content + "|" + createTime);
						}

						ps.setInt(1, id);
						ps.setString(2, filename);
						ps.setString(3, content);
						ps.setTimestamp(4, createTime);

						try {
							int effectID = ps.executeUpdate();
							if (effectID > 0) {
								cstat2.executeUpdate("DELETE FROM ccfacer_c2m WHERE id=" + id);
							}
						} catch (Exception e) {
							e.printStackTrace();
							log.error(e.getMessage());
						}
					}
				} catch (Exception ex) {
					ex.printStackTrace();
					log.error(ex.getMessage());
				} finally {
					try {
						cstat2.close();
					} catch (Exception e) {
						e.printStackTrace();
						log.error(e.getMessage());
					}
				}

				Statement mstat2 = mconn.createStatement();
				// M To C
				try {
					ResultSet rs = mstat.executeQuery("SELECT * FROM ccfacer_m2c");
					PreparedStatement ps = cconn.prepareStatement(
							"INSERT INTO ccfacer_m2c(id, filename, content, create_time) value(?, ?, ?, ?)");
					while (rs.next()) {
						int id = rs.getInt("id");
						String filename = rs.getString("filename");
						String content = rs.getString("content");
						Timestamp createTime = rs.getTimestamp("create_time");
						if (log.isDebugEnabled()) {
							log.debug("移动m2c: " + id + "|" + filename + "|" + content + "|" + createTime);
						}
						ps.setInt(1, id);
						ps.setString(2, filename);
						ps.setString(3, content);
						ps.setTimestamp(4, createTime);
						try {
							int effectID = ps.executeUpdate();
							if (effectID > 0) {
								mstat2.executeUpdate("DELETE FROM ccfacer_m2c WHERE id=" + id);
							}
						} catch (Exception e) {
							e.printStackTrace();
							log.error(e.getMessage());
						}
					}
				} catch (Exception ex) {
					ex.printStackTrace();
					log.error(ex.getMessage());
				}

			} catch (Exception e) {
				e.printStackTrace();
				log.error(e.getMessage());

				try {
					loadMConn(mDirver, mUrl, mUser, mPass);
				} catch (Exception ex) {
					e.printStackTrace();
					log.error(ex.getMessage());
				}

				try {
					loadCConn(cDriver, cUrl, cUser, cPass);
				} catch (Exception ex) {
					e.printStackTrace();
					log.error(ex.getMessage());
				}

			} finally {
				if (cstat != null) {
					try {
						cstat.close();
					} catch (Exception e) {
						e.printStackTrace();
						log.error(e.getMessage());
					}
				}
				if (mstat != null) {
					try {
						mstat.close();
					} catch (Exception e) {
						e.printStackTrace();
						log.error(e.getMessage());
					}
				}
			}

			try {
				Thread.sleep(duration);
			} catch (Exception e) {
				e.printStackTrace();
				log.error(e.getMessage());
			}
		}
	}

	public static Connection loadMConn(String driver, String url, String user, String password) throws Exception {

		try {
			if (mconn != null && !mconn.isClosed()) {
				mconn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			mconn = null;
		}

		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url, user, password);
			mconn = conn;
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			throw e;
		}
		return mconn;
	}

	public static Connection loadCConn(String driver, String url, String user, String password) throws Exception {

		try {
			if (cconn != null && !cconn.isClosed()) {
				cconn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			cconn = null;
		}

		try {
			Class.forName(driver);
			Connection conn = DriverManager.getConnection(url, user, password);
			cconn = conn;
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage());
			throw e;
		}
		return cconn;
	}

}
