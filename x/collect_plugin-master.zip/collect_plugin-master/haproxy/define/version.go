package define

const (
	AUTHOR  = "GEESUNN"
	VERSION = "Haproxy V1.8.0"
)
