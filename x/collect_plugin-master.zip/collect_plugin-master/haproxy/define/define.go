package define

type HaproxyInfo struct {
	ID            int64               `json:"id"`
	ServerID      int64               `json:"server_id"`
	MonitorCycle  int64               `json:"monitor_cycle"`
	PoolArr       []map[string]string `json:"pool_arr"`
	ConfigPath    string              `json:"config_path"`
	AppConnect    int64               `json:"app_connect"`
	AppConnectMsg string              `json:"app_connect_msg"`
	Unixtime      int64               `json:"unixtime"`
}
