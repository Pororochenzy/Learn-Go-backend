package logic

import (
	"collect_plugin/haproxy/global"
	"runtime"
)

const LINE_NUM = 32

func PrintTrace() {
	for i := 0; i < LINE_NUM; i++ {
		funcName, file, line, ok := runtime.Caller(i)
		if ok {
			global.Logger.Error("frame %v:[func:%v,file:%v,line:%v]", i, runtime.FuncForPC(funcName).Name(), file, line)
		}
	}
}

func HanderPanic() {
	if r := recover(); r != nil {
		PrintTrace()
	}
}
