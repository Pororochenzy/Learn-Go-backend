package cycle

import (
	"collect_plugin/haproxy/define"
	"collect_plugin/haproxy/global"
	"collect_plugin/haproxy/logic"
	"collect_plugin/haproxy/mq"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"strings"

	gs_define "geesunn.com/define"
	"geesunn.com/gpool"
	gs_tool "geesunn.com/tool"
)

type cache struct {
	ID           int64  `json:"id"`
	ServerID     int64  `json:"server_id"`
	MonitorCycle int64  `json:"monitor_cycle"`
	URL          string `json:"url"`
	User         string `json:"user"`
	Password     string `json:"password"`
	ConfigPath   string `json:"config_path"`
}

func getFromCache(key string) *cache {
	info, err := global.CCacheDB.GetString(gs_define.REDIS_COLLECT_DB, key)
	if err != nil {
		global.Logger.Error("%v %v", key, err.Error())
		return nil
	}

	data := cache{}
	if err := json.Unmarshal([]byte(info), &data); err != nil {
		global.Logger.Error(err.Error())
		return nil
	}

	if len(data.Password) > 0 {
		data.Password = logic.EncryptPassword(data.Password)
	}

	return &data
}

var (
	checkIPPool = gpool.NewGoPool(100)
	runManager  = gs_tool.NewRunManger()
)

// 采集程序
func start() {
	for {
		tqu := <-global.TaskQueue

		checkIPPool.GetGo()

		key := tqu.Data["key"].(string)

		go func(tqu gs_define.TaskQueueUnit) {
			defer logic.HanderPanic()
			defer checkIPPool.ReleaseGo()

			switch tqu.Type {
			case gs_define.COLLECT_TYPE_CYCLE:
				data := getFromCache(key)
				if data != nil {
					global.Logger.Info("%v %v", key, data.MonitorCycle)
					SetCycleKeyExpire(gs_define.REDIS_COLLECT_DB, key, int(data.MonitorCycle))

					if runManager.IsRunning(key) {
						return
					}

					m := getInfo(data, key)
					global.Logger.Debug("%+v", m)

					dataBytes, _ := json.Marshal(m)

					if err := mq.Push2Collect(gs_define.MQMsg{
						MQType:   gs_define.MQ_TYPE_HAPROXY_COLLECT,
						UUID:     gs_tool.NewUUID(),
						From:     "haproxy",
						To:       gs_define.M_CACHE_CCHANDLER_RECV_QUEUE,
						Unixtime: gs_tool.CurrentTimeSecond(),
						Data:     string(dataBytes),
					}); err != nil {
						global.Logger.Error(err.Error())
					}
				} else {
					global.CCacheDB.DELKey(gs_define.REDIS_COLLECT_DB, "cycle:"+key)
				}
			case gs_define.COLLECT_TYPE_INSPECT:
			}
		}(tqu)
	}
}

func getInfo(data *cache, key string) define.HaproxyInfo {
	defer runManager.Clear(key)
	runManager.Set(key)

	m := define.HaproxyInfo{
		ID:           data.ID,
		ServerID:     data.ServerID,
		MonitorCycle: data.MonitorCycle,
		Unixtime:     gs_tool.CurrentTimeSecond(),
		PoolArr:      []map[string]string{},
		ConfigPath:   data.ConfigPath,
	}

	data.URL = data.URL + ";csv"

	req, _ := http.NewRequest("GET", data.URL, nil)

	auth := "Basic " + gs_tool.Base64Encode(data.User+":"+data.Password)
	req.Header.Add("Authorization", auth)
	resp, _ := global.HttpClient.Do(req)
	if resp == nil {
		m.AppConnectMsg = "请检查Haproxy状态页可访问且配置正确!"
		return m
	}
	if resp != nil {
		defer resp.Body.Close()
	}

	if resp.StatusCode/100 != 2 {
		m.AppConnect = 0
		m.AppConnectMsg = "http不通"
		return m
	}

	m.AppConnect = 1

	bytes, _ := ioutil.ReadAll(resp.Body)
	info := string(bytes)
	global.Logger.Info(info)

	info = strings.TrimSpace(info)
	lines := strings.Split(info, "\n")
	arr := []map[string]string{}
	items := []string{}

	if len(lines) > 0 {
		items = strings.Split(strings.Trim(lines[0], "# "), ",")
		if len(items) == 0 || items[0] != "pxname" {
			m.AppConnect = 0
			m.AppConnectMsg = "采集Haproxy状态页内容异常，请检查页面地址是否填写正确！"
			return m
		}
	} else {
		m.AppConnect = 0
		m.AppConnectMsg = "采集Haproxy状态页内容异常，请检查页面地址是否填写正确！"
		return m
	}

	for i := 1; i < len(lines); i++ {
		ts := strings.Split(lines[i], ",")
		if len(ts) < 7 {
			continue
		}

		pool := map[string]string{}
		for j, item := range items {
			pool[item] = ts[j]
		}
		arr = append(arr, pool)
	}

	m.PoolArr = arr
	return m
}
