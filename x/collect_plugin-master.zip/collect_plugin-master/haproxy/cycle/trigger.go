package cycle

import (
	"collect_plugin/haproxy/global"
	"collect_plugin/haproxy/logic"
	"time"

	gs_define "geesunn.com/define"
)

// 缓存设置过期时间
func SetCycleKeyExpire(db int, key string, monitor_cycle int) {
	key = "cycle:" + key
	global.CCacheDB.SET(db, key, 1)
	global.CCacheDB.SetExpire(db, key, monitor_cycle)
}

// 需要执行的任务
func CycleTask() []string {
	start := time.Now()
	defer func(start time.Time) {
		use := time.Since(start)
		if use > time.Millisecond*500 {
			global.Logger.Info("cycle task 耗时:%v", use)
		}
	}(start)

	taskKeys := []string{}
	// 需要检测对象
	{
		keys, _ := global.CCacheDB.RegularKeys(gs_define.REDIS_COLLECT_DB, "collect:haproxy:*")
		for _, key := range keys {
			exist, err := global.CCacheDB.IsKeyExist(gs_define.REDIS_COLLECT_DB, "cycle:"+key)
			if exist == 0 && err == nil {
				taskKeys = append(taskKeys, key)
			}
		}
	}

	return taskKeys
}

// 防止短期内重复采集
func PrevCycleAgain(key string) {
	// 先设置一个60分钟,运行的时候会重新设置过期时间
	SetCycleKeyExpire(gs_define.REDIS_COLLECT_DB, key, 3600)
}

// 采集触发器
// 检查是否监控指标是否需要进行采集了
func CollectTrigger() {
	defer logic.HanderPanic()
	global.CCacheDB.DelRegularKeys(gs_define.REDIS_COLLECT_DB, "cycle:collect:haproxy:*")
	for {
		func() {
			defer logic.HanderPanic()
			// 检查需要采集的内容
			keys := CycleTask()
			if len(keys) > 0 {
				global.Logger.Info("Redis拉取到即将采集的指标：%v", keys)
				for _, key := range keys {
					if len(global.TaskQueue) < cap(global.TaskQueue) {
						PrevCycleAgain(key)
						global.TaskQueue <- gs_define.TaskQueueUnit{
							Type: gs_define.COLLECT_TYPE_CYCLE,
							Data: map[string]interface{}{"key": key},
						}
					}
				}
			}
		}()
		time.Sleep(time.Second * 2)
	}
}

func StartCollect() {
	go start()
	go CollectTrigger()
}
