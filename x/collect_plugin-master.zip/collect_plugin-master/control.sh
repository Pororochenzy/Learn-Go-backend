#!/bin/bash

WORKSPACE=$(cd $(dirname $0)/; pwd)
cd $WORKSPACE

function start() {
    for file in */; do 
        if [ -x $file/control.sh ]; then
            file=${file%?}
            echo $file: `$file/control.sh start`
        fi
    done
}

function stop() {
    for file in */; do 
        if [ -x $file/control.sh ]; then
            file=${file%?}
            echo $file: `$file/control.sh stop`
        fi
    done
}

function restart() {
    for file in */; do 
        if [ -x $file/control.sh ]; then
            file=${file%?}
            echo $file: `$file/control.sh restart`
        fi
    done
}

function status() {
    for file in */; do 
        if [ -x $file/control.sh ]; then
            file=${file%?}
            echo $file: `$file/control.sh status`
        fi
    done
}


function help() {
    echo "$0 start|stop|restart|status"
}

if [ "$1" == "" ]; then
    help
elif [ "$1" == "stop" ];then
    stop
elif [ "$1" == "start" ];then
    start
elif [ "$1" == "restart" ];then
    restart
elif [ "$1" == "status" ];then
    status
else
    help
fi