package logic

import (
	"collect_plugin/blade/global"
	"encoding/json"

	gs_define "geesunn.com/define"
)

// GetVoucher 获取凭证信息
func GetVoucher(vouchers []map[string]interface{}, voucherType string) *gs_define.Voucher {

	for _, m := range vouchers {
		if m["voucher_type"].(string) == voucherType {
			voucher := &gs_define.Voucher{}
			if err := json.Unmarshal([]byte(m["voucher_content"].(string)), voucher); err != nil {
				global.Logger.Error(err.Error())
				return nil
			}
			return voucher
		}
	}
	return nil
}
