package logic

import (
	"collect_plugin/blade/global"
	"errors"
	"strconv"
	"strings"

	gs_ssh "geesunn.com/ssh"
)

// InitSSHClient 初始化SSH连接
func InitSSHClient(host, port, username, password, privateKey string, timeouts ...int) (*gs_ssh.SSHClient, error) {
	authMode := gs_ssh.SSHAuthMode_PASSWORD
	authPass := password
	if privateKey != "" {
		authMode = gs_ssh.SSHAuthMode_PRIVATE_KEY
		authPass = privateKey
	}

	if authPass == "" {
		return nil, errors.New("SSH密码和私钥不能同时为空")
	}

	timeout := 3
	if len(timeouts) > 0 {
		timeout = timeouts[0]
	}

	authPort, _ := strconv.ParseInt(port, 10, 64)
	auth := gs_ssh.SSHAuth{
		Host:     host,
		Port:     authPort,
		UserName: username,
		AuthMode: authMode,
		AuthPass: authPass,
		Timeout:  timeout,
	}

	client, err := gs_ssh.InitClient(auth)
	if err != nil {
		errMsg := err.Error()
		global.Logger.Error("SSH连接异常: [%v %v %v %v %v] %v", host, port, username, password, privateKey, errMsg)
		if errMsg == "ssh privatekey is error" {
			err = errors.New("私钥错误")
		} else if strings.Contains(errMsg, "handshake failed") {
			if authMode == gs_ssh.SSHAuthMode_PRIVATE_KEY {
				err = errors.New("用户名或私钥错误")
			} else {
				err = errors.New("用户名或密码错误")
			}
		} else {
			err = errors.New("IP或端口不通")
		}
	}
	return client, err
}
