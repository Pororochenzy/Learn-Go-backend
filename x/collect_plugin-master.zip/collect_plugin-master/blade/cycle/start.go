package cycle

import (
	"collect_plugin/blade/define"
	"collect_plugin/blade/global"
	"collect_plugin/blade/logic"
	"collect_plugin/blade/mq"
	"encoding/json"
	"fmt"

	"geesunn.com/gpool"

	gs_define "geesunn.com/define"
	gs_tool "geesunn.com/tool"
)

func getFromCache(key string) *define.Cache {
	info, err := global.CCacheDB.GetString(gs_define.REDIS_COLLECT_DB, key)
	if err != nil {
		global.Logger.Error("%v %v", key, err.Error())
		return nil
	}

	data := define.Cache{}
	if err := json.Unmarshal([]byte(info), &data); err != nil {
		global.Logger.Error(err.Error())
		return nil
	}
	return &data
}

// 采集程序
func start() {

	checkIPPool := gpool.NewGoPool(100)
	running := gs_tool.NewRunManger()

	for {
		tqu := <-global.TaskQueue

		checkIPPool.GetGo()

		key := ""
		if v, ok := tqu.Data["key"].(string); ok {
			key = v
		} else if id, ok := tqu.Data["object_id"]; ok {
			key = fmt.Sprintf("collect:blade:%v", id)
		} else {
			global.Logger.Warn("数据异常: %v", tqu)
			continue
		}

		go func(tqu gs_define.TaskQueueUnit) {

			defer logic.HanderPanic("刀片机操作异常退出！")
			// 释放协程
			defer checkIPPool.ReleaseGo()

			switch tqu.Type {
			case gs_define.COLLECT_TYPE_CYCLE:
				if running.IsRunning(key) {
					SetCycleKeyExpire(gs_define.REDIS_COLLECT_DB, key, 60) // 正在运行，60s再试
					return
				}
				running.Set(key)
				defer running.Clear(key)
				// 采集
				triggerCollect(key)
			case gs_define.COLLECT_TYPE_INSPECT:
			case gs_define.COLLECT_TYPE_POWER:

				toCollect(tqu, power(key, tqu.Data["power"].(string), tqu.Data["slot"].(int64)))
			}
		}(tqu)
	}
}

func toCollect(tqu gs_define.TaskQueueUnit, data interface{}) {

	bytes, _ := json.Marshal(data)
	if err := mq.Push2Collect(gs_define.MQMsg{
		MQType:   gs_define.C_CACHE_TO_BLADE,
		UUID:     tqu.Data["uuid"].(string),
		From:     "blade",
		To:       tqu.Data["back_to"].(string),
		Unixtime: gs_tool.CurrentTimeSecond(),
		Data:     string(bytes),
	}); err != nil {
		global.Logger.Error(err.Error())
	}
}
