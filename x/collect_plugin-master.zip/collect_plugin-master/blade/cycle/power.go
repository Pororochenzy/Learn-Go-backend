package cycle

import (
	"collect_plugin/blade/client"
	"collect_plugin/blade/define"
	"collect_plugin/blade/global"
	"collect_plugin/blade/logic"
	"strings"
)

type Response struct {
	Ret int64  `json:"ret"`
	Msg string `json:"msg"`
}

func power(key string, control string, slot int64) Response {

	defer logic.HanderPanic("电源操作异常退出！！！")

	if slot <= 0 {
		global.Logger.Warn("数据异常: %v", slot)
		return Response{
			Ret: define.RET_FAILED,
			Msg: "操作失败，刀片不存在",
		}
	}

	data := getFromCache(key)
	if data == nil {
		data = getFromCache(strings.Replace(key, "blade", "blade_box", 1))
		if data == nil {
			global.Logger.Warn("数据异常: %v", data)
			return Response{
				Ret: define.RET_FAILED,
				Msg: "操作失败，刀箱不存在",
			}
		}
	}

	c, err := client.InitClient(data)
	if err != nil {
		global.Logger.Error("初始化连接异常: %v %v", data.IP, err.Error())
		return Response{
			Ret: define.RET_FAILED,
			Msg: err.Error(),
		}
	}
	defer c.Close()

	switch control {
	case "on":
		err = c.PowerOn(slot)
	case "off":
		err = c.PowerOff(slot)
	case "reset":
		err = c.PowerReset(slot)
	default:
		return Response{
			Ret: define.RET_FAILED,
			Msg: "暂不支持该操作",
		}
	}

	if err != nil {
		global.Logger.Error("开关机操作失败: %v %v", data, err.Error())
		return Response{
			Ret: define.RET_FAILED,
			Msg: err.Error(),
		}
	}

	return Response{
		Ret: define.RET_SUCCESS,
		Msg: define.RET_SUCCESS_MSG,
	}
}
