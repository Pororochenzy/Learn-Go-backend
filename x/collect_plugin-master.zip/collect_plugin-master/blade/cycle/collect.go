package cycle

import (
	"collect_plugin/blade/client"
	"collect_plugin/blade/define"
	"collect_plugin/blade/global"
	"collect_plugin/blade/logic"
	"collect_plugin/blade/mq"
	"encoding/json"

	gs_define "geesunn.com/define"
	gs_tool "geesunn.com/tool"
)

func triggerCollect(key string) {

	defer logic.HanderPanic("刀片机采集异常退出！")

	data := getFromCache(key)
	if data == nil {
		global.CCacheDB.DELKey(gs_define.REDIS_COLLECT_DB, "cycle:"+key)
		return
	}
	defer SetCycleKeyExpire(gs_define.REDIS_COLLECT_DB, key, int(data.MonitorCycle))
	global.Logger.Info("%v %v", data.IP, data.MonitorCycle)

	m := collect(data)
	dataBytes, _ := json.Marshal(m)
	global.Logger.Debug("返回数据: %v", string(dataBytes))
	if err := mq.Push2Collect(gs_define.MQMsg{
		MQType:   gs_define.MQ_TYPE_BLADE_BOX_COLLECT,
		UUID:     gs_tool.NewUUID(),
		From:     "blade",
		To:       gs_define.M_CACHE_CCHANDLER_RECV_QUEUE,
		Unixtime: gs_tool.CurrentTimeSecond(),
		Data:     string(dataBytes),
	}); err != nil {
		global.Logger.Error(err.Error())
	}
}

func collect(data *define.Cache) gs_define.Box {

	defer logic.HanderPanic("刀片机采集异常退出！")

	box := gs_define.Box{
		ID:           data.ID,
		IP:           data.IP,
		Unixtime:     gs_tool.CurrentTimeSecond(),
		Connected:    "1",
		Msg:          "暂不支持采集",
		MonitorCycle: data.MonitorCycle,
	}

	c, err := client.InitClient(data)
	if err != nil {
		global.Logger.Error("初始化连接异常: %v %v", data.IP, err.Error())
		box.Msg = err.Error()
		return box
	}
	defer c.Close()

	box.BaseInfo, _ = c.GetBaseInfo()
	box.Blades, _ = c.GetBlades()
	box.Modules, _ = c.GetModules()
	box.Fans, _ = c.GetFans()
	box.Powers, _ = c.GetPowers()
	box.Cmcs, _ = c.GetCmcs()
	box.Kvms, _ = c.GetKvm()
	box.Source = c.GetSource()

	c.SpecialHandler(&box)

	box.Connected = "0"
	box.Msg = "Success"

	return box
}
