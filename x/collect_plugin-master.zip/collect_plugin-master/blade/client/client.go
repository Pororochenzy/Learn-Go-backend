package client

import (
	"collect_plugin/blade/define"
	"collect_plugin/blade/global"
	"errors"

	gs_define "geesunn.com/define"
)

type Client interface {
	GetSource() string
	GetBaseInfo() (*gs_define.BaseInfo, error)
	GetBlades() ([]gs_define.Blade, error)
	GetModules() ([]gs_define.Module, error)
	GetCmcs() ([]gs_define.CMC, error)
	GetFans() ([]gs_define.Fan, error)
	GetPowers() ([]gs_define.BladePower, error)
	GetKvm() ([]gs_define.KVM, error)
	SpecialHandler(box *gs_define.Box)
	Close() error
	PowerOn(slot int64) error
	PowerOff(slot int64) error
	PowerReset(slot int64) error
}

func RegistClient(model string, f func(data *define.Cache) (Client, error)) {
	clients[model] = f
}

var clients = map[string]func(data *define.Cache) (Client, error){}

func InitClient(data *define.Cache) (Client, error) {

	global.Logger.Debug("%v", data)
	if f, ok := clients[data.Model]; ok {
		return f(data)
	}

	return nil, errors.New("暂不支持该型号")
}
