# blade

# auth hsfish

# 发行版本
1. v1.0.0 
    支持华为Tecal E6000
2. v1.0.1
    支持惠普C7000