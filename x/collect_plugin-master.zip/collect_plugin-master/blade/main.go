package main

import (
	_ "collect_plugin/blade/brand/dell"
	_ "collect_plugin/blade/brand/hp"
	_ "collect_plugin/blade/brand/huawei"
	"collect_plugin/blade/cycle"
	"collect_plugin/blade/define"
	"collect_plugin/blade/global"
	"collect_plugin/blade/logic"
	"collect_plugin/blade/mq"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"
)

func ReleaseLimit() {
	var rlimit, zero syscall.Rlimit
	err := syscall.Getrlimit(syscall.RLIMIT_NOFILE, &rlimit)
	if err != nil {
		panic(err)
	}
	if zero == rlimit {
		panic(fmt.Sprintf("Getrlimit: save failed: got zero value %#v", rlimit))
	}
	if rlimit.Max < 1024 {
		panic("Max fd is less than 1024, please check your system setting")
	}
	set := rlimit
	set.Cur = set.Max - 1
	err = syscall.Setrlimit(syscall.RLIMIT_NOFILE, &set)
	if err != nil {
		panic(err)
	}
	syscall.Getrlimit(syscall.RLIMIT_NOFILE, &rlimit)
	fmt.Println(rlimit.Cur)
}

func main() {

	defer logic.HanderPanic("采集服务退出！")

	fmt.Println("Hello! I'm Blade, Happy your time !!!")

	ReleaseLimit()

	// 接收自定义配置路径
	configPath := flag.String("c", "blade/config", "configuration file")

	flag.Parse()

	// 初始化系统
	global.InitSystem(*configPath)
	defer global.Close()

	// 初始化MQ，处理MQ请求数据
	go mq.InitMQ()

	go cycle.StartCollect()

	global.Logger.Info(fmt.Sprintf("\nAuthor: %v \nVersion: %v \nSuccessful !!! ", define.Author, define.Version))

	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)

	<-sigs
	global.Logger.Info("exit")
	os.Exit(0)

}
