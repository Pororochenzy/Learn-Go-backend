package huawei

import (
	"collect_plugin/blade/client"
	"collect_plugin/blade/define"
	"collect_plugin/blade/global"
	"collect_plugin/blade/logic"
	"errors"
	"fmt"
	"regexp"
	"strconv"
	"strings"

	gs_define "geesunn.com/define"
	gs_ssh "geesunn.com/ssh"
)

func init() {
	client.RegistClient("E6000", InitClient)
}

// InitClient 初始化
func InitClient(data *define.Cache) (client.Client, error) {

	voucher := logic.GetVoucher(data.Vouchers, gs_define.VOUCHER_TYPE_SSH)
	if voucher == nil {
		return nil, errors.New("凭证不存在")
	}

	client, err := logic.InitSSHClient(data.IP, fmt.Sprintf("%v", voucher.SSHPort), voucher.SSHUser, voucher.SSHPassword, "", 5)
	if err != nil {
		global.Logger.Error("SSH连接异常:%v %v", data.IP, err.Error())
		return nil, err
	}

	return &E6000{
		voucherType: gs_define.VOUCHER_TYPE_SSH,
		ip:          data.IP,
		client:      client,
	}, nil
}

// E6000 tecal e6000
type E6000 struct {
	voucherType string
	ip          string
	client      *gs_ssh.SSHClient
}

func (p *E6000) GetSource() string {
	return p.voucherType
}

// Close 关闭
func (p *E6000) Close() error {
	return p.client.Close()
}

func (p *E6000) run(cmd string) (string, error) {
	cmd = fmt.Sprintf("/smm/%v", cmd)
	bytes, err := p.client.Run(cmd)
	if err != nil {
		global.Logger.Error("%v %v \n %v", p.ip, cmd, err)
	}
	global.Logger.Debug("%v %v \n %v", p.ip, cmd, string(bytes))
	return string(bytes), err
}

// GetBaseInfo 获取基本信息
func (p *E6000) GetBaseInfo() (*gs_define.BaseInfo, error) {

	hostname, err := p.client.Run("hostname")
	if err != nil {
		global.Logger.Error("%v %v %v", p.ip, "hostname", err.Error())
	}
	return &gs_define.BaseInfo{
		Hostname: strings.Trim(string(hostname), "\n"),
	}, nil
}

// GetBlades 获取刀片信息
func (p *E6000) GetBlades() ([]gs_define.Blade, error) {

	getItems := func(slot int64) []gs_define.Item {
		items := []gs_define.Item{}

		for _, sensorName := range []string{
			"CPU1 Core Rem",
			"CPU1 Prochot",
			"CPU2 Core Rem",
			"CPU2 Prochot",
		} {
			lines, err := p.run(fmt.Sprintf("smmget -l blade%v -t %v -d current", slot, sensorName))
			if err != nil {
				global.Logger.Error("%v %v", p.ip, err.Error())
				continue
			}

			strs := regexp.MustCompile("\\d+(.\\d+)( )*Celsius").FindAllString(lines, 1)
			if len(strs) > 0 {
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_SENSOR,
					Name:   sensorName,
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.Replace(strs[0], "Celsius", "℃", 1),
					Units:  "℃",
				})
			}
		}

		return items
	}

	getBladeInfo := func(slot int64) gs_define.Blade {

		blade := gs_define.Blade{
			MasterSlot: gs_define.Slot{
				Slot: slot,
			},
			Present: gs_define.PRESENT_EXIST,
		}
		// 电源状态
		{
			line, err := p.run(fmt.Sprintf("smmget -l blade%v -t Power -d current", slot))
			if err != nil {
				global.Logger.Error("%v %v", p.ip, err.Error())
			} else {
				strs := regexp.MustCompile("\\d+(.\\d+)( )+Watts").FindAllString(line, 1)
				if len(strs) > 0 {
					blade.PowerStatus = gs_define.POWER_STATUS_ON
					blade.Items = []gs_define.Item{
						gs_define.Item{
							NameEN: gs_define.FIELD_INPUT_POWER,
							Name:   define.FieldToName[gs_define.FIELD_INPUT_POWER],
							OsType: gs_define.OSTYPE_STRING,
							Value:  strings.Replace(strs[0], "Watts", "W", -1),
							Units:  "W",
						},
					}
				} else {
					blade.PowerStatus = gs_define.POWER_STATUS_OFF
					blade.Items = []gs_define.Item{
						gs_define.Item{
							NameEN: gs_define.FIELD_INPUT_POWER,
							Name:   define.FieldToName[gs_define.FIELD_INPUT_POWER],
							OsType: gs_define.OSTYPE_STRING,
							Value:  "0.0 W",
							Units:  "W",
						},
					}
				}
			}
		}
		// 健康状态
		{
			lines, err := p.run(fmt.Sprintf("smmget -l blade%v -d health", slot))
			if err != nil {
				global.Logger.Error("%v %v", p.ip, err.Error())
			} else {
				if strings.Contains(lines, "has no problem") {
					blade.Health = "OK"
				} else {
					blade.Health = "NOT OK"
				}
			}
		}
		// ipmi ip
		{
			lines, err := p.run(fmt.Sprintf("smmget -l blade%v -d ipinfo", slot))
			if err != nil {
				global.Logger.Error("%v %v", p.ip, err.Error())
			} else {
				net := gs_define.Net{}
				for _, line := range strings.Split(lines, "\n") {
					if net.IP == "" {
						if v := parseLine(line, ":", "ip address"); v != "" {
							net.IP = v
							continue
						}
					}
					if net.SubnetMask != "" {
						if v := parseLine(line, ":", "gateway"); v != "" {
							net.SubnetMask = v
							continue
						}
					}
				}
				blade.Net = net
			}
		}
		// 基本信息
		{
			lines, err := p.run(fmt.Sprintf("smmget -l blade%v -t fru -d all", slot))
			if err != nil {
				global.Logger.Error("%v %v", p.ip, err.Error())
			} else {
				boardSN := ""
				desc := ""
				for _, line := range strings.Split(lines, "\n") {

					if boardSN == "" {
						if v := parseLine(line, ":", "board serial number"); v != "" {
							boardSN = v
							continue
						}
					}
					if desc == "" {
						if v := parseLine(line, ":", "description"); v != "" {
							desc = v
							continue
						}
					}
					if blade.SN == "" {
						if v := parseLine(line, ":", "product serial number"); v != "" {
							blade.SN = v
							continue
						}
					}
					if blade.Model == "" {
						if v := parseLine(line, ":", "product model"); v != "" {
							blade.Model = v
							continue
						}
					}
				}
				if blade.SN == "" {
					blade.SN = boardSN
				}
				if blade.Model == "" {
					blade.Model = desc
				}
			}
		}

		blade.Items = getItems(slot)
		return blade
	}

	blades := []gs_define.Blade{}
	for slot := int64(1); slot <= 10; slot++ {
		lines, err := p.run(fmt.Sprintf("smmget -l blade%v -d presence", slot))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}
		if strings.Contains(lines, "is present") {
			blades = append(blades, getBladeInfo(slot))
		} else {
			blades = append(blades, gs_define.Blade{
				MasterSlot: gs_define.Slot{
					Slot: slot,
				},
				Present: gs_define.PRESENT_NOT_EXIST,
			})
		}
	}

	return blades, nil
}

// GetModules 获取模块信息
func (p *E6000) GetModules() ([]gs_define.Module, error) {

	getModuleInfo := func(arg string) gs_define.Module {
		module := gs_define.Module{
			Present: gs_define.PRESENT_EXIST,
		}
		// 健康状态
		{
			lines, err := p.run(fmt.Sprintf("smmget -l NEM%v -d health", arg))
			if err != nil {
				global.Logger.Error("%v %v", p.ip, err.Error())
			} else {
				if strings.Contains(lines, "has no problem") {
					module.Health = "OK"
				} else {
					module.Health = "NOT OK"
				}
			}
		}
		// 基本信息
		{
			lines, err := p.run(fmt.Sprintf("smmget -l NEM%v -t fru -d all", arg))
			if err != nil {
				global.Logger.Error("%v %v", p.ip, err.Error())
			} else {
				boardSN := ""
				desc := ""
				for _, line := range strings.Split(lines, "\n") {

					if boardSN == "" {
						if v := parseLine(line, ":", "board serial number"); v != "" {
							boardSN = v
							continue
						}
					}
					if desc == "" {
						if v := parseLine(line, ":", "description"); v != "" {
							desc = v
							continue
						}
					}
					if module.SN == "" {
						if v := parseLine(line, ":", "product serial number"); v != "" {
							module.SN = v
							continue
						}
					}
					if module.Model == "" {
						if v := parseLine(line, ":", "product model"); v != "" {
							module.Model = v
							continue
						}
					}
				}
				if module.SN == "" {
					module.SN = boardSN
				}
				if module.Model == "" {
					module.Model = desc
				}
			}
		}
		return module
	}

	modules := []gs_define.Module{}
	for slotName, slot := range map[string]int64{
		"A1": 1,
		"A2": 2,
		"B1": 3,
		"B2": 4,
		"C1": 5,
		"C2": 6,
	} {
		lines, err := p.run(fmt.Sprintf("smmget -l NEM%v -d presence", slotName))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}

		if strings.Contains(lines, "is present") {
			module := getModuleInfo(slotName)
			module.Slot = gs_define.Slot{
				Slot: slot,
				Name: slotName,
			}
			module.PowerStatus = gs_define.POWER_STATUS_ON
			modules = append(modules, module)
		} else {
			modules = append(modules, gs_define.Module{
				Slot: gs_define.Slot{
					Slot: slot,
					Name: slotName,
				},
				PowerStatus: gs_define.POWER_STATUS_OFF,
				Present:     gs_define.PRESENT_NOT_EXIST,
			})
		}
	}
	return modules, nil
}

// GetCmcs 获取CMC 信息
func (p *E6000) GetCmcs() ([]gs_define.CMC, error) {

	cmcs := []gs_define.CMC{}
	// 是否存在
	{
		lines, err := p.run("smmget -d redundancy")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			return nil, err
		}
		for index, line := range getMatchLines(lines, "SMM\\d") {
			lineSlow := strings.ToLower(line)
			if strings.Contains(lineSlow, "not present") {
				cmcs = append(cmcs, gs_define.CMC{
					Name:        fmt.Sprintf("SMM%v", index+1),
					Slot:        int64(index + 1),
					Present:     gs_define.PRESENT_NOT_EXIST,
					PowerStatus: gs_define.POWER_STATUS_OFF,
				})
				continue
			}

			cmc := gs_define.CMC{
				Name:        fmt.Sprintf("SMM%v", index+1),
				Slot:        int64(index + 1),
				Present:     gs_define.PRESENT_EXIST,
				PowerStatus: gs_define.POWER_STATUS_ON,
			}

			if strings.Contains(lineSlow, "active") {
				cmc.Items = []gs_define.Item{
					gs_define.Item{
						NameEN: gs_define.FIELD_SHOW,
						Name:   "角色",
						OsType: gs_define.OSTYPE_STRING,
						Value:  "主用",
					},
				}
			} else {
				cmc.Items = []gs_define.Item{
					gs_define.Item{
						NameEN: gs_define.FIELD_SHOW,
						Name:   "角色",
						OsType: gs_define.OSTYPE_STRING,
						Value:  "备用",
					},
				}
			}
			cmcs = append(cmcs, cmc)
		}
	}

	// items
	{
		items := []gs_define.Item{}
		lines, err := p.run("smmget -d version")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
		} else {
			m := map[string]string{
				"Uboot":    "Uboot Version",
				"Kernel":   "Kernel Version",
				"FPGA":     "FPGA Version",
				"Software": "Software Version",
			}
			for _, line := range strings.Split(lines, "\n") {
				for match, name := range m {
					if v := parseLine(line, ":", match); v != "" {
						items = append(items, gs_define.Item{
							NameEN: gs_define.FIELD_SHOW,
							Name:   name,
							OsType: gs_define.OSTYPE_STRING,
							Value:  v,
						})
						delete(m, match)
						break
					}
				}
			}
		}

		if len(items) > 0 {
			for index := range cmcs {
				if cmcs[index].Present == gs_define.PRESENT_EXIST {
					cmcs[index].Items = append(cmcs[index].Items, items...)
				}
			}
		}
	}

	return cmcs, nil
}

// GetFans 风扇信息
func (p *E6000) GetFans() ([]gs_define.Fan, error) {

	fans := []gs_define.Fan{}

	// 是否存在
	{
		lines, err := p.run("smmget -l Fan -d presence")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			return nil, err
		}
		for index, line := range getMatchLines(lines, "Fan\\d") {

			name := getName(line, "Fan\\d")
			if strings.Contains(line, "is present") {
				fans = append(fans, gs_define.Fan{
					Name:        name,
					Slot:        int64(index + 1),
					Present:     gs_define.PRESENT_EXIST,
					PowerStatus: gs_define.POWER_STATUS_ON,
					Health:      "OK",
					Status:      "OK",
					Items:       []gs_define.Item{},
				})
			} else {
				fans = append(fans, gs_define.Fan{
					Name:    name,
					Slot:    int64(index + 1),
					Present: gs_define.PRESENT_NOT_EXIST,
					Items:   []gs_define.Item{},
				})
			}
		}
	}
	// 健康状态
	{
		lines, err := p.run("smmget -l Fan -d health")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
		}
		if !strings.Contains(lines, "has no problem") {
			for index := range fans {
				fans[index].Health = "NOT OK"
				fans[index].Status = "NOT OK"
			}
		}
	}
	// 运行速率
	{
		lines, err := p.run("smmget -l fan -d fanlevel")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
		}
		for index, line := range getMatchLines(lines, "(Fan\\d|fan\\d)") {
			if fans[index].Present != gs_define.PRESENT_EXIST {
				continue
			}
			strs := regexp.MustCompile("(\\d+%)").FindAllString(line, -1)
			if len(strs) > 0 {
				fans[index].Items = append(fans[index].Items, gs_define.Item{
					NameEN: gs_define.FIELD_SPEED_RATE,
					Name:   define.FieldToName[gs_define.FIELD_SPEED_RATE],
					OsType: gs_define.OSTYPE_STRING,
					Value:  strs[0],
					Units:  "%",
				})
			}
		}
	}
	// 转速
	{
		for index, fan := range fans {

			if fan.Present == gs_define.PRESENT_NOT_EXIST {
				continue
			}

			items := fan.Items
			{
				lines, err := p.run(fmt.Sprintf("smmget -l fan  -t Fan%v F Speed -d current", fan.Slot))
				if err != nil {
					global.Logger.Error("%v %v", p.ip, err.Error())
				} else {
					strs := regexp.MustCompile("\\d+(.\\d+)( )+RPM").FindAllString(lines, -1)
					if len(strs) > 0 {
						items = append(items, gs_define.Item{
							NameEN: gs_define.FIELD_SPEED,
							Name:   "前风扇",
							OsType: gs_define.OSTYPE_STRING,
							Value:  strs[0],
							Units:  "RPM",
						})
					}
				}
			}
			{
				lines, err := p.run(fmt.Sprintf("smmget -l fan  -t Fan%v R Speed -d current", fan.Slot))
				if err != nil {
					global.Logger.Error("%v %v", p.ip, err.Error())
				} else {
					strs := regexp.MustCompile("\\d+(.\\d+)( )+RPM").FindAllString(lines, -1)
					if len(strs) > 0 {
						items = append(items, gs_define.Item{
							NameEN: gs_define.FIELD_BACK_SPEED,
							Name:   "后风扇",
							OsType: gs_define.OSTYPE_STRING,
							Value:  strs[0],
							Units:  "RPM",
						})
					}
				}

			}
			fans[index].Items = items
		}
	}

	return fans, nil
}

// GetPowers 电源
func (p *E6000) GetPowers() ([]gs_define.BladePower, error) {

	powers := []gs_define.BladePower{}
	// 是否存在
	{
		lines, err := p.run("smmget -l PS -d presence")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			return nil, err
		}
		for index, line := range getMatchLines(lines, "PS\\d") {
			name := getName(line, "PS\\d")
			if strings.Contains(line, "is present") {
				powers = append(powers, gs_define.BladePower{
					Slot:        int64(index + 1),
					Name:        name,
					Present:     gs_define.PRESENT_EXIST,
					PowerStatus: gs_define.POWER_STATUS_ON,
					Health:      "OK",
					Items:       []gs_define.Item{},
				})
			} else {
				powers = append(powers, gs_define.BladePower{
					Slot:    int64(index + 1),
					Name:    name,
					Present: gs_define.PRESENT_NOT_EXIST,
				})
			}
		}
	}
	// 健康状态
	{
		lines, err := p.run("smmget -l PS -d health")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
		}
		if !strings.Contains(lines, "has no problem") {
			for index := range powers {
				powers[index].Health = "NOT OK"
			}
		}
	}
	// 功率
	{
		lines, err := p.run("smmget -l PS -d power")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
		}
		for index, line := range getMatchLines(lines, "PS\\d") {

			if powers[index].Present != gs_define.PRESENT_EXIST {
				continue
			}

			watts := regexp.MustCompile("\\d+(.\\d+)( )+Watts").FindAllString(line, 1)
			if len(watts) > 0 {
				powers[index].Items = []gs_define.Item{
					gs_define.Item{
						NameEN: gs_define.FIELD_INPUT_POWER,
						Name:   define.FieldToName[gs_define.FIELD_INPUT_POWER],
						OsType: gs_define.OSTYPE_STRING,
						Value:  strings.Replace(watts[0], "Watts", "W", -1),
						Units:  "W",
					},
				}
			} else {
				powers[index].PowerStatus = gs_define.POWER_STATUS_OFF
			}
		}
	}
	return powers, nil
}

// GetKvm 获取KVM信息
func (p *E6000) GetKvm() ([]gs_define.KVM, error) {
	return []gs_define.KVM{}, nil
}

// PowerOn 开机
func (p *E6000) PowerOn(slot int64) error {

	cmd := fmt.Sprintf("echo y | /smm/smmset -l blade%v -d powerstate -v poweron", slot)
	bytes, err := p.client.Run(cmd)
	if err != nil {
		global.Logger.Error("开机异常: %v %v", p.ip, err.Error())
		return err
	}

	lines := string(bytes)
	if strings.Contains(lines, "Succes") {
		return nil
	}
	global.Logger.Error(lines)
	return fmt.Errorf("操作失败：%v", lines)
}

// PowerOff 关机
func (p *E6000) PowerOff(slot int64) error {

	cmd := fmt.Sprintf("echo y | /smm/smmset -l blade%v -d powerstate -v poweroff", slot)
	bytes, err := p.client.Run(cmd)
	if err != nil {
		global.Logger.Error("关机异常: %v %v %v", p.ip, cmd, err.Error())
		return err
	}

	lines := string(bytes)
	if strings.Contains(lines, "Succes") {
		return nil
	}
	global.Logger.Error(lines)
	return fmt.Errorf("操作失败：%v", lines)
}

// PowerReset 重启 gracefulreset.平滑重启    coldreset.冷重启
func (p *E6000) PowerReset(slot int64) error {

	cmd := fmt.Sprintf("echo y | /smm/smmset -l blade%v -d frucontrol -v coldreset", slot)
	bytes, err := p.client.Run(cmd)
	if err != nil {
		global.Logger.Error("重启异常: %v %v %v", p.ip, cmd, err.Error())
		return err
	}

	lines := string(bytes)
	if strings.Contains(lines, "Succes") {
		return nil
	}
	global.Logger.Error(lines)
	return fmt.Errorf("操作失败：%v", lines)
}

func (p *E6000) SpecialHandler(box *gs_define.Box) {

	// 刀箱输入功率
	{
		getInputPower := func(items []gs_define.Item) float64 {

			for _, item := range items {
				if item.NameEN == gs_define.FIELD_INPUT_POWER {
					strs := regexp.MustCompile("\\d+(.\\d+)").FindAllString(item.Value, 1)
					if len(strs) > 0 {
						f, _ := strconv.ParseFloat(strs[0], 64)
						return f
					}
					break
				}
			}
			return 0
		}

		inputPower := float64(0)
		for _, power := range box.Powers {
			if power.PowerStatus == gs_define.POWER_STATUS_ON {
				inputPower += getInputPower(power.Items)
			}
		}

		box.Items = append(box.Items, gs_define.Item{
			NameEN: gs_define.FIELD_INPUT_POWER,
			Name:   define.FieldToName[gs_define.FIELD_INPUT_POWER],
			OsType: gs_define.OSTYPE_FLOAT,
			Value:  fmt.Sprintf("%v", inputPower),
			Units:  "W",
		})
	}

	// 刀箱温度
	{
		lines, err := p.run("smmget -t inlet temp -d current")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
		} else {
			strs := regexp.MustCompile("\\d+(.\\d+)( )*Celsius").FindAllString(lines, 1)
			if len(strs) > 0 {
				box.Items = append(box.Items, gs_define.Item{
					NameEN: gs_define.FIELD_SENSOR_TEMP,
					Name:   "inlet temp",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.Replace(strs[0], "Celsius", "℃", 1),
					Units:  "℃",
				})
			}
		}

	}

	// 刀箱传感器
	{
		lines, err := p.run("smmget -t Flash Usage -d current")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
		} else {
			strs := regexp.MustCompile("\\d+(.\\d+)( )*%").FindAllString(lines, 1)
			if len(strs) > 0 {
				box.Items = append(box.Items, gs_define.Item{
					NameEN: gs_define.FIELD_SENSOR,
					Name:   "Flash Usage",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strs[0],
					Units:  "%",
				})
			}
		}

	}

}

func getMatchLines(lines, match string) []string {

	strs := []string{}
	for _, line := range strings.Split(lines, "\n") {
		if matched, _ := regexp.MatchString(match, line); matched {
			strs = append(strs, line)
		}
	}
	return strs
}

func parseLine(line, sep, match string) string {

	if matched, _ := regexp.MatchString(match, strings.ToLower(line)); matched {
		values := strings.Split(line, sep)
		if len(values) > 1 {
			return strings.TrimSpace(values[1])
		}
	}

	return ""
}

func getName(line, match string) string {

	names := regexp.MustCompile(match).FindAllString(line, 1)
	if len(names) > 0 {
		return names[0]
	}
	return ""
}
