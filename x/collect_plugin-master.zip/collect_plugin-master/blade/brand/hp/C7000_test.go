package hp

import (
	"collect_plugin/blade/client"
	"collect_plugin/blade/global"
	"collect_plugin/blade/logic"
	"encoding/json"
	"testing"

	gs_define "geesunn.com/define"
)

func Init() (client.Client, error) {
	client, err := logic.InitSSHClient("192.168.1.142", "22", "Administrator", "password", "", 5)
	if err != nil {
		global.Logger.Error("SSH连接异常:%v %v", "192.168.1.142", err.Error())
		return nil, err
	}
	return &C7000{
		voucherType: gs_define.VOUCHER_TYPE_SSH,
		ip:          "192.168.1.142",
		client:      client,
	}, nil
}

func Test_GetBaseInfo(t *testing.T) {

	c, err := Init()
	if err != nil {
		t.Error(err)
		return
	}
	defer c.Close()
	t.Log(c.GetBaseInfo())
}

func Test_GetBlades(t *testing.T) {

	c, err := Init()
	if err != nil {
		t.Error(err)
		return
	}
	defer c.Close()
	blade, err := c.GetBlades()
	t.Log(toJSON(blade), err)
}

func Test_GetCmcs(t *testing.T) {

	c, err := Init()
	if err != nil {
		t.Error(err)
		return
	}
	defer c.Close()
	obj, err := c.GetCmcs()
	t.Log(toJSON(obj), err)
}

func Test_GetFans(t *testing.T) {

	c, err := Init()
	if err != nil {
		t.Error(err)
		return
	}
	defer c.Close()
	obj, err := c.GetFans()
	t.Log(toJSON(obj), err)
}

func Test_GetPowers(t *testing.T) {

	c, err := Init()
	if err != nil {
		t.Error(err)
		return
	}
	defer c.Close()
	obj, err := c.GetPowers()
	t.Log(toJSON(obj), err)
}

func toJSON(v interface{}) string {
	bytes, _ := json.Marshal(v)
	return string(bytes)
}
