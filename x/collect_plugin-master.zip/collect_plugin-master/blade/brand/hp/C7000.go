package hp

import (
	"collect_plugin/blade/client"
	"collect_plugin/blade/define"
	"collect_plugin/blade/global"
	"collect_plugin/blade/logic"
	"errors"
	"fmt"
	"regexp"
	"strconv"
	"strings"

	gs_define "geesunn.com/define"
	gs_ssh "geesunn.com/ssh"
)

func init() {
	client.RegistClient("C7000", InitClient)
}

// InitClient 初始化
func InitClient(data *define.Cache) (client.Client, error) {

	voucher := logic.GetVoucher(data.Vouchers, gs_define.VOUCHER_TYPE_SSH)
	if voucher == nil {
		return nil, errors.New("凭证不存在")
	}

	client, err := logic.InitSSHClient(data.IP, fmt.Sprintf("%v", voucher.SSHPort), voucher.SSHUser, voucher.SSHPassword, "", 5)
	if err != nil {
		global.Logger.Error("SSH连接异常:%v %v", data.IP, err.Error())
		return nil, err
	}

	return &C7000{
		voucherType: gs_define.VOUCHER_TYPE_SSH,
		ip:          data.IP,
		client:      client,
	}, nil
}

// C7000 惠普 C7000
type C7000 struct {
	voucherType string
	ip          string
	client      *gs_ssh.SSHClient
}

// GetSource 获取来源
func (p *C7000) GetSource() string {
	return p.voucherType
}

// Close 关闭
func (p *C7000) Close() error {
	return p.client.Close()
}

func (p *C7000) run(cmd string) (string, error) {

	bytes, err := p.client.Run(cmd)
	if err != nil {
		global.Logger.Error("%v %v \n %v", p.ip, cmd, err)
	} else {
		global.Logger.Debug("%v %v \n %v", p.ip, cmd, string(bytes))
		return string(bytes), err
	}
	return "", err

}

// GetBaseInfo 获取基本信息
func (p *C7000) GetBaseInfo() (*gs_define.BaseInfo, error) {

	baseInfo := &gs_define.BaseInfo{}

	lines, err := p.run("show enclosure info")
	if err != nil {
		return baseInfo, err
	}

	for _, line := range strings.Split(lines, "\n") {

		kv := strings.Split(line, ":")
		if len(kv) < 2 {
			continue
		}
		switch strings.TrimSpace(kv[0]) {
		case "Enclosure Name":
			baseInfo.Hostname = strings.TrimSpace(kv[1])
		case "Serial Number":
			baseInfo.SN = strings.TrimSpace(kv[1])
		}
	}

	return baseInfo, nil
}

// GetBlades 获取刀片信息
func (p *C7000) GetBlades() ([]gs_define.Blade, error) {

	m := map[int64]*gs_define.Blade{}

	for slot := int64(1); slot <= 16; slot++ {
		lines, err := p.run(fmt.Sprintf("show server info %v", slot))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}

		if strings.Contains(strings.ToUpper(lines), "SERVER BLADE TYPE: NO SERVER BLADE INSTALLED") {
			m[slot] = &gs_define.Blade{
				MasterSlot: gs_define.Slot{Slot: slot},
				Present:    gs_define.PRESENT_NOT_EXIST,
			}
			continue
		}

		if strings.Contains(strings.ToUpper(lines), "SERVER BLADE TYPE: BAY SUBSUMED") {
			if blade, ok := m[slot-8]; ok {
				blade.AppendSlot = append(blade.AppendSlot, gs_define.Slot{Slot: slot})
			}
			continue
		}

		if strings.Contains(lines, "Type: Unknown") {
			global.Logger.Info("刀片状态异常: %v %v %v", p.ip, slot, lines)
			m[slot] = &gs_define.Blade{
				MasterSlot:  gs_define.Slot{Slot: slot},
				Present:     gs_define.PRESENT_EXIST,
				PowerStatus: gs_define.POWER_STATUS_UNKNOW,
				Health:      "NOT OK",
			}
			continue
		}

		blade := &gs_define.Blade{
			MasterSlot: gs_define.Slot{Slot: slot},
			Present:    gs_define.PRESENT_EXIST,
		}
		for _, line := range strings.Split(lines, "\n") {

			kv := strings.Split(line, ":")
			if len(kv) < 2 {
				continue
			}
			switch strings.TrimSpace(kv[0]) {
			case "Serial Number":
				blade.SN = strings.TrimSpace(kv[1])
			case "Product Name":
				blade.Model = strings.TrimSpace(kv[1])
			case "IP Address":
				blade.Net = gs_define.Net{
					IP: strings.TrimSpace(kv[1]),
				}
			}
		}
		m[slot] = blade
	}

	blades := []gs_define.Blade{}
	for slot, blade := range m {

		func() {

			if blade.Present == gs_define.PRESENT_NOT_EXIST {
				return
			}

			if blade.PowerStatus == gs_define.POWER_STATUS_UNKNOW {
				return
			}

			lines, err := p.run(fmt.Sprintf("show server status %v", slot))
			if err != nil {
				global.Logger.Error("%v %v", p.ip, err.Error())
				return
			}

			for _, line := range strings.Split(lines, "\n") {

				kv := strings.Split(line, ":")
				if len(kv) < 2 {
					continue
				}
				switch strings.TrimSpace(kv[0]) {
				case "Power":
					switch strings.TrimSpace(kv[1]) {
					case "Off":
						blade.PowerStatus = gs_define.POWER_STATUS_OFF
					case "On":
						blade.PowerStatus = gs_define.POWER_STATUS_ON
					default:
						blade.PowerStatus = gs_define.POWER_STATUS_UNKNOW
					}
				case "Current Wattage used":
					blade.Items = append(blade.Items, gs_define.Item{
						NameEN: gs_define.FIELD_INPUT_POWER,
						Name:   define.FieldToName[gs_define.FIELD_INPUT_POWER],
						OsType: gs_define.OSTYPE_FLOAT,
						Value:  strings.TrimSpace(kv[1]),
						Units:  "W",
					})
				case "Virtual Fan":
					blade.Items = append(blade.Items, gs_define.Item{
						NameEN: gs_define.FIELD_FAN_PERCENT,
						Name:   define.FieldToName[gs_define.FIELD_FAN_PERCENT],
						OsType: gs_define.OSTYPE_STRING,
						Value:  strings.TrimSpace(kv[1]),
						Units:  "%",
					})

				case "Internal Health":
					switch strings.TrimSpace(kv[1]) {
					case "Failed":
						blade.Health = "NOT OK"
					case "Degraded":
						blade.Health = "NOT OK"
					default:
						blade.Health = "OK"
					}
				case "System Health":
					blade.Items = append(blade.Items, toShowItem("System Event Health", kv[1]))
				}
			}
		}()

		blades = append(blades, *blade)
	}

	return blades, nil
}

// GetModules 获取模块信息
func (p *C7000) GetModules() ([]gs_define.Module, error) {

	modules := []gs_define.Module{}
	for slot := int64(1); slot <= 8; slot++ {
		lines, err := p.run(fmt.Sprintf("show interconnect info %v", slot))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}

		if strings.Contains(strings.ToUpper(lines), "<ABSENT>") {
			modules = append(modules, gs_define.Module{
				Slot:    gs_define.Slot{Slot: slot},
				Present: gs_define.PRESENT_NOT_EXIST,
			})
			continue
		}

		module := gs_define.Module{
			Slot:    gs_define.Slot{Slot: slot},
			Present: gs_define.PRESENT_EXIST,
			Items:   []gs_define.Item{},
		}
		for _, line := range strings.Split(lines, "\n") {

			kv := strings.Split(line, ":")
			if len(kv) < 2 {
				continue
			}
			switch strings.TrimSpace(kv[0]) {
			case "Serial Number":
				module.SN = strings.TrimSpace(kv[1])
			case "Product Name":
				module.Model = strings.TrimSpace(kv[1])
			case "In-Band IPv4 Address":
				module.Net = gs_define.Net{
					IP: strings.TrimSpace(kv[1]),
				}
			case "Part Number":
				module.Items = append(module.Items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Part Number",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(kv[1]),
					Units:  "",
				})
			case "Spare Part Number":
				module.Items = append(module.Items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Spare Part Number",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(kv[1]),
					Units:  "",
				})
			}
		}

		modules = append(modules, module)
	}

	for index, module := range modules {

		if module.Present == gs_define.PRESENT_NOT_EXIST {
			continue
		}

		lines, err := p.run(fmt.Sprintf("show interconnect status %v", module.Slot.Slot))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}

		for _, line := range strings.Split(lines, "\n") {

			kv := strings.Split(line, ":")
			if len(kv) < 2 {
				continue
			}
			switch strings.TrimSpace(kv[0]) {
			case "Status":
				modules[index].Items = append(modules[index].Items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Status",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(kv[1]),
					Units:  "",
				})
			case "Health LED":
				if strings.TrimSpace(kv[1]) == "OK" {
					modules[index].Health = "OK"
				} else {
					modules[index].Health = "NOT OK"
				}

			case "Powered":
				if strings.ToUpper(strings.TrimSpace(kv[1])) == "ON" {
					modules[index].PowerStatus = gs_define.POWER_STATUS_ON
				} else {
					modules[index].PowerStatus = gs_define.POWER_STATUS_OFF
				}
			}
		}
	}
	return modules, nil
}

// GetCmcs 获取CMC 信息
func (p *C7000) GetCmcs() ([]gs_define.CMC, error) {

	cmcs := []gs_define.CMC{}

	for slot := int64(1); slot <= 2; slot++ {

		lines, err := p.run(fmt.Sprintf("show oa info %v", slot))
		if err != nil {
			global.Logger.Error("cmc 获取异常： %v %v", p.ip, err.Error())
			continue
		}

		if strings.Contains(lines, "OA Absent") {
			cmcs = append(cmcs, gs_define.CMC{
				Slot:    slot,
				Present: gs_define.PRESENT_NOT_EXIST,
			})
			continue
		}

		cmc := gs_define.CMC{
			Slot:        slot,
			Present:     gs_define.PRESENT_EXIST,
			PowerStatus: gs_define.POWER_STATUS_ON,
		}

		items := []gs_define.Item{}
		for _, line := range strings.Split(lines, "\n") {
			kv := strings.Split(line, ":")
			if len(kv) < 2 {
				continue
			}
			switch strings.TrimSpace(kv[0]) {
			case "Product Name":
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Product Name",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(kv[1]),
				})
			case "Part Number":
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Part Number",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(kv[1]),
				})
			case "Spare Part No.":
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Spare Part No",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(kv[1]),
				})
			case "Serial Number":
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Serial Number",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(kv[1]),
				})
			case "Manufacturer":
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Manufacturer",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(kv[1]),
				})
			}
		}

		cmc.Items = items

		cmcs = append(cmcs, cmc)
	}

	for index, cmc := range cmcs {

		if cmc.Present == gs_define.PRESENT_NOT_EXIST {
			continue
		}

		// 基本信息
		func() {
			lines, err := p.run(fmt.Sprintf("show oa status %v", cmc.Slot))
			if err != nil {
				global.Logger.Error("cmc 状态异常： %v %v", p.ip, err)
				return
			}

			for _, line := range strings.Split(lines, "\n") {
				kv := strings.Split(line, ":")
				if len(kv) < 2 {
					continue
				}
				switch strings.TrimSpace(kv[0]) {
				case "Name":
					cmcs[index].Name = strings.TrimSpace(kv[1])
				case "Role":
					cmcs[index].Items = append(cmcs[index].Items, gs_define.Item{
						NameEN: gs_define.FIELD_SHOW,
						Name:   "Role",
						OsType: gs_define.OSTYPE_STRING,
						Value:  strings.TrimSpace(kv[1]),
					})
				case "Status":
					if strings.TrimSpace(kv[1]) == "OK" {
						cmcs[index].Health = "OK"
					} else {
						cmcs[index].Health = "NOT OK"
					}
				}
			}
		}()

		// 负载
		func() {
			lines, err := p.run(fmt.Sprintf("show oa uptime %v", cmc.Slot))
			if err != nil {
				global.Logger.Error("cmc 状态异常： %v %v", p.ip, err)
				return
			}
			for _, line := range strings.Split(lines, "\n") {

				kv := strings.Split(line, ":")
				if len(kv) < 2 {
					continue
				}
				if strings.TrimSpace(kv[0]) == "CPU Load" {
					cmcs[index].Items = append(cmcs[index].Items, gs_define.Item{
						NameEN: gs_define.FIELD_SHOW,
						Name:   "CPU Load",
						OsType: gs_define.OSTYPE_STRING,
						Value:  strings.TrimSpace(kv[1]),
					})
					break
				}
			}
		}()
	}

	return cmcs, nil
}

// GetFans 风扇信息
func (p *C7000) GetFans() ([]gs_define.Fan, error) {

	fans := []gs_define.Fan{}

	for slot := int64(1); slot <= 10; slot++ {

		lines, err := p.run(fmt.Sprintf("show ENCLOSURE fan %v", slot))
		if err != nil {
			global.Logger.Error("风扇异常：%v %v")
			continue
		}
		if strings.Contains(lines, "Fan slot Empty") {
			fans = append(fans, gs_define.Fan{
				Name:    fmt.Sprintf("Fan%v", slot),
				Slot:    slot,
				Present: gs_define.PRESENT_NOT_EXIST,
			})
			continue
		}

		fan := gs_define.Fan{
			Name:        fmt.Sprintf("Fan%v", slot),
			Slot:        slot,
			Present:     gs_define.PRESENT_EXIST,
			PowerStatus: gs_define.POWER_STATUS_ON,
		}
		items := []gs_define.Item{}
		speedRate := float64(0)
		speedMax := float64(0)
		for _, line := range strings.Split(lines, "\n") {
			kv := strings.Split(line, ":")
			if len(kv) < 2 {
				continue
			}
			switch strings.TrimSpace(kv[0]) {
			case "Status":
				if strings.TrimSpace(kv[1]) == "OK" {
					fan.Health = "OK"
					fan.Status = "OK"
				} else {
					fan.Health = "NOT OK"
					fan.Status = "NOT OK"
				}
			case "Speed":
				speeds := regexp.MustCompile("\\d+").FindAllString(kv[1], 1)
				if len(speeds) > 0 {
					items = append(items, gs_define.Item{
						NameEN: gs_define.FIELD_SPEED_RATE,
						Name:   define.FieldToName[gs_define.FIELD_SPEED_RATE],
						OsType: gs_define.OSTYPE_FLOAT,
						Value:  speeds[0],
						Units:  "%",
					})
					speedRate, _ = strconv.ParseFloat(speeds[0], 10)
				}

			case "Power consumed":
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_MAX_SPEED,
					Name:   "Present Power",
					OsType: gs_define.OSTYPE_FLOAT,
					Value:  strings.TrimSpace(kv[1]),
					Units:  "W",
				})
			case "Maximum speed":
				v := strings.TrimSpace(kv[1])
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_MAX_SPEED,
					Name:   "Maximum speed",
					OsType: gs_define.OSTYPE_FLOAT,
					Value:  v,
					Units:  "RPM",
				})
				speedMax, _ = strconv.ParseFloat(v, 10)
			case "Minimum speed":
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_MIN_SPEED,
					Name:   "Minimum speed",
					OsType: gs_define.OSTYPE_FLOAT,
					Value:  strings.TrimSpace(kv[1]),
					Units:  "RPM",
				})
			case "Product Name":
				items = append(items, toShowItem("Product Name", kv[1]))
			case "Part Number":
				items = append(items, toShowItem("Part Number", kv[1]))
			case "Spare Part Number":
				items = append(items, toShowItem("Spare Part Number", kv[1]))
			case "Version":
				items = append(items, toShowItem("Version", kv[1]))
			}

		}
		items = append(items, gs_define.Item{
			NameEN: gs_define.FIELD_SPEED,
			Name:   define.FieldToName[gs_define.FIELD_SPEED],
			OsType: gs_define.OSTYPE_FLOAT,
			Value:  fmt.Sprintf("%.2f", float64(speedMax*speedRate/100)),
			Units:  "RPM",
		})

		fan.Items = items
		fans = append(fans, fan)
	}

	return fans, nil
}

// GetPowers 电源
func (p *C7000) GetPowers() ([]gs_define.BladePower, error) {

	powers := []gs_define.BladePower{}

	for slot := int64(1); slot <= 6; slot++ {
		lines, err := p.run(fmt.Sprintf("show ENCLOSURE POWERSUPPLY %v", slot))
		if err != nil {
			global.Logger.Error("电源信息异常: %v %v", p.ip, err)
			continue
		}

		power := gs_define.BladePower{
			Name:    fmt.Sprintf("PS%v", slot),
			Present: gs_define.PRESENT_EXIST,
			Slot:    slot,
		}

		items := []gs_define.Item{}
		for _, line := range strings.Split(lines, "\n") {
			kv := strings.Split(line, ":")
			if len(kv) < 2 {
				continue
			}

			value := strings.TrimSpace(kv[1])
			if value == "" {
				continue
			}

			switch strings.TrimSpace(kv[0]) {
			case "Status":
				if value == "OK" {
					power.Health = "OK"
				} else {
					power.Health = "NOT OK"
				}
			case "AC Input Status":
				if value == "OK" {
					power.PowerStatus = gs_define.POWER_STATUS_ON
				} else {
					power.PowerStatus = gs_define.POWER_STATUS_OFF
				}
			case "Output Capacity":
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Output Capacity",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.Replace(value, "Watts DC", "W", 1),
					Units:  "W",
				})
			case "Current Power Output":
				items = append(items, gs_define.Item{
					NameEN: gs_define.FIELD_SHOW,
					Name:   "Current Power Output",
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.Replace(value, "Watts DC", "W", 1),
					Units:  "W",
				})
			case "Product Name":
				items = append(items, toShowItem("Product Name", kv[1]))
			case "Part Number":
				items = append(items, toShowItem("Part Number", kv[1]))
			case "Spare Part Number":
				items = append(items, toShowItem("Spare Part Number", kv[1]))
			case "Serial Number":
				items = append(items, toShowItem("Serial Number", kv[1]))
			}

		}

		power.Items = items

		powers = append(powers, power)
	}

	return powers, nil
}

// GetKvm 获取KVM信息
func (p *C7000) GetKvm() ([]gs_define.KVM, error) {
	return []gs_define.KVM{}, nil
}

// PowerOn 开机
func (p *C7000) PowerOn(slot int64) error {

	cmd := fmt.Sprintf("POWERON SERVER %v", slot)
	bytes, err := p.client.Run(cmd)
	if err != nil {
		global.Logger.Error("开机异常: %v %v", p.ip, err.Error())
		return err
	}

	lines := string(bytes)
	if strings.Contains(lines, "Powering on") {
		return nil
	}
	global.Logger.Error(lines)
	return fmt.Errorf("操作失败：%v", lines)
}

// PowerOff 关机
func (p *C7000) PowerOff(slot int64) error {

	cmd := fmt.Sprintf("POWEROFF SERVER %v", slot)
	bytes, err := p.client.Run(cmd)
	if err != nil {
		global.Logger.Error("关机异常: %v %v %v", p.ip, cmd, err.Error())
		return err
	}

	lines := string(bytes)
	if strings.Contains(lines, "Powering") {
		return nil
	}
	global.Logger.Error(lines)
	return fmt.Errorf("操作失败：%v", lines)
}

// PowerReset 重启
func (p *C7000) PowerReset(slot int64) error {

	cmd := fmt.Sprintf("reboot server %v", slot)
	bytes, err := p.client.Run(cmd)
	if err != nil {
		global.Logger.Error("重启异常: %v %v %v", p.ip, cmd, err.Error())
		return err
	}

	lines := string(bytes)
	if strings.Contains(lines, "Powering") {
		return nil
	}
	global.Logger.Error(lines)
	return fmt.Errorf("操作失败：%v", lines)
}

// SpecialHandler 特殊处理
func (p *C7000) SpecialHandler(box *gs_define.Box) {

	// 功率
	{
		lines, err := p.run("show POWER")
		if err != nil {
			global.Logger.Error("刀箱功率异常：%v %v", p.ip, err)
		} else {
			for _, line := range strings.Split(lines, "\n") {

				kv := strings.Split(line, ":")
				if len(kv) < 2 {
					continue
				}
				switch strings.TrimSpace(kv[0]) {
				case "Present Power":
					box.Items = append(box.Items, gs_define.Item{
						NameEN: gs_define.FIELD_INPUT_POWER,
						Name:   define.FieldToName[gs_define.FIELD_INPUT_POWER],
						OsType: gs_define.OSTYPE_STRING,
						Value:  strings.Replace(strings.TrimSpace(kv[1]), "Watts AC", "W", -1),
						Units:  "W",
					})
				case "Power Limit":
					box.Items = append(box.Items, gs_define.Item{
						NameEN: gs_define.FIELD_SHOW,
						Name:   "Power Limit",
						OsType: gs_define.OSTYPE_STRING,
						Value:  strings.Replace(strings.TrimSpace(kv[1]), "Watts AC", "W", -1),
						Units:  "W",
					})
				}
			}
		}

	}

	// 温度
	{
		lines, err := p.run("show enclosure TEMP")
		if err != nil {
			global.Logger.Error("刀箱温度异常：%v %v", p.ip, err)
		} else {
			for _, line := range strings.Split(lines, "\n") {
				if ok, _ := regexp.MatchString("\\d+(.\\d+)?C/", line); ok {

					name := ""
					names := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(line, 1)
					if len(names) > 0 {
						name = names[0]
					}

					value := ""
					values := regexp.MustCompile("\\d+(.\\d+)?C/").FindAllString(line, 1)
					if len(values) > 0 {
						value = strings.Trim(values[0], "C/")
					}

					box.Items = append(box.Items, gs_define.Item{
						NameEN: gs_define.FIELD_SENSOR_TEMP,
						Name:   name,
						OsType: gs_define.OSTYPE_FLOAT,
						Value:  value,
						Units:  "℃",
					})
				}
			}
		}
	}
}

func getMatchLines(lines, match string) []string {

	strs := []string{}
	for _, line := range strings.Split(lines, "\n") {
		if matched, _ := regexp.MatchString(match, line); matched {
			strs = append(strs, line)
		}
	}
	return strs
}

func parseLine(line, sep, match string) (bool, string) {

	if matched, _ := regexp.MatchString(match, strings.ToLower(line)); matched {
		values := strings.Split(line, sep)
		if len(values) > 1 {
			return true, strings.TrimSpace(values[1])
		}
	}

	return false, ""
}

func getName(line, match string) string {

	names := regexp.MustCompile(match).FindAllString(line, 1)
	if len(names) > 0 {
		return names[0]
	}
	return ""
}

func toShowItem(name, value string) gs_define.Item {

	return gs_define.Item{
		NameEN: gs_define.FIELD_SHOW,
		Name:   name,
		OsType: gs_define.OSTYPE_STRING,
		Value:  strings.TrimSpace(value),
	}

}
