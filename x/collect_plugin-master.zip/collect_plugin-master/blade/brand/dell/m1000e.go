package dell

import (
	"collect_plugin/blade/client"
	"collect_plugin/blade/define"
	"collect_plugin/blade/global"
	"collect_plugin/blade/logic"
	"errors"
	"fmt"
	"regexp"
	"strings"

	gs_define "geesunn.com/define"
	gs_ssh "geesunn.com/ssh"
)

func init() {
	client.RegistClient("M1000E", InitClient)
}

// InitClient 初始化
func InitClient(data *define.Cache) (client.Client, error) {

	voucher := logic.GetVoucher(data.Vouchers, gs_define.VOUCHER_TYPE_SSH)
	if voucher == nil {
		return nil, errors.New("凭证不存在")
	}

	client, err := logic.InitSSHClient(data.IP, fmt.Sprintf("%v", voucher.SSHPort), voucher.SSHUser, voucher.SSHPassword, "", 5)
	if err != nil {
		global.Logger.Error("SSH连接异常:%v %v", data.IP, err.Error())
		return nil, err
	}

	return &Client{
		voucherType: gs_define.VOUCHER_TYPE_SSH,
		ip:          data.IP,
		client:      client,
	}, nil
}

// Client M1000e
type Client struct {
	voucherType string
	ip          string
	client      *gs_ssh.SSHClient
}

func (p *Client) GetSource() string {
	return p.voucherType
}

// Close 关闭
func (p *Client) Close() error {
	return p.client.Close()
}

func (p *Client) run(cmd string) (string, error) {

	bytes, err := p.client.Run(cmd)
	if err != nil {
		global.Logger.Error("%v %v", cmd, err.Error())
	}
	global.Logger.Debug("%v \n %v \n %v", cmd, string(bytes), err)
	return string(bytes), err
}

// GetBaseInfo 获取基本信息
func (p *Client) GetBaseInfo() (*gs_define.BaseInfo, error) {
	return nil, nil
}

// GetBlades 获取刀片信息
func (p *Client) GetBlades() ([]gs_define.Blade, error) {

	blades := []gs_define.Blade{}

	for slot := int64(1); slot <= 16; slot++ {
		lines, err := p.run(fmt.Sprintf("getmodinfo -m server-%v -A", slot))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}

		values := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(lines, -1)
		if len(values) < 5 {
			continue
		}

		blades = append(blades, gs_define.Blade{
			MasterSlot: gs_define.Slot{
				Slot: slot,
			},
			Present:     getPresent(values[1]),
			PowerStatus: getPowerStatus(values[2]),
			Health:      getHealth(values[3]),
			SN:          strings.TrimSpace(values[4]),
		})
	}

	// for _, blade := range blades {

	// }

	return blades, nil
}

// GetModules 获取模块信息
func (p *Client) GetModules() ([]gs_define.Module, error) {

	modules := []gs_define.Module{}

	for slot := int64(1); slot <= 8; slot++ {
		lines, err := p.run(fmt.Sprintf("getmodinfo -m switch-%v -A", slot))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}

		values := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(lines, -1)
		if len(values) < 5 {
			continue
		}

		modules = append(modules, gs_define.Module{
			Slot: gs_define.Slot{
				Slot: slot,
			},
			Present:     getPresent(values[1]),
			PowerStatus: getPowerStatus(values[2]),
			Health:      getHealth(values[3]),
			SN:          strings.TrimSpace(values[4]),
		})
	}
	return modules, nil
}

// GetCmcs 获取CMC 信息
func (p *Client) GetCmcs() ([]gs_define.CMC, error) {

	cmcs := []gs_define.CMC{}
	for slot := int64(1); slot <= 2; slot++ {
		lines, err := p.run(fmt.Sprintf("getmodinfo -m cmc-%v -A", slot))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}

		values := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(lines, -1)
		if len(values) < 4 {
			continue
		}

		// role := int64(0)
		// if strings.TrimSpace(values[2]) == "Primary" {
		// 	role = 1
		// }

		cmcs = append(cmcs, gs_define.CMC{
			Slot: slot,
			Name: strings.TrimSpace(values[0]),
			// Role:        role,
			// Location:    strings.TrimSpace(values[0]),
			Present:     getPresent(values[1]),
			PowerStatus: getPowerStatus(values[2]),
			Health:      getHealth(values[3]),
		})
	}

	{
		lines, err := p.run("getsysinfo")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
		}
		m := map[string]gs_define.Field{
			"Primary CMC Version": gs_define.FIELD_FIRMWARE_VERSION,
			"Hardware Version":    gs_define.FIELD_HARD_VERSION,
			"Current IP Address":  gs_define.FIELD_IP,
			"Standby CMC Version": gs_define.FIELD_SPARE_VERSION,
		}
		items := []gs_define.Item{}
		for _, line := range getMatchLines(lines, "(Primary CMC Version|Hardware Version|Current IP Address|cmc_spare_version)") {
			values := strings.Split(line, "=")
			if len(values) < 2 {
				continue
			}

			field, ok := m[strings.TrimSpace(values[0])]
			if ok {
				items = append(items, gs_define.Item{
					NameEN: field,
					Name:   define.FieldToName[field],
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(values[1]),
				})
			}
		}
	}

	return cmcs, nil
}

// GetFans 风扇信息
func (p *Client) GetFans() ([]gs_define.Fan, error) {

	fans := []gs_define.Fan{}

	for slot := int64(1); slot <= 9; slot++ {
		lines, err := p.run(fmt.Sprintf("getmodinfo -m fan-%v -A", slot))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}

		values := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(lines, -1)
		if len(values) < 4 {
			continue
		}

		fans = append(fans, gs_define.Fan{
			Slot:        slot,
			Name:        strings.TrimSpace(values[0]),
			Present:     getPresent(values[1]),
			PowerStatus: getPowerStatus(values[2]),
			Health:      getHealth(values[3]),
		})
	}

	lines, err := p.run("getsensorinfo")
	if err != nil {
		global.Logger.Error("%v %v", p.ip, err.Error())
	}
	for index, line := range getMatchLines(lines, "FanSpeed") {

		if fans[index].Present != gs_define.PRESENT_NOT_EXIST {
			continue
		}

		values := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(line, -1)
		if len(values) < 8 {
			continue
		}

		units := strings.TrimSpace(values[5])
		fans[index].Status = getHealth(values[3])
		fans[index].Items = []gs_define.Item{
			gs_define.Item{
				NameEN: gs_define.FIELD_SPEED,
				Name:   define.FieldToName[gs_define.FIELD_SPEED],
				OsType: gs_define.OSTYPE_STRING,
				Value:  fmt.Sprintf("%v %v", strings.TrimSpace(values[4]), units),
				Units:  units,
			},
			gs_define.Item{
				NameEN: gs_define.FIELD_MIN_SPEED,
				Name:   define.FieldToName[gs_define.FIELD_MIN_SPEED],
				OsType: gs_define.OSTYPE_STRING,
				Value:  fmt.Sprintf("%v %v", strings.TrimSpace(values[6]), units),
				Units:  units,
			},
			gs_define.Item{
				NameEN: gs_define.FIELD_MAX_SPEED,
				Name:   define.FieldToName[gs_define.FIELD_MAX_SPEED],
				OsType: gs_define.OSTYPE_STRING,
				Value:  fmt.Sprintf("%v %v", strings.TrimSpace(values[7]), units),
				Units:  units,
			},
		}
	}

	return fans, nil
}

// GetPowers 电源
func (p *Client) GetPowers() ([]gs_define.BladePower, error) {

	powers := []gs_define.BladePower{}

	for slot := int64(1); slot <= 6; slot++ {
		lines, err := p.run(fmt.Sprintf("getmodinfo -m ps-%v -A", slot))
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
			continue
		}

		values := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(lines, -1)
		if len(values) < 4 {
			continue
		}

		powers = append(powers, gs_define.BladePower{
			Slot:        slot,
			Name:        strings.TrimSpace(values[0]),
			Present:     getPresent(values[1]),
			PowerStatus: getPowerStatus(values[2]),
			Health:      getHealth(values[3]),
		})
	}

	lines, err := p.run("getpbinfo")
	if err != nil {
		global.Logger.Error("%v %v", p.ip, err.Error())
	}
	for index, line := range getMatchLines(lines, "PS\\d") {

		if powers[index].Present != gs_define.PRESENT_NOT_EXIST {
			continue
		}

		values := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(line, -1)
		if len(values) < 6 {
			continue
		}

		powers[index].Items = []gs_define.Item{
			gs_define.Item{
				NameEN: gs_define.FIELD_INPUT_VOLTS,
				Name:   define.FieldToName[gs_define.FIELD_INPUT_VOLTS],
				OsType: gs_define.OSTYPE_STRING,
				Value:  strings.TrimSpace(values[3]),
				Units:  "V",
			},
			gs_define.Item{
				NameEN: gs_define.FIELD_INPUT_CURRENT,
				Name:   define.FieldToName[gs_define.FIELD_INPUT_CURRENT],
				OsType: gs_define.OSTYPE_STRING,
				Value:  strings.TrimSpace(values[4]),
				Units:  "A",
			},
			gs_define.Item{
				NameEN: gs_define.FIELD_INPUT_POWER,
				Name:   define.FieldToName[gs_define.FIELD_INPUT_POWER],
				OsType: gs_define.OSTYPE_STRING,
				Value:  strings.TrimSpace(values[5]),
				Units:  "W",
			},
		}
	}

	return powers, nil
}

// GetKvm 获取KVM信息
func (p *Client) GetKvm() ([]gs_define.KVM, error) {

	lines, err := p.run("getmodinfo -m kvm -A")
	if err != nil {
		global.Logger.Error("%v %v", p.ip, err.Error())
		return nil, nil
	}

	values := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(lines, -1)
	if len(values) < 4 {
		return nil, nil
	}

	kvm := gs_define.KVM{
		Present:     getPresent(values[1]),
		PowerStatus: getPowerStatus(values[2]),
		Health:      getHealth(values[3]),
		Items: []gs_define.Item{gs_define.Item{
			NameEN: gs_define.FIELD_HEALTH,
			Name:   define.FieldToName[gs_define.FIELD_HEALTH],
			OsType: gs_define.OSTYPE_STRING,
			Value:  strings.TrimSpace(values[3]),
		}},
	}

	{
		lines, err := p.run("getkvminfo")
		if err != nil {
			global.Logger.Error("%v %v", p.ip, err.Error())
		}
		line := getMatchLines(lines, "KVM")
		if len(line) > 0 {
			values := regexp.MustCompile("(\\S+( \\S+)+)|\\S+").FindAllString(line[0], -1)
			if len(values) >= 5 {
				kvm.Status = getHealth(values[4])
				kvm.Items = append(kvm.Items, gs_define.Item{
					NameEN: gs_define.FIELD_MODEL,
					Name:   define.FieldToName[gs_define.FIELD_MODEL],
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(values[2]),
				}, gs_define.Item{
					NameEN: gs_define.FIELD_FIRMWARE_VERSION,
					Name:   define.FieldToName[gs_define.FIELD_FIRMWARE_VERSION],
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(values[3]),
				}, gs_define.Item{
					NameEN: gs_define.FIELD_STATUS,
					Name:   define.FieldToName[gs_define.FIELD_STATUS],
					OsType: gs_define.OSTYPE_STRING,
					Value:  strings.TrimSpace(values[4]),
				})
			}
		}
	}

	return []gs_define.KVM{kvm}, nil
}

// PowerOn 开机
func (p *Client) PowerOn(slot int64) error {

	lines, err := p.run(fmt.Sprintf("serveraction -m server-%v powerup", slot))
	if err != nil {
		global.Logger.Error("开机异常: %v %v", p.ip, err.Error())
		return fmt.Errorf("操作失败: %v", err.Error())
	}
	if strings.Contains(lines, "ERROR") {
		global.Logger.Error(err.Error())
		return fmt.Errorf("操作失败: %v", lines)
	}

	return nil
}

// PowerOff 关机
func (p *Client) PowerOff(slot int64) error {

	lines, err := p.run(fmt.Sprintf("serveraction -m server-%v powerdown", slot))
	if err != nil {
		global.Logger.Error("开机异常: %v %v", p.ip, err.Error())
		return fmt.Errorf("操作失败: %v", err.Error())
	}

	if strings.Contains(lines, "ERROR") {
		global.Logger.Error(err.Error())
		return fmt.Errorf("操作失败: %v", lines)
	}

	return nil
}

// PowerReset 重启 gracefulreset.平滑重启    coldreset.冷重启
func (p *Client) PowerReset(slot int64) error {

	lines, err := p.run(fmt.Sprintf("serveraction -m server-%v hardreset", slot))
	if err != nil {
		global.Logger.Error("开机异常: %v %v", p.ip, err.Error())
		return fmt.Errorf("操作失败: %v", err.Error())
	}
	if strings.Contains(lines, "ERROR") {
		global.Logger.Error(err.Error())
		return fmt.Errorf("操作失败: %v", lines)
	}

	return nil
}

func (p *Client) SpecialHandler(box *gs_define.Box) {

}

func getPresent(presence string) gs_define.Present {

	switch strings.TrimSpace(presence) {
	case "Present":
		return gs_define.PRESENT_EXIST
	case "Not Present":
		return gs_define.PRESENT_NOT_EXIST
	default:
		return gs_define.PRESENT_NOT_EXIST
	}

}

func getPowerStatus(pwrState string) gs_define.PowerStatus {

	switch strings.TrimSpace(pwrState) {
	case "ON":
		return gs_define.POWER_STATUS_ON
	case "OFF":
		return gs_define.POWER_STATUS_OFF
	case "Online":
		return gs_define.POWER_STATUS_ON
	case "Failed(No AC)":
		return gs_define.POWER_STATUS_OFF
	case "Primary":
		return gs_define.POWER_STATUS_ON
	default:
		return gs_define.POWER_STATUS_OFF
	}

}

func getHealth(health string) string {

	switch strings.TrimSpace(health) {
	case "OK":
		return "OK"
	case "Not OK":
		return "NOT OK"
	default:
		return ""
	}
}

func getMatchLines(lines, match string) []string {

	strs := []string{}
	for _, line := range strings.Split(lines, "\n") {
		if matched, _ := regexp.MatchString(match, line); matched {
			strs = append(strs, line)
		}
	}
	return strs
}
