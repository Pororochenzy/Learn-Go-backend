package define

type Cache struct {
	IP           string                   `json:"ip"`
	ID           int64                    `json:"id"`
	Brand        string                   `json:"brand_name"`
	Series       string                   `json:"series"`
	Model        string                   `json:"model"`
	Vouchers     []map[string]interface{} `json:"vouchers"`
	MonitorCycle int64                    `json:"monitor_cycle"`
}
