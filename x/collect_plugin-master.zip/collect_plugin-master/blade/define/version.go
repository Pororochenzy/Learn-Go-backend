package define

const (
	Version = "1.0.1"
	Author  = "Geesunn Team"
)
