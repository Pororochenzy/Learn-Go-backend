package define

import (
	gs_define "geesunn.com/define"
)

// FieldToName itemField转name
var FieldToName = map[gs_define.Field]string{
	gs_define.FIELD_INPUT_CURRENT:    "输入电流",
	gs_define.FIELD_INPUT_POWER:      "输入功率",
	gs_define.FIELD_INPUT_VOLTS:      "输入电压",
	gs_define.FIELD_SPEED_RATE:       "速率",
	gs_define.FIELD_SPEED:            "转速",
	gs_define.FIELD_MAX_SPEED:        "阈值上限",
	gs_define.FIELD_MIN_SPEED:        "阈值下限",
	gs_define.FIELD_HARD_VERSION:     "硬件版本",
	gs_define.FIELD_FIRMWARE_VERSION: "固件版本",
	gs_define.FIELD_SPARE_VERSION:    "备用固件版本",
	gs_define.FIELD_FAN_PERCENT:      "风扇利用率",
	gs_define.FIELD_HEALTH:           "健康状态",
	gs_define.FIELD_STATUS:           "运行状态",
	gs_define.FIELD_MODEL:            "型号",
	gs_define.FIELD_IP:               "ip",
}

const (
	RET_SUCCESS     = 0
	RET_SUCCESS_MSG = "成功"
	RET_FAILED      = 1
)
