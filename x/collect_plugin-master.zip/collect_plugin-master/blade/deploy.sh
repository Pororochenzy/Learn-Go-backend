gitdir=/data/geesunn_fedel/code/src/blade
build=/root/geesunn/build/geesunn-blade
pro=/geesunn/app/geesunn-blade
cd $gitdir
git checkout dev
git pull

cd ../../geesunn.com
git checkout dev
git pull

cd -

./pack.sh build "test"
if [[ $? -gt 0 ]];
then
    exit 1
fi 

rm -fr $pro
mkdir -p $pro
cp -fr $build/* $pro

cd $pro
./control.sh restart
if [[ $? -gt 0 ]];
then
    exit 1
fi 
