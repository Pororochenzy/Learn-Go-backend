# collect_plugin

采集组件集