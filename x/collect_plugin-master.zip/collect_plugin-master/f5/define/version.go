package define

const (
	AUTHOR  = "GEESUNN"
	VERSION = "f5 v1.8.0"
)
