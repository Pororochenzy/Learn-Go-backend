package define

type CollectStatus int

const (
	COLLECT_STOP = 0
	COLLECT_RUN  = 1
	COLLECT_EXIT = 2

	MIB_SOURCE_DB   = "DB"
	MIB_SOURCE_FILE = "FILE"
)

type EtagIpInfo struct {
	CtrId int64  `json:"ctr_id"`
	Ip    string `json:"ip"`
	Port  int64  `json:"port"`
}

type OidInfo struct {
	Oid     string `json:"oid"`
	Method  string `json:"method"`
	Item    string `json:"item"`
	ItemCN  string `json:"itemcn"`
	Show    string `json:"show"`
	Jz      string `json:"jz"`
	JzStart string `json:"jz_start"`
	Remark  string `json:"remark"`
	Value   string `json:"value"`
}

type MemInfo struct {
	MemTotal   float64 `json:"mem_total"`
	MemUsed    float64 `json:"mem_used"`
	MemFree    float64 `json:"mem_free"`
	MemPercent float64 `json:"mem_percent"`
}

var (
	SNMP_METHOD_GET    = "get"
	SNMP_METHOD_WALK   = "walk"
	SNMP_METHOD_GONEXT = "getnext"
)

type SSHParm struct {
	Host       string
	Port       string
	UserName   string
	Password   string
	PrivateKey string
}

type LinuxFile struct {
	Type     string `json:"type"`
	Prop     string `json:"prop"`
	FileNum  string `json:"file_num"`
	Owner    string `json:"owner"`
	Group    string `json:"group"`
	Size     string `json:"size"`
	Date     string `json:"date"`
	FileName string `json:"fileName"`
	SoftAddr string `json:"soft_addr"`
}

type DeviceConf struct {
	Id       string
	DeviceId string
	Brand    string
	Model    string
	HostName string
	Type     string
	Host     string
	Port     string
	User     string
	Password string
	Commands []Command
}

type Command struct {
	Name string
	Cmd  string
}

type CollectType string

// 任务队列数据单元
type TaskQueueUnit struct {
	Type CollectType            `json:"type"`
	Data map[string]interface{} `json:"data"`
}

const (
	COLLECT_TYPE_CYCLE     = CollectType("cycle")   // 循环采集
	COLLECT_TYPE_INSPECT   = CollectType("inspect") // 巡检采集
	COLLECT_TYPE_AUTO_FIND = CollectType("find")    // 自动发现
)
