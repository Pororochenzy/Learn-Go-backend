package main

import (
	"collect_plugin/f5/cycle"
	"collect_plugin/f5/global"
	"collect_plugin/f5/logic"
	"collect_plugin/f5/mq"
	"flag"
	"fmt"
	"os"
	"os/signal"

	"syscall"
)

func ReleaseLimit() {
	var rlimit, zero syscall.Rlimit
	err := syscall.Getrlimit(syscall.RLIMIT_NOFILE, &rlimit)
	if err != nil {
		panic(err)
	}
	if zero == rlimit {
		panic(fmt.Sprintf("Getrlimit: save failed: got zero value %#v", rlimit))
	}
	if rlimit.Max < 1024 {
		panic("Max fd is less than 1024, please check your system setting")
	}
	set := rlimit
	set.Cur = set.Max - 1
	err = syscall.Setrlimit(syscall.RLIMIT_NOFILE, &set)
	if err != nil {
		panic(err)
	}
	syscall.Getrlimit(syscall.RLIMIT_NOFILE, &rlimit)
	fmt.Println(rlimit.Cur)
}

func main() {
	defer func() {
		global.Logger.Warning("采集服务退出！")
		if r := recover(); r != nil {
			global.Logger.Error("Error: %v", r)
			logic.PrintTrace()
		}
	}()

	ReleaseLimit()

	// 接收自定义配置路径
	configPath := flag.String("c", "f5/config", "configuration file")
	flag.Parse()
	// 初始化系统
	global.InitSystem(*configPath)
	// 初始化MQ，处理MQ请求数据
	go mq.InitMQ()
	global.Logger.Info("=======start....")
	go cycle.StartCollect()
	global.Logger.Info("=======end....")

	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		<-sigs
		global.Logger.Info("exit")
		global.CCacheDB.Close()
		os.Exit(0)
	}()

	select {}
}
