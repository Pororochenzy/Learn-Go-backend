package mq

import (
	"collect_plugin/f5/global"
	gs_define "geesunn.com/define"
)

// 发送消息给collect代理
func Push2Collect(msg gs_define.MQMsg) error {
	return global.CCacheDB.CheckToLPUSH(gs_define.REDIS_MQ_DB, gs_define.C_CACHE_F5_UPLOAD_QUEUE, msg)
}
