package cycle

import (
	"collect_plugin/f5/global"
	"collect_plugin/f5/logic"
	"collect_plugin/f5/mq"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/pkg/errors"
	"io/ioutil"
	"net"
	"path/filepath"
	"strings"
	"sync"
	"time"

	snmp_new "collect_plugin/f5/snmp"
	gs_define "geesunn.com/define"
	"geesunn.com/gpool"
	gs_snmp "geesunn.com/snmp"
	gs_tool "geesunn.com/tool"
)

var (
	// 品牌_型号 oid
	NetworkOids = struct {
		sync.RWMutex
		m map[string][]gs_define.OidInfo
	}{m: make(map[string][]gs_define.OidInfo)}
)

type cache struct {
	ID           int64  `json:"id"`
	IP           string `json:"ip"`
	SnmpInfo     string `json:"snmp_info"`
	MonitorCycle int64  `json:"monitor_cycle"`
	Brand        string `json:"brand_name"`
}

func getFromCache(key string) *cache {
	info, err := global.CCacheDB.GetString(gs_define.REDIS_COLLECT_DB, key)
	if err != nil {
		global.Logger.Error("%v %v", key, err.Error())
		return nil
	}

	data := cache{}
	if err := json.Unmarshal([]byte(info), &data); err != nil {
		global.Logger.Error(err.Error())
		return nil
	}
	return &data
}

var (
	checkIPPool = gpool.NewGoPool(100)

	runManger = gs_tool.NewRunManger()
)

// 采集程序
func start() {
	for {
		tqu := <-global.TaskQueue

		checkIPPool.GetGo()

		go func(tqu gs_define.TaskQueueUnit) {
			defer logic.HanderPanic()
			defer checkIPPool.ReleaseGo()

			key := tqu.Data["key"].(string)

			switch tqu.Type {
			case gs_define.COLLECT_TYPE_CYCLE:
				data := getFromCache(key)
				if data != nil && len(data.IP) > 0 && len(data.SnmpInfo) > 0 {
					SetCycleKeyExpire(gs_define.REDIS_COLLECT_DB, key, int(data.MonitorCycle))

					// 在采集的设备，避免重复采集
					if runManger.IsRunning(key) {
						return
					}
					// 设置设备正在采集中
					runManger.Set(key)
					defer runManger.Clear(key)
					global.Logger.Info("%v %v", key, data.MonitorCycle)

					collctInfo, err := getInfo(data)
					setNetStatus(collctInfo)
					m := gs_define.F5Info{
						ID:            data.ID,
						IP:            data.IP,
						MonitorCycle:  data.MonitorCycle,
						Unixtime:      gs_tool.CurrentTimeSecond(),
						Data:          collctInfo,
						AppConnect:    "1",
						AppConnectMsg: "",
					}
					if err != nil {
						m.AppConnect = "0"
						m.AppConnectMsg = err.Error()
					}

					global.Logger.Debug("%v", m)

					dataBytes, _ := json.Marshal(m)

					if err := mq.Push2Collect(gs_define.MQMsg{
						MQType:   gs_define.MQ_TYPE_LOAD_BALANCE_F5,
						UUID:     gs_tool.NewUUID(),
						From:     "f5",
						To:       gs_define.M_CACHE_CCHANDLER_RECV_QUEUE,
						Unixtime: gs_tool.CurrentTimeSecond(),
						Data:     string(dataBytes),
					}); err != nil {
						global.Logger.Error(err.Error())
					}
				} else {
					global.CCacheDB.DELKey(gs_define.REDIS_COLLECT_DB, "cycle:"+key)
				}
			case gs_define.COLLECT_TYPE_INSPECT:
			}
		}(tqu)
	}
}

var (
	mibTemplate = struct {
		sync.Mutex
		M map[string][]gs_define.OidInfo
	}{
		M: map[string][]gs_define.OidInfo{},
	}
)

// 获取f5信息
func getInfo(data *cache) (*gs_define.F5CollectInfo, error) {
	return SNMPCollect(data.SnmpInfo, data.IP, data.Brand, "", "")
}

// SNMPCollect snmp采集
func SNMPCollect(voucherContent, ip, brand, series, model string) (*gs_define.F5CollectInfo, error) {
	defer logic.HanderPanic()
	voucher := gs_define.Voucher{}
	if err := json.Unmarshal([]byte(voucherContent), &voucher); err != nil {
		global.Logger.Error("凭证信息异常: %v", err.Error())
		return nil, errors.New("数据异常")
	}
	client, err := gs_snmp.InitClient(gs_define.SNMP_Auth{
		IP:            ip,
		Version:       voucher.SNMPVersion,
		Port:          voucher.SNMPPort,
		ReadComunity:  voucher.SNMPReadComunity,
		User:          voucher.SNMPUser,
		SecurityLevel: voucher.SNMPSecurityLevel,
		AuthPro:       voucher.SNMPAuthPro,
		AuthPassword:  voucher.SNMPAuthPassword,
		DataPro:       voucher.SNMPDataPro,
		DataPassword:  voucher.SNMPDataPassword,
		Brand:         brand,
		Product:       series,
		Model:         model,
	})
	if err != nil {
		global.Logger.Error("SNMP连接异常: %v", err)
		return nil, errors.New(fmt.Sprintf("SNMP连接异常: %v", err.Error()))
	}
	defer client.Close()

	versionOID := `1.3.6.1.4.1.3375.2.1.4.2.0`
	vlines, err := snmp_new.SnmpGet(client.SNMP, versionOID, ip)
	version := vlines[0].Variable.String()
	if err != nil {
		global.Logger.Error("SNMP连接异常: %v", err)
		return nil, errors.New(fmt.Sprintf("SNMP连接异常: %v，获取版本失败", err.Error()))
	}

	// 获取模板
	oids, err := GetMibsAdapter(brand, version)
	if err != nil {
		global.Logger.Error("%v %v获取mib模板异常: %v", brand, version, err.Error())
		return nil, errors.New("暂未支持该品牌:" + brand + " version:" + version)
	}

	var cErr error
	timeOutCount := 0
	for i, oid := range oids {
		switch strings.ToUpper(oid.Method) {
		case "GET":
			lines, err := snmp_new.SnmpGet(client.SNMP, oid.Oid, ip)
			if err != nil {
				global.Logger.Error("设备%v, oid：%v 采集异常：%v", ip, oid.Oid, err.Error())
				if logic.IsNetTimeout(err) {
					timeOutCount++
					cErr = err
				}
			}
			if len(lines) > 0 {
				oids[i].Value = lines[0].Variable.String()
			}
		case "WALK":
			values := []string{}
			oidIndexs := []string{}
			lines, err := snmp_new.SnmpWalk(client.SNMP, oid.Oid, ip)
			if err != nil {
				global.Logger.Error("设备%v, oid：%v 采集异常：%v", ip, oid.Oid, err.Error())
				if logic.IsNetTimeout(err) {
					timeOutCount++
					cErr = err
				}
			}
			replaceOid := oid.Oid + "."
			for _, line := range lines {
				oidIndexs = append(oidIndexs, strings.Replace(line.Oid.String(), replaceOid, "", 1))
				values = append(values, line.Variable.String())
			}
			bytes, err := json.Marshal(values)

			if err != nil {
				global.Logger.Error("数据异常: %v", err.Error())
				oids[i].Value = "[]"
			} else {
				oids[i].Value = string(bytes)
			}
			oids[i].OidIndex = oidIndexs
		}
		// 错误次数超过限定，采集退出，不再消耗硬件资源
		if timeOutCount >= global.SnmpTimeOutCount {
			global.Logger.Warn("bad: %v %v %v %v", ip, "snmp采集错误", global.SnmpTimeOutCount, "次后退出，后面不再采集")
			return nil, cErr
		}
	}

	global.Logger.Debug("%v 采集信息: %v", ip, oids)
	return &gs_define.F5CollectInfo{
		oids,
		brand,
		series,
		model,
		map[string]int64{},
	}, nil
}

func GetMibsAdapter(brand, version string) ([]gs_define.OidInfo, error) {
	for _, name := range []string{version, "default"} {
		key := fmt.Sprintf("%v_%v", brand, name)
		NetworkOids.RLock()
		oids, ok := NetworkOids.m[key]
		NetworkOids.RUnlock()
		if ok {
			return deepCopy(oids), nil
		}
		mibPath := FindTemplate(brand, name)
		if mibPath == "" {
			continue
		}
		if gs_tool.IsFileExist(mibPath) {
			oids, err := snmp_new.GetOidInfo(mibPath)
			if err != nil {
				global.Logger.Error(err.Error())
			} else {
				template := strings.TrimPrefix(mibPath, global.MibBasePath)
				for i, _ := range oids {
					oids[i].Template = template
					if oids[i].EntPhysical != "" {
						oids[i].Method = "walk"
						oids[i].OidIndex = []string{}
					}
				}
				NetworkOids.Lock()
				NetworkOids.m[key] = oids
				NetworkOids.Unlock()
				return deepCopy(oids), nil
			}
		} else {
			global.Logger.Warn("%v Mib Template Is Not Exist", mibPath)
		}

	}
	return nil, fmt.Errorf("Not Find F5Oids [brand: %v version: %v ]", brand, version)
}

func deepCopy(oidInfo []gs_define.OidInfo) []gs_define.OidInfo {
	info := []gs_define.OidInfo{}
	bytes, err := json.Marshal(oidInfo)
	if err != nil {
		global.Logger.Error("deepCody error 【%v】", err.Error())
		return info
	}
	if err := json.Unmarshal(bytes, &info); err != nil {
		global.Logger.Error("deepCody error 【%v】", err.Error())
	}
	return info
}

// 查找
func FindTemplate(brand, sufix string) string {
	brand = strings.ToUpper(brand)
	sufix = strings.ToUpper(sufix)
	fs, err := ioutil.ReadDir(filepath.Join(global.MibBasePath, brand))
	if err != nil {
		global.Logger.Error(err.Error())
		return ""
	}
	names := []string{}
	for _, f := range fs {
		fName := f.Name()
		fName = strings.ToUpper(fName)
		fNameSufix := strings.TrimPrefix(fName, strings.ToUpper(brand)+"_")
		fNameSufix = strings.TrimSuffix(fNameSufix, ".YML")
		if strings.Contains(sufix, fNameSufix) {
			names = append(names, f.Name())
		}
	}
	if len(names) == 0 {
		return ""
	}

	maxLenName := ""
	for _, name := range names {
		if len(name) > len(maxLenName) {
			maxLenName = name
		}
	}

	return filepath.Join(global.MibBasePath, brand, maxLenName)
}

//检查节点网络状态
func setNetStatus(data *gs_define.F5CollectInfo) {
	defer logic.HanderPanic()

	if data == nil {
		return
	}

	oidMap := map[string]*gs_define.OidInfo{}
	for i, v := range data.Oids {
		oidMap[v.Item] = &data.Oids[i]
	}

	memberIPs := []string{}
	memberPorts := []string{}

	json.Unmarshal([]byte(oidMap["member_ip"].Value), &memberIPs)
	memberIPs = convertManyHexIP2IP(memberIPs)
	json.Unmarshal([]byte(oidMap["member_port"].Value), &memberPorts)

	size := len(memberIPs)
	netStatus := make([]int64, size)
	if len(memberPorts) == size {
		netStatus := make([]int64, size)
		wg := sync.WaitGroup{}
		wg.Add(size)
		for i := 0; i < size; i++ {

			go func(i int) {
				defer logic.HanderPanic()
				defer wg.Done()
				conn, err := net.DialTimeout("tcp", fmt.Sprintf("%v:%v", memberIPs[i], memberPorts[i]), 2*time.Second)
				if err != nil {
					return
				}
				conn.Close()
				netStatus[i] = 1
			}(i)

		}
		wg.Wait()
	}

	data.MemberNetStatus = map[string]int64{}
	for i := 0; i < size; i++ {
		data.MemberNetStatus[memberIPs[i]] = netStatus[i]
	}

}

func convertManyHexIP2IP(hexIPs []string) []string {
	if len(hexIPs) == 0 {
		return []string{}
	}
	list := []string{}
	for _, v := range hexIPs {
		list = append(list, convertHexIP2IP(v))
	}

	return list
}

// 转换hexIP to ip .如 2c:21:16:0b --> 44.33.22.11
func convertHexIP2IP(hexIP string) string {
	if len(hexIP) == 0 {
		return ""
	}

	target := []string{}
	src := strings.Split(hexIP, ":")
	if len(src) == 4 {
		for _, v := range src {
			m, _ := hex.DecodeString(v)
			target = append(target, fmt.Sprintf("%v", m[0]))
		}
	} else {
		global.Logger.Error("采集F5信息，转换IP失败，hexIP:%v", hexIP)
		return ""
	}

	return strings.Join(target, ".")
}
