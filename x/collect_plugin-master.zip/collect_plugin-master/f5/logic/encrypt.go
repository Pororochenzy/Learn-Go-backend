package logic

import (
	"collect_plugin/f5/global"
	"geesunn.com/encrypt"
)

// 解密密码
func EncryptPassword(password string) string {
	tempPass, err := encrypt.AesDecryptBase64(password, encrypt.EncryptDBKey)
	if err != nil {
		global.Logger.Error("密码【%v】解密异常：%v", password, err.Error())
	} else {
		password = tempPass
	}
	return password
}
