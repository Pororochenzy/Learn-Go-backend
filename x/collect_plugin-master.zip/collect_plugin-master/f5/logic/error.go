package logic

import (
	"net"
	"strings"
)

func IsNetTimeout(err error) bool {
	if err, ok := err.(net.Error); ok && err.Timeout() {
		return true
	}
	if strings.Contains(err.Error(), "i/o timeout") {
		return true
	}
	return false
}
