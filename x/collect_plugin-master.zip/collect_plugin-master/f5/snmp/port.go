package snmp

import (
	"encoding/json"
	"fmt"
	"collect_plugin/f5/global"
	"collect_plugin/f5/logic"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/toolkits/slice"

	gs_define "geesunn.com/define"
	"geesunn.com/snmpgo"
)

func check(after, before uint64) bool {
	return after >= before && after > 0 && before > 0
}

type unit struct {
	Name string
	Oid  string
	Vars snmpgo.VarBinds
}

type CollectPortInfo struct {
	IfUnits  []unit
	IfXUnits []unit
	Unixtime int64
}

var LastCollectPortInfo = struct {
	sync.RWMutex
	M map[string]CollectPortInfo
}{M: make(map[string]CollectPortInfo)}

func GetPortInfo2(obj *snmpgo.SNMP, ip string) ([]gs_define.NetworkPortInfo, error) {
	lastCollectUnix := int64(0)
	currCollectUnix := int64(0)

	collectPort := func(isCurrnet bool) (map[string]map[string]string, map[string]map[string]string, error) {

		parseUnits := func(units []unit) map[string]map[string]string {
			temp := map[string]map[string]string{}
			for _, unit := range units {
				temp[unit.Name] = map[string]string{}
				for _, varBind := range unit.Vars {
					index := strings.Replace(varBind.Oid.String(), unit.Oid+".", "", 1)
					temp[unit.Name][index] = varBind.Variable.String()
				}
			}
			return temp
		}

		if !isCurrnet {
			LastCollectPortInfo.RLock()
			unitInfo, ok := LastCollectPortInfo.M[ip]
			if ok {
				ifExtry := parseUnits(unitInfo.IfUnits)
				ifXExtry := parseUnits(unitInfo.IfXUnits)
				lastCollectUnix = unitInfo.Unixtime
				LastCollectPortInfo.RUnlock()
				return ifExtry, ifXExtry, nil
			}
			LastCollectPortInfo.RUnlock()
			lastCollectUnix = time.Now().UnixNano()
		} else {
			currCollectUnix = time.Now().UnixNano()
		}

		timeout := 0
		getPort := func(oids map[string]string) ([]unit, error) {
			units := []unit{}
			for name, oid := range oids {
				varBinds, err := SnmpWalk(obj, oid)
				if err != nil {
					global.Logger.Error("IP: %v 采集端口信息oid: %v异常: %v", ip, oid, err.Error())
					if logic.IsNetTimeout(err) {
						timeout++
					}
				}
				if timeout >= global.SnmpTimeOutCount {
					global.Logger.Warn("bad: %v %v %v %v", ip, "snmp采集错误", global.SnmpTimeOutCount, "次后退出，后面不再采集")
					return units, fmt.Errorf("snmp采集超时超过%v次后退出，后面不再采集", global.SnmpTimeOutCount)
				}
				units = append(units, unit{
					Name: name,
					Oid:  oid,
					Vars: varBinds,
				})
			}
			return units, nil
		}

		ifUnits, err := getPort(map[string]string{
			"ifIndex":        "1.3.6.1.2.1.2.2.1.1",
			"ifDescr":        "1.3.6.1.2.1.2.2.1.2",
			"ifType":         "1.3.6.1.2.1.2.2.1.3",
			"ifMtu":          "1.3.6.1.2.1.2.2.1.4",
			"ifSpeed":        "1.3.6.1.2.1.2.2.1.5",
			"ifPhysAddress":  "1.3.6.1.2.1.2.2.1.6",
			"ifLastChange":   "1.3.6.1.2.1.2.2.1.9",
			"ifInOctets":     "1.3.6.1.2.1.2.2.1.10",
			"ifInUcastPkts":  "1.3.6.1.2.1.2.2.1.11",
			"ifOutOctets":    "1.3.6.1.2.1.2.2.1.16",
			"ifOutUcastPkts": "1.3.6.1.2.1.2.2.1.17",
			"ifInDiscards":   "1.3.6.1.2.1.2.2.1.13",
			"ifInErrors":     "1.3.6.1.2.1.2.2.1.14",
			"ifOutDiscards":  "1.3.6.1.2.1.2.2.1.19",
			"ifOutErrors":    "1.3.6.1.2.1.2.2.1.20",
		})
		if err != nil {
			global.Logger.Error("IP: %v 不存在ifExtry,异常：%v", ip, err.Error())
			return nil, nil, err
		}

		ifXUnits, err := getPort(map[string]string{
			"ifName":                     "1.3.6.1.2.1.31.1.1.1.1",
			"ifHCInOctets":               "1.3.6.1.2.1.31.1.1.1.6",
			"ifHCInUcastPkts":            "1.3.6.1.2.1.31.1.1.1.7",
			"ifHCInMulticastPkts":        "1.3.6.1.2.1.31.1.1.1.8",
			"ifHCInBroadcastPkts":        "1.3.6.1.2.1.31.1.1.1.9",
			"ifHCOutOctets":              "1.3.6.1.2.1.31.1.1.1.10",
			"ifHCOutUcastPkts":           "1.3.6.1.2.1.31.1.1.1.11",
			"ifHCOutMulticastPkts":       "1.3.6.1.2.1.31.1.1.1.12",
			"ifHCOutBroadcastPkts":       "1.3.6.1.2.1.31.1.1.1.13",
			"ifHighSpeed":                "1.3.6.1.2.1.31.1.1.1.15",
			"ifPromiscuousMode":          "1.3.6.1.2.1.31.1.1.1.16",
			"ifConnectorPresent":         "1.3.6.1.2.1.31.1.1.1.17",
			"ifAlias":                    "1.3.6.1.2.1.31.1.1.1.18",
			"ifCounterDiscontinuityTime": "1.3.6.1.2.1.31.1.1.1.19",
		})
		if err != nil {
			global.Logger.Warn("IP: %v 不存在ifXExtry,异常：%v", ip, err.Error())
			return nil, nil, err
		}

		ifExtry := parseUnits(ifUnits)
		ifXExtry := parseUnits(ifXUnits)

		if isCurrnet {
			LastCollectPortInfo.Lock()
			LastCollectPortInfo.M[ip] = CollectPortInfo{
				IfUnits:  ifUnits,
				IfXUnits: ifXUnits,
				Unixtime: currCollectUnix,
			}
			LastCollectPortInfo.Unlock()
			ifBytes, _ := json.Marshal(ifExtry)
			ifXBytes, _ := json.Marshal(ifXExtry)
			global.Logger.Debug("IP %v, 采集的低端口信息：\n %v", ip, string(ifBytes))
			global.Logger.Debug("IP %v, 采集的高端口信息：\n %v", ip, string(ifXBytes))
		} else {
			time.Sleep(time.Duration(global.PortColDuration) * time.Second)
		}
		return ifExtry, ifXExtry, nil
	}

	ifExtry, ifXExtry, err := collectPort(false)
	if err != nil {
		global.Logger.Error("IP %v 采集端口异常： %v", ip, err.Error())
		return nil, err
	}

	ifExtryAfter, ifXExtryAfter, err := collectPort(true)
	if err != nil {
		global.Logger.Error("IP %v 采集端口异常： %v", ip, err.Error())
		return nil, err
	}

	duration := (currCollectUnix - lastCollectUnix) / 1000000

	ports := []gs_define.NetworkPortInfo{}
	for index, _ := range ifExtryAfter["ifIndex"] {
		for k, _ := range ifExtry {
			if _, ok := ifExtry[k][index]; !ok {
				ifExtry[k][index] = ""
			}
		}
		for k, _ := range ifExtryAfter {
			if _, ok := ifExtryAfter[k][index]; !ok {
				ifExtryAfter[k][index] = ""
			}
		}
		for k, _ := range ifXExtry {
			if _, ok := ifXExtry[k][index]; !ok {
				ifXExtry[k][index] = ""
			}
		}
		for k, _ := range ifXExtryAfter {
			if _, ok := ifXExtryAfter[k][index]; !ok {
				ifXExtryAfter[k][index] = ""
			}
		}
	}

	for index, _ := range ifExtryAfter["ifIndex"] {

		port := gs_define.NetworkPortInfo{
			IfIndex:       ifExtryAfter["ifIndex"][index],
			IfDescr:       ifExtryAfter["ifDescr"][index],
			IfType:        ifExtryAfter["ifType"][index],
			IfName:        ifXExtryAfter["ifName"][index],
			IfAlias:       ifXExtryAfter["ifAlias"][index],
			IfPhysAddress: ifExtryAfter["ifPhysAddress"][index],
		}
		if port.IfName == "" {
			port.IfName = ifExtryAfter["ifDescr"][index]
		}
		ifSpeed, _ := strconv.ParseUint(ifExtryAfter["ifSpeed"][index], 10, 64)
		if ifSpeed >= 4294967295 {
			// isHighIndex = true
			ifHSpeed, _ := strconv.ParseUint(ifXExtryAfter["ifHighSpeed"][index], 10, 64)
			port.IfSpeed = ifHSpeed * 1000000
		} else {
			port.IfSpeed = ifSpeed
		}

		// 判断是否为物理端口
		{
			port.IsVirtualPort = true

			if slice.ContainsString([]string{"6", "7", "11", "62", "69", "117"}, port.IfType) {
				port.IsVirtualPort = false
			}
		}

		// Octets
		ifHCInOctets, err := strconv.ParseUint(ifXExtry["ifHCInOctets"][index], 10, 64)
		if err == nil {

			ifHCOutOctets, _ := strconv.ParseUint(ifXExtry["ifHCOutOctets"][index], 10, 64)
			ifHCInOctetsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCInOctets"][index], 10, 64)
			ifHCOutOctetsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCOutOctets"][index], 10, 64)
			if check(ifHCInOctetsAfter, ifHCInOctets) {
				port.IfHCInOctets = ifHCInOctetsAfter
				port.IfHCInOctetsSpeed = (ifHCInOctetsAfter - ifHCInOctets) * 1000 / uint64(duration)
				port.IfHCInOctetsDelta = ifHCInOctetsAfter - ifHCInOctets
			}
			if check(ifHCOutOctetsAfter, ifHCOutOctets) {
				port.IfHCOutOctets = ifHCOutOctetsAfter
				port.IfHCOutOctetsSpeed = (ifHCOutOctetsAfter - ifHCOutOctets) * 1000 / uint64(duration)
				port.IfHCOutOctetsDelta = ifHCOutOctetsAfter - ifHCOutOctets
			}
			// UcastPkts
			ifHCInUcastPkts, _ := strconv.ParseUint(ifXExtry["ifHCInUcastPkts"][index], 10, 64)
			ifHCOutUcastPkts, _ := strconv.ParseUint(ifXExtry["ifHCOutUcastPkts"][index], 10, 64)
			ifHCInUcastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCInUcastPkts"][index], 10, 64)
			ifHCOutUcastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCOutUcastPkts"][index], 10, 64)
			if check(ifHCInUcastPktsAfter, ifHCInUcastPkts) {
				port.IfHCInUcastPkts = ifHCInUcastPktsAfter
				port.IfHCInUcastPktsSpeed = (ifHCInUcastPktsAfter - ifHCInUcastPkts) * 1000 / uint64(duration)
				port.IfHCInUcastPktsDelta = ifHCInUcastPktsAfter - ifHCInUcastPkts
			}
			if check(ifHCOutUcastPktsAfter, ifHCOutUcastPkts) {
				port.IfHCOutUcastPkts = ifHCOutUcastPktsAfter
				port.IfHCOutUcastPktsSpeed = (ifHCOutUcastPktsAfter - ifHCOutUcastPkts) * 1000 / uint64(duration)
				port.IfHCOutUcastPktsDelta = ifHCOutUcastPktsAfter - ifHCOutUcastPkts
			}
		} else {
			global.Logger.Warn("IP %v index %v ifName %v ifHCInOctets is err %v", ip, index, port.IfName, err.Error())
			ifInOctets, _ := strconv.ParseUint(ifExtry["ifInOctets"][index], 10, 64)
			ifOutOctets, _ := strconv.ParseUint(ifExtry["ifOutOctets"][index], 10, 64)
			ifInOctetsAfter, _ := strconv.ParseUint(ifExtryAfter["ifInOctets"][index], 10, 64)
			ifOutOctetsAfter, _ := strconv.ParseUint(ifExtryAfter["ifOutOctets"][index], 10, 64)
			if check(ifInOctetsAfter, ifInOctets) {
				port.IfHCInOctets = ifInOctetsAfter
				port.IfHCInOctetsSpeed = (ifInOctetsAfter - ifInOctets) * 1000 / uint64(duration)
				port.IfHCInOctetsDelta = ifInOctetsAfter - ifInOctets
			}
			if check(ifOutOctetsAfter, ifOutOctets) {
				port.IfHCOutOctets = ifOutOctetsAfter
				port.IfHCOutOctetsSpeed = (ifOutOctetsAfter - ifOutOctets) * 1000 / uint64(duration)
				port.IfHCOutOctetsDelta = ifOutOctetsAfter - ifOutOctets
			}
			// UcastPkts
			ifInUcastPkts, _ := strconv.ParseUint(ifExtry["ifInUcastPkts"][index], 10, 64)
			ifOutUcastPkts, _ := strconv.ParseUint(ifExtry["ifOutUcastPkts"][index], 10, 64)
			ifInUcastPktsAfter, _ := strconv.ParseUint(ifExtryAfter["ifInUcastPkts"][index], 10, 64)
			ifOutUcastPktsAfter, _ := strconv.ParseUint(ifExtryAfter["ifOutUcastPkts"][index], 10, 64)
			if check(ifInUcastPktsAfter, ifInUcastPkts) {
				port.IfHCInUcastPkts = ifInUcastPktsAfter
				port.IfHCInUcastPktsSpeed = (ifInUcastPktsAfter - ifInUcastPkts) * 1000 / uint64(duration)
				port.IfHCInUcastPktsDelta = ifInUcastPktsAfter - ifInUcastPkts
			}
			if check(ifOutUcastPktsAfter, ifOutUcastPkts) {
				port.IfHCOutUcastPkts = ifOutUcastPktsAfter
				port.IfHCOutUcastPktsSpeed = (ifOutUcastPktsAfter - ifOutUcastPkts) * 1000 / uint64(duration)
				port.IfHCOutUcastPktsDelta = ifOutUcastPktsAfter - ifOutUcastPkts
			}
		}

		// MulticastPkts
		ifHCInMulticastPkts, _ := strconv.ParseUint(ifXExtry["ifHCInMulticastPkts"][index], 10, 64)
		ifHCOutMulticastPkts, _ := strconv.ParseUint(ifXExtry["ifHCOutMulticastPkts"][index], 10, 64)
		ifHCInMulticastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCInMulticastPkts"][index], 10, 64)
		ifHCOutMulticastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCOutMulticastPkts"][index], 10, 64)
		if check(ifHCInMulticastPktsAfter, ifHCInMulticastPkts) {
			port.IfHCInMulticastPkts = ifHCInMulticastPktsAfter
			port.IfHCInMulticastPktsSpeed = (ifHCInMulticastPktsAfter - ifHCInMulticastPkts) * 1000 / uint64(duration)
			port.IfHCInMulticastPktsDelta = ifHCInMulticastPktsAfter - ifHCInMulticastPkts
		}
		if check(ifHCOutMulticastPktsAfter, ifHCOutMulticastPkts) {
			port.IfHCOutMulticastPkts = ifHCOutMulticastPktsAfter
			port.IfHCOutMulticastPktsSpeed = (ifHCOutMulticastPktsAfter - ifHCOutMulticastPkts) * 1000 / uint64(duration)
			port.IfHCOutMulticastPktsDelta = ifHCOutMulticastPktsAfter - ifHCOutMulticastPkts
		}
		// BroadcastPkts
		ifHCInBroadcastPkts, _ := strconv.ParseUint(ifXExtry["ifHCInBroadcastPkts"][index], 10, 64)
		ifHCOutBroadcastPkts, _ := strconv.ParseUint(ifXExtry["ifHCOutBroadcastPkts"][index], 10, 64)
		ifHCInBroadcastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCInBroadcastPkts"][index], 10, 64)
		ifHCOutBroadcastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCOutBroadcastPkts"][index], 10, 64)
		if check(ifHCInBroadcastPktsAfter, ifHCInBroadcastPkts) {
			port.IfHCInBroadcastPkts = ifHCInBroadcastPktsAfter
			port.IfHCInBroadcastPktsSpeed = (ifHCInBroadcastPktsAfter - ifHCInBroadcastPkts) * 1000 / uint64(duration)
			port.IfHCInBroadcastPktsDelta = ifHCInBroadcastPktsAfter - ifHCInBroadcastPkts
		}
		if check(ifHCOutBroadcastPktsAfter, ifHCOutBroadcastPkts) {
			port.IfHCOutBroadcastPkts = ifHCOutBroadcastPktsAfter
			port.IfHCOutBroadcastPktsSpeed = (ifHCOutBroadcastPktsAfter - ifHCOutBroadcastPkts) * 1000 / uint64(duration)
			port.IfHCOutBroadcastPktsDelta = ifHCOutBroadcastPktsAfter - ifHCOutBroadcastPkts
		}
		// Discards
		ifInDiscards, _ := strconv.ParseUint(ifExtry["ifInDiscards"][index], 10, 64)
		ifOutDiscards, _ := strconv.ParseUint(ifExtry["ifOutDiscards"][index], 10, 64)
		ifInDiscardsAfter, _ := strconv.ParseUint(ifExtryAfter["ifInDiscards"][index], 10, 64)
		ifOutDiscardsAfter, _ := strconv.ParseUint(ifExtryAfter["ifOutDiscards"][index], 10, 64)
		if check(ifInDiscardsAfter, ifInDiscards) {
			port.IfInDiscards = ifInDiscardsAfter
			port.IfInDiscardsSpeed = (ifInDiscardsAfter - ifInDiscards) * 1000 / uint64(duration)
			port.IfInDiscardsDelta = ifInDiscardsAfter - ifInDiscards
		}
		if check(ifOutDiscardsAfter, ifOutDiscards) {
			port.IfOutDiscards = ifOutDiscardsAfter
			port.IfOutDiscardsSpeed = (ifOutDiscardsAfter - ifOutDiscards) * 1000 / uint64(duration)
			port.IfOutDiscardsDelta = ifOutDiscardsAfter - ifOutDiscards
		}
		// Errors
		ifInErrors, _ := strconv.ParseUint(ifExtry["ifInErrors"][index], 10, 64)
		ifOutErrors, _ := strconv.ParseUint(ifExtry["ifOutErrors"][index], 10, 64)
		ifInErrorsAfter, _ := strconv.ParseUint(ifExtryAfter["ifInErrors"][index], 10, 64)
		ifOutErrorsAfter, _ := strconv.ParseUint(ifExtryAfter["ifOutErrors"][index], 10, 64)
		if check(ifInErrorsAfter, ifInErrors) {
			port.IfInErrors = ifInErrorsAfter
			port.IfInErrorsSpeed = (ifInErrorsAfter - ifInErrors) * 1000 / uint64(duration)
			port.IfInErrorsDelta = ifInErrorsAfter - ifInErrors
		}
		if check(ifOutErrorsAfter, ifOutErrors) {
			port.IfOutErrors = ifOutErrorsAfter
			port.IfOutErrorsSpeed = (ifOutErrorsAfter - ifOutErrors) * 1000 / uint64(duration)
			port.IfOutErrorsDelta = ifOutErrorsAfter - ifOutErrors
		}
		ports = append(ports, port)
	}

	return ports, nil
}

func GetPortForIntime(obj *snmpgo.SNMP, ip string) ([]gs_define.NetworkPortInfo, error) {
	lastCollectUnix := int64(0)
	currCollectUnix := int64(0)

	collectPort := func(isCurrnet bool) (map[string]map[string]string, map[string]map[string]string, error) {

		parseUnits := func(units []unit) map[string]map[string]string {
			temp := map[string]map[string]string{}
			for _, unit := range units {
				temp[unit.Name] = map[string]string{}
				for _, varBind := range unit.Vars {
					index := strings.Replace(varBind.Oid.String(), unit.Oid+".", "", 1)
					temp[unit.Name][index] = varBind.Variable.String()
				}
			}
			return temp
		}

		if !isCurrnet {
			LastCollectPortInfo.RLock()
			unitInfo, ok := LastCollectPortInfo.M[ip]
			if ok {
				ifExtry := parseUnits(unitInfo.IfUnits)
				ifXExtry := parseUnits(unitInfo.IfXUnits)
				lastCollectUnix = unitInfo.Unixtime
				LastCollectPortInfo.RUnlock()
				return ifExtry, ifXExtry, nil
			}
			LastCollectPortInfo.RUnlock()
			return nil, nil, nil
		} else {
			currCollectUnix = time.Now().UnixNano()
		}

		timeout := 0
		getPort := func(oids map[string]string) ([]unit, error) {
			units := []unit{}
			for name, oid := range oids {
				varBinds, err := SnmpWalk(obj, oid)
				if err != nil {
					global.Logger.Error("IP: %v 采集端口信息oid: %v异常: %v", ip, oid, err.Error())
					if logic.IsNetTimeout(err) {
						timeout++
					}
				}
				if timeout >= global.SnmpTimeOutCount {
					global.Logger.Warn("bad: %v %v %v %v", ip, "snmp采集错误", global.SnmpTimeOutCount, "次后退出，后面不再采集")
					return units, fmt.Errorf("snmp采集超时超过%v次后退出，后面不再采集", global.SnmpTimeOutCount)
				}
				units = append(units, unit{
					Name: name,
					Oid:  oid,
					Vars: varBinds,
				})
			}
			return units, nil
		}

		ifUnits, err := getPort(map[string]string{
			"ifIndex":        "1.3.6.1.2.1.2.2.1.1",
			"ifDescr":        "1.3.6.1.2.1.2.2.1.2",
			"ifType":         "1.3.6.1.2.1.2.2.1.3",
			"ifMtu":          "1.3.6.1.2.1.2.2.1.4",
			"ifSpeed":        "1.3.6.1.2.1.2.2.1.5",
			"ifPhysAddress":  "1.3.6.1.2.1.2.2.1.6",
			"ifAdminStatus":  "1.3.6.1.2.1.2.2.1.7",
			"ifOperStatus":   "1.3.6.1.2.1.2.2.1.8",
			"ifLastChange":   "1.3.6.1.2.1.2.2.1.9",
			"ifInOctets":     "1.3.6.1.2.1.2.2.1.10",
			"ifInUcastPkts":  "1.3.6.1.2.1.2.2.1.11",
			"ifOutOctets":    "1.3.6.1.2.1.2.2.1.16",
			"ifOutUcastPkts": "1.3.6.1.2.1.2.2.1.17",
			"ifInDiscards":   "1.3.6.1.2.1.2.2.1.13",
			"ifInErrors":     "1.3.6.1.2.1.2.2.1.14",
			"ifOutDiscards":  "1.3.6.1.2.1.2.2.1.19",
			"ifOutErrors":    "1.3.6.1.2.1.2.2.1.20",
		})
		if err != nil {
			global.Logger.Error("IP: %v 不存在ifExtry,异常：%v", ip, err.Error())
			return nil, nil, err
		}

		ifXUnits, err := getPort(map[string]string{
			"ifName":                     "1.3.6.1.2.1.31.1.1.1.1",
			"ifHCInOctets":               "1.3.6.1.2.1.31.1.1.1.6",
			"ifHCInUcastPkts":            "1.3.6.1.2.1.31.1.1.1.7",
			"ifHCInMulticastPkts":        "1.3.6.1.2.1.31.1.1.1.8",
			"ifHCInBroadcastPkts":        "1.3.6.1.2.1.31.1.1.1.9",
			"ifHCOutOctets":              "1.3.6.1.2.1.31.1.1.1.10",
			"ifHCOutUcastPkts":           "1.3.6.1.2.1.31.1.1.1.11",
			"ifHCOutMulticastPkts":       "1.3.6.1.2.1.31.1.1.1.12",
			"ifHCOutBroadcastPkts":       "1.3.6.1.2.1.31.1.1.1.13",
			"ifHighSpeed":                "1.3.6.1.2.1.31.1.1.1.15",
			"ifPromiscuousMode":          "1.3.6.1.2.1.31.1.1.1.16",
			"ifConnectorPresent":         "1.3.6.1.2.1.31.1.1.1.17",
			"ifAlias":                    "1.3.6.1.2.1.31.1.1.1.18",
			"ifCounterDiscontinuityTime": "1.3.6.1.2.1.31.1.1.1.19",
		})
		if err != nil {
			global.Logger.Warn("IP: %v 不存在ifXExtry,异常：%v", ip, err.Error())
			return nil, nil, err
		}

		ifExtry := parseUnits(ifUnits)
		ifXExtry := parseUnits(ifXUnits)
		if !isCurrnet {
			time.Sleep(time.Duration(global.PortColDuration) * time.Second)
		}
		return ifExtry, ifXExtry, nil
	}

	ifExtry, ifXExtry, err := collectPort(false)
	if err != nil {
		global.Logger.Error("IP %v 采集端口异常： %v", ip, err.Error())
		return nil, err
	}

	ifExtryAfter, ifXExtryAfter, err := collectPort(true)
	if err != nil {
		global.Logger.Error("IP %v 采集端口异常： %v", ip, err.Error())
		return nil, err
	}

	duration := int64(0)
	if lastCollectUnix > 0 {
		duration = (currCollectUnix - lastCollectUnix) / 1000000
	}

	ports := []gs_define.NetworkPortInfo{}
	for index, _ := range ifExtryAfter["ifIndex"] {
		for k, _ := range ifExtry {
			if _, ok := ifExtry[k][index]; !ok {
				ifExtry[k][index] = ""
			}
		}
		for k, _ := range ifExtryAfter {
			if _, ok := ifExtryAfter[k][index]; !ok {
				ifExtryAfter[k][index] = ""
			}
		}
		for k, _ := range ifXExtry {
			if _, ok := ifXExtry[k][index]; !ok {
				ifXExtry[k][index] = ""
			}
		}
		for k, _ := range ifXExtryAfter {
			if _, ok := ifXExtryAfter[k][index]; !ok {
				ifXExtryAfter[k][index] = ""
			}
		}
	}
	for index, _ := range ifExtryAfter["ifIndex"] {

		port := gs_define.NetworkPortInfo{
			IfIndex:       ifExtryAfter["ifIndex"][index],
			IfName:        ifXExtryAfter["ifName"][index],
			IfAlias:       ifXExtryAfter["ifAlias"][index],
			IfPhysAddress: ifExtryAfter["ifPhysAddress"][index],
		}
		if port.IfName == "" {
			port.IfName = ifExtryAfter["ifDescr"][index]
		}
		if strings.Contains(ifExtryAfter["ifAdminStatus"][index], "1") {
			port.IfAdminStatus = 1
		} else {
			port.IfAdminStatus = 0
		}
		if strings.Contains(ifExtryAfter["ifOperStatus"][index], "1") {
			port.IfOperStatus = 1
		} else {
			port.IfOperStatus = 0
		}
		ifSpeed, _ := strconv.ParseUint(ifExtryAfter["ifSpeed"][index], 10, 64)
		if ifSpeed >= 4294967295 {
			// isHighIndex = true
			ifHSpeed, _ := strconv.ParseUint(ifXExtryAfter["ifHighSpeed"][index], 10, 64)
			port.IfSpeed = ifHSpeed * 1000000
		} else {
			port.IfSpeed = ifSpeed
		}
		port.IsVirtualPort = true
		for _, tag := range []string{"gigabitethernet", "ethernet", "gi", "xgigabitethernet", "ten-gigabitethernet", "fastethernet", "ge", "eth"} {
			if strings.HasPrefix(strings.ToLower(port.IfName), tag) {
				port.IsVirtualPort = false
				break
			}
		}

		if duration == 0 {
			ports = append(ports, port)
			continue
		}

		// Octets
		ifHCInOctets, err := strconv.ParseUint(ifXExtry["ifHCInOctets"][index], 10, 64)
		if err == nil {

			ifHCOutOctets, _ := strconv.ParseUint(ifXExtry["ifHCOutOctets"][index], 10, 64)
			ifHCInOctetsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCInOctets"][index], 10, 64)
			ifHCOutOctetsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCOutOctets"][index], 10, 64)
			if check(ifHCInOctetsAfter, ifHCInOctets) {
				port.IfHCInOctets = ifHCInOctetsAfter
				port.IfHCInOctetsSpeed = (ifHCInOctetsAfter - ifHCInOctets) * 1000 / uint64(duration)
				port.IfHCInOctetsDelta = ifHCInOctetsAfter - ifHCInOctets
			}
			if check(ifHCOutOctetsAfter, ifHCOutOctets) {
				port.IfHCOutOctets = ifHCOutOctetsAfter
				port.IfHCOutOctetsSpeed = (ifHCOutOctetsAfter - ifHCOutOctets) * 1000 / uint64(duration)
				port.IfHCOutOctetsDelta = ifHCOutOctetsAfter - ifHCOutOctets
			}
			// UcastPkts
			ifHCInUcastPkts, _ := strconv.ParseUint(ifXExtry["ifHCInUcastPkts"][index], 10, 64)
			ifHCOutUcastPkts, _ := strconv.ParseUint(ifXExtry["ifHCOutUcastPkts"][index], 10, 64)
			ifHCInUcastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCInUcastPkts"][index], 10, 64)
			ifHCOutUcastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCOutUcastPkts"][index], 10, 64)
			if check(ifHCInUcastPktsAfter, ifHCInUcastPkts) {
				port.IfHCInUcastPkts = ifHCInUcastPktsAfter
				port.IfHCInUcastPktsSpeed = (ifHCInUcastPktsAfter - ifHCInUcastPkts) * 1000 / uint64(duration)
				port.IfHCInUcastPktsDelta = ifHCInUcastPktsAfter - ifHCInUcastPkts
			}
			if check(ifHCOutUcastPktsAfter, ifHCOutUcastPkts) {
				port.IfHCOutUcastPkts = ifHCOutUcastPktsAfter
				port.IfHCOutUcastPktsSpeed = (ifHCOutUcastPktsAfter - ifHCOutUcastPkts) * 1000 / uint64(duration)
				port.IfHCOutUcastPktsDelta = ifHCOutUcastPktsAfter - ifHCOutUcastPkts
			}
		} else {
			global.Logger.Warn("IP %v index %v ifName %v ifHCInOctets is err %v", ip, index, port.IfName, err.Error())
			ifInOctets, _ := strconv.ParseUint(ifExtry["ifInOctets"][index], 10, 64)
			ifOutOctets, _ := strconv.ParseUint(ifExtry["ifOutOctets"][index], 10, 64)
			ifInOctetsAfter, _ := strconv.ParseUint(ifExtryAfter["ifInOctets"][index], 10, 64)
			ifOutOctetsAfter, _ := strconv.ParseUint(ifExtryAfter["ifOutOctets"][index], 10, 64)
			if check(ifInOctetsAfter, ifInOctets) {
				port.IfHCInOctets = ifInOctetsAfter
				port.IfHCInOctetsSpeed = (ifInOctetsAfter - ifInOctets) * 1000 / uint64(duration)
				port.IfHCInOctetsDelta = ifInOctetsAfter - ifInOctets
			}
			if check(ifOutOctetsAfter, ifOutOctets) {
				port.IfHCOutOctets = ifOutOctetsAfter
				port.IfHCOutOctetsSpeed = (ifOutOctetsAfter - ifOutOctets) * 1000 / uint64(duration)
				port.IfHCOutOctetsDelta = ifOutOctetsAfter - ifOutOctets
			}
			// UcastPkts
			ifInUcastPkts, _ := strconv.ParseUint(ifExtry["ifInUcastPkts"][index], 10, 64)
			ifOutUcastPkts, _ := strconv.ParseUint(ifExtry["ifOutUcastPkts"][index], 10, 64)
			ifInUcastPktsAfter, _ := strconv.ParseUint(ifExtryAfter["ifInUcastPkts"][index], 10, 64)
			ifOutUcastPktsAfter, _ := strconv.ParseUint(ifExtryAfter["ifOutUcastPkts"][index], 10, 64)
			if check(ifInUcastPktsAfter, ifInUcastPkts) {
				port.IfHCInUcastPkts = ifInUcastPktsAfter
				port.IfHCInUcastPktsSpeed = (ifInUcastPktsAfter - ifInUcastPkts) * 1000 / uint64(duration)
				port.IfHCInUcastPktsDelta = ifInUcastPktsAfter - ifInUcastPkts
			}
			if check(ifOutUcastPktsAfter, ifOutUcastPkts) {
				port.IfHCOutUcastPkts = ifOutUcastPktsAfter
				port.IfHCOutUcastPktsSpeed = (ifOutUcastPktsAfter - ifOutUcastPkts) * 1000 / uint64(duration)
				port.IfHCOutUcastPktsDelta = ifOutUcastPktsAfter - ifOutUcastPkts
			}
		}

		// MulticastPkts
		ifHCInMulticastPkts, _ := strconv.ParseUint(ifXExtry["ifHCInMulticastPkts"][index], 10, 64)
		ifHCOutMulticastPkts, _ := strconv.ParseUint(ifXExtry["ifHCOutMulticastPkts"][index], 10, 64)
		ifHCInMulticastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCInMulticastPkts"][index], 10, 64)
		ifHCOutMulticastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCOutMulticastPkts"][index], 10, 64)
		if check(ifHCInMulticastPktsAfter, ifHCInMulticastPkts) {
			port.IfHCInMulticastPkts = ifHCInMulticastPktsAfter
			port.IfHCInMulticastPktsSpeed = (ifHCInMulticastPktsAfter - ifHCInMulticastPkts) * 1000 / uint64(duration)
			port.IfHCInMulticastPktsDelta = ifHCInMulticastPktsAfter - ifHCInMulticastPkts
		}
		if check(ifHCOutMulticastPktsAfter, ifHCOutMulticastPkts) {
			port.IfHCOutMulticastPkts = ifHCOutMulticastPktsAfter
			port.IfHCOutMulticastPktsSpeed = (ifHCOutMulticastPktsAfter - ifHCOutMulticastPkts) * 1000 / uint64(duration)
			port.IfHCOutMulticastPktsDelta = ifHCOutMulticastPktsAfter - ifHCOutMulticastPkts
		}
		// BroadcastPkts
		ifHCInBroadcastPkts, _ := strconv.ParseUint(ifXExtry["ifHCInBroadcastPkts"][index], 10, 64)
		ifHCOutBroadcastPkts, _ := strconv.ParseUint(ifXExtry["ifHCOutBroadcastPkts"][index], 10, 64)
		ifHCInBroadcastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCInBroadcastPkts"][index], 10, 64)
		ifHCOutBroadcastPktsAfter, _ := strconv.ParseUint(ifXExtryAfter["ifHCOutBroadcastPkts"][index], 10, 64)
		if check(ifHCInBroadcastPktsAfter, ifHCInBroadcastPkts) {
			port.IfHCInBroadcastPkts = ifHCInBroadcastPktsAfter
			port.IfHCInBroadcastPktsSpeed = (ifHCInBroadcastPktsAfter - ifHCInBroadcastPkts) * 1000 / uint64(duration)
			port.IfHCInBroadcastPktsDelta = ifHCInBroadcastPktsAfter - ifHCInBroadcastPkts
		}
		if check(ifHCOutBroadcastPktsAfter, ifHCOutBroadcastPkts) {
			port.IfHCOutBroadcastPkts = ifHCOutBroadcastPktsAfter
			port.IfHCOutBroadcastPktsSpeed = (ifHCOutBroadcastPktsAfter - ifHCOutBroadcastPkts) * 1000 / uint64(duration)
			port.IfHCOutBroadcastPktsDelta = ifHCOutBroadcastPktsAfter - ifHCOutBroadcastPkts
		}
		// Discards
		ifInDiscards, _ := strconv.ParseUint(ifExtry["ifInDiscards"][index], 10, 64)
		ifOutDiscards, _ := strconv.ParseUint(ifExtry["ifOutDiscards"][index], 10, 64)
		ifInDiscardsAfter, _ := strconv.ParseUint(ifExtryAfter["ifInDiscards"][index], 10, 64)
		ifOutDiscardsAfter, _ := strconv.ParseUint(ifExtryAfter["ifOutDiscards"][index], 10, 64)
		if check(ifInDiscardsAfter, ifInDiscards) {
			port.IfInDiscards = ifInDiscardsAfter
			port.IfInDiscardsSpeed = (ifInDiscardsAfter - ifInDiscards) * 1000 / uint64(duration)
			port.IfInDiscardsDelta = ifInDiscardsAfter - ifInDiscards
		}
		if check(ifOutDiscardsAfter, ifOutDiscards) {
			port.IfOutDiscards = ifOutDiscardsAfter
			port.IfOutDiscardsSpeed = (ifOutDiscardsAfter - ifOutDiscards) * 1000 / uint64(duration)
			port.IfOutDiscardsDelta = ifOutDiscardsAfter - ifOutDiscards
		}
		// Errors
		ifInErrors, _ := strconv.ParseUint(ifExtry["ifInErrors"][index], 10, 64)
		ifOutErrors, _ := strconv.ParseUint(ifExtry["ifOutErrors"][index], 10, 64)
		ifInErrorsAfter, _ := strconv.ParseUint(ifExtryAfter["ifInErrors"][index], 10, 64)
		ifOutErrorsAfter, _ := strconv.ParseUint(ifExtryAfter["ifOutErrors"][index], 10, 64)
		if check(ifInErrorsAfter, ifInErrors) {
			port.IfInErrors = ifInErrorsAfter
			port.IfInErrorsSpeed = (ifInErrorsAfter - ifInErrors) * 1000 / uint64(duration)
			port.IfInErrorsDelta = ifInErrorsAfter - ifInErrors
		}
		if check(ifOutErrorsAfter, ifOutErrors) {
			port.IfOutErrors = ifOutErrorsAfter
			port.IfOutErrorsSpeed = (ifOutErrorsAfter - ifOutErrors) * 1000 / uint64(duration)
			port.IfOutErrorsDelta = ifOutErrorsAfter - ifOutErrors
		}
		ports = append(ports, port)
	}

	return ports, nil
}
