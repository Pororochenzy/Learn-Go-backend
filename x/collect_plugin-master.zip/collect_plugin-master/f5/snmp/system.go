package snmp

import (
	"collect_plugin/f5/define"
	"collect_plugin/f5/global"
	"fmt"
	"strings"

	"geesunn.com/snmpgo"
)

// 设备类型, 交换机、路由器、打印机、一般主机
const (
	DEVTYPE_SWITCH  = 1
	DEVTYPE_ROUTER  = 2
	DEVTYPE_PRINTER = 3
	DEVTYPE_SVR     = 4
)

func CheckDeviceType(obj *snmpgo.SNMP) []int {
	types := []int{}
	// 检查是否为打印机
	{
		vbs, err := SnmpWalk(obj, "1.3.6.1.2.1.43")
		if err != nil {
			global.Logger.Error(err.Error())
		} else {
			if len(vbs) > 0 {
				types = append(types, DEVTYPE_PRINTER)
			}
		}
	}
	// 检测是否为主机
	{
		vbs, err := SnmpWalk(obj, "1.3.6.1.2.1.25")
		if err != nil {
			global.Logger.Error(err.Error())
		} else {
			if len(vbs) > 0 {
				types = append(types, DEVTYPE_SVR)
			}
		}
	}
	// 检查是否为路由器
	{
		vbs, err := SnmpWalk(obj, "1.3.6.1.2.1.4.1")
		if err != nil {
			global.Logger.Error(err.Error())
		} else {
			for _, item := range vbs {
				if item.Variable.String() == "1" {
					types = append(types, DEVTYPE_ROUTER)
					break
				}
			}
		}
	}
	// 检查是否为交换机
	{
		vbs, err := SnmpWalk(obj, "1.3.6.1.2.1.17.4.3")
		if err != nil {
			global.Logger.Error(err.Error())
		} else {
			if len(vbs) > 0 {
				types = append(types, DEVTYPE_SWITCH)
			}
		}
	}
	return types
}

/*系统描述*/
func GetSysDesc(obj *snmpgo.SNMP, oidInfo define.OidInfo) (string, error) {
	return GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
}

/*系统名称*/
func GetSysName(obj *snmpgo.SNMP, oidInfo define.OidInfo) (string, error) {
	return GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
}

/*系统运行时长*/
func GetSysUpTime(obj *snmpgo.SNMP, oidInfo define.OidInfo) (string, error) {
	return GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
}

/*系统型号*/
func GetSysModel(obj *snmpgo.SNMP, oidInfo define.OidInfo) (string, error) {
	model, err := GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
	if err != nil {
		return model, err
	}
	model = SNHex2str(model)
	return model, err
}

/*设备安装的物理位置 （记录在/etc/snmp/snmpd.conf）*/
func GetHostLocation(obj *snmpgo.SNMP, oidInfo define.OidInfo) (string, error) {
	return GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
}

/* 设备品牌 */
func GetMfgName(obj *snmpgo.SNMP, oidInfo define.OidInfo) (string, error) {
	return GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
}

// SN十六进制转字符串，如果不为16进制，返回原字符串
func SNHex2str(sn string) string {
	hexSN := strings.Split(sn, ":")
	if len(hexSN) > 5 {
		args := []interface{}{}
		formats := []string{}
		for range hexSN {
			var arg string
			args = append(args, &arg)
			formats = append(formats, "%x")
		}
		fmt.Sscanf(sn, strings.Join(formats, ":"), args...)
		values := []string{}
		for _, arg := range args {
			values = append(values, *arg.(*string))
		}
		return strings.Join(values, "")
	}
	return sn
}

/* 设备序列号 */
func GetSerialNumber(obj *snmpgo.SNMP, oidInfo define.OidInfo) (sn string, err error) {
	sn, err = GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
	sn = SNHex2str(sn)
	return sn, err
}

/*软件版本*/
func GetSoftwareVer(obj *snmpgo.SNMP, oidInfo define.OidInfo) (string, error) {
	return GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
}

/*设备系统名称*/
func GetSysHostName(obj *snmpgo.SNMP, oidInfo define.OidInfo) (string, error) {
	hostname, err := GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
	hostname = SNHex2str(hostname)
	return hostname, err
}
