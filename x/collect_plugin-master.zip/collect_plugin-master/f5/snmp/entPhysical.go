package snmp

import (
	"collect_plugin/f5/global"
	"strings"

	"geesunn.com/snmpgo"
)

var (
	entPhysicalOids = map[string]string{
		"entPhysicalIndex":        "1.3.6.1.2.1.47.1.1.1.1.1",
		"entPhysicalDescr":        "1.3.6.1.2.1.47.1.1.1.1.2",
		"entPhysicalVendorType":   "1.3.6.1.2.1.47.1.1.1.1.3",
		"entPhysicalContainedIn":  "1.3.6.1.2.1.47.1.1.1.1.4",
		"entPhysicalClass":        "1.3.6.1.2.1.47.1.1.1.1.5",
		"entPhysicalParentRelPos": "1.3.6.1.2.1.47.1.1.1.1.6",
		"entPhysicalName":         "1.3.6.1.2.1.47.1.1.1.1.7",
		"entPhysicalHardwareRev":  "1.3.6.1.2.1.47.1.1.1.1.8",
		"entPhysicalFirmwareRev":  "1.3.6.1.2.1.47.1.1.1.1.9",
		"entPhysicalSoftwareRev":  "1.3.6.1.2.1.47.1.1.1.1.10",
		"entPhysicalSerialNum":    "1.3.6.1.2.1.47.1.1.1.1.11",
		"entPhysicalMfgName":      "1.3.6.1.2.1.47.1.1.1.1.12",
		"entPhysicalModelName":    "1.3.6.1.2.1.47.1.1.1.1.13",
		"entPhysicalAlias":        "1.3.6.1.2.1.47.1.1.1.1.14",
		"entPhysicalAssetID":      "1.3.6.1.2.1.47.1.1.1.1.15",
		"entPhysicalIsFRU":        "1.3.6.1.2.1.47.1.1.1.1.16",
		"entPhysicalMfgDate":      "1.3.6.1.2.1.47.1.1.1.1.17",
		"entPhysicalUris":         "1.3.6.1.2.1.47.1.1.1.1.18",
	}
	enPhysicalStatus = map[string]string{
		"1":  "other",
		"2":  "unknown",
		"3":  "chassis",
		"4":  "backplane",
		"5":  "container",
		"6":  "powerSupply",
		"7":  "fan",
		"8":  "sensor",
		"9":  "module",
		"10": "port",
		"11": "stack",
		"12": "cpu",
	}
)

// 获取snmp硬件信息
func GetEntPhysical(obj *snmpgo.SNMP) (map[string][]map[string]string, error) {
	walkData := map[string]snmpgo.VarBinds{}
	for name, oid := range map[string]string{
		"entPhysicalDescr":       entPhysicalOids["entPhysicalDescr"],
		"entPhysicalClass":       entPhysicalOids["entPhysicalClass"],
		"entPhysicalName":        entPhysicalOids["entPhysicalName"],
		"entPhysicalSerialNum":   entPhysicalOids["entPhysicalSerialNum"],
		"entPhysicalSoftwareRev": entPhysicalOids["entPhysicalSoftwareRev"],
	} {
		varBinds, err := SnmpWalk(obj, oid)
		if err != nil {
			return nil, err
		}
		walkData[name] = varBinds
	}

	// global.Logger.Debug("%v", walkData)
	ep := map[string][]map[string]string{}

	for i, varBind := range walkData["entPhysicalClass"] {
		typ := varBind.Variable.String()
		tmps := strings.Split(varBind.Oid.String(), ".")
		index := tmps[len(tmps)-1]
		if v, ok := enPhysicalStatus[typ]; ok {
			if _, ok := ep[v]; !ok {
				ep[v] = []map[string]string{}
			}
			ep[v] = append(ep[v], map[string]string{
				"entPhysicalName":        walkData["entPhysicalName"][i].Variable.String(),
				"entPhysicalDescr":       walkData["entPhysicalDescr"][i].Variable.String(),
				"entPhysicalClass":       walkData["entPhysicalClass"][i].Variable.String(),
				"entPhysicalSerialNum":   walkData["entPhysicalSerialNum"][i].Variable.String(),
				"entPhysicalSoftwareRev": walkData["entPhysicalSoftwareRev"][i].Variable.String(),
				"snmp_index":             index,
			})
		}
	}
	return ep, nil
}

// 获取主板的index
func getPhysicalIndex(obj *snmpgo.SNMP, phyStatus string) []string {
	// 获取class type=3 主板的snmp_index
	snmpIndexs := []string{}
	{
		varBinds, err := SnmpWalk(obj, entPhysicalOids["entPhysicalClass"])
		if err != nil {
			global.Logger.Error("设备%v, oid：%v 采集异常：%v", obj.String(), entPhysicalOids["entPhysicalClass"], err.Error())
			return snmpIndexs
		}
		for _, varBind := range varBinds {
			if varBind.Variable.String() == phyStatus {
				tmps := strings.Split(varBind.Oid.String(), ".")
				if len(tmps) > 0 {
					snmpIndexs = append(snmpIndexs, tmps[len(tmps)-1])
				}
			}
		}
	}
	return snmpIndexs
}

// 获取主板信息
func GetChassisInfo(obj *snmpgo.SNMP) map[string]string {
	m := map[string]string{}
	chassisIndexs := getPhysicalIndex(obj, "3")
	if len(chassisIndexs) > 0 {
		chassisIndex := chassisIndexs[0]
		if chassisIndex != "" {
			for k, v := range entPhysicalOids {
				if k == "entPhysicalClass" {
					m["entPhysicalClass"] = "3"
				} else {
					varBinds, err := SnmpGet(obj, v+"."+chassisIndex)
					if err != nil {
						global.Logger.Error("设备%v, oid：%v 采集异常：%v", obj.String(), v, err.Error())
						continue
					}
					if len(varBinds) > 0 {
						m[k] = varBinds[0].Variable.String()
					}
				}
			}
		}
	}
	return m
}

// // GetPhysicalPorts 获取物理端口名称列表
// func GetPhysicalPorts(obj *snmpgo.SNMP) []string {
// 	ports := []string{}
// 	portIndexs := getPhysicalIndex(obj, "10")
// 	for _, portIndex := range portIndexs {
// 		oid := entPhysicalOids["entPhysicalName"] + "." + portIndex
// 		varBinds, err := SnmpGet(obj, oid)
// 		if err != nil {
// 			global.Logger.Error("设备%v, oid：%v 采集异常：%v", obj.String(), oid, err.Error())
// 			continue
// 		}
// 		if len(varBinds) > 0 {
// 			ports = append(ports, varBinds[0].Variable.String())
// 		}
// 	}
// 	return ports
// }

// GetEntPhysicalDetail 获取entPhysical对应的CPU,MEM信息
// ep 参数可以为空，标识不重复利用先前查找到的entPhysical
func DependOnEntPhysical(ep map[string][]map[string]string, obj *snmpgo.SNMP, entStatus, oid string) []string {
	wants := []string{}
	if ep == nil {
		ep, _ = GetEntPhysical(obj)
	}

	for _, item := range ep[entStatus] {
		varBinds, err := SnmpGet(obj, oid+"."+item["snmp_index"])
		if err != nil {
			global.Logger.Error(err.Error())
			continue
		}
		if len(varBinds) > 0 {
			wants = append(wants, varBinds[0].Variable.String())
		}
	}

	return wants
}
