package snmp

import (
	"collect_plugin/f5/global"
	"strings"
)

/*获取H3C产品*/
func GetH3CProduct(sysDescr string) string {
	if sysDescr == "" {
		return ""
	}
	if strings.Contains(sysDescr, "Software Version 5") {
		return "H3C_V5"
	}

	if strings.Contains(sysDescr, "Software Version 7") {
		return "H3C_V7"
	}

	if strings.Contains(sysDescr, "Version S9500") {
		return "H3C_S9500"
	}
	if strings.Contains(sysDescr, "Version 3.10") {
		return "H3c_V3.10"
	}

	return "H3C"
}

func GetCiscoProduct(softwareVer, remark string) (product string) {
	if softwareVer != "" {
		if softwareVer >= "12.2(3.5)" {
			product = "CISCO_NEW"
		} else if softwareVer <= "12.0(3)T" {
			product = "CISCO_OLD"
		} else {
			product = "CISCO_MIDDLE"
		}
	} else {
		global.Logger.Warning(" Software version is null, Unable to judge the product! ")
		return
	}
	if remark != "" {
		if strings.Contains(strings.ToLower(remark), "cisco nx-os") {
			product = strings.Replace(product, "CISCO", "Cisco_NX", -1)
		}
	}
	return
}
