package snmp

import (
	"collect_plugin/f5/define"
	"collect_plugin/f5/global"

	"io/ioutil"

	gs_define "geesunn.com/define"
	gs_tool "geesunn.com/tool"
	yaml "gopkg.in/yaml.v2"
)

// 返回模板文件的oid组
func GetOidInfo(mibPath string) ([]gs_define.OidInfo, error) {
	oids := []gs_define.OidInfo{}
	if gs_tool.IsFileExist(mibPath) {
		bytes, err := ioutil.ReadFile(mibPath)
		if err != nil {
			return oids, err
		}
		if err := yaml.Unmarshal(bytes, &oids); err != nil {
			return oids, err
		}
	}
	global.Logger.Info("%v %v", mibPath, oids)
	return oids, nil
}

func DeepCopy(oidInfo map[string]define.OidInfo) map[string]define.OidInfo {
	info := map[string]define.OidInfo{}
	for k, v := range oidInfo {
		info[k] = v
	}
	return info
}
