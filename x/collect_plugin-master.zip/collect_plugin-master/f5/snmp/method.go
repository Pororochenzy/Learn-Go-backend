package snmp

import (
	"errors"
	"fmt"
	"collect_plugin/f5/define"
	"collect_plugin/f5/global"
	"strings"

	gs_define "geesunn.com/define"
	"geesunn.com/snmpgo"
)

// 带auth的查询
func SnmpWalkWithAuth(auth gs_define.SNMP_Auth, oid string) (snmpgo.VarBinds, error) {
	obj, err := GetSNMPObject(auth)
	if err != nil {
		return nil, err
	}
	defer obj.Close()

	oids, _ := snmpgo.NewOids([]string{oid})
	pdu, err := obj.GetRequest(oids)

	if err != nil || (pdu != nil && len(pdu.VarBinds()) == 0) {
		pdu, err = obj.GetBulkWalk(oids, 0, 1)
	}

	if pdu != nil {
		return pdu.VarBinds(), err
	}
	return nil, err
}

func SnmpGet(obj *snmpgo.SNMP, oid string, args ...string) (snmpgo.VarBinds, error) {
	oids, _ := snmpgo.NewOids([]string{oid})
	pdu, err := obj.GetRequest(oids)
	if pdu != nil {
		if len(pdu.VarBinds()) == 0 {
			global.Logger.Warn("设备:%v 不支持 此oid: %v", args, oid)
			return nil, nil
		} else if pdu.VarBinds()[0].Variable.Type() == "NoSucheObject" {
			global.Logger.Warn("设备:%v NoSucheObject 此oid: %v", args, oid)
			return nil, nil
		} else {
			return pdu.VarBinds(), err
		}
	}
	return nil, err
}

func SnmpWalk(obj *snmpgo.SNMP, oid string, args ...string) (snmpgo.VarBinds, error) {
	oids, _ := snmpgo.NewOids([]string{oid})
	pdu, err := obj.GetBulkWalk(oids, 0, 1)
	if pdu != nil {
		if len(pdu.VarBinds()) == 0 {
			global.Logger.Warn("设备:%v 不支持 此oid: %v", args, oid)
			return nil, nil
		} else if pdu.VarBinds()[0].Variable.Type() == "NoSucheObject" {
			global.Logger.Warn("设备NoSucheObject 此oid: %v", oid)
			return nil, nil
		} else {
			return pdu.VarBinds(), err
		}
	}
	return nil, err
}

func SnmpNext(obj *snmpgo.SNMP, oid string) (snmpgo.VarBinds, error) {
	oids, _ := snmpgo.NewOids([]string{oid})
	pdu, err := obj.GetNextRequest(oids)
	if pdu != nil {
		if len(pdu.VarBinds()) == 0 {
			return nil, fmt.Errorf("No more variables left in this MIB View (It is past the end of the MIB tree)")
		} else if pdu.VarBinds()[0].Variable.Type() == "NoSucheObject" {
			return nil, fmt.Errorf("NoSucheObject")
		} else {
			return pdu.VarBinds(), err
		}
	}
	return nil, err
}

func GetRequestVarBind(obj *snmpgo.SNMP, oid string) (*snmpgo.VarBind, error) {
	oids, _ := snmpgo.NewOids([]string{oid})
	pdu, err := obj.GetRequest(oids)
	if pdu != nil {
		return pdu.VarBinds()[0], err
	}
	return nil, err
}

func GetNextRequestVarBind(obj *snmpgo.SNMP, oid string) (*snmpgo.VarBind, error) {
	oids, _ := snmpgo.NewOids([]string{oid})
	pdu, err := obj.GetNextRequest(oids)
	if pdu != nil {
		return pdu.VarBinds()[0], err
	}
	return nil, err

}

/*GetNextRequest Value*/
func GetNextRequest(snmp *snmpgo.SNMP, oid string, condition string) (interface{}, error) {
	oidNext := oid
	isFind := false
	for {
		varBind, err := GetNextRequestVarBind(snmp, oidNext)
		if err != nil {
			return condition, err
		}
		oidNext = varBind.Oid.String()
		if strings.Contains(oidNext, oid) {
			isFind = true
			if varBind.Variable.String() != condition {
				if condition == "0" {
					n, err := varBind.Variable.BigInt()
					if err != nil {
						return condition, err
					}
					return n.Uint64(), err
				}
				return varBind.Variable.String(), err
			}
		} else {
			if isFind {
				break
			} else {
				return condition, fmt.Errorf("No Such Object available on this agent at this OID")
			}

		}
	}
	if condition == "0" {
		return uint64(0), nil
	}
	return condition, nil
}

/* 获取uint64 */
func GetSNMPUint64(obj *snmpgo.SNMP, oid, method string) (uint64, error) {

	switch method {
	case define.SNMP_METHOD_GET:
		varBind, err := GetRequestVarBind(obj, oid)
		if err != nil {
			return uint64(0), err
		}
		value, err := varBind.Variable.BigInt()
		if err == nil {
			return value.Uint64(), err
		}
		return uint64(0), err
	case define.SNMP_METHOD_WALK:
		snmpPDUs, err := SnmpWalk(obj, oid)
		if err != nil {
			return uint64(0), err
		}
		for _, pdu := range snmpPDUs {
			if strings.TrimSpace(pdu.Variable.String()) != "0" {
				n, err := pdu.Variable.BigInt()
				if err != nil {
					return uint64(0), err
				}
				return n.Uint64(), err
			}
		}
		return uint64(0), err
	case define.SNMP_METHOD_GONEXT:
		value, err := GetNextRequest(obj, oid, "0")
		if err != nil {
			return uint64(0), err
		}
		return value.(uint64), err
	default:
		return uint64(0), errors.New("not support this method")
	}
}

/* 获取string */
func GetSNMPString(obj *snmpgo.SNMP, oid, method string) (string, error) {

	switch method {
	case define.SNMP_METHOD_GET:
		varBind, err := GetRequestVarBind(obj, oid)
		if err != nil {
			return "", err
		}
		return varBind.Variable.String(), err
	case define.SNMP_METHOD_WALK:
		snmpPDUs, err := SnmpWalk(obj, oid)
		if err != nil {
			return "", err
		}
		for _, pdu := range snmpPDUs {
			if strings.TrimSpace(pdu.Variable.String()) != "" {
				return pdu.Variable.String(), err
			}
		}
		return "", err
	case define.SNMP_METHOD_GONEXT:
		value, err := GetNextRequest(obj, oid, "")
		if err != nil {
			return "", err
		}
		return value.(string), err
	default:
		return "", errors.New("not support this method")
	}
}
