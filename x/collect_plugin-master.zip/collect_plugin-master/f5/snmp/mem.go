package snmp

import (
	"collect_plugin/f5/global"
	"strconv"
	"strings"

	gs_define "geesunn.com/define"
	"geesunn.com/snmpgo"
)

/*获取设备内存信息*/
func GetMemInfo(obj *snmpgo.SNMP, oids map[string]gs_define.OidInfo) (gs_define.MemInfo, error) {
	memInfo := gs_define.MemInfo{}
	isGet := false
	if oidInfo, ok := oids["mem_percent"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		memInfo.MemPercent = float64(value)
		isGet = true
	}
	if oidInfo, ok := oids["mem_total"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		memInfo.MemTotal = float64(value) * 1024
	}
	if oidInfo, ok := oids["mem_used"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		memInfo.MemUsed = float64(value) * 1024
	}
	if oidInfo, ok := oids["mem_free"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		memInfo.MemFree = float64(value) * 1024
	}
	if !isGet {
		memTotal := getMemTotal(memInfo, 1)
		memUsed := getMemUsed(memInfo, 1)
		if memTotal > 0 {
			memInfo.MemPercent = memUsed * 100 / memTotal
			memInfo.MemTotal = memTotal
			memInfo.MemUsed = memUsed
			memInfo.MemFree = memInfo.MemTotal - memInfo.MemUsed
		} else {
			global.Logger.Warning("memTotal is 0")
		}
	} else {
		memInfo.MemTotal = getMemTotal(memInfo, 2)
		memInfo.MemUsed = getMemUsed(memInfo, 2)
		memInfo.MemFree = memInfo.MemTotal - memInfo.MemUsed
	}

	if oidInfo, ok := oids["mem_buffer"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		memInfo.MemBuffer = float64(value) * 1024
	}

	if oidInfo, ok := oids["mem_cached"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		memInfo.MemCached = float64(value) * 1024
	}
	return memInfo, nil
}

/*获取设备内存总量*/
func getMemTotal(memInfo gs_define.MemInfo, mothed int) float64 {
	memTotal := memInfo.MemTotal
	if memTotal == 0 {
		memTotal = memInfo.MemUsed + memInfo.MemFree
	}
	if memTotal == 0 && mothed == 2 {
		if memInfo.MemUsed > 0 && memInfo.MemPercent > 0 {
			memTotal = memInfo.MemUsed * 100 / memInfo.MemPercent
		} else if memInfo.MemFree > 0 && memInfo.MemPercent < 100 {
			memTotal = memInfo.MemFree * 100 / (100 - memInfo.MemPercent)
		}
	}
	return memTotal
}

/*获取设备已用内存*/
func getMemUsed(memInfo gs_define.MemInfo, mothed int) float64 {
	memUsed := memInfo.MemUsed
	if memUsed == 0 {
		if mothed == 2 && memInfo.MemPercent > 0 && memInfo.MemTotal > 0 {
			memUsed = memInfo.MemTotal * memInfo.MemPercent / 100
		} else {
			memUsed = memInfo.MemTotal - memInfo.MemFree
		}
	}
	return memUsed
}

func GetSangforMemInfo(obj *snmpgo.SNMP, oids map[string]gs_define.OidInfo) (gs_define.MemInfo, error) {
	memInfo := gs_define.MemInfo{}
	isGet := false
	if oidInfo, ok := oids["mem_percent"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		memInfo.MemPercent = float64(value)
		isGet = true
	}
	if oidInfo, ok := oids["mem_total"]; ok {
		value, err := GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		strs := strings.Split(value, " ")
		if len(strs) > 1 {
			v, err := strconv.ParseFloat(strs[0], 64)
			if err != nil {
				global.Logger.Warning("sangfor total %v %v", value, v)
				return memInfo, err
			}
			memInfo.MemTotal = v
		} else {
			v, err := strconv.ParseFloat(value, 64)
			if err != nil {
				global.Logger.Warning("sangfor total %v %v", value, v)
				return memInfo, err
			}
			memInfo.MemTotal = v
		}
	}
	if oidInfo, ok := oids["mem_used"]; ok {
		value, err := GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		strs := strings.Split(value, " ")
		if len(strs) > 1 {
			v, err := strconv.ParseFloat(strs[0], 64)
			if err != nil {
				global.Logger.Warning("sangfor used %v %v", value, v)
				return memInfo, err
			}
			memInfo.MemUsed = v
		} else {
			v, err := strconv.ParseFloat(value, 64)
			if err != nil {
				global.Logger.Warning("sangfor used %v %v", value, v)
				return memInfo, err
			}
			memInfo.MemUsed = v
		}
	}
	if oidInfo, ok := oids["mem_free"]; ok {
		value, err := GetSNMPString(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		strs := strings.Split(value, " ")
		if len(strs) > 1 {
			v, err := strconv.ParseFloat(strs[0], 64)
			if err != nil {
				global.Logger.Warning("sangfor free %v %v", value, v)
				return memInfo, err
			}
			memInfo.MemFree = v
		} else {
			v, err := strconv.ParseFloat(value, 64)
			if err != nil {
				global.Logger.Warning("sangfor free %v %v", value, v)
				return memInfo, err
			}
			memInfo.MemFree = v
		}

	}
	if !isGet {
		memTotal := getMemTotal(memInfo, 1)
		memUsed := getMemUsed(memInfo, 1)
		if memTotal > 0 {
			memInfo.MemPercent = memUsed * 100 / memTotal
			memInfo.MemTotal = memTotal
			memInfo.MemUsed = memUsed
			memInfo.MemFree = memInfo.MemTotal - memInfo.MemUsed
		} else {
			global.Logger.Warning("memTotal is 0")
		}
	} else {
		memInfo.MemTotal = getMemTotal(memInfo, 2)
		memInfo.MemUsed = getMemUsed(memInfo, 2)
		memInfo.MemFree = memInfo.MemTotal - memInfo.MemUsed
	}

	if oidInfo, ok := oids["mem_buffer"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		memInfo.MemBuffer = float64(value) * 1024
	}

	if oidInfo, ok := oids["mem_cached"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return memInfo, err
		}
		memInfo.MemCached = float64(value) * 1024
	}
	return memInfo, nil
}
