package snmp

import (
	"fmt"
	"collect_plugin/f5/define"

	"geesunn.com/snmpgo"
)

/*获取CPU利用率*/
func GetCpuUtilization(obj *snmpgo.SNMP, oidInfo define.OidInfo) (float64, error) {
	value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
	if err != nil {
		return float64(0), err
	}
	return float64(value), err
}

func GetCpuUtilization2(obj *snmpgo.SNMP, oids map[string]define.OidInfo) (float64, error) {
	if oidInfo, ok := oids["cpu_percent"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return float64(0), err
		}
		return float64(value), err
	}

	if oidInfo, ok := oids["cpu_percent_free"]; ok {
		value, err := GetSNMPUint64(obj, oidInfo.Oid, oidInfo.Method)
		if err != nil {
			return float64(0), err
		}
		return float64(100 - value), err
	}
	return float64(0), fmt.Errorf(fmt.Sprintf("no cpu_percent oid"))
}
