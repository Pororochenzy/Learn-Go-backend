package snmp

import (
	"encoding/json"
	"fmt"
	"collect_plugin/f5/global"
	"net"
	"strconv"
	"strings"
	"time"

	gs_define "geesunn.com/define"
	gs_snmp "geesunn.com/snmp"
	"geesunn.com/snmpgo"
	"github.com/toolkits/slice"
)

func GetSNMPObject(auth gs_define.SNMP_Auth) (*snmpgo.SNMP, error) {
	client, err := gs_snmp.InitClient(auth)
	if err != nil {
		return nil, err
	}
	return client.SNMP, nil
	// community := auth.ReadComunity
	// authPassword := auth.AuthPassword
	// dataPassword := auth.DataPassword
	// {
	// 	if community != "" {
	// 		tempPass, err := encrypt.AesDecryptBase64(community, encrypt.EncryptDBKey)
	// 		if err != nil {
	// 			global.Logger.Error("snmp 团体字【%v】解密异常：%v", community, err.Error())
	// 		} else {
	// 			community = tempPass
	// 		}
	// 	}
	// 	if authPassword != "" {
	// 		tempPass, err := encrypt.AesDecryptBase64(authPassword, encrypt.EncryptDBKey)
	// 		if err != nil {
	// 			global.Logger.Error("authPassword 【%v】解密异常：%v", authPassword, err.Error())
	// 		} else {
	// 			authPassword = tempPass
	// 		}
	// 	}
	// 	if dataPassword != "" {
	// 		tempPass, err := encrypt.AesDecryptBase64(dataPassword, encrypt.EncryptDBKey)
	// 		if err != nil {
	// 			global.Logger.Error("dataPassword【%v】解密异常：%v", dataPassword, err.Error())
	// 		} else {
	// 			dataPassword = tempPass
	// 		}
	// 	}
	// }

	// obj, err := snmpgo.NewSNMP(snmpgo.SNMPArguments{
	// 	Version: map[string]snmpgo.SNMPVersion{
	// 		"1":  snmpgo.V1,
	// 		"2c": snmpgo.V2c,
	// 		"3":  snmpgo.V1,
	// 	}[auth.Version],
	// 	Address:   fmt.Sprintf("%v:%v", auth.IP, auth.Port),
	// 	Community: community,
	// 	Retries:   1,
	// 	Timeout:   time.Second * 3,
	// 	UserName:  auth.User,
	// 	SecurityLevel: map[string]snmpgo.SecurityLevel{
	// 		"authPriv":     snmpgo.AuthPriv,
	// 		"authNoPriv":   snmpgo.AuthNoPriv,
	// 		"noAuthNoPriv": snmpgo.NoAuthNoPriv,
	// 	}[auth.SecurityLevel],
	// 	AuthPassword: authPassword,
	// 	AuthProtocol: map[string]snmpgo.AuthProtocol{
	// 		"MD5": snmpgo.Md5,
	// 		"SHA": snmpgo.Sha,
	// 	}[auth.AuthPro],
	// 	PrivPassword: dataPassword,
	// 	PrivProtocol: map[string]snmpgo.PrivProtocol{
	// 		"DES": snmpgo.Des,
	// 		"AES": snmpgo.Aes,
	// 	}[auth.DataPro],
	// })
	// if err != nil {
	// 	return nil, err
	// }
	// if err := obj.Open(); err != nil {
	// 	return nil, err
	// }
	// _, err = SnmpGet(obj, "1.3.6.1.2.1.1.1.0", auth.IP)
	// if err != nil {
	// 	global.Logger.Error("\n snmp-check ip: %v err: %v", auth.IP, err.Error())
	// 	return nil, err
	// }

	// return obj, nil
}

type SnmpClient struct {
	*snmpgo.SNMP
	Oids         map[string]gs_define.OidInfo
	TimeoutCount int
	Auth         gs_define.SNMP_Auth
}

func GetIndexFromLeft(left string) string {
	items := strings.Split(left, ".")
	return items[len(items)-1]
}

func InitSnmpClient(auth gs_define.SNMP_Auth, oids map[string]gs_define.OidInfo) (*SnmpClient, error) {
	// snmp, err := InitSnmp(auth)
	snmp, err := GetSNMPObject(auth)
	if err != nil {
		return nil, err
	}

	client := &SnmpClient{
		SNMP:         snmp,
		Oids:         oids,
		TimeoutCount: 0,
		Auth:         auth,
	}
	return client, nil
}

func InitSnmp(auth gs_define.SNMP_Auth) (*snmpgo.SNMP, error) {
	return snmpgo.NewSNMP(snmpgo.SNMPArguments{
		Version: map[string]snmpgo.SNMPVersion{
			"1":  snmpgo.V1,
			"2c": snmpgo.V2c,
			"3":  snmpgo.V1,
		}[auth.Version],
		Address:   fmt.Sprintf("%v:%v", auth.IP, auth.Port),
		Community: auth.ReadComunity,
		Retries:   1,
		Timeout:   time.Second * 5,
		UserName:  auth.User,
		SecurityLevel: map[string]snmpgo.SecurityLevel{
			"authPriv":     snmpgo.AuthPriv,
			"authNoPriv":   snmpgo.AuthNoPriv,
			"noAuthNoPriv": snmpgo.NoAuthNoPriv,
		}[auth.SecurityLevel],
		AuthPassword: auth.AuthPassword,
		AuthProtocol: map[string]snmpgo.AuthProtocol{
			"MD5": snmpgo.Md5,
			"SHA": snmpgo.Sha,
		}[auth.AuthPro],
		PrivPassword: auth.DataPassword,
		PrivProtocol: map[string]snmpgo.PrivProtocol{
			"DES": snmpgo.Des,
			"AES": snmpgo.Aes,
		}[auth.DataPro],
	})
}

/**
获取cpu
*/
func (p *SnmpClient) CpuPercent() (float64, error) {
	if oidInfo, ok := p.Oids["cpu_percent"]; ok {
		value, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return float64(0), err
		}
		return float64(value), err
	}

	if oidInfo, ok := p.Oids["cpu_percent_free"]; ok {
		value, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return float64(0), err
		}
		return float64(100 - value), err
	}

	if oidInfo, ok := p.Oids["cpu_avg_percent"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return float64(0), err
		}
		sum := int64(0)
		count := int64(0)
		for _, pdu := range snmpPDUs {
			value, err := pdu.Variable.BigInt()
			if err != nil {
				global.Logger.Error(err.Error())
				continue
			}
			count++
			sum += value.Int64()
		}
		if count > 0 {
			return float64(sum / count), nil
		} else {
			return float64(0), nil
		}
	}

	return float64(0), fmt.Errorf("no cpu_percent oid")
}

/**
获取其他CPU信息
*/
func (p *SnmpClient) CpuPercentInfo() (gs_define.CpuPercentInfo, error) {
	cpuPercent, err := p.CpuPercent()
	cpuPercentInfo := gs_define.CpuPercentInfo{
		LoadPercent: cpuPercent,
	}
	if oidInfo, ok := p.Oids["user_cpu_percent"]; ok {
		value, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			cpuPercentInfo.UserLoadPercent = float64(value)
		} else {
			return cpuPercentInfo, err
		}
	}

	if oidInfo, ok := p.Oids["sys_cpu_percent"]; ok {
		value, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			cpuPercentInfo.SysLoadPercent = float64(value)
		} else {
			return cpuPercentInfo, err
		}
	}
	return cpuPercentInfo, err
}

/**
获取内存
*/
func (p *SnmpClient) MemInfo() (gs_define.MemInfo, error) {
	memInfo, err := GetMemInfo(p.SNMP, p.Oids)
	p.SumTimeOut(err, "mem info")
	return memInfo, err
}

/**
系统信息
*/
func (p *SnmpClient) HostInfo() (gs_define.SnmpHostInfo, error) {
	hostInfo := gs_define.SnmpHostInfo{}
	if oidInfo, ok := p.Oids["system_desc"]; ok {
		value, err := GetSNMPString(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			hostInfo.SysDesc = value
		} else {
			return hostInfo, err
		}
	}

	if oidInfo, ok := p.Oids["system_host_name"]; ok {
		value, err := GetSNMPString(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			hostInfo.HostName = value
		} else {
			return hostInfo, err
		}
	}

	if oidInfo, ok := p.Oids["system_run_time"]; ok {
		value, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			hostInfo.SysRuntime = value / 100
		} else {
			return hostInfo, err
		}
	}

	return hostInfo, nil
}

/**
系统运行时长
*/
func (p *SnmpClient) SysRunTime() (uint64, error) {
	if oidInfo, ok := p.Oids["system_run_time"]; ok {
		sysRunTime, err := GetSNMPString(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return 0, err
		}
		if sysRunTime == "" {
			return 0, fmt.Errorf("system_run_time is null")
		}
		runTime, err := strconv.ParseUint(sysRunTime, 10, 64)
		if err != nil {
			return 0, fmt.Errorf(fmt.Sprintf("system_run_time parse error [%v]", sysRunTime))
		}
		return runTime / 100, err
	}
	return 0, fmt.Errorf("Not Find SysRunTime oid")
}

/**
端口
*/
func (p *SnmpClient) Ports() ([]int64, error) {
	ports := []int64{}
	if oidInfo, ok := p.Oids["port"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return ports, err
		}
		for _, pdu := range snmpPDUs {
			n, err := pdu.Variable.BigInt()
			if err != nil {
				return ports, err
			}
			if !slice.ContainsInt64(ports, n.Int64()) {
				ports = append(ports, n.Int64())
			}
		}
	}
	return ports, nil
}

/**
进程
*/
func (p *SnmpClient) Process() ([]gs_define.SnmpProcess, error) {
	process := map[string]*gs_define.SnmpProcess{}

	if oidInfo, ok := p.Oids["hr_swrun_index"]; !ok {
		return []gs_define.SnmpProcess{}, fmt.Errorf("Not Find Process oid")
	} else {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return []gs_define.SnmpProcess{}, err
		}
		for _, pdu := range snmpPDUs {
			n, err := pdu.Variable.BigInt()
			if err != nil {
				return []gs_define.SnmpProcess{}, err
			}
			process[pdu.Variable.String()] = &gs_define.SnmpProcess{
				PId: n.Int64(),
			}
		}
	}

	if oidInfo, ok := p.Oids["hr_swrun_name"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := process[index]; ok {
					v.Name = pdu.Variable.String()
				} else {
					fmt.Println(index, pdu.Variable.String())
				}
			}
		} else {
			return []gs_define.SnmpProcess{}, err
		}
	}

	if oidInfo, ok := p.Oids["hr_swrun_path"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := process[index]; ok {
					v.Cmd = pdu.Variable.String()
				}
			}
		} else {
			return []gs_define.SnmpProcess{}, err
		}
	}

	if oidInfo, ok := p.Oids["hr_swrun_parameters"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := process[index]; ok {
					v.Parameters = pdu.Variable.String()
				}
			}
		} else {
			return []gs_define.SnmpProcess{}, err
		}
	}

	if oidInfo, ok := p.Oids["hr_swrun_status"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := process[index]; ok {
					v.Status = pdu.Variable.String()
				}
			}
		} else {
			return []gs_define.SnmpProcess{}, err
		}
	}

	prs := []gs_define.SnmpProcess{}
	for _, ps := range process {
		prs = append(prs, *ps)
	}
	return prs, nil
}

/**
nets
*/
func (p *SnmpClient) Nets(duration int) ([]gs_define.SnmpIf, error) {
	indexs := []string{}
	hIndexs := []string{}
	ifs := map[string]*gs_define.SnmpIf{}

	if oidInfo, ok := p.Oids["if_index"]; !ok {
		return []gs_define.SnmpIf{}, fmt.Errorf("Not Fund IfNumber oid")
	} else {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return []gs_define.SnmpIf{}, err
		}
		for _, pdu := range snmpPDUs {
			index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
			indexs = append(indexs, index)
			ifs[index] = &gs_define.SnmpIf{
				IfIndex: pdu.Variable.String(),
			}
		}
	}

	if oidInfo, ok := p.Oids["if_descr"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := ifs[index]; ok {
					v.IfDescr = SNHex2str(pdu.Variable.String())
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_alias"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := ifs[index]; ok {
					v.IfAlias = SNHex2str(pdu.Variable.String())
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_name"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := ifs[index]; ok {
					v.IfName = SNHex2str(pdu.Variable.String())
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_type"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := ifs[index]; ok {
					v.IfType = pdu.Variable.String()
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_phys_address"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := ifs[index]; ok {
					v.IfPhysAddress = pdu.Variable.String()
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_oper_status"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := ifs[index]; ok {
					if pdu.Variable.String() == "1" {
						v.IfOperStatus = "up"
					} else {
						v.IfOperStatus = "down"
					}
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_mtu"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					v.IfMtu = value.Uint64()
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_speed"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					v.IfSpeed = value.Uint64()
					if value.Uint64() >= 4294967295 {
						hIndexs = append(hIndexs, index)
					}
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_in_ucast_pkts"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					v.IfInUcastPkts = value.Uint64()
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_out_ucast_pkts"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					v.IfOutUcastPkts = value.Uint64()
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_in_octet"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					v.IfInOctet = value.Uint64()
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_out_octet"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					v.IfOutOctet = value.Uint64()
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if len(hIndexs) > 0 {
		if oidInfo, ok := p.Oids["if_high_speed"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if !slice.ContainsString(hIndexs, index) {
						continue
					}
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := ifs[index]; ok {
						v.IfSpeed = value.Uint64() * 1000000
					}
				}
			} else {
				return []gs_define.SnmpIf{}, err
			}
		}

		if oidInfo, ok := p.Oids["if_hc_in_octets"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if !slice.ContainsString(hIndexs, index) {
						continue
					}
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := ifs[index]; ok {
						v.IfInOctet = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpIf{}, err
			}
		}

		if oidInfo, ok := p.Oids["if_hc_out_octets"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if !slice.ContainsString(hIndexs, index) {
						continue
					}
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := ifs[index]; ok {
						v.IfOutOctet = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpIf{}, err
			}
		}

		if oidInfo, ok := p.Oids["if_hc_in_ucast_pkts"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if !slice.ContainsString(hIndexs, index) {
						continue
					}
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := ifs[index]; ok {
						v.IfInUcastPkts = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpIf{}, err
			}
		}

		if oidInfo, ok := p.Oids["if_hc_out_ucast_pkts"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if !slice.ContainsString(hIndexs, index) {
						continue
					}
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := ifs[index]; ok {
						v.IfOutUcastPkts = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpIf{}, err
			}
		}
	}

	time.Sleep(time.Second * time.Duration(duration))
	if oidInfo, ok := p.Oids["if_in_octet"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					if value.Uint64() > v.IfInOctet {
						v.IfInSpeed = (value.Uint64() - v.IfInOctet) / 15
					}
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}
	if oidInfo, ok := p.Oids["if_out_octet"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					if value.Uint64() > v.IfOutOctet {
						v.IfOutSpeed = (value.Uint64() - v.IfOutOctet) / 15
					}
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_in_ucast_pkts"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					if value.Uint64() > v.IfInUcastPkts {
						v.IfInUcastPktsSpeed = (value.Uint64() - v.IfInUcastPkts) / 15
					}
				}

			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if oidInfo, ok := p.Oids["if_out_ucast_pkts"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				if v, ok := ifs[index]; ok {
					if value.Uint64() > v.IfOutUcastPkts {
						v.IfOutUcastPktsSpeed = (value.Uint64() - v.IfOutUcastPkts) / 15
					}
				}
			}
		} else {
			return []gs_define.SnmpIf{}, err
		}
	}

	if len(hIndexs) > 0 {
		if oidInfo, ok := p.Oids["if_hc_in_octets"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if !slice.ContainsString(hIndexs, index) {
						continue
					}
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := ifs[index]; ok {
						if value.Uint64() > v.IfInOctet {
							v.IfInSpeed = (value.Uint64() - v.IfInOctet) / 15
						}
					}
				}
			} else {
				return []gs_define.SnmpIf{}, err
			}
		}

		if oidInfo, ok := p.Oids["if_hc_out_octets"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if !slice.ContainsString(hIndexs, index) {
						continue
					}
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := ifs[index]; ok {
						if value.Uint64() > v.IfOutOctet {
							v.IfOutSpeed = (value.Uint64() - v.IfOutOctet) / 15
						}
					}
				}
			} else {
				return []gs_define.SnmpIf{}, err
			}
		}

		if oidInfo, ok := p.Oids["if_hc_in_ucast_pkts"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if !slice.ContainsString(hIndexs, index) {
						continue
					}
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := ifs[index]; ok {
						if value.Uint64() > v.IfInUcastPkts {
							v.IfInUcastPktsSpeed = (value.Uint64() - v.IfInUcastPkts) / 15
						}
					}
				}
			} else {
				return []gs_define.SnmpIf{}, err
			}
		}

		if oidInfo, ok := p.Oids["if_hc_out_ucast_pkts"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if !slice.ContainsString(hIndexs, index) {
						continue
					}
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := ifs[index]; ok {
						if value.Uint64() > v.IfOutUcastPkts {
							v.IfOutUcastPktsSpeed = (value.Uint64() - v.IfOutUcastPkts) / 15
						}
					}
				}
			} else {
				return []gs_define.SnmpIf{}, err
			}
		}
	}

	nets := []gs_define.SnmpIf{}
	for _, index := range indexs {
		nets = append(nets, *ifs[index])
	}
	return nets, nil
}

/**
disk
*/
func (p *SnmpClient) Disks() ([]gs_define.SnmpDisk, error) {
	disks := map[string]*gs_define.SnmpDisk{}

	if oidInfo, ok := p.Oids["dsk_index"]; !ok {
		return []gs_define.SnmpDisk{}, fmt.Errorf("Not Find dsk oid")
	} else {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return []gs_define.SnmpDisk{}, err
		}
		for _, pdu := range snmpPDUs {
			index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
			disks[index] = &gs_define.SnmpDisk{
				DskIndex: pdu.Variable.String(),
			}
		}
	}

	if oidInfo, ok := p.Oids["dsk_path"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				disks[index].DskPath = pdu.Variable.String()
			}
		} else {
			return []gs_define.SnmpDisk{}, err
		}
	}

	if oidInfo, ok := p.Oids["dsk_device"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				disks[index].DskDevice = pdu.Variable.String()
			}
		} else {
			return []gs_define.SnmpDisk{}, err
		}
	}

	if oidInfo, ok := p.Oids["dsk_total"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				v, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				disks[index].DskTotal = v.Uint64() * 1024
			}
		} else {
			return []gs_define.SnmpDisk{}, err
		}
	}

	if oidInfo, ok := p.Oids["dsk_avail"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				v, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				disks[index].DskAvail = v.Uint64() * 1024
			}
		} else {
			return []gs_define.SnmpDisk{}, err
		}
	}

	if oidInfo, ok := p.Oids["dsk_used"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				v, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				disks[index].DskUsed = v.Uint64() * 1024
			}
		} else {
			return []gs_define.SnmpDisk{}, err
		}
	}

	if oidInfo, ok := p.Oids["dsk_percent"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				v, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				disks[index].DskPercent = float64(v.Int64())
			}
		} else {
			return []gs_define.SnmpDisk{}, err
		}
	}
	if oidInfo, ok := p.Oids["dsk_percent_node"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				v, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}
				disks[index].DskPercentNode = float64(v.Int64())
			}
		} else {
			return []gs_define.SnmpDisk{}, err
		}
	}
	snmpDisk := []gs_define.SnmpDisk{}
	for _, disk := range disks {
		snmpDisk = append(snmpDisk, *disk)
	}
	return snmpDisk, nil
}

/**
loads
*/
func (p *SnmpClient) Loads() (gs_define.SnmpLoad, error) {
	laLoad1, laLoad5, laLoad15 := 0.0, 0.0, 0.0
	if oidInfo, ok := p.Oids["load1"]; ok {
		_laLoad1, err := GetSNMPString(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			if _laLoad1 != "" {
				laLoad1, err = strconv.ParseFloat(_laLoad1, 64)
				if err != nil {
					global.Logger.Error(err.Error())
				}
			}
		} else {
			return gs_define.SnmpLoad{}, err
		}
	}
	if oidInfo, ok := p.Oids["load5"]; ok {
		_laLoad1, err := GetSNMPString(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			if _laLoad1 != "" {
				laLoad5, err = strconv.ParseFloat(_laLoad1, 64)
				if err != nil {
					global.Logger.Error(err.Error())
				}
			}
		} else {
			return gs_define.SnmpLoad{}, err
		}
	}
	if oidInfo, ok := p.Oids["load15"]; ok {
		_laLoad1, err := GetSNMPString(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			if _laLoad1 != "" {
				laLoad15, err = strconv.ParseFloat(_laLoad1, 64)
				if err != nil {
					global.Logger.Error(err.Error())
				}
			}
		} else {
			return gs_define.SnmpLoad{}, err
		}
	}
	return gs_define.SnmpLoad{
		Load1:  laLoad1,
		Load5:  laLoad5,
		Load15: laLoad15,
	}, nil
}

/**
diskIO
*/
func (p *SnmpClient) DiskIOs() ([]gs_define.SnmpDiskIO, error) {
	diskIOs := map[string]*gs_define.SnmpDiskIO{}

	if oidInfo, ok := p.Oids["disk_io_device_speed"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				if pdu.Variable.String() == "_Total" {
					continue
				}
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				diskIOs[index] = &gs_define.SnmpDiskIO{
					DiskIOIndex:  index,
					DiskIODevice: pdu.Variable.String(),
				}
			}
		} else {
			return []gs_define.SnmpDiskIO{}, err
		}

		if oidInfo, ok := p.Oids["disk_io_nread_speed"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIONReadSpeed = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_read_speed"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIOReadsSpeed = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_nwrites_speed"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIONWrittenSpeed = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_writes_speed"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIOWritesSpeed = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}
	} else if oidInfo, ok := p.Oids["disk_io_index"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return []gs_define.SnmpDiskIO{}, err
		}
		for _, pdu := range snmpPDUs {
			index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
			diskIOs[index] = &gs_define.SnmpDiskIO{
				DiskIOIndex: pdu.Variable.String(),
			}
		}

		if oidInfo, ok := p.Oids["disk_io_device"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					if v, ok := diskIOs[index]; ok {
						v.DiskIODevice = pdu.Variable.String()
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_nread"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIONRead = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_nwritten"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIONWritten = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_reads"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIOReads = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_writes"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIOWrites = value.Uint64()
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		time.Sleep(time.Second * 15)
		if oidInfo, ok := p.Oids["disk_io_nread"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIONReadSpeed = (value.Uint64() - diskIOs[index].DiskIONRead) / 15
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_nwritten"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIONWrittenSpeed = (value.Uint64() - diskIOs[index].DiskIONWritten) / 15
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_reads"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIOReadsSpeed = (value.Uint64() - diskIOs[index].DiskIOReads) / 15
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}

		if oidInfo, ok := p.Oids["disk_io_writes"]; ok {
			snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
			if !p.SumTimeOut(err, oidInfo.Oid) {
				for _, pdu := range snmpPDUs {
					index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
					value, err := pdu.Variable.BigInt()
					if err != nil {
						global.Logger.Error(err.Error())
						continue
					}
					if v, ok := diskIOs[index]; ok {
						v.DiskIOWritesSpeed = (value.Uint64() - diskIOs[index].DiskIOWrites) / 15
					}
				}
			} else {
				return []gs_define.SnmpDiskIO{}, err
			}

		}
	} else {
		return []gs_define.SnmpDiskIO{}, fmt.Errorf("Not Find disk_io oid")
	}

	snmpDiskIOs := []gs_define.SnmpDiskIO{}
	for _, diskIO := range diskIOs {
		snmpDiskIOs = append(snmpDiskIOs, *diskIO)
	}
	return snmpDiskIOs, nil
}

/**
tcp连接数量
*/
func (p *SnmpClient) TcpInfo() (gs_define.SnmpTcpInfo, error) {
	tcpInfo := gs_define.SnmpTcpInfo{}

	if oidInfo, ok := p.Oids["tcp_active_opens"]; ok {
		num, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			tcpInfo.Active = num
		} else {
			return tcpInfo, err
		}
	}

	if oidInfo, ok := p.Oids["tcp_passive_opens"]; ok {
		num, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			tcpInfo.Passive = num
		} else {
			return tcpInfo, err
		}
	}

	if oidInfo, ok := p.Oids["tcp_attempt_fails"]; ok {
		num, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			tcpInfo.AttemptFail = num
		} else {
			return tcpInfo, err
		}
	}

	if oidInfo, ok := p.Oids["tcp_estab_resets"]; ok {
		num, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			tcpInfo.Reset = num
		} else {
			return tcpInfo, err
		}
	}
	if oidInfo, ok := p.Oids["tcp_curr_estab"]; ok {
		num, err := GetSNMPUint64(p.SNMP, oidInfo.Oid, oidInfo.Method)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			tcpInfo.Established = num
		} else {
			return tcpInfo, err
		}
	}
	return tcpInfo, nil
}

/**
设备详情
*/
func (p *SnmpClient) StorageInfo() ([]gs_define.SnmpDisk, gs_define.MemInfo, error) {
	disks := map[string]*gs_define.SnmpDisk{}
	mems := map[string]*gs_define.MemInfo{}
	if oidInfo, ok := p.Oids["hr_storage_type"]; !ok {
		return []gs_define.SnmpDisk{}, gs_define.MemInfo{}, fmt.Errorf("Not Fund hrStorage oid")
	} else {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if p.SumTimeOut(err, oidInfo.Oid) {
			return []gs_define.SnmpDisk{}, gs_define.MemInfo{}, err
		}
		for _, pdu := range snmpPDUs {
			index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
			// hrStorageRam 表示内存, hrStorageFixedDisk 表示硬盘, hrStorageVirtualMemory 表示虚拟内存, hrStorageCompactDisc 表示光盘
			switch pdu.Variable.String() {
			case "hrStorageRam":
				fallthrough
			case "1.3.6.1.2.1.25.2.1.2":
				mems[index] = &gs_define.MemInfo{}

			case "hrStorageFixedDisk":
				fallthrough
			case "1.3.6.1.2.1.25.2.1.4":
				disks[index] = &gs_define.SnmpDisk{
					DskIndex: index,
				}

			case "hrStorageVirtualMemory":
				fallthrough
			case "1.3.6.1.2.1.25.2.1.3":
				continue

			case "hrStorageCompactDisc":
				fallthrough
			case "1.3.6.1.2.1.25.2.1.7":
				continue

			case "hrStorageOther":
				fallthrough
			case "1.3.6.1.2.1.25.2.1.1":
				continue
			default:
				continue
			}
		}
	}

	if oidInfo, ok := p.Oids["hr_storage_descr"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)
				if v, ok := disks[index]; ok {
					value := SNHex2str(pdu.Variable.String())
					values := strings.Split(value, "\\")
					v.DskDevice = values[0]
				}
			}
		} else {
			return []gs_define.SnmpDisk{}, gs_define.MemInfo{}, err
		}
	}

	if oidInfo, ok := p.Oids["hr_storage_size"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)

				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}

				if v, ok := disks[index]; ok {
					v.DskTotal = value.Uint64()
					continue
				}
				if v, ok := mems[index]; ok {
					v.MemTotal = float64(value.Uint64())
					continue
				}
			}
		} else {
			return []gs_define.SnmpDisk{}, gs_define.MemInfo{}, err
		}
	}

	if oidInfo, ok := p.Oids["hr_storage_used"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)

				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}

				if v, ok := disks[index]; ok {
					v.DskUsed = value.Uint64()
					if v.DskTotal > 0 {
						v.DskPercent = float64(value.Uint64()*100) / float64(v.DskTotal)
					}
					continue
				}
				if v, ok := mems[index]; ok {
					v.MemUsed = float64(value.Uint64())
					if v.MemTotal > 0 {
						v.MemPercent = float64(v.MemUsed*100) / float64(v.MemTotal)
					}
					continue
				}
			}
		} else {
			return []gs_define.SnmpDisk{}, gs_define.MemInfo{}, err
		}
	}

	if oidInfo, ok := p.Oids["hr_storage_allocation_units"]; ok {
		snmpPDUs, err := SnmpWalk(p.SNMP, oidInfo.Oid)
		if !p.SumTimeOut(err, oidInfo.Oid) {
			for _, pdu := range snmpPDUs {
				index := strings.Replace(pdu.Oid.String(), oidInfo.Oid+".", "", 1)

				value, err := pdu.Variable.BigInt()
				if err != nil {
					global.Logger.Error(err.Error())
					continue
				}

				if v, ok := disks[index]; ok {
					v.DskTotal = value.Uint64() * v.DskTotal
					v.DskUsed = value.Uint64() * v.DskUsed
					if v.DskTotal > v.DskUsed {
						v.DskAvail = v.DskTotal - v.DskUsed
					}
					continue
				}
				if v, ok := mems[index]; ok {
					v.MemTotal = float64(value.Uint64()) * v.MemTotal
					v.MemUsed = float64(value.Uint64()) * v.MemUsed
					if v.MemTotal > v.MemUsed {
						v.MemFree = v.MemTotal - v.MemUsed
					}
					continue
				}
			}
		} else {
			return []gs_define.SnmpDisk{}, gs_define.MemInfo{}, err
		}
	}

	snmpDisk := []gs_define.SnmpDisk{}
	for _, disk := range disks {
		snmpDisk = append(snmpDisk, *disk)
	}
	snmpMem := []gs_define.MemInfo{}
	for _, mem := range mems {
		snmpMem = append(snmpMem, *mem)
	}

	mem := gs_define.MemInfo{}
	if len(snmpMem) > 0 {
		mem = snmpMem[0]
	}

	if len(snmpMem) > 1 {
		total := float64(0.0)
		used := float64(0.0)
		for _, tmp := range snmpMem {
			total += tmp.MemTotal
			used += tmp.MemUsed
		}
		mem.MemTotal = total
		mem.MemUsed = used
		if total > 0 {
			mem.MemPercent = float64(used*100) / total
		}
		if total > used {
			mem.MemFree = total - used
		}

	}
	return snmpDisk, mem, nil
}

func (p *SnmpClient) SumTimeOut(err error, oid string) bool {
	if err != nil {
		global.Logger.Error("%v %v %v", p.Auth.IP, oid, err.Error())
		if strings.Contains(err.Error(), "i/o timeout") {
			p.TimeoutCount = p.TimeoutCount + 1
		} else if err, ok := err.(net.Error); ok && err.Timeout() {
			p.TimeoutCount = p.TimeoutCount + 1
		}
		return true
	}
	return false
}

// 检查snmp连接是否正常
func CheckSNMPConn(auth gs_define.SNMP_Auth) bool {
	snmp, err := GetSNMPObject(auth)
	if err != nil {
		global.Logger.Error("%v 初始化SNMP异常: %v", auth.IP, err.Error())
		return false
	}
	defer snmp.Close()
	_, err = SnmpGet(snmp, "1.3.6.1.2.1.1.1.0", auth.IP)
	if err != nil {
		global.Logger.Error("\n snmp-check ip: %v err: %v", auth.IP, err.Error())
		return false
	}
	return true
}

// 返回RetData json string
func CheckSNMP(data gs_define.MQMsg) interface{} {
	retData := struct {
		Status int    `json:"status"`
		Msg    string `json:"msg"`
	}{}
	auth := gs_define.SNMP_Auth{}
	err := json.Unmarshal([]byte(data.Data), &auth)
	if err != nil {
		global.Logger.Error("json.Unmarshal失败 parm: %v, err:%v", data, err.Error())
		retData.Msg = "解析错误"
		retData.Status = 1
	} else {
		// 新建snmp对象
		if CheckSNMPConn(auth) {
			retData.Msg = "snmp连接成功"
			retData.Status = 0
		} else {
			retData.Msg = "snmp连接失败"
			retData.Status = 1
		}
	}
	return retData
}
