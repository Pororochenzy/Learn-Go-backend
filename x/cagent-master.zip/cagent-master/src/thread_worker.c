#include "thread_worker.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <pthread.h>

#include "../libs/C-Snip/buf.h"
#include "../libs/parson/parson.h"
#include "../libs/C-Thread-Pool/thpool.h"
#include "util/zx_time.h"
#include "util/zx_file.h"
#include "util/zx_md5.h"
#include "util/zx_download.h"
#include "collect/system.h"
#include "collect/cpu.h"
#include "collect/diskio.h"
#include "collect/diskspace.h"
#include "collect/memory.h"
#include "collect/netinterface.h"
#include "collect/protocol.h"
#include "version.h"
#include "tcp_client.h"
#include "tcp_packet.h"
#include "thread_job.h"


#define MSG_TYPE_AGENT_HEART            "agent.heart"               // 心跳
#define MSG_TYPE_AGENT_INSPECT          "agent.inspect"             // 巡检
#define MSG_TYPE_AGENT_BASIC_COLLECT    "agent.basic.collect"       // 基本信息采集
#define MSG_TYPE_AGENT_CUSTOM_COLLECT   "agent.custom.collect"      // 自定义采集
#define MSG_TYPE_AGENT_CYCLE            "agent.cycle"               // 修改采集周期
#define MSG_TYPE_AGENT_MQ               "agent.mq"                  // 订阅/发布的消息


static int global_collect_cycle   = 60;    // 默认采集周期
static int global_heartbeat_cycle = 15;    // 默认心跳周期
static char global_file_server_host[128] = {0};
static int global_file_server_port = 80;


// 主动上报(心跳、基础信息)
static void send_active_data(const tcp_client_ptr client, const char *type, const char *data) {
    tcp_packet_ptr new_pkg = tcp_packet_new();
    buf_puts(new_pkg->type, type);
    buf_sprintf(new_pkg->uuid, "%lld", nowtime_us());
    buf_puts(new_pkg->from, "cagent");
    buf_puts(new_pkg->to, "cagent_proxy");
    buf_puts(new_pkg->back_to_mq, "");
    buf_puts(new_pkg->data, data);
    new_pkg->timestamp = nowtime();
    new_pkg->isback = 0;

    struct buf *bf = tcp_packet_to_string(new_pkg);
    printf("主动上报数据:\n%s\n", buf_str(bf));
    tcp_client_sendmq_push(client, bf);
    buf_free(bf);

    tcp_packet_free(new_pkg);
}

// 响应消息
static void send_response_data(const tcp_client_ptr client, const tcp_packet_ptr old_pkg, const char *data) {
    tcp_packet_ptr new_pkg = tcp_packet_new();
    buf_puts(new_pkg->type, buf_str(old_pkg->type));
    buf_puts(new_pkg->uuid, buf_str(old_pkg->uuid));
    buf_puts(new_pkg->from, buf_str(old_pkg->to));
    if (buf_len(old_pkg->back_to_mq) > 0) {
        buf_puts(new_pkg->to, buf_str(old_pkg->back_to_mq));
    } else {
        buf_puts(new_pkg->to, buf_str(old_pkg->from));
    }
    buf_puts(new_pkg->back_to_mq, "");
    buf_puts(new_pkg->data, data);
    new_pkg->timestamp = nowtime();
    new_pkg->isback = 1;

    struct buf *bf = tcp_packet_to_string(new_pkg);
    printf("返回响应消息:\n%s\n", buf_str(bf));
    tcp_client_sendmq_push(client, bf);
    buf_free(bf);
    
    tcp_packet_free(new_pkg);
}

// 执行结果
static void send_execute_result(
    const tcp_client_ptr client,
    const tcp_packet_ptr old_pkg,
    const tcp_packet_d4m_ptr d4m,
    const char *msg, int state, int ret_code
) {
    tcp_packet_d2m_ptr d2m = tcp_packet_new_d2m();
    buf_puts(d2m->session_id, buf_str(d4m->session_id));
    buf_puts(d2m->msg, msg);
    buf_puts(d2m->ret_msg, "");
    d2m->pkg_type = d4m->pkg_type;
    d2m->ret_code = ret_code;
    d2m->state = state;
    {
        tcp_packet_ptr new_pkg = tcp_packet_new();
        buf_puts(new_pkg->type, buf_str(old_pkg->type));
        buf_puts(new_pkg->uuid, buf_str(old_pkg->uuid));
        buf_puts(new_pkg->from, buf_str(old_pkg->to));
        buf_puts(new_pkg->to, buf_str(old_pkg->from));
        buf_puts(new_pkg->back_to_mq, buf_str(old_pkg->back_to_mq));
        struct buf *cache = tcp_packet_d2m_to_string(d2m);
        buf_puts(new_pkg->data, buf_str(cache));
        buf_free(cache);
        new_pkg->timestamp = nowtime();
        new_pkg->isback = 0;

        struct buf *bf = tcp_packet_to_string(new_pkg);
        printf("返回执行结果:\n%s\n", buf_str(bf));
        tcp_client_sendmq_push(client, bf);
        buf_free(bf);
        
        tcp_packet_free(new_pkg);
    }
    tcp_packet_free_d2m(d2m);
}

void *handle_command_or_script(void *arg) {
    assert(arg != NULL);
    thread_job_ptr job = (thread_job_ptr)arg;
    tcp_client_ptr c = thread_job_client(job);
    tcp_packet_ptr packet = thread_job_packet(job);
    tcp_packet_d4m_ptr d4m = thread_job_d4m(job);
    struct buf *filename = buf_empty();
    while (tcp_client_running(c)) {
        // 立即返回执行中状态
        send_execute_result(c, packet, d4m, "", TAgentStateExecuting, 0);

        // 执行路径
        if (buf_len(d4m->execute_path) > 0) {
            struct buf *cache = buf_empty();
            buf_sprintf(cache, "cd %s && %s", buf_str(d4m->execute_path), buf_str(d4m->command));
            buf_clear(d4m->command);
            buf_puts(d4m->command, buf_str(cache));
            buf_free(cache);
        }

        if (d4m->type == TypeCommand) {

            // nothing to do

        } else if (d4m->type == TypeScript) {
            // http下载脚本
            if (buf_len(d4m->script_path) > 0) {
                // 获取文件名
                zx_file_name(buf_str(d4m->script_path), filename);

                char url[1024] = {0};
                snprintf(url, 1024, "http://%s:%d%s",
                    global_file_server_host,
                    global_file_server_port,
                    buf_str(d4m->script_path));
                if (-1 == zx_download(url, buf_str(filename))) {
                    send_execute_result(c, packet, d4m, "下载脚本错误", TAgentStateException, 1);
                }
            }

            // 校验脚本的md5
            if (buf_len(d4m->script_md5) > 0) {
                char md5[ZX_MD5_STR_LEN+1] = {0};
                zx_md5_file(buf_str(filename), md5);
                if (0 != strcmp(md5, buf_str(d4m->script_md5))) {
                    send_execute_result(c, packet, d4m, "脚本md5校验错误", TAgentStateException, 1);
                    break;
                }
            }

            buf_clear(d4m->command);
            // 脚本类型
            if (0 == strcmp(buf_str(d4m->command_type), "shell")) {
                buf_sprintf(d4m->command, "sh %s", buf_str(filename));
            } else if (0 == strcmp(buf_str(d4m->command_type), "python")) {
                buf_sprintf(d4m->command, "python %s", buf_str(filename));
            } else {
                buf_sprintf(d4m->command, "%s %s", buf_str(d4m->command_type), buf_str(filename));
            }

        } else {
            printf("不支持的类型:%d\n", d4m->type);
            send_execute_result(c, packet, d4m, "不支持的类型", TAgentStateFinished, 0);
            break;
        }

        printf("执行:%s\n", buf_str(d4m->command));
        FILE *fp = popen(buf_str(d4m->command), "r");
        if (fp == NULL) {
            perror("执行失败");
            send_execute_result(c, packet, d4m, strerror(errno), TAgentStateException, 1);
            break;
        }

        // 持续读取执行结果并返回，直到执行完成、取消执行、超时退出、程序退出
        unsigned long long st = nowtime();
        unsigned long long last_result_time = nowtime_ms();
        struct buf *cache = buf_empty();
        while (tcp_client_running(c)) {
            usleep(20000); // 20ms 避免CPU占用过高

            // 超时退出(由于未实现取消，暂定2分钟)
            if (nowtime() - st > 120) {
                send_execute_result(c, packet, d4m, buf_str(cache), TAgentStateTerminated, 0);
                break;
            }

            int ret = zx_getline2(fp, cache, 2);
            if (ret < 0) {
                // 异常退出
                send_execute_result(c, packet, d4m, buf_str(cache), TAgentStateException, 1);
                break;
            } else if (ret == 0) {
                // 超时、EOF
                send_execute_result(c, packet, d4m, buf_str(cache), TAgentStateFinished, 0);
                break;
            } else {
                // 持续返回执行结果(最小间隔200ms)
                if (nowtime_ms() - last_result_time > 200) {
                    last_result_time = nowtime_ms();
                    send_execute_result(c, packet, d4m, buf_str(cache), TAgentStateExecuting, 0);
                    buf_clear(cache);
                }
            }
        }
        buf_free(cache);
        pclose(fp);
        break;
    }
    // 删除脚本文件
    if (buf_len(filename) > 0) {
        remove(buf_str(filename));
    }
    buf_free(filename);
    thread_job_free(job);
    // pthread_exit(NULL); // ？？？ 很奇怪，这里会阻塞线程退出
    return EXIT_SUCCESS;
}

void *thread_keeper(void *arg) {
    assert(arg != NULL);
    tcp_client_ptr c = (tcp_client_ptr)arg;
    unsigned long long st = nowtime();
    while (tcp_client_running(c)) {
        if (tcp_client_connected(c)) {
            if (nowtime() - st > global_heartbeat_cycle) {
                st = nowtime();

                struct zx_system_t si;
                zx_system_collect(&si);
                
                JSON_Value *root_value = json_value_init_object();
                JSON_Object *root_object = json_value_get_object(root_value);
                json_object_set_string(root_object, "os", si.os);
                json_object_set_string(root_object, "version", CAGENT_VERSION);
                char *serialized_string = json_serialize_to_string(root_value);

                send_active_data(c, MSG_TYPE_AGENT_HEART, serialized_string);
                tcp_client_ping(c);

                json_free_serialized_string(serialized_string);
                json_value_free(root_value);
            }
        }
        sleep(1);
    }
    pthread_exit(NULL);
    return EXIT_SUCCESS;
}

void *thread_collector(void *arg) {
    assert(arg != NULL);
    tcp_client_ptr c = (tcp_client_ptr)arg;
    unsigned long long st = nowtime();
    while (tcp_client_running(c)) {
        if (tcp_client_connected(c)) {
            if (nowtime() - st > global_collect_cycle) {
                st = nowtime();

                JSON_Value *root_value = json_value_init_object();
                JSON_Object *root_object = json_value_get_object(root_value);
                json_object_set_number(root_object, "unixtime", (double)nowtime());

                // system
                {
                    zx_system_t sys;
                    zx_system_collect(&sys);
                    json_object_dotset_string(root_object, "system.os", sys.os);
                    json_object_dotset_string(root_object, "system.hostname", sys.hostname);
                    json_object_dotset_string(root_object, "system.platform", sys.platform);
                    json_object_dotset_string(root_object, "system.platform_version", sys.platform_version);
                    json_object_dotset_string(root_object, "system.platform_family", sys.platform_family);
                    json_object_dotset_string(root_object, "system.machine", sys.machine);
                }

                // cpu
                {
                    zx_cpu_stat_t *stat = zx_cpu_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "cpu.num", stat->ncpus);
                        json_object_dotset_string(root_object, "cpu.desc", stat->desc);
                        json_object_dotset_number(root_object, "cpu.mhz", stat->mhz);
                        json_object_dotset_number(root_object, "cpu.user_pct", stat->user_pct);
                        json_object_dotset_number(root_object, "cpu.sys_pct", stat->sys_pct);
                        json_object_dotset_number(root_object, "cpu.idle_pct", stat->idle_pct);
                        json_object_dotset_number(root_object, "cpu.wait_pct", stat->wait_pct);
                        json_object_dotset_number(root_object, "cpu.pswitch", stat->pswitch);
                        json_object_dotset_number(root_object, "cpu.syscall", stat->syscall);
                        json_object_dotset_number(root_object, "cpu.sysread", stat->sysread);
                        json_object_dotset_number(root_object, "cpu.syswrite", stat->syswrite);
                        json_object_dotset_number(root_object, "cpu.sysfork", stat->sysfork);
                        json_object_dotset_number(root_object, "cpu.sysexec", stat->sysexec);
                        json_object_dotset_number(root_object, "cpu.load_avg1", stat->load_avg1);
                        json_object_dotset_number(root_object, "cpu.load_avg5", stat->load_avg5);
                        json_object_dotset_number(root_object, "cpu.load_avg15", stat->load_avg15);
                        json_object_dotset_number(root_object, "cpu.uptime", stat->uptime);

                        json_object_dotset_value(root_object, "cpu.list", json_value_init_array());
                        JSON_Array *arr = json_object_dotget_array(root_object, "cpu.list");
                        for (int i = 0; (i < stat->ncpus) && (stat->cpus_stat != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->cpus_stat[i].name);
                            json_object_set_number(obj, "user_pct", stat->cpus_stat[i].user_pct);
                            json_object_set_number(obj, "sys_pct", stat->cpus_stat[i].sys_pct);
                            json_object_set_number(obj, "idle_pct", stat->cpus_stat[i].idle_pct);
                            json_object_set_number(obj, "wait_pct", stat->cpus_stat[i].wait_pct);
                            json_object_set_number(obj, "pswitch", stat->cpus_stat[i].pswitch);
                            json_object_set_number(obj, "syscall", stat->cpus_stat[i].syscall);
                            json_object_set_number(obj, "sysread", stat->cpus_stat[i].sysread);
                            json_object_set_number(obj, "syswrite", stat->cpus_stat[i].syswrite);
                            json_object_set_number(obj, "sysfork", stat->cpus_stat[i].sysfork);
                            json_object_set_number(obj, "sysexec", stat->cpus_stat[i].sysexec);
                            json_array_append_value(arr, val);
                        }
                    }
                    zx_cpu_stat_destroy(stat);
                }
                
                // mem
                {
                    zx_mem_stat_t *stat = zx_mem_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "mem.real_total", stat->real_total);
                        json_object_dotset_number(root_object, "mem.real_free", stat->real_free);
                        json_object_dotset_number(root_object, "mem.real_pinned", stat->real_pinned);
                        json_object_dotset_number(root_object, "mem.real_inuse", stat->real_inuse);
                        json_object_dotset_number(root_object, "mem.real_system", stat->real_system);
                        json_object_dotset_number(root_object, "mem.real_user", stat->real_user);
                        json_object_dotset_number(root_object, "mem.real_process", stat->real_process);
                        json_object_dotset_number(root_object, "mem.virt_total", stat->virt_total);
                        json_object_dotset_number(root_object, "mem.virt_active", stat->virt_active);
                        json_object_dotset_number(root_object, "mem.pgsp_total",stat->pgsp_total);
                        json_object_dotset_number(root_object, "mem.pgsp_free", stat->pgsp_free);
                        json_object_dotset_number(root_object, "mem.pgsp_rsvd", stat->pgsp_rsvd);
                        json_object_dotset_number(root_object, "mem.pgbad", stat->pgbad);
                        json_object_dotset_number(root_object, "mem.pgexct", stat->pgexct);
                        json_object_dotset_number(root_object, "mem.pgins", stat->pgins);
                        json_object_dotset_number(root_object, "mem.pgouts", stat->pgouts);
                        json_object_dotset_number(root_object, "mem.pgspins", stat->pgspins);
                        json_object_dotset_number(root_object, "mem.pgspouts", stat->pgspouts);
                        json_object_dotset_number(root_object, "mem.pgsteals", stat->pgsteals);
                        json_object_dotset_number(root_object, "mem.scans", stat->scans);
                        json_object_dotset_number(root_object, "mem.cycles", stat->cycles);
                        json_object_dotset_number(root_object, "mem.numperm", stat->numperm);
                        json_object_dotset_number(root_object, "mem.iome", stat->iome);
                        json_object_dotset_number(root_object, "mem.iomu", stat->iomu);
                        json_object_dotset_number(root_object, "mem.iohwm", stat->iohwm);
                        json_object_dotset_number(root_object, "mem.pmem", stat->pmem);
                    }
                    zx_mem_stat_destroy(stat);
                }
                
                // disk
                {
                    zx_disk_stat_t *stat = zx_disk_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "disk.num", stat->ndisks);
                        json_object_dotset_number(root_object, "disk.size", stat->size);
                        json_object_dotset_number(root_object, "disk.free", stat->free);
                        json_object_dotset_number(root_object, "disk.rxfers", stat->rxfers);
                        json_object_dotset_number(root_object, "disk.xfers", stat->xfers);
                        json_object_dotset_number(root_object, "disk.wblks", stat->wblks);
                        json_object_dotset_number(root_object, "disk.rblks", stat->rblks);
                        json_object_dotset_number(root_object, "disk.time", stat->time);

                        json_object_dotset_value(root_object, "disk.list", json_value_init_array());
                        JSON_Array *arr = json_object_dotget_array(root_object, "disk.list");
                        for (int i = 0; (i < stat->ndisks) && (stat->disks_stat != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->disks_stat[i].name);
                            json_object_set_string(obj, "adapter", stat->disks_stat[i].adapter);
                            json_object_set_string(obj, "desc", stat->disks_stat[i].name);
                            json_object_set_string(obj, "vgname", stat->disks_stat[i].name);
                            json_object_set_number(obj, "size", stat->disks_stat[i].size);
                            json_object_set_number(obj, "free", stat->disks_stat[i].free);
                            json_object_set_number(obj, "bsize", stat->disks_stat[i].bsize);
                            json_object_set_number(obj, "rxfers", stat->disks_stat[i].rxfers);
                            json_object_set_number(obj, "xfers", stat->disks_stat[i].xfers);      
                            json_object_set_number(obj, "wblks", stat->disks_stat[i].wblks);      
                            json_object_set_number(obj, "rblks", stat->disks_stat[i].rblks);      
                            json_object_set_number(obj, "time", stat->disks_stat[i].time);       
                            json_object_set_number(obj, "paths_count", stat->disks_stat[i].paths_count);
                            json_object_set_number(obj, "qdepth", stat->disks_stat[i].qdepth);     
                            json_object_set_number(obj, "q_full", stat->disks_stat[i].q_full);     
                            json_object_set_number(obj, "q_sampled", stat->disks_stat[i].q_sampled);  
                            json_object_set_number(obj, "rserv", stat->disks_stat[i].rserv);      
                            json_object_set_number(obj, "rtimeout", stat->disks_stat[i].rtimeout);   
                            json_object_set_number(obj, "rfailed", stat->disks_stat[i].rfailed);    
                            json_object_set_number(obj, "min_rserv", stat->disks_stat[i].min_rserv);  
                            json_object_set_number(obj, "max_rserv", stat->disks_stat[i].max_rserv);  
                            json_object_set_number(obj, "wserv", stat->disks_stat[i].wserv);      
                            json_object_set_number(obj, "wtimeout", stat->disks_stat[i].wtimeout);   
                            json_object_set_number(obj, "wfailed", stat->disks_stat[i].wfailed);    
                            json_object_set_number(obj, "min_wserv", stat->disks_stat[i].min_wserv);  
                            json_object_set_number(obj, "max_wserv", stat->disks_stat[i].max_wserv);  
                            json_object_set_number(obj, "wq_depth", stat->disks_stat[i].wq_depth);   
                            json_object_set_number(obj, "wq_sampled", stat->disks_stat[i].wq_sampled); 
                            json_object_set_number(obj, "wq_time", stat->disks_stat[i].wq_time);    
                            json_object_set_number(obj, "wq_min_time", stat->disks_stat[i].wq_min_time);
                            json_object_set_number(obj, "wq_max_time", stat->disks_stat[i].wq_max_time);
                            json_array_append_value(arr, val);
                        }

                        json_object_dotset_value(root_object, "disk.list2", json_value_init_array());
                        JSON_Array *arr2 = json_object_dotget_array(root_object, "disk.list2");
                        for (int i = 0; (i < stat->ndisks) && (stat->disks_stat_1s != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->disks_stat_1s[i].name);
                            json_object_set_string(obj, "adapter", stat->disks_stat_1s[i].adapter);
                            json_object_set_string(obj, "desc", stat->disks_stat_1s[i].name);
                            json_object_set_string(obj, "vgname", stat->disks_stat_1s[i].name);
                            json_object_set_number(obj, "size", stat->disks_stat_1s[i].size);
                            json_object_set_number(obj, "free", stat->disks_stat_1s[i].free);
                            json_object_set_number(obj, "bsize", stat->disks_stat_1s[i].bsize);
                            json_object_set_number(obj, "rxfers", stat->disks_stat_1s[i].rxfers);
                            json_object_set_number(obj, "xfers", stat->disks_stat_1s[i].xfers);      
                            json_object_set_number(obj, "wblks", stat->disks_stat_1s[i].wblks);      
                            json_object_set_number(obj, "rblks", stat->disks_stat_1s[i].rblks);      
                            json_object_set_number(obj, "time", stat->disks_stat_1s[i].time);       
                            json_object_set_number(obj, "paths_count", stat->disks_stat_1s[i].paths_count);
                            json_object_set_number(obj, "qdepth", stat->disks_stat_1s[i].qdepth);     
                            json_object_set_number(obj, "q_full", stat->disks_stat_1s[i].q_full);     
                            json_object_set_number(obj, "q_sampled", stat->disks_stat_1s[i].q_sampled);  
                            json_object_set_number(obj, "rserv", stat->disks_stat_1s[i].rserv);      
                            json_object_set_number(obj, "rtimeout", stat->disks_stat_1s[i].rtimeout);   
                            json_object_set_number(obj, "rfailed", stat->disks_stat_1s[i].rfailed);    
                            json_object_set_number(obj, "min_rserv", stat->disks_stat_1s[i].min_rserv);  
                            json_object_set_number(obj, "max_rserv", stat->disks_stat_1s[i].max_rserv);  
                            json_object_set_number(obj, "wserv", stat->disks_stat_1s[i].wserv);      
                            json_object_set_number(obj, "wtimeout", stat->disks_stat_1s[i].wtimeout);   
                            json_object_set_number(obj, "wfailed", stat->disks_stat_1s[i].wfailed);    
                            json_object_set_number(obj, "min_wserv", stat->disks_stat_1s[i].min_wserv);  
                            json_object_set_number(obj, "max_wserv", stat->disks_stat_1s[i].max_wserv);  
                            json_object_set_number(obj, "wq_depth", stat->disks_stat_1s[i].wq_depth);   
                            json_object_set_number(obj, "wq_sampled", stat->disks_stat_1s[i].wq_sampled); 
                            json_object_set_number(obj, "wq_time", stat->disks_stat_1s[i].wq_time);    
                            json_object_set_number(obj, "wq_min_time", stat->disks_stat_1s[i].wq_min_time);
                            json_object_set_number(obj, "wq_max_time", stat->disks_stat_1s[i].wq_max_time);
                            json_array_append_value(arr2, val);
                        }
                    }
                    zx_disk_stat_destroy(stat);
                }

                // disk adapter
                {
                    zx_diskadapter_stat_t *stat = zx_diskadapter_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "diskadapter.num", stat->ndiskadapters);

                        json_object_dotset_value(root_object, "diskadapter.list", json_value_init_array());
                        JSON_Array *arr = json_object_dotget_array(root_object, "diskadapter.list");
                        for (int i = 0; (i < stat->ndiskadapters) && (stat->diskadapters_stat != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->diskadapters_stat[i].name);
                            json_object_set_number(obj, "ndisks", stat->diskadapters_stat[i].ndisks);
                            json_object_set_number(obj, "size", stat->diskadapters_stat[i].size);
                            json_object_set_number(obj, "free", stat->diskadapters_stat[i].free);
                            json_object_set_number(obj, "rxfers", stat->diskadapters_stat[i].rxfers);
                            json_object_set_number(obj, "xfers", stat->diskadapters_stat[i].xfers);
                            json_object_set_number(obj, "wblks", stat->diskadapters_stat[i].wblks);
                            json_object_set_number(obj, "rblks", stat->diskadapters_stat[i].rblks);
                            json_object_set_number(obj, "time", stat->diskadapters_stat[i].time);
                            json_array_append_value(arr, val);
                        }

                        json_object_dotset_value(root_object, "diskadapter.list2", json_value_init_array());
                        JSON_Array *arr2 = json_object_dotget_array(root_object, "diskadapter.list2");
                        for (int i = 0; (i < stat->ndiskadapters) && (stat->diskadapters_stat_1s != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->diskadapters_stat_1s[i].name);
                            json_object_set_number(obj, "ndisks", stat->diskadapters_stat_1s[i].ndisks);
                            json_object_set_number(obj, "size", stat->diskadapters_stat_1s[i].size);
                            json_object_set_number(obj, "free", stat->diskadapters_stat_1s[i].free);
                            json_object_set_number(obj, "rxfers", stat->diskadapters_stat_1s[i].rxfers);
                            json_object_set_number(obj, "xfers", stat->diskadapters_stat_1s[i].xfers);
                            json_object_set_number(obj, "wblks", stat->diskadapters_stat_1s[i].wblks);
                            json_object_set_number(obj, "rblks", stat->diskadapters_stat_1s[i].rblks);
                            json_object_set_number(obj, "time", stat->diskadapters_stat_1s[i].time);
                            json_array_append_value(arr2, val);
                        }
                    }
                    zx_diskadapter_stat_destroy(stat);
                }

                // disk path
                {
                    zx_diskpath_stat_t *stat = zx_diskpath_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "diskpath.num", stat->ndiskpaths);

                        json_object_dotset_value(root_object, "diskpath.list", json_value_init_array());
                        JSON_Array *arr = json_object_dotget_array(root_object, "diskpath.list");
                        for (int i = 0; (i < stat->ndiskpaths) && (stat->diskpaths_stat != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->diskpaths_stat[i].name);
                            json_object_set_string(obj, "adapter", stat->diskpaths_stat[i].adapter);
                            json_object_set_number(obj, "rxfers", stat->diskpaths_stat[i].rxfers);
                            json_object_set_number(obj, "xfers", stat->diskpaths_stat[i].xfers);
                            json_object_set_number(obj, "wblks", stat->diskpaths_stat[i].wblks);
                            json_object_set_number(obj, "rblks", stat->diskpaths_stat[i].rblks);
                            json_object_set_number(obj, "time", stat->diskpaths_stat[i].time);
                            json_object_set_number(obj, "q_full", stat->diskpaths_stat[i].q_full);     
                            json_object_set_number(obj, "q_sampled", stat->diskpaths_stat[i].q_sampled);  
                            json_object_set_number(obj, "rserv", stat->diskpaths_stat[i].rserv);      
                            json_object_set_number(obj, "rtimeout", stat->diskpaths_stat[i].rtimeout);   
                            json_object_set_number(obj, "rfailed", stat->diskpaths_stat[i].rfailed);    
                            json_object_set_number(obj, "min_rserv", stat->diskpaths_stat[i].min_rserv);  
                            json_object_set_number(obj, "max_rserv", stat->diskpaths_stat[i].max_rserv);  
                            json_object_set_number(obj, "wserv", stat->diskpaths_stat[i].wserv);      
                            json_object_set_number(obj, "wtimeout", stat->diskpaths_stat[i].wtimeout);   
                            json_object_set_number(obj, "wfailed", stat->diskpaths_stat[i].wfailed);    
                            json_object_set_number(obj, "min_wserv", stat->diskpaths_stat[i].min_wserv);  
                            json_object_set_number(obj, "max_wserv", stat->diskpaths_stat[i].max_wserv);  
                            json_object_set_number(obj, "wq_depth", stat->diskpaths_stat[i].wq_depth);   
                            json_object_set_number(obj, "wq_sampled", stat->diskpaths_stat[i].wq_sampled); 
                            json_object_set_number(obj, "wq_time", stat->diskpaths_stat[i].wq_time);    
                            json_object_set_number(obj, "wq_min_time", stat->diskpaths_stat[i].wq_min_time);
                            json_object_set_number(obj, "wq_max_time", stat->diskpaths_stat[i].wq_max_time);
                            json_array_append_value(arr, val);
                        }

                        json_object_dotset_value(root_object, "diskpath.list2", json_value_init_array());
                        JSON_Array *arr2 = json_object_dotget_array(root_object, "diskpath.list2");
                        for (int i = 0; (i < stat->ndiskpaths) && (stat->diskpaths_stat_1s != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->diskpaths_stat_1s[i].name);
                            json_object_set_string(obj, "adapter", stat->diskpaths_stat_1s[i].adapter);
                            json_object_set_number(obj, "rxfers", stat->diskpaths_stat_1s[i].rxfers);
                            json_object_set_number(obj, "xfers", stat->diskpaths_stat_1s[i].xfers);
                            json_object_set_number(obj, "wblks", stat->diskpaths_stat_1s[i].wblks);
                            json_object_set_number(obj, "rblks", stat->diskpaths_stat_1s[i].rblks);
                            json_object_set_number(obj, "time", stat->diskpaths_stat_1s[i].time);
                            json_object_set_number(obj, "q_full", stat->diskpaths_stat_1s[i].q_full);     
                            json_object_set_number(obj, "q_sampled", stat->diskpaths_stat_1s[i].q_sampled);  
                            json_object_set_number(obj, "rserv", stat->diskpaths_stat_1s[i].rserv);      
                            json_object_set_number(obj, "rtimeout", stat->diskpaths_stat_1s[i].rtimeout);   
                            json_object_set_number(obj, "rfailed", stat->diskpaths_stat_1s[i].rfailed);    
                            json_object_set_number(obj, "min_rserv", stat->diskpaths_stat_1s[i].min_rserv);  
                            json_object_set_number(obj, "max_rserv", stat->diskpaths_stat_1s[i].max_rserv);  
                            json_object_set_number(obj, "wserv", stat->diskpaths_stat_1s[i].wserv);      
                            json_object_set_number(obj, "wtimeout", stat->diskpaths_stat_1s[i].wtimeout);   
                            json_object_set_number(obj, "wfailed", stat->diskpaths_stat_1s[i].wfailed);    
                            json_object_set_number(obj, "min_wserv", stat->diskpaths_stat_1s[i].min_wserv);  
                            json_object_set_number(obj, "max_wserv", stat->diskpaths_stat_1s[i].max_wserv);  
                            json_object_set_number(obj, "wq_depth", stat->diskpaths_stat_1s[i].wq_depth);   
                            json_object_set_number(obj, "wq_sampled", stat->diskpaths_stat_1s[i].wq_sampled); 
                            json_object_set_number(obj, "wq_time", stat->diskpaths_stat_1s[i].wq_time);    
                            json_object_set_number(obj, "wq_min_time", stat->diskpaths_stat_1s[i].wq_min_time);
                            json_object_set_number(obj, "wq_max_time", stat->diskpaths_stat_1s[i].wq_max_time);
                            json_array_append_value(arr2, val);
                        }
                    }
                    zx_diskpath_stat_destroy(stat);
                }

                // disk volume
                {
                    zx_diskvolume_stat_t *stat = zx_diskvolume_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "diskvolume.num", stat->ndiskvolumes);

                        json_object_dotset_value(root_object, "diskvolume.list", json_value_init_array());
                        JSON_Array *arr = json_object_dotget_array(root_object, "diskvolume.list");
                        for (int i = 0; (i < stat->ndiskvolumes) && (stat->diskvolumes_stat != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->diskvolumes_stat[i].name);
                            json_object_set_string(obj, "vgname", stat->diskvolumes_stat[i].vgname);
                            json_object_set_number(obj, "open_close", stat->diskvolumes_stat[i].open_close);
                            json_object_set_number(obj, "state", stat->diskvolumes_stat[i].state);
                            json_object_set_number(obj, "mirror_policy", stat->diskvolumes_stat[i].mirror_policy);
                            json_object_set_number(obj, "mirror_write_consistency", stat->diskvolumes_stat[i].mirror_write_consistency);
                            json_object_set_number(obj, "write_verify", stat->diskvolumes_stat[i].write_verify);
                            json_object_set_number(obj, "ppsize", stat->diskvolumes_stat[i].ppsize);
                            json_object_set_number(obj, "logical_partitions", stat->diskvolumes_stat[i].logical_partitions);
                            json_object_set_number(obj, "mirrors", stat->diskvolumes_stat[i].mirrors); 
                            json_object_set_number(obj, "iocnt", stat->diskvolumes_stat[i].iocnt);
                            json_object_set_number(obj, "kbreads", stat->diskvolumes_stat[i].kbreads);
                            json_object_set_number(obj, "kbwrites", stat->diskvolumes_stat[i].kbwrites);
                            json_array_append_value(arr, val);
                        }
                    }
                    zx_diskvolume_stat_destroy(stat);
                }

                // filesystem
                {
                    zx_diskspace_stat_t *stat = zx_diskspace_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "filesystem.num", stat->nfs);

                        json_object_dotset_value(root_object, "filesystem.list", json_value_init_array());
                        JSON_Array *arr = json_object_dotget_array(root_object, "filesystem.list");
                        for (int i = 0; (i < stat->nfs) && (stat->fs_stat != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "fs_path", stat->fs_stat[i].fs_path);
                            json_object_set_string(obj, "fs_type", stat->fs_stat[i].fs_type);
                            json_object_set_string(obj, "fs_mount", stat->fs_stat[i].fs_mount);
                            json_object_set_number(obj, "block_bsize", stat->fs_stat[i].block_bsize);
                            json_object_set_number(obj, "block_total", stat->fs_stat[i].block_total);
                            json_object_set_number(obj, "block_used", stat->fs_stat[i].block_used);
                            json_object_set_number(obj, "block_free", stat->fs_stat[i].block_free);
                            json_object_set_number(obj, "block_used_pct", stat->fs_stat[i].block_used_pct);
                            json_object_set_number(obj, "block_free_pct", stat->fs_stat[i].block_free_pct);
                            json_object_set_number(obj, "inode_total", stat->fs_stat[i].inode_total);
                            json_object_set_number(obj, "inode_free", stat->fs_stat[i].inode_free);
                            json_array_append_value(arr, val);
                        }
                    }
                    zx_diskspace_stat_destroy(stat);
                }

                // net interface
                {
                    zx_netif_stat_t *stat = zx_netif_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "netif.num", stat->nnetifs);
                        json_object_dotset_number(root_object, "netif.ibytes", stat->ibytes);
                        json_object_dotset_number(root_object, "netif.ipackets", stat->ipackets);
                        json_object_dotset_number(root_object, "netif.ierrors", stat->ierrors);
                        json_object_dotset_number(root_object, "netif.obytes", stat->obytes);
                        json_object_dotset_number(root_object, "netif.opackets", stat->opackets);
                        json_object_dotset_number(root_object, "netif.oerrors", stat->oerrors);
                        json_object_dotset_number(root_object, "netif.collisions", stat->collisions);

                        json_object_dotset_value(root_object, "netif.list", json_value_init_array());
                        JSON_Array *arr = json_object_dotget_array(root_object, "netif.list");
                        for (int i = 0; (i < stat->nnetifs) && (stat->netifs_stat != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->netifs_stat[i].name);
                            json_object_set_string(obj, "desc", stat->netifs_stat[i].desc);
                            json_object_set_string(obj, "type", stat->netifs_stat[i].type);
                            json_object_set_number(obj, "ibytes", stat->netifs_stat[i].ibytes);
                            json_object_set_number(obj, "ipackets", stat->netifs_stat[i].ipackets);
                            json_object_set_number(obj, "ierrors", stat->netifs_stat[i].ierrors);
                            json_object_set_number(obj, "obytes", stat->netifs_stat[i].obytes);
                            json_object_set_number(obj, "opackets", stat->netifs_stat[i].opackets);
                            json_object_set_number(obj, "oerrors", stat->netifs_stat[i].oerrors);
                            json_object_set_number(obj, "collisions", stat->netifs_stat[i].collisions);
                            json_object_set_number(obj, "mtu", stat->netifs_stat[i].mtu);
                            json_object_set_number(obj, "bitrate", stat->netifs_stat[i].bitrate);
                            json_array_append_value(arr, val);
                        }

                        json_object_dotset_value(root_object, "netif.list2", json_value_init_array());
                        JSON_Array *arr2 = json_object_dotget_array(root_object, "netif.list2");
                        for (int i = 0; (i < stat->nnetifs) && (stat->netifs_stat_1s != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->netifs_stat_1s[i].name);
                            json_object_set_string(obj, "desc", stat->netifs_stat_1s[i].desc);
                            json_object_set_string(obj, "type", stat->netifs_stat_1s[i].type);
                            json_object_set_number(obj, "ibytes", stat->netifs_stat_1s[i].ibytes);
                            json_object_set_number(obj, "ipackets", stat->netifs_stat_1s[i].ipackets);
                            json_object_set_number(obj, "ierrors", stat->netifs_stat_1s[i].ierrors);
                            json_object_set_number(obj, "obytes", stat->netifs_stat_1s[i].obytes);
                            json_object_set_number(obj, "opackets", stat->netifs_stat_1s[i].opackets);
                            json_object_set_number(obj, "oerrors", stat->netifs_stat_1s[i].oerrors);
                            json_object_set_number(obj, "collisions", stat->netifs_stat_1s[i].collisions);
                            json_object_set_number(obj, "mtu", stat->netifs_stat_1s[i].mtu);
                            json_object_set_number(obj, "bitrate", stat->netifs_stat_1s[i].bitrate);
                            json_array_append_value(arr2, val);
                        }
                    }
                    zx_netif_stat_destroy(stat);
                }

                // net adapter
                {
                    zx_netadapter_stat_t *stat = zx_netadapter_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "netadapter.num", stat->nnetadapters);

                        json_object_dotset_value(root_object, "netadapter.list", json_value_init_array());
                        JSON_Array *arr = json_object_dotget_array(root_object, "netadapter.list");
                        for (int i = 0; (i < stat->nnetadapters) && (stat->netadapters_stat != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->netadapters_stat[i].name);
                            json_object_set_number(obj, "tx_packets", stat->netadapters_stat[i].tx_packets);
                            json_object_set_number(obj, "tx_bytes", stat->netadapters_stat[i].tx_bytes);
                            json_object_set_number(obj, "tx_interrupts", stat->netadapters_stat[i].tx_interrupts);
                            json_object_set_number(obj, "tx_errors", stat->netadapters_stat[i].tx_errors);
                            json_object_set_number(obj, "tx_packets_dropped", stat->netadapters_stat[i].tx_packets_dropped);
                            json_object_set_number(obj, "tx_queue_size", stat->netadapters_stat[i].tx_queue_size);
                            json_object_set_number(obj, "tx_queue_len", stat->netadapters_stat[i].tx_queue_len);
                            json_object_set_number(obj, "tx_queue_overflow", stat->netadapters_stat[i].tx_queue_overflow);
                            json_object_set_number(obj, "tx_broadcast_packets", stat->netadapters_stat[i].tx_broadcast_packets);
                            json_object_set_number(obj, "tx_multicast_packets", stat->netadapters_stat[i].tx_multicast_packets);
                            json_object_set_number(obj, "tx_carrier_sense", stat->netadapters_stat[i].tx_carrier_sense);
                            json_object_set_number(obj, "tx_DMA_underrun", stat->netadapters_stat[i].tx_DMA_underrun);
                            json_object_set_number(obj, "tx_lost_CTS_errors", stat->netadapters_stat[i].tx_lost_CTS_errors);
                            json_object_set_number(obj, "tx_max_collision_errors", stat->netadapters_stat[i].tx_max_collision_errors);
                            json_object_set_number(obj, "tx_late_collision_errors", stat->netadapters_stat[i].tx_late_collision_errors);
                            json_object_set_number(obj, "tx_deferred", stat->netadapters_stat[i].tx_deferred);
                            json_object_set_number(obj, "tx_timeout_errors", stat->netadapters_stat[i].tx_timeout_errors);
                            json_object_set_number(obj, "tx_single_collision_count", stat->netadapters_stat[i].tx_single_collision_count);
                            json_object_set_number(obj, "tx_multiple_collision_count", stat->netadapters_stat[i].tx_multiple_collision_count);
                            json_object_set_number(obj, "rx_packets", stat->netadapters_stat[i].rx_packets);
                            json_object_set_number(obj, "rx_bytes", stat->netadapters_stat[i].rx_bytes);
                            json_object_set_number(obj, "rx_interrupts", stat->netadapters_stat[i].rx_interrupts);
                            json_object_set_number(obj, "rx_errors", stat->netadapters_stat[i].rx_errors);
                            json_object_set_number(obj, "rx_packets_dropped", stat->netadapters_stat[i].rx_packets_dropped);
                            json_object_set_number(obj, "rx_bad_packets", stat->netadapters_stat[i].rx_bad_packets);
                            json_object_set_number(obj, "rx_multicast_packets", stat->netadapters_stat[i].rx_multicast_packets);
                            json_object_set_number(obj, "rx_broadcast_packets", stat->netadapters_stat[i].rx_broadcast_packets);
                            json_object_set_number(obj, "rx_CRC_errors", stat->netadapters_stat[i].rx_CRC_errors);
                            json_object_set_number(obj, "rx_DMA_overrun", stat->netadapters_stat[i].rx_DMA_overrun);
                            json_object_set_number(obj, "rx_alignment_errors", stat->netadapters_stat[i].rx_alignment_errors);
                            json_object_set_number(obj, "rx_noresource_errors", stat->netadapters_stat[i].rx_noresource_errors);
                            json_object_set_number(obj, "rx_collision_errors", stat->netadapters_stat[i].rx_collision_errors);
                            json_object_set_number(obj, "rx_packet_tooshort_errors", stat->netadapters_stat[i].rx_packet_tooshort_errors);
                            json_object_set_number(obj, "rx_packet_toolong_errors", stat->netadapters_stat[i].rx_packet_toolong_errors);
                            json_object_set_number(obj, "rx_packets_discardedbyadapter", stat->netadapters_stat[i].rx_packets_discardedbyadapter);
                            json_array_append_value(arr, val);
                        }

                        json_object_dotset_value(root_object, "netadapter.list2", json_value_init_array());
                        JSON_Array *arr2 = json_object_dotget_array(root_object, "netadapter.list2");
                        for (int i = 0; (i < stat->nnetadapters) && (stat->netadapters_stat_1s != NULL); i++) {
                            JSON_Value *val = json_value_init_object();
                            JSON_Object *obj = json_value_get_object(val);
                            json_object_set_string(obj, "name", stat->netadapters_stat_1s[i].name);
                            json_object_set_number(obj, "tx_packets", stat->netadapters_stat_1s[i].tx_packets);
                            json_object_set_number(obj, "tx_bytes", stat->netadapters_stat_1s[i].tx_bytes);
                            json_object_set_number(obj, "tx_interrupts", stat->netadapters_stat_1s[i].tx_interrupts);
                            json_object_set_number(obj, "tx_errors", stat->netadapters_stat_1s[i].tx_errors);
                            json_object_set_number(obj, "tx_packets_dropped", stat->netadapters_stat_1s[i].tx_packets_dropped);
                            json_object_set_number(obj, "tx_queue_size", stat->netadapters_stat_1s[i].tx_queue_size);
                            json_object_set_number(obj, "tx_queue_len", stat->netadapters_stat_1s[i].tx_queue_len);
                            json_object_set_number(obj, "tx_queue_overflow", stat->netadapters_stat_1s[i].tx_queue_overflow);
                            json_object_set_number(obj, "tx_broadcast_packets", stat->netadapters_stat_1s[i].tx_broadcast_packets);
                            json_object_set_number(obj, "tx_multicast_packets", stat->netadapters_stat_1s[i].tx_multicast_packets);
                            json_object_set_number(obj, "tx_carrier_sense", stat->netadapters_stat_1s[i].tx_carrier_sense);
                            json_object_set_number(obj, "tx_DMA_underrun", stat->netadapters_stat_1s[i].tx_DMA_underrun);
                            json_object_set_number(obj, "tx_lost_CTS_errors", stat->netadapters_stat_1s[i].tx_lost_CTS_errors);
                            json_object_set_number(obj, "tx_max_collision_errors", stat->netadapters_stat_1s[i].tx_max_collision_errors);
                            json_object_set_number(obj, "tx_late_collision_errors", stat->netadapters_stat_1s[i].tx_late_collision_errors);
                            json_object_set_number(obj, "tx_deferred", stat->netadapters_stat_1s[i].tx_deferred);
                            json_object_set_number(obj, "tx_timeout_errors", stat->netadapters_stat_1s[i].tx_timeout_errors);
                            json_object_set_number(obj, "tx_single_collision_count", stat->netadapters_stat_1s[i].tx_single_collision_count);
                            json_object_set_number(obj, "tx_multiple_collision_count", stat->netadapters_stat_1s[i].tx_multiple_collision_count);
                            json_object_set_number(obj, "rx_packets", stat->netadapters_stat_1s[i].rx_packets);
                            json_object_set_number(obj, "rx_bytes", stat->netadapters_stat_1s[i].rx_bytes);
                            json_object_set_number(obj, "rx_interrupts", stat->netadapters_stat_1s[i].rx_interrupts);
                            json_object_set_number(obj, "rx_errors", stat->netadapters_stat_1s[i].rx_errors);
                            json_object_set_number(obj, "rx_packets_dropped", stat->netadapters_stat_1s[i].rx_packets_dropped);
                            json_object_set_number(obj, "rx_bad_packets", stat->netadapters_stat_1s[i].rx_bad_packets);
                            json_object_set_number(obj, "rx_multicast_packets", stat->netadapters_stat_1s[i].rx_multicast_packets);
                            json_object_set_number(obj, "rx_broadcast_packets", stat->netadapters_stat_1s[i].rx_broadcast_packets);
                            json_object_set_number(obj, "rx_CRC_errors", stat->netadapters_stat_1s[i].rx_CRC_errors);
                            json_object_set_number(obj, "rx_DMA_overrun", stat->netadapters_stat_1s[i].rx_DMA_overrun);
                            json_object_set_number(obj, "rx_alignment_errors", stat->netadapters_stat_1s[i].rx_alignment_errors);
                            json_object_set_number(obj, "rx_noresource_errors", stat->netadapters_stat_1s[i].rx_noresource_errors);
                            json_object_set_number(obj, "rx_collision_errors", stat->netadapters_stat_1s[i].rx_collision_errors);
                            json_object_set_number(obj, "rx_packet_tooshort_errors", stat->netadapters_stat_1s[i].rx_packet_tooshort_errors);
                            json_object_set_number(obj, "rx_packet_toolong_errors", stat->netadapters_stat_1s[i].rx_packet_toolong_errors);
                            json_object_set_number(obj, "rx_packets_discardedbyadapter", stat->netadapters_stat_1s[i].rx_packets_discardedbyadapter);
                            json_array_append_value(arr2, val);
                        }
                    }
                    zx_netadapter_stat_destroy(stat);
                }

                // protocol
                {
                    zx_protocol_stat_t *stat = zx_protocol_stat_init();
                    if (stat != NULL) {
                        json_object_dotset_number(root_object, "protocol.ip.ipackets", stat->ip_ipackets);
                        json_object_dotset_number(root_object, "protocol.ip.ierrors", stat->ip_ierrors);
                        json_object_dotset_number(root_object, "protocol.ip.iqueueoverflow", stat->ip_iqueueoverflow);
                        json_object_dotset_number(root_object, "protocol.ip.opackets", stat->ip_opackets);
                        json_object_dotset_number(root_object, "protocol.ip.oerrors", stat->ip_oerrors);

                        json_object_dotset_number(root_object, "protocol.ipv6.ipackets", stat->ipv6_ipackets);
                        json_object_dotset_number(root_object, "protocol.ipv6.ierrors", stat->ipv6_ierrors);
                        json_object_dotset_number(root_object, "protocol.ipv6.iqueueoverflow", stat->ipv6_iqueueoverflow);
                        json_object_dotset_number(root_object, "protocol.ipv6.opackets", stat->ipv6_opackets);
                        json_object_dotset_number(root_object, "protocol.ipv6.oerrors", stat->ipv6_oerrors);

                        json_object_dotset_number(root_object, "protocol.icmp.received", stat->icmp_received);
                        json_object_dotset_number(root_object, "protocol.icmp.sent", stat->icmp_sent);
                        json_object_dotset_number(root_object, "protocol.icmp.errors", stat->icmp_errors);

                        json_object_dotset_number(root_object, "protocol.icmpv6.received", stat->icmpv6_received);
                        json_object_dotset_number(root_object, "protocol.icmpv6.sent", stat->icmpv6_sent);
                        json_object_dotset_number(root_object, "protocol.icmpv6.errors", stat->icmpv6_errors);

                        json_object_dotset_number(root_object, "protocol.udp.ipackets", stat->udp_ipackets);
                        json_object_dotset_number(root_object, "protocol.udp.ierrors", stat->udp_ierrors);
                        json_object_dotset_number(root_object, "protocol.udp.opackets", stat->udp_opackets);
                        json_object_dotset_number(root_object, "protocol.udp.no_socket", stat->udp_no_socket);

                        json_object_dotset_number(root_object, "protocol.tcp.ipackets", stat->tcp_ipackets);
                        json_object_dotset_number(root_object, "protocol.tcp.ierrors", stat->tcp_ierrors);
                        json_object_dotset_number(root_object, "protocol.tcp.opackets", stat->tcp_opackets);
                        json_object_dotset_number(root_object, "protocol.tcp.initiated", stat->tcp_initiated);
                        json_object_dotset_number(root_object, "protocol.tcp.accepted", stat->tcp_accepted);
                        json_object_dotset_number(root_object, "protocol.tcp.established", stat->tcp_established);
                        json_object_dotset_number(root_object, "protocol.tcp.dropped", stat->tcp_dropped);
                    }
                    zx_protocol_stat_destroy(stat);
                }

                // todo 进程、端口等

                char *serialized_string = json_serialize_to_string(root_value);
                
                send_active_data(c, MSG_TYPE_AGENT_BASIC_COLLECT, serialized_string);

                json_free_serialized_string(serialized_string);
                json_value_free(root_value);
            }
        }
        sleep(1);
    }
    pthread_exit(NULL);
    return EXIT_SUCCESS;
}

void *thread_executor(void *arg) {
    assert(arg != NULL);
    tcp_client_ptr c = (tcp_client_ptr)arg;
    int thpool_cap = 10;
    threadpool thpool = thpool_init(thpool_cap);
    struct buf *bf = buf_empty();
    while (tcp_client_running(c)) {
        usleep(20000); // 20ms 避免CPU占用过高

        if (thpool_num_threads_working(thpool) >= thpool_cap) {
            continue;
        }
        
        tcp_client_recvmq_pop(c, bf);
        if (buf_len(bf) == 0) {
            continue;
        }
        printf("当前活跃线程:%d\n", thpool_num_threads_working(thpool));
        printf("处理消息:\n%s\n", buf_str(bf));

        // 收到任何消息均重置ping计数
        tcp_client_pong(c);

        tcp_packet_ptr packet = tcp_packet_new();
        if (-1 == tcp_packet_parse(bf, packet)) {
            printf("解析消息错误\n");
            tcp_packet_free(packet);
            continue;
        }

        // 丢弃过期数据(暂定30分钟过期)
        // if (nowtime() - packet->timestamp > 1800) {
        //     printf("消息过期\n");
        //     tcp_packet_free(packet);
        //     continue;
        // }

        if (0 == strcmp(buf_str(packet->type), MSG_TYPE_AGENT_HEART)) {
            // 获取文件服务器信息
            JSON_Value *root_value = json_parse_string(buf_str(packet->data));
            if (root_value == NULL) {
                printf("解析数据错误\n");
                tcp_packet_free(packet);
                continue;
            }

            JSON_Object *root_object = json_value_get_object(root_value);
            const char *host = json_object_get_string(root_object, "file_server_ip");
            int port = (int)json_object_get_number(root_object, "file_server_port");
            if (0 != strcmp(global_file_server_host, host)) {
                snprintf(global_file_server_host, 128, "%s", host);
            }

            if (global_file_server_port != port) {
                global_file_server_port = port;
            }

            json_value_free(root_value);
        } else if (0 == strcmp(buf_str(packet->type), MSG_TYPE_AGENT_MQ)) {
            // 解析消息
            tcp_packet_d4m_ptr d4m = tcp_packet_new_d4m();
            tcp_packet_parse_d4m(packet->data, d4m);

            // 创建线程任务(packet、d4m均为深拷贝)
            thread_job_ptr job = thread_job_new(c, packet, d4m);

            // 处理消息
            if (0 == strcmp(buf_str(d4m->control), "start")) {
                // 添加至线程队列
                thpool_add_work(thpool, (void*)handle_command_or_script, (void*)job);

            } else if (0 == strcmp(buf_str(d4m->control), "stop")) {
                // todo 取消任务
                printf("todo 取消任务session id:%s\n", buf_str(d4m->session_id));

                // 返回取消成功的消息(应该判断是终止还是已执行(成功、失败、异常))
                send_execute_result(c, packet, d4m, "", TAgentStateTerminated, 0);

                // todo 取消任务实现后移除
                thread_job_free(job);
                
            } else {
                printf("不支持的控制类型:%s\n", buf_str(d4m->control));
                thread_job_free(job);
            }

            tcp_packet_free_d4m(d4m);

        } else if (0 == strcmp(buf_str(packet->type), MSG_TYPE_AGENT_INSPECT)) {

            printf("不支持的消息类型:%s\n", buf_str(packet->type));

        } else if (0 == strcmp(buf_str(packet->type), MSG_TYPE_AGENT_CUSTOM_COLLECT)) {

            printf("不支持的消息类型:%s\n", buf_str(packet->type));

        } else if (0 == strcmp(buf_str(packet->type), MSG_TYPE_AGENT_CYCLE)) {
            // 修改采集间隔
            int cycle = atoi(buf_str(packet->data));
            if (cycle >= 30) {
                global_file_server_port = cycle;
            }
            send_response_data(c, packet, "");

        } else {
            printf("不支持的消息类型:%s\n", buf_str(packet->type));
        }

        tcp_packet_free(packet);
    }
    buf_free(bf);
    thpool_destroy(thpool);
    pthread_exit(NULL);
    return EXIT_SUCCESS;
}