#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

#include "../libs/C-Snip/signals.h"
#include "version.h"
#include "util/zx_config.h"
#include "tcp_client.h"
#include "thread_worker.h"

extern char *optarg;

void signals_handler(int sig) {
    switch (sig) {
        case SIGPIPE:
            printf("SIGPIPE\n");
            break;
        default:
            printf("signal:%d\n", sig);
    }
}

int zx_config_init(const char *filename, char *host, int *port) {
    zx_cfg_file_t *file = zx_cfg_open(filename);
    if (file == NULL) {
        return -1;
    }

	zx_cfg_section_t *section = file->sections;
	zx_cfg_pair_t *pair = NULL;

    while (section) {
        printf("[%s]\n", section->name);
        if (0 == strcmp(section->name, "cagent_proxy")) {
            pair = section->pairs;
            while (pair) {
                printf("%s = %s\n", pair->key, pair->value);
                if (0 == strcmp(pair->key, "host")) {
                    snprintf(host, 256, "%s", pair->value);
                } else if (0 == strcmp(pair->key, "port")) {
                    *port = atoi(pair->value);
                }
                pair = pair->next;
            }
        }
		printf("\n");
		section = section->next;
	}

    zx_cfg_close(&file);

    return 0;
}

int main(int argc, char* argv[])
{
    char host[256] = {0};
    int port = 0;

    if (argc == 1) {
        printf("未指定配置文件，默认读取./cagent.conf\n");
        if (zx_config_init("./cagent.conf", host, &port) < 0) {
            printf("读取配置文件失败\n");
            return -1;
        }

    } else {
        int i;
        while ((i = getopt(argc, argv, "h:p:c:v")) != EOF) {
            switch(i) {
                case 'h':
                    snprintf(host, sizeof(host), "%s", optarg);
                    break;
                case 'p':
                    port = atoi(optarg);
                    break;
                case 'c':
                    if (zx_config_init(optarg, host, &port) < 0) {
                        printf("读取配置文件(%s)失败\n", optarg);
                        return -1;
                    }
                    break;
                case 'v':
                    printf("%s\n", CAGENT_VERSION);
                    return 0;
                default:
                    fprintf(stderr, "usage: %s [-h <host> ] [-p <port> ] [-c <config file> ] [-v <version> ]\n", argv[0]);
                    return -1;
            }
        }
    }

    if (0 == strcmp("", host) || port <= 0) {
        printf("参数值不正确，请检查\n");
        return -1;
    }

    printf("程序启动, 服务器:%s, 端口:%d\n", host, port);
 
    // socket连接断开时，send会产生SIGPIPE信号
    signals_register(SIGPIPE, signals_handler);

    tcp_client_ptr cli = tcp_client_new(host, port);
    if (cli == NULL) {
        printf("创建tcp_client错误\n");
        return -1;
    }
    tcp_client_run(cli);

    // 启动工作线程
    pthread_t t1, t2, t3;
    pthread_create(&t1, NULL, thread_keeper, (void*)cli);
    pthread_create(&t2, NULL, thread_collector, (void*)cli);
    pthread_create(&t3, NULL, thread_executor, (void*)cli);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);

    tcp_client_wait(cli);
    tcp_client_free(cli);

    printf("cagent程序退出\n");
    return 0;
}