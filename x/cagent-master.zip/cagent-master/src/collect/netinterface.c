#include "netinterface.h"
#include <unistd.h>
#include <string.h>
#include <net/if_types.h>
#include "../util/zx_common.h"

#define PERIOD 1

static char *netif_type(uchar type) {
    switch(type) {
    case IFT_LOOP:
        return "loopback";
    case IFT_ISO88025:
        return "token-ring";
    case IFT_ETHER:
        return "ethernet";
    }
    return "other";
}

zx_netif_stat_t *zx_netif_stat_init() {
    zx_netif_stat_t *stat = zx_malloc(NULL, sizeof(zx_netif_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_netif_stat_t));

    int ret = perfstat_netinterface(NULL, NULL, sizeof(perfstat_netinterface_t), 0);
    if (ret < 1) {
        perror("perfstat_netinterface");
        return stat;
    }
    stat->nnetifs = ret;

    perfstat_netinterface_total_t oldt_total, newt_total;
    perfstat_netinterface_t *oldt = zx_malloc(NULL, stat->nnetifs * sizeof(perfstat_netinterface_t));
    perfstat_netinterface_t *newt = zx_malloc(NULL, stat->nnetifs * sizeof(perfstat_netinterface_t));


    perfstat_id_t first_netif;
    strscpy(first_netif.name , FIRST_NETINTERFACE);

    perfstat_netinterface_total(NULL, &oldt_total, sizeof(perfstat_netinterface_total_t), 1);
    perfstat_netinterface(&first_netif, oldt, sizeof(perfstat_netinterface_t), stat->nnetifs);
    sleep(PERIOD);
    perfstat_netinterface_total(NULL, &newt_total, sizeof(perfstat_netinterface_total_t), 1);
    perfstat_netinterface(&first_netif, newt, sizeof(perfstat_netinterface_t), stat->nnetifs);

    stat->ibytes = newt_total.ibytes;
    stat->ipackets = newt_total.ipackets;
    stat->ierrors = newt_total.ierrors;
    stat->obytes = newt_total.obytes;
    stat->opackets = newt_total.opackets;
    stat->oerrors = newt_total.oerrors;
    stat->collisions = newt_total.collisions;

    stat->netifs_stat = zx_malloc(NULL, stat->nnetifs * sizeof(zx_netif_t));
    for (int i = 0; i < stat->nnetifs; i++) {
        snprintf(stat->netifs_stat[i].name, IDENTIFIER_LENGTH, "%s", oldt[i].name);
        snprintf(stat->netifs_stat[i].desc, IDENTIFIER_LENGTH, "%s", oldt[i].description);
        snprintf(stat->netifs_stat[i].type, IDENTIFIER_LENGTH, "%s", netif_type(oldt[i].type));
        stat->netifs_stat[i].ibytes = oldt[i].ibytes;
        stat->netifs_stat[i].ipackets = oldt[i].ipackets;
        stat->netifs_stat[i].ierrors = oldt[i].ierrors;
        stat->netifs_stat[i].obytes = oldt[i].obytes;
        stat->netifs_stat[i].opackets = oldt[i].opackets;
        stat->netifs_stat[i].oerrors = oldt[i].oerrors;
        stat->netifs_stat[i].collisions = oldt[i].collisions;
        stat->netifs_stat[i].mtu = oldt[i].mtu;
        stat->netifs_stat[i].bitrate = oldt[i].bitrate;
    }

    stat->netifs_stat_1s = zx_malloc(NULL, stat->nnetifs * sizeof(zx_netif_t));
    for (int i = 0; i < stat->nnetifs; i++) {
        snprintf(stat->netifs_stat_1s[i].name, IDENTIFIER_LENGTH, "%s", newt[i].name);
        snprintf(stat->netifs_stat_1s[i].desc, IDENTIFIER_LENGTH, "%s", newt[i].description);
        snprintf(stat->netifs_stat_1s[i].type, IDENTIFIER_LENGTH, "%s", netif_type(newt[i].type));
        stat->netifs_stat_1s[i].ibytes = newt[i].ibytes;
        stat->netifs_stat_1s[i].ipackets = newt[i].ipackets;
        stat->netifs_stat_1s[i].ierrors = newt[i].ierrors;
        stat->netifs_stat_1s[i].obytes = newt[i].obytes;
        stat->netifs_stat_1s[i].opackets = newt[i].opackets;
        stat->netifs_stat_1s[i].oerrors = newt[i].oerrors;
        stat->netifs_stat_1s[i].collisions = newt[i].collisions;
        stat->netifs_stat_1s[i].mtu = newt[i].mtu;
        stat->netifs_stat_1s[i].bitrate = newt[i].bitrate;
    }

    zx_free(oldt);
    zx_free(newt);

    return stat;
}

void zx_netif_stat_destroy(zx_netif_stat_t *stat) {
    if (stat != NULL) {
        if (stat->netifs_stat != NULL) {
            zx_free(stat->netifs_stat);
        }
        if (stat->netifs_stat_1s != NULL) {
            zx_free(stat->netifs_stat_1s);
        }
        zx_free(stat);
    }
}


zx_netadapter_stat_t *zx_netadapter_stat_init() {
    zx_netadapter_stat_t *stat =zx_malloc(NULL, sizeof(zx_netadapter_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_netadapter_stat_t));

#ifdef AIX_VERSION_7X

    int ret = perfstat_netadapter(NULL, NULL, sizeof(perfstat_netadapter_t), 0);
    if (ret < 1) {
        perror("perfstat_netadapter");
        return stat;
    }
    stat->nnetadapters = ret;

    perfstat_netadapter_t *oldt = zx_malloc(NULL, stat->nnetadapters * sizeof(perfstat_netadapter_t));
    perfstat_netadapter_t *newt = zx_malloc(NULL, stat->nnetadapters * sizeof(perfstat_netadapter_t));

    perfstat_id_t first_netadapter;
    strscpy(first_netadapter.name , FIRST_NETINTERFACE);
    perfstat_netadapter(&first_netadapter, oldt, sizeof(perfstat_netadapter_t), stat->nnetadapters);
    sleep(PERIOD);
    perfstat_netadapter(&first_netadapter, newt, sizeof(perfstat_netadapter_t), stat->nnetadapters);

    stat->netadapters_stat = zx_malloc(NULL, stat->nnetadapters * sizeof(zx_netif_t));
    for (int i = 0; i < stat->nnetadapters; i++) {
        snprintf(stat->netadapters_stat[i].name, IDENTIFIER_LENGTH, "%s", oldt[i].name);

        stat->netadapters_stat[i].tx_packets = oldt[i].tx_packets;
        stat->netadapters_stat[i].tx_bytes = oldt[i].tx_bytes;
        stat->netadapters_stat[i].tx_interrupts = oldt[i].tx_interrupts;
        stat->netadapters_stat[i].tx_errors = oldt[i].tx_errors;
        stat->netadapters_stat[i].tx_packets_dropped = oldt[i].tx_packets_dropped;
        stat->netadapters_stat[i].tx_queue_size = oldt[i].tx_queue_size;
        stat->netadapters_stat[i].tx_queue_len = oldt[i].tx_queue_len;
        stat->netadapters_stat[i].tx_queue_overflow = oldt[i].tx_queue_overflow;
        stat->netadapters_stat[i].tx_broadcast_packets = oldt[i].tx_broadcast_packets;
        stat->netadapters_stat[i].tx_multicast_packets = oldt[i].tx_multicast_packets;
        stat->netadapters_stat[i].tx_carrier_sense = oldt[i].tx_carrier_sense;
        stat->netadapters_stat[i].tx_DMA_underrun = oldt[i].tx_DMA_underrun;
        stat->netadapters_stat[i].tx_lost_CTS_errors = oldt[i].tx_lost_CTS_errors;
        stat->netadapters_stat[i].tx_max_collision_errors = oldt[i].tx_max_collision_errors;
        stat->netadapters_stat[i].tx_late_collision_errors = oldt[i].tx_late_collision_errors;
        stat->netadapters_stat[i].tx_deferred = oldt[i].tx_deferred;
        stat->netadapters_stat[i].tx_timeout_errors = oldt[i].tx_timeout_errors;
        stat->netadapters_stat[i].tx_single_collision_count = oldt[i].tx_single_collision_count;
        stat->netadapters_stat[i].tx_multiple_collision_count = oldt[i].tx_multiple_collision_count;

        stat->netadapters_stat[i].rx_packets = oldt[i].rx_packets;
        stat->netadapters_stat[i].rx_bytes = oldt[i].rx_bytes;
        stat->netadapters_stat[i].rx_interrupts = oldt[i].rx_interrupts;
        stat->netadapters_stat[i].rx_errors = oldt[i].rx_errors;
        stat->netadapters_stat[i].rx_packets_dropped = oldt[i].rx_packets_dropped;
        stat->netadapters_stat[i].rx_bad_packets = oldt[i].rx_bad_packets;
        stat->netadapters_stat[i].rx_multicast_packets = oldt[i].rx_multicast_packets;
        stat->netadapters_stat[i].rx_broadcast_packets = oldt[i].rx_broadcast_packets;
        stat->netadapters_stat[i].rx_CRC_errors = oldt[i].rx_CRC_errors;
        stat->netadapters_stat[i].rx_DMA_overrun = oldt[i].rx_DMA_overrun;
        stat->netadapters_stat[i].rx_alignment_errors = oldt[i].rx_alignment_errors;
        stat->netadapters_stat[i].rx_noresource_errors = oldt[i].rx_noresource_errors;
        stat->netadapters_stat[i].rx_collision_errors = oldt[i].rx_collision_errors;
        stat->netadapters_stat[i].rx_packet_tooshort_errors = oldt[i].rx_packet_tooshort_errors;
        stat->netadapters_stat[i].rx_packet_toolong_errors = oldt[i].rx_packet_toolong_errors;
        stat->netadapters_stat[i].rx_packets_discardedbyadapter = oldt[i].rx_packets_discardedbyadapter;
    }

    stat->netadapters_stat_1s = zx_malloc(NULL, stat->nnetadapters * sizeof(zx_netif_t));
    for (int i = 0; i < stat->nnetadapters; i++) {
        snprintf(stat->netadapters_stat_1s[i].name, IDENTIFIER_LENGTH, "%s", newt[i].name);

        stat->netadapters_stat_1s[i].tx_packets = newt[i].tx_packets;
        stat->netadapters_stat_1s[i].tx_bytes = newt[i].tx_bytes;
        stat->netadapters_stat_1s[i].tx_interrupts = newt[i].tx_interrupts;
        stat->netadapters_stat_1s[i].tx_errors = newt[i].tx_errors;
        stat->netadapters_stat_1s[i].tx_packets_dropped = newt[i].tx_packets_dropped;
        stat->netadapters_stat_1s[i].tx_queue_size = newt[i].tx_queue_size;
        stat->netadapters_stat_1s[i].tx_queue_len = newt[i].tx_queue_len;
        stat->netadapters_stat_1s[i].tx_queue_overflow = newt[i].tx_queue_overflow;
        stat->netadapters_stat_1s[i].tx_broadcast_packets = newt[i].tx_broadcast_packets;
        stat->netadapters_stat_1s[i].tx_multicast_packets = newt[i].tx_multicast_packets;
        stat->netadapters_stat_1s[i].tx_carrier_sense = newt[i].tx_carrier_sense;
        stat->netadapters_stat_1s[i].tx_DMA_underrun = newt[i].tx_DMA_underrun;
        stat->netadapters_stat_1s[i].tx_lost_CTS_errors = newt[i].tx_lost_CTS_errors;
        stat->netadapters_stat_1s[i].tx_max_collision_errors = newt[i].tx_max_collision_errors;
        stat->netadapters_stat_1s[i].tx_late_collision_errors = newt[i].tx_late_collision_errors;
        stat->netadapters_stat_1s[i].tx_deferred = newt[i].tx_deferred;
        stat->netadapters_stat_1s[i].tx_timeout_errors = newt[i].tx_timeout_errors;
        stat->netadapters_stat_1s[i].tx_single_collision_count = newt[i].tx_single_collision_count;
        stat->netadapters_stat_1s[i].tx_multiple_collision_count = newt[i].tx_multiple_collision_count;

        stat->netadapters_stat_1s[i].rx_packets = newt[i].rx_packets;
        stat->netadapters_stat_1s[i].rx_bytes = newt[i].rx_bytes;
        stat->netadapters_stat_1s[i].rx_interrupts = newt[i].rx_interrupts;
        stat->netadapters_stat_1s[i].rx_errors = newt[i].rx_errors;
        stat->netadapters_stat_1s[i].rx_packets_dropped = newt[i].rx_packets_dropped;
        stat->netadapters_stat_1s[i].rx_bad_packets = newt[i].rx_bad_packets;
        stat->netadapters_stat_1s[i].rx_multicast_packets = newt[i].rx_multicast_packets;
        stat->netadapters_stat_1s[i].rx_broadcast_packets = newt[i].rx_broadcast_packets;
        stat->netadapters_stat_1s[i].rx_CRC_errors = newt[i].rx_CRC_errors;
        stat->netadapters_stat_1s[i].rx_DMA_overrun = newt[i].rx_DMA_overrun;
        stat->netadapters_stat_1s[i].rx_alignment_errors = newt[i].rx_alignment_errors;
        stat->netadapters_stat_1s[i].rx_noresource_errors = newt[i].rx_noresource_errors;
        stat->netadapters_stat_1s[i].rx_collision_errors = newt[i].rx_collision_errors;
        stat->netadapters_stat_1s[i].rx_packet_tooshort_errors = newt[i].rx_packet_tooshort_errors;
        stat->netadapters_stat_1s[i].rx_packet_toolong_errors = newt[i].rx_packet_toolong_errors;
        stat->netadapters_stat_1s[i].rx_packets_discardedbyadapter = newt[i].rx_packets_discardedbyadapter;
    }

    zx_free(oldt);
    zx_free(newt);

#endif

    return stat;
}

void zx_netadapter_stat_destroy(zx_netadapter_stat_t *stat) {
    if (stat != NULL) {
        if (stat->netadapters_stat != NULL) {
            zx_free(stat->netadapters_stat);
        }
        if (stat->netadapters_stat_1s != NULL) {
            zx_free(stat->netadapters_stat_1s);
        }
        zx_free(stat);
    }
}