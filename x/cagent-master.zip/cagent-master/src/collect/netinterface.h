#ifndef __ZX_NETINTERFACE_H__
#define __ZX_NETINTERFACE_H__

#include <sys/protosw.h>
#include <libperfstat.h>

typedef struct zx_netif_t {
	char name[IDENTIFIER_LENGTH];	// name of the netinterface
	char desc[IDENTIFIER_LENGTH];   // interface description
	char type[IDENTIFIER_LENGTH];	// type of the interface
	unsigned long long ibytes;		// number of input bytes
	unsigned long long ipackets;	// number of input packets
	unsigned long long ierrors;		// number of input errors
	unsigned long long obytes;		// number of output bytes
	unsigned long long opackets;	// number of output packets
	unsigned long long oerrors;		// number of output errors
	unsigned long long collisions;  // number of collisions on csma interface
	unsigned long long mtu;			// network frame size
	unsigned long long bitrate;		// adapter rating in bit per second
} zx_netif_t;

typedef struct zx_netif_stat_t {
	int nnetifs;
	unsigned long long ibytes;
	unsigned long long ipackets;
	unsigned long long ierrors;
	unsigned long long obytes;
	unsigned long long opackets;
	unsigned long long oerrors;
	unsigned long long collisions;
	zx_netif_t *netifs_stat;
	zx_netif_t *netifs_stat_1s;
} zx_netif_stat_t;

zx_netif_stat_t *zx_netif_stat_init();

void zx_netif_stat_destroy(zx_netif_stat_t *stat);


typedef struct zx_netadapter_t {
	char name[IDENTIFIER_LENGTH];
	unsigned long long tx_packets;                      
	unsigned long long tx_bytes;
	unsigned long long tx_interrupts;
	unsigned long long tx_errors;
	unsigned long long tx_packets_dropped;
	unsigned long long tx_queue_size;
	unsigned long long tx_queue_len;
	unsigned long long tx_queue_overflow;
	unsigned long long tx_broadcast_packets;
	unsigned long long tx_multicast_packets;
	unsigned long long tx_carrier_sense;
	unsigned long long tx_DMA_underrun;
	unsigned long long tx_lost_CTS_errors;
	unsigned long long tx_max_collision_errors;
	unsigned long long tx_late_collision_errors;
	unsigned long long tx_deferred;
	unsigned long long tx_timeout_errors;
	unsigned long long tx_single_collision_count;
	unsigned long long tx_multiple_collision_count;
	unsigned long long rx_packets;
	unsigned long long rx_bytes;
	unsigned long long rx_interrupts;
	unsigned long long rx_errors;
	unsigned long long rx_packets_dropped;
	unsigned long long rx_bad_packets;
	unsigned long long rx_multicast_packets;
	unsigned long long rx_broadcast_packets;
	unsigned long long rx_CRC_errors;
	unsigned long long rx_DMA_overrun;
	unsigned long long rx_alignment_errors;
	unsigned long long rx_noresource_errors;
	unsigned long long rx_collision_errors;
	unsigned long long rx_packet_tooshort_errors;
	unsigned long long rx_packet_toolong_errors;
	unsigned long long rx_packets_discardedbyadapter;
} zx_netadapter_t;

typedef struct zx_netadapter_stat_t {
	int nnetadapters;
	zx_netadapter_t *netadapters_stat;
	zx_netadapter_t *netadapters_stat_1s;
} zx_netadapter_stat_t;

zx_netadapter_stat_t *zx_netadapter_stat_init();

void zx_netadapter_stat_destroy(zx_netadapter_stat_t *stat);


#endif