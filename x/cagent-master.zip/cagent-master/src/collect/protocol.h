#ifndef __ZX_PROTOCOL_H__
#define __ZX_PROTOCOL_H__

typedef struct zx_protocol_stat_t {
    unsigned long long ip_ipackets;
    unsigned long long ip_ierrors;
    unsigned long long ip_iqueueoverflow;
    unsigned long long ip_opackets;
    unsigned long long ip_oerrors;

    unsigned long long ipv6_ipackets;
    unsigned long long ipv6_ierrors;
    unsigned long long ipv6_iqueueoverflow;
    unsigned long long ipv6_opackets;
    unsigned long long ipv6_oerrors;

    unsigned long long icmp_received;
    unsigned long long icmp_sent;
    unsigned long long icmp_errors;
    unsigned long long icmpv6_received;
    unsigned long long icmpv6_sent;
    unsigned long long icmpv6_errors;

    unsigned long long udp_ipackets;
    unsigned long long udp_ierrors;
    unsigned long long udp_opackets;
    unsigned long long udp_no_socket;

    unsigned long long tcp_ipackets;
    unsigned long long tcp_ierrors;
    unsigned long long tcp_opackets;
    unsigned long long tcp_initiated;
    unsigned long long tcp_accepted;
    unsigned long long tcp_established;
    unsigned long long tcp_dropped;

    // todo 参数有点多哦
    // rpc
    // nfs
    // nfsv2
    // nfsv3

} zx_protocol_stat_t;

zx_protocol_stat_t *zx_protocol_stat_init();

void zx_protocol_stat_destroy(zx_protocol_stat_t *stat);

#endif