#include "diskio.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "../util/zx_common.h"

#define PERIOD 1

zx_disk_stat_t *zx_disk_stat_init() {
    zx_disk_stat_t *stat = zx_malloc(NULL, sizeof(zx_disk_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_disk_stat_t));

    int ret = perfstat_disk(NULL, NULL,sizeof(perfstat_disk_t), 0);
    if (ret < 1) {
        perror("perfstat_disk");
        return stat;
    }
    stat->ndisks = ret;

    perfstat_disk_total_t disk_total;
    perfstat_disk_total(NULL, &disk_total, sizeof(perfstat_disk_total_t), 1);
    stat->size = disk_total.size;
    stat->free = disk_total.free;
    stat->rxfers = disk_total.__rxfers;
    stat->xfers = disk_total.xfers;
    stat->wblks = disk_total.wblks;
    stat->rblks = disk_total.rblks;
    stat->time = disk_total.time;

    perfstat_disk_t *oldt = zx_malloc(NULL, stat->ndisks * sizeof(perfstat_disk_t));
    perfstat_disk_t *newt = zx_malloc(NULL, stat->ndisks * sizeof(perfstat_disk_t));

    perfstat_id_t first_disk;
    strscpy(first_disk.name, FIRST_DISK);
    perfstat_disk(&first_disk, oldt, sizeof(perfstat_disk_t), stat->ndisks);
    sleep(PERIOD);
    perfstat_disk(&first_disk, newt, sizeof(perfstat_disk_t), stat->ndisks);

    stat->disks_stat = zx_malloc(NULL, stat->ndisks * sizeof(zx_disk_t));
    for (int i = 0; i < stat->ndisks; i++) {
        snprintf(stat->disks_stat[i].name, IDENTIFIER_LENGTH, "%s", oldt[i].name);
        snprintf(stat->disks_stat[i].adapter, IDENTIFIER_LENGTH, "%s", oldt[i].adapter);
        snprintf(stat->disks_stat[i].desc, IDENTIFIER_LENGTH, "%s", oldt[i].description);
        snprintf(stat->disks_stat[i].vgname, IDENTIFIER_LENGTH, "%s", oldt[i].vgname);
        stat->disks_stat[i].size = oldt[i].size;
        stat->disks_stat[i].free = oldt[i].free;
        stat->disks_stat[i].bsize = oldt[i].bsize;
        stat->disks_stat[i].rxfers = oldt[i].__rxfers;
        stat->disks_stat[i].xfers = oldt[i].xfers;     
        stat->disks_stat[i].wblks = oldt[i].wblks;      
        stat->disks_stat[i].rblks = oldt[i].rblks;      
        stat->disks_stat[i].time = oldt[i].time;       
        stat->disks_stat[i].paths_count = oldt[i].paths_count;
        stat->disks_stat[i].qdepth = oldt[i].qdepth;     
        stat->disks_stat[i].q_full = oldt[i].q_full;    
        stat->disks_stat[i].q_sampled = oldt[i].q_sampled;  
        stat->disks_stat[i].rserv = oldt[i].rserv;     
        stat->disks_stat[i].rtimeout = oldt[i].rtimeout;   
        stat->disks_stat[i].rfailed = oldt[i].rfailed;    
        stat->disks_stat[i].min_rserv = oldt[i].min_rserv;  
        stat->disks_stat[i].max_rserv = oldt[i].max_rserv;  
        stat->disks_stat[i].wserv = oldt[i].wserv;      
        stat->disks_stat[i].wtimeout = oldt[i].wtimeout;   
        stat->disks_stat[i].wfailed = oldt[i].wfailed;   
        stat->disks_stat[i].min_wserv = oldt[i].min_wserv; 
        stat->disks_stat[i].max_wserv = oldt[i].max_wserv;  
        stat->disks_stat[i].wq_depth = oldt[i].wq_depth;   
        stat->disks_stat[i].wq_sampled = oldt[i].wq_sampled; 
        stat->disks_stat[i].wq_time = oldt[i].wq_time;    
        stat->disks_stat[i].wq_min_time = oldt[i].wq_min_time;
        stat->disks_stat[i].wq_max_time = oldt[i].wq_max_time;
    }

    stat->disks_stat_1s = zx_malloc(NULL, stat->ndisks * sizeof(zx_disk_t));
    for (int i = 0; i < stat->ndisks; i++) {
        snprintf(stat->disks_stat_1s[i].name, IDENTIFIER_LENGTH, "%s", newt[i].name);
        snprintf(stat->disks_stat_1s[i].adapter, IDENTIFIER_LENGTH, "%s", newt[i].adapter);
        snprintf(stat->disks_stat_1s[i].desc, IDENTIFIER_LENGTH, "%s", newt[i].description);
        snprintf(stat->disks_stat_1s[i].vgname, IDENTIFIER_LENGTH, "%s", newt[i].vgname);
        stat->disks_stat_1s[i].size = newt[i].size;
        stat->disks_stat_1s[i].free = newt[i].free;
        stat->disks_stat_1s[i].bsize = newt[i].bsize;
        stat->disks_stat_1s[i].rxfers = newt[i].__rxfers;    
        stat->disks_stat_1s[i].xfers = newt[i].xfers;     
        stat->disks_stat_1s[i].wblks = newt[i].wblks;      
        stat->disks_stat_1s[i].rblks = newt[i].rblks;      
        stat->disks_stat_1s[i].time = newt[i].time;       
        stat->disks_stat_1s[i].paths_count = newt[i].paths_count;
        stat->disks_stat_1s[i].qdepth = newt[i].qdepth;     
        stat->disks_stat_1s[i].q_full = newt[i].q_full;    
        stat->disks_stat_1s[i].q_sampled = newt[i].q_sampled;  
        stat->disks_stat_1s[i].rserv = newt[i].rserv;     
        stat->disks_stat_1s[i].rtimeout = newt[i].rtimeout;   
        stat->disks_stat_1s[i].rfailed = newt[i].rfailed;    
        stat->disks_stat_1s[i].min_rserv = newt[i].min_rserv;  
        stat->disks_stat_1s[i].max_rserv = newt[i].max_rserv;  
        stat->disks_stat_1s[i].wserv = newt[i].wserv;      
        stat->disks_stat_1s[i].wtimeout = newt[i].wtimeout;   
        stat->disks_stat_1s[i].wfailed = newt[i].wfailed;   
        stat->disks_stat_1s[i].min_wserv = newt[i].min_wserv; 
        stat->disks_stat_1s[i].max_wserv = newt[i].max_wserv;  
        stat->disks_stat_1s[i].wq_depth = newt[i].wq_depth;   
        stat->disks_stat_1s[i].wq_sampled = newt[i].wq_sampled; 
        stat->disks_stat_1s[i].wq_time = newt[i].wq_time;    
        stat->disks_stat_1s[i].wq_min_time = newt[i].wq_min_time;
        stat->disks_stat_1s[i].wq_max_time = newt[i].wq_max_time;
    }

    zx_free(oldt);
    zx_free(newt);

    return stat;
}

void zx_disk_stat_destroy(zx_disk_stat_t *stat) {
    if (stat != NULL) {
        if (stat->disks_stat != NULL) {
            zx_free(stat->disks_stat);
        }
        if (stat->disks_stat_1s != NULL) {
            zx_free(stat->disks_stat_1s);
        }
        zx_free(stat);
    }
}


zx_diskadapter_stat_t *zx_diskadapter_stat_init() {
    zx_diskadapter_stat_t *stat = zx_malloc(NULL, sizeof(zx_diskadapter_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_diskadapter_stat_t));

    int ret = perfstat_diskadapter(NULL, NULL, sizeof(perfstat_diskadapter_t), 0);
    if (ret < 1) {
        perror("perfstat_diskadapter");
        return stat;
    }
    stat->ndiskadapters = ret;

    perfstat_diskadapter_t *oldt = zx_malloc(NULL, stat->ndiskadapters * sizeof(perfstat_diskadapter_t));
    perfstat_diskadapter_t *newt = zx_malloc(NULL, stat->ndiskadapters * sizeof(perfstat_diskadapter_t));

    perfstat_id_t first_diskadapter;
    strscpy(first_diskadapter.name, FIRST_DISKADAPTER);
    perfstat_diskadapter(&first_diskadapter, oldt, sizeof(perfstat_diskadapter_t), stat->ndiskadapters);
    sleep(PERIOD);
    perfstat_diskadapter(&first_diskadapter, newt, sizeof(perfstat_diskadapter_t), stat->ndiskadapters);

    stat->diskadapters_stat = zx_malloc(NULL, stat->ndiskadapters * sizeof(zx_diskadapter_t));
    for (int i = 0; i < stat->ndiskadapters; i++) {
        snprintf(stat->diskadapters_stat[i].name, IDENTIFIER_LENGTH, "%s", oldt[i].name);
        stat->diskadapters_stat[i].ndisks = oldt[i].number;
        stat->diskadapters_stat[i].size = oldt[i].size;
        stat->diskadapters_stat[i].free = oldt[i].free;
        stat->diskadapters_stat[i].rxfers = oldt[i].__rxfers;
        stat->diskadapters_stat[i].xfers = oldt[i].xfers;
        stat->diskadapters_stat[i].wblks = oldt[i].wblks;
        stat->diskadapters_stat[i].rblks = oldt[i].rblks;
        stat->diskadapters_stat[i].time = oldt[i].time;
    }

    stat->diskadapters_stat_1s = zx_malloc(NULL, stat->ndiskadapters * sizeof(zx_diskadapter_t));
    for (int i = 0; i < stat->ndiskadapters; i++) {
        snprintf(stat->diskadapters_stat_1s[i].name, IDENTIFIER_LENGTH, "%s", newt[i].name);
        stat->diskadapters_stat_1s[i].ndisks = newt[i].number;
        stat->diskadapters_stat_1s[i].size = newt[i].size;
        stat->diskadapters_stat_1s[i].free = newt[i].free;
        stat->diskadapters_stat_1s[i].rxfers = newt[i].__rxfers;
        stat->diskadapters_stat_1s[i].xfers = newt[i].xfers;
        stat->diskadapters_stat_1s[i].wblks = newt[i].wblks;
        stat->diskadapters_stat_1s[i].rblks = newt[i].rblks;
        stat->diskadapters_stat_1s[i].time = newt[i].time;
    }

    zx_free(oldt);
    zx_free(newt);

    return stat;
}

void zx_diskadapter_stat_destroy(zx_diskadapter_stat_t *stat) {
    if (stat != NULL) {
        if (stat->diskadapters_stat != NULL) {
            zx_free(stat->diskadapters_stat);
        }
         if (stat->diskadapters_stat_1s != NULL) {
            zx_free(stat->diskadapters_stat_1s);
        }
        zx_free(stat);
    }
}

zx_diskpath_stat_t *zx_diskpath_stat_init() {
    zx_diskpath_stat_t *stat = zx_malloc(NULL, sizeof(zx_diskpath_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_diskpath_stat_t));

    int ret = perfstat_diskpath(NULL, NULL, sizeof(perfstat_diskpath_t), 0);
    if (ret < 1) {
        perror("perfstat_diskpath");
        return stat;
    }
    stat->ndiskpaths = ret;

    perfstat_diskpath_t *oldt = zx_malloc(NULL, stat->ndiskpaths * sizeof(perfstat_diskpath_t));
    perfstat_diskpath_t *newt = zx_malloc(NULL, stat->ndiskpaths * sizeof(perfstat_diskpath_t));

    perfstat_id_t first_diskpath;
    strscpy(first_diskpath.name, FIRST_DISKPATH);
    perfstat_diskpath(&first_diskpath, oldt, sizeof(perfstat_diskpath_t), stat->ndiskpaths);
    sleep(PERIOD);
    perfstat_diskpath(&first_diskpath, newt, sizeof(perfstat_diskpath_t), stat->ndiskpaths);

    stat->diskpaths_stat = zx_malloc(NULL, stat->ndiskpaths * sizeof(zx_diskpath_t));
    for (int i = 0; i < stat->ndiskpaths; i++) {
        snprintf(stat->diskpaths_stat[i].name, IDENTIFIER_LENGTH, "%s", oldt[i].name);
        snprintf(stat->diskpaths_stat[i].adapter, IDENTIFIER_LENGTH, "%s", oldt[i].adapter);
        stat->diskpaths_stat[i].rxfers = oldt[i].__rxfers;
        stat->diskpaths_stat[i].xfers = oldt[i].xfers;
        stat->diskpaths_stat[i].rblks = oldt[i].rblks;
        stat->diskpaths_stat[i].wblks = oldt[i].wblks;
        stat->diskpaths_stat[i].time = oldt[i].time;
        stat->diskpaths_stat[i].q_full = oldt[i].q_full;
        stat->diskpaths_stat[i].q_sampled = oldt[i].q_sampled;
        stat->diskpaths_stat[i].rserv = oldt[i].rserv;
        stat->diskpaths_stat[i].rtimeout = oldt[i].rtimeout;
        stat->diskpaths_stat[i].rfailed = oldt[i].rfailed;
        stat->diskpaths_stat[i].min_rserv = oldt[i].min_rserv;
        stat->diskpaths_stat[i].max_rserv = oldt[i].max_rserv;
        stat->diskpaths_stat[i].wserv = oldt[i].wserv;
        stat->diskpaths_stat[i].wtimeout = oldt[i].wtimeout;
        stat->diskpaths_stat[i].wfailed = oldt[i].wfailed;
        stat->diskpaths_stat[i].min_wserv = oldt[i].min_wserv;
        stat->diskpaths_stat[i].max_wserv = oldt[i].max_wserv;
        stat->diskpaths_stat[i].wq_depth = oldt[i].wq_depth;
        stat->diskpaths_stat[i].wq_sampled = oldt[i].wq_sampled;
        stat->diskpaths_stat[i].wq_time = oldt[i].wq_time;
        stat->diskpaths_stat[i].wq_min_time = oldt[i].wq_min_time;
        stat->diskpaths_stat[i].wq_max_time = oldt[i].wq_max_time;
    }

    stat->diskpaths_stat_1s = zx_malloc(NULL, stat->ndiskpaths * sizeof(zx_diskpath_t));
    for (int i = 0; i < stat->ndiskpaths; i++) {
        snprintf(stat->diskpaths_stat_1s[i].name, IDENTIFIER_LENGTH, "%s", newt[i].name);
        snprintf(stat->diskpaths_stat_1s[i].adapter, IDENTIFIER_LENGTH, "%s", newt[i].adapter);
        stat->diskpaths_stat_1s[i].rxfers = newt[i].__rxfers;
        stat->diskpaths_stat_1s[i].xfers = newt[i].xfers;
        stat->diskpaths_stat_1s[i].rblks = newt[i].rblks;
        stat->diskpaths_stat_1s[i].wblks = newt[i].wblks;
        stat->diskpaths_stat_1s[i].time = newt[i].time;
        stat->diskpaths_stat_1s[i].q_full = newt[i].q_full;
        stat->diskpaths_stat_1s[i].q_sampled = newt[i].q_sampled;
        stat->diskpaths_stat_1s[i].rserv = newt[i].rserv;
        stat->diskpaths_stat_1s[i].rtimeout = newt[i].rtimeout;
        stat->diskpaths_stat_1s[i].rfailed = newt[i].rfailed;
        stat->diskpaths_stat_1s[i].min_rserv = newt[i].min_rserv;
        stat->diskpaths_stat_1s[i].max_rserv = newt[i].max_rserv;
        stat->diskpaths_stat_1s[i].wserv = newt[i].wserv;
        stat->diskpaths_stat_1s[i].wtimeout = newt[i].wtimeout;
        stat->diskpaths_stat_1s[i].wfailed = newt[i].wfailed;
        stat->diskpaths_stat_1s[i].min_wserv = newt[i].min_wserv;
        stat->diskpaths_stat_1s[i].max_wserv = newt[i].max_wserv;
        stat->diskpaths_stat_1s[i].wq_depth = newt[i].wq_depth;
        stat->diskpaths_stat_1s[i].wq_sampled = newt[i].wq_sampled;
        stat->diskpaths_stat_1s[i].wq_time = newt[i].wq_time;
        stat->diskpaths_stat_1s[i].wq_min_time = newt[i].wq_min_time;
        stat->diskpaths_stat_1s[i].wq_max_time = newt[i].wq_max_time;
    }

    zx_free(oldt);
    zx_free(newt);

    return stat;
}

void zx_diskpath_stat_destroy(zx_diskpath_stat_t *stat) {
    if (stat != NULL) {
        if (stat->diskpaths_stat != NULL) {
            zx_free(stat->diskpaths_stat);
        }
        if (stat->diskpaths_stat_1s != NULL) {
            zx_free(stat->diskpaths_stat_1s);
        }
        zx_free(stat);
    }
}


zx_diskvolume_stat_t *zx_diskvolume_stat_init() {
    zx_diskvolume_stat_t *stat = (zx_diskvolume_stat_t *)zx_malloc(NULL, sizeof(zx_diskvolume_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_diskvolume_stat_t));

    perfstat_config(PERFSTAT_ENABLE | PERFSTAT_LV, NULL);

    int ret = perfstat_logicalvolume(NULL, NULL, sizeof(perfstat_logicalvolume_t), 0);
    if (ret < 1) {
        perror("perfstat_logicalvolume");
        perfstat_config(PERFSTAT_DISABLE | PERFSTAT_LV, NULL);
        return stat;
    }
    stat->ndiskvolumes = ret;

    perfstat_logicalvolume_t *lv = 
        (perfstat_logicalvolume_t *)zx_malloc(NULL, stat->ndiskvolumes * sizeof(perfstat_logicalvolume_t));

    perfstat_id_t first_lv;
    strscpy(first_lv.name, FIRST_LOGICALVOLUME);
    perfstat_logicalvolume(&first_lv, lv, sizeof(perfstat_logicalvolume_t), stat->ndiskvolumes);

    stat->diskvolumes_stat = (zx_diskvolume_t *)zx_malloc(NULL, stat->ndiskvolumes * sizeof(zx_diskvolume_t));
    for (int i = 0; i < stat->ndiskvolumes; i++) {
        snprintf(stat->diskvolumes_stat[i].name, IDENTIFIER_LENGTH, "%s", lv[i].name);
        snprintf(stat->diskvolumes_stat[i].vgname, IDENTIFIER_LENGTH, "%s", lv[i].vgname);
        stat->diskvolumes_stat[i].open_close = lv[i].open_close;
        stat->diskvolumes_stat[i].state = lv[i].state;
        stat->diskvolumes_stat[i].mirror_policy = lv[i].mirror_policy;
        stat->diskvolumes_stat[i].mirror_write_consistency = lv[i].mirror_write_consistency;
        stat->diskvolumes_stat[i].write_verify = lv[i].write_verify;
        stat->diskvolumes_stat[i].ppsize = lv[i].ppsize;
        stat->diskvolumes_stat[i].logical_partitions = lv[i].logical_partitions;
        stat->diskvolumes_stat[i].mirrors = lv[i].mirrors;
        stat->diskvolumes_stat[i].iocnt = lv[i].iocnt;
        stat->diskvolumes_stat[i].kbreads = lv[i].kbreads;
        stat->diskvolumes_stat[i].kbwrites = lv[i].kbwrites;
    }

    perfstat_config(PERFSTAT_DISABLE | PERFSTAT_LV, NULL);

    zx_free(lv);

    return stat;
}

void zx_diskvolume_stat_destroy(zx_diskvolume_stat_t *stat) {
    if (stat != NULL) {
        if (stat->diskvolumes_stat != NULL) {
            zx_free(stat->diskvolumes_stat);
        }
        zx_free(stat);
    }
}