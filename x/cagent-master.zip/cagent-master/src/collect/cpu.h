#ifndef __ZX_CPU_H__
#define __ZX_CPU_H__

#include <sys/protosw.h>
#include <libperfstat.h>

typedef struct zx_cpu_t {
    char name[IDENTIFIER_LENGTH];
    double user_pct;
    double sys_pct;
    double idle_pct;
    double wait_pct;
    unsigned long long pswitch;
    unsigned long long syscall;
    unsigned long long sysread;
    unsigned long long syswrite;
    unsigned long long sysfork;
    unsigned long long sysexec;
} zx_cpu_t;

typedef struct zx_cpu_stat_t {
    int ncpus;                      // 逻辑核心数量
    char desc[IDENTIFIER_LENGTH];   // 处理器类型名称
    double mhz;
    double user_pct;
    double sys_pct;
    double idle_pct;
    double wait_pct;
    unsigned long long pswitch;
    unsigned long long syscall;
    unsigned long long sysread;
    unsigned long long syswrite;
    unsigned long long sysfork;
    unsigned long long sysexec;
    double load_avg1;
    double load_avg5;
    double load_avg15;
    unsigned long long uptime;
    zx_cpu_t *cpus_stat;             // 各个逻辑核心详细信息
} zx_cpu_stat_t;

zx_cpu_stat_t *zx_cpu_stat_init();

void zx_cpu_stat_destroy(zx_cpu_stat_t *stat);


#endif