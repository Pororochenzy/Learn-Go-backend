#ifndef __ZX_DISK_SPACE_H__
#define __ZX_DISK_SPACE_H__

typedef struct zx_filesystem_t {
    char fs_path[128];
    char fs_type[32];    
    char fs_mount[512];
    unsigned long long block_bsize; // 经过优化的块大小 (byte)
    unsigned long long block_total;
    unsigned long long block_used;
    unsigned long long block_free;
    double block_used_pct;
    double block_free_pct;
    unsigned long long inode_total;
    unsigned long long inode_free;
} zx_filesystem_t;

typedef struct zx_diskspace_stat_t {
    int nfs;
    zx_filesystem_t *fs_stat;
} zx_diskspace_stat_t;

zx_diskspace_stat_t *zx_diskspace_stat_init();

void zx_diskspace_stat_destroy(zx_diskspace_stat_t *stat);

#endif