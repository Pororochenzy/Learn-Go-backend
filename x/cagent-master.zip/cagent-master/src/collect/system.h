#ifndef __ZX_SYSTEM_H__
#define __ZX_SYSTEM_H__

typedef struct zx_system_t {
    char os[256];                // 平台
    char hostname[256];          // 主机名
    char platform[256];          // 系统
    char platform_version[256];  // 系统版本
    char platform_family[256];   // 系统类型
    char machine[256];           // 硬件体系类型
} zx_system_t;

int zx_system_collect(zx_system_t *sys);

#endif