#include "diskspace.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/mntctl.h>
#include <sys/vfs.h>
#include <sys/vmount.h>
#include <sys/statfs.h>
#include <sys/statvfs.h>

#include "../util/zx_common.h"

static const char *get_fs_name(int type) {
    extern struct vfs_ent *getvfsbytype(int type);

	struct vfs_ent *vfs;
	static char	*fs_names[MNT_AIXLAST + 1] = {};
	if (NULL == fs_names[type] && NULL != (vfs = getvfsbytype(type))) {
		fs_names[type] = zx_strdup(fs_names[type], vfs->vfsent_name);
    }
	return (NULL != fs_names[type]) ? fs_names[type] : "unknown";
}

zx_diskspace_stat_t *zx_diskspace_stat_init() {
    zx_diskspace_stat_t *stat = zx_malloc(NULL, sizeof(zx_diskspace_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_diskspace_stat_t));

    int size = 0;
    if (0 != mntctl(MCTL_QUERY, sizeof(size), (char *)&(size))) {
        perror("mntctl");
        return stat;
    }

    struct vmount *vmt = (struct vmount *)zx_malloc(NULL, size);
    int ret = mntctl(MCTL_QUERY, size, (char *)vmt);
    if (ret < 1) {
        perror("mntctl");
        return stat;
    }
    stat->nfs = ret;
    stat->fs_stat = (zx_filesystem_t *)zx_malloc(NULL, stat->nfs * sizeof(zx_filesystem_t));

    struct vmount *p = vmt;
    for (int i = 0; i < stat->nfs; i++, p = (struct vmount *)((char*)p + p->vmt_length)) {

        snprintf(stat->fs_stat[i].fs_path, sizeof(stat->fs_stat[i].fs_path), "%s", vmt2dataptr(p, VMT_OBJECT));
        snprintf(stat->fs_stat[i].fs_type, sizeof(stat->fs_stat[i].fs_type), "%s", get_fs_name(p->vmt_gfstype));
        snprintf(stat->fs_stat[i].fs_mount, sizeof(stat->fs_stat[i].fs_mount), "%s", vmt2dataptr(p, VMT_STUB));

        struct statfs sb;
        statfs(stat->fs_stat[i].fs_mount, &sb);

        stat->fs_stat[i].block_bsize = sb.f_bsize;
        stat->fs_stat[i].block_total = sb.f_blocks;
        stat->fs_stat[i].block_used = sb.f_blocks - sb.f_bfree;
        stat->fs_stat[i].block_free = sb.f_bavail;
        if (0 != sb.f_blocks - sb.f_bfree + sb.f_bavail) {
		    stat->fs_stat[i].block_used_pct =
                100.0 - (double)(100.0 * sb.f_bavail) / (sb.f_blocks - sb.f_bfree + sb.f_bavail);
        } else {
            stat->fs_stat[i].block_used_pct = 0.0;
        }
        if (0 != sb.f_blocks - sb.f_bfree + sb.f_bavail) {
            stat->fs_stat[i].block_free_pct =
                (double)(100.0 * sb.f_bavail) / (sb.f_blocks - sb.f_bfree + sb.f_bavail);
        } else {
            stat->fs_stat[i].block_free_pct = 0.0;
        }
        
        stat->fs_stat[i].inode_total = sb.f_files;
        stat->fs_stat[i].inode_free = sb.f_ffree;
    }

    zx_free(vmt);

    return stat;
}

void zx_diskspace_stat_destroy(zx_diskspace_stat_t *stat) {
    if (stat != NULL) {
        if (stat->fs_stat != NULL) {
            zx_free(stat->fs_stat);
        }
        zx_free(stat);
    }
}