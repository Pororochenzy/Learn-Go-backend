#include "protocol.h"
#include <unistd.h>
#include <string.h>
#include <sys/protosw.h>
#include <libperfstat.h>
#include "../util/zx_common.h"

zx_protocol_stat_t *zx_protocol_stat_init() {
    zx_protocol_stat_t *stat = zx_malloc(NULL, sizeof(zx_protocol_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_protocol_stat_t));

    int nprotocols = perfstat_protocol(NULL, NULL, sizeof(perfstat_protocol_t), 0);
    if (nprotocols < 1) {
        perror("perfstat_protocol");
        return stat;
    }
    perfstat_protocol_t *pinfo = zx_malloc(NULL, nprotocols * sizeof(perfstat_protocol_t));

    perfstat_id_t first_protocol;
    strcpy(first_protocol.name, FIRST_PROTOCOL);
    perfstat_protocol(&first_protocol, pinfo, sizeof(perfstat_protocol_t), nprotocols);

    for (int i = 0; i < nprotocols; i++) {
        if (0 == strcmp(pinfo[i].name, "ip")) {
            stat->ip_ipackets = pinfo[i].u.ip.ipackets;
            stat->ip_ierrors = pinfo[i].u.ip.ierrors;
            stat->ip_opackets = pinfo[i].u.ip.opackets;
            stat->ip_oerrors = pinfo[i].u.ip.oerrors;
        } else if (0 == strcmp(pinfo[i].name, "ipv6")) {
            stat->ipv6_ipackets = pinfo[i].u.ipv6.ipackets;
            stat->ipv6_ierrors = pinfo[i].u.ipv6.ierrors;
            stat->ipv6_opackets = pinfo[i].u.ipv6.opackets;
            stat->ipv6_oerrors = pinfo[i].u.ipv6.oerrors;
        } else if (0 == strcmp(pinfo[i].name, "icmp")) {
            stat->icmp_received = pinfo[i].u.icmp.received;
            stat->icmp_sent = pinfo[i].u.icmp.sent;
            stat->icmp_errors = pinfo[i].u.icmp.errors;
        } else if (0 == strcmp(pinfo[i].name, "icmpv6")) {
            stat->icmpv6_received = pinfo[i].u.icmpv6.received;
            stat->icmpv6_sent = pinfo[i].u.icmpv6.sent;
            stat->icmpv6_errors = pinfo[i].u.icmpv6.errors;
        } else if (0 == strcmp(pinfo[i].name, "udp")) {
            stat->udp_ipackets = pinfo[i].u.udp.ipackets;
            stat->udp_ierrors = pinfo[i].u.udp.ierrors;
            stat->udp_opackets = pinfo[i].u.udp.opackets;
            stat->udp_no_socket = pinfo[i].u.udp.no_socket;
        } else if (0 == strcmp(pinfo[i].name, "tcp")) {
            stat->tcp_ipackets = pinfo[i].u.tcp.ipackets;
            stat->tcp_ierrors = pinfo[i].u.tcp.ierrors;
            stat->tcp_opackets = pinfo[i].u.tcp.opackets;
            stat->tcp_initiated = pinfo[i].u.tcp.initiated;
            stat->tcp_accepted = pinfo[i].u.tcp.accepted;
            stat->tcp_established = pinfo[i].u.tcp.established;
            stat->tcp_dropped = pinfo[i].u.tcp.dropped;
        } else if (0 == strcmp(pinfo[i].name, "rpc")) {
            // todo
        } else if (0 == strcmp(pinfo[i].name, "nfs")) {
            // todo
        } else if (0 == strcmp(pinfo[i].name, "nfsv2")) {
            // todo
        } else if (0 == strcmp(pinfo[i].name, "nfsv3")) {
            // todo
        } else {
            printf("未支持的协议类型:%s\n", pinfo[i].name);
        }
    }

    return stat;
}

void zx_protocol_stat_destroy(zx_protocol_stat_t *stat) {
    if (stat != NULL) {
        zx_free(stat);
    }
}