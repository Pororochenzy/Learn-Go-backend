#include "memory.h"
#include <unistd.h>
#include <string.h>
#include <sys/protosw.h>
#include <libperfstat.h>
#include "../util/zx_common.h"

zx_mem_stat_t *zx_mem_stat_init() {
    zx_mem_stat_t *stat = zx_malloc(NULL, sizeof(zx_mem_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_mem_stat_t));

    perfstat_memory_total_t minfo;
    int ret = perfstat_memory_total(NULL, &minfo, sizeof(perfstat_memory_total_t), 1);
    if (ret < 1) {
        perror("perfstat_memory_total");
        return stat;
    }

    stat->real_total = minfo.real_total * PAGE_4K;
    stat->real_system = minfo.real_system * PAGE_4K; 
    stat->real_user = minfo.real_user * PAGE_4K;   
    stat->real_process = minfo.real_process * PAGE_4K;
    stat->real_free = minfo.real_free * PAGE_4K;
    stat->real_pinned = minfo.real_pinned * PAGE_4K;
    stat->real_inuse = minfo.real_inuse * PAGE_4K;
    stat->virt_total = minfo.virt_total * PAGE_4K;
    stat->virt_active = minfo.virt_active;
    stat->pgsp_total = minfo.pgsp_total * PAGE_4K;
    stat->pgsp_free = minfo.pgsp_free * PAGE_4K;
    stat->pgsp_rsvd = minfo.pgsp_rsvd * PAGE_4K;
    stat->pgbad = minfo.pgbad;
    stat->pgexct = minfo.pgexct;
    stat->pgins = minfo.pgins;
    stat->pgouts = minfo.pgouts;
    stat->pgspins = minfo.pgspins;
    stat->pgspouts = minfo.pgspouts;
    stat->pgsteals = minfo.pgsteals;
    stat->scans = minfo.scans;       
    stat->cycles = minfo.cycles;  
    stat->numperm = minfo.numperm * PAGE_4K;
    stat->iome = minfo.iome;        
    stat->iomu = minfo.iomu;        
    stat->iohwm = minfo.iohwm;       
    stat->pmem = minfo.pmem;        
    return stat;
}

void zx_mem_stat_destroy(zx_mem_stat_t *stat) {
    if (stat != NULL) {
        zx_free(stat);
    }
}