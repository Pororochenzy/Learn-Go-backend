#include "system.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/utsname.h>
#include "../util/zx_common.h"

int zx_system_collect(zx_system_t *sys) {
    memset((void *)sys, 0, sizeof(struct zx_system_t));
    struct utsname buf;
    if(-1 == uname(&buf)) {
        perror("uname");
        return -1;
    }

    zx_strlower(buf.sysname);
    zx_strlower(buf.nodename);
    zx_strlower(buf.version);
    zx_strlower(buf.release);
    zx_strlower(buf.machine);

    snprintf(sys->os, 256, "%s", buf.sysname);
    snprintf(sys->hostname, 256, "%s", buf.nodename);
    snprintf(sys->platform, 256, "%s", buf.sysname);
    snprintf(sys->platform_version, 256, "%s.%s", buf.version, buf.release);
    snprintf(sys->platform_family, 256, "%s", "unix"); // 针对AIX暂时写死
    snprintf(sys->machine, 256, "%s", buf.machine);
    return 0;
}