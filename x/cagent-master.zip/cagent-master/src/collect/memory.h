#ifndef __ZX_MEMORY_H__
#define __ZX_MEMORY_H__

typedef struct zx_mem_stat_t {
    /* real memory */
    unsigned long long real_total;  // total real memory (byte)
    unsigned long long real_free;   // free real memory (byte)
    unsigned long long real_pinned; // real memory which is pinned (byte)
    unsigned long long real_inuse;  // real memory which is in use (byte)
    unsigned long long real_system; // real memory used by system segments (byte)    
    unsigned long long real_user;   // real memory used by non-system segments (byte)      
    unsigned long long real_process;// real memory used by process segments (byte)

    unsigned long long virt_total;  // total virtual memory (byte)
    unsigned long long virt_active; // active virtual pages (avm column in vmstat output)

    /* paging space */
    unsigned long long pgsp_total;  // total paging space (byte)
    unsigned long long pgsp_free;   // free paging space (byte)
    unsigned long long pgsp_rsvd;   // reserved paging space (byte)
    unsigned long long pgbad;       // number of bad pages
    unsigned long long pgexct;      // number of page faults
    unsigned long long pgins;       // number of pages paged in
    unsigned long long pgouts;      // number of pages paged out
    unsigned long long pgspins;     // number of page ins from paging space
    unsigned long long pgspouts;    // number of page outs from paging space
    unsigned long long pgsteals;    // number of page steals

    unsigned long long scans;       // number of page scans by clock
    unsigned long long cycles;      // number of page replacement cycles
    unsigned long long numperm;     // number of frames used for files (byte)
    unsigned long long iome;        // I/O memory entitlement of the partition in bytes
    unsigned long long iomu;        // I/O memory entitlement of the partition in use in bytes
    unsigned long long iohwm;       // high water mark of I/O memory entitlement used in bytes
    unsigned long long pmem;        // amount of physical memory currently backing partition’s logical memory in bytes
} zx_mem_stat_t;

zx_mem_stat_t *zx_mem_stat_init();

void zx_mem_stat_destroy(zx_mem_stat_t *stat);

#endif