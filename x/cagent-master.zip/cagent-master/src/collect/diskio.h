#ifndef __ZX_DISK_IO_H__
#define __ZX_DISK_IO_H__

#include <sys/protosw.h>
#include <libperfstat.h>

typedef struct zx_disk_t {
    char name[IDENTIFIER_LENGTH];   // name of the disk
    char adapter[IDENTIFIER_LENGTH]; // disk adapter name
    char desc[IDENTIFIER_LENGTH];   // disk description (from ODM)
    char vgname[IDENTIFIER_LENGTH]; // volume group name (from ODM)
    unsigned long long size;        // size of the disk (mb)
    unsigned long long free;        // free space on the disk (mb)
    unsigned long long bsize;       // disk block size (in bytes)
    unsigned long long rxfers;      // number of transfers from disk
    unsigned long long xfers;       // number of transfers to/from disk
    unsigned long long wblks;       // number of blocks written to disk
    unsigned long long rblks;       // number of blocks read from disk
    unsigned long long time;        // amount of time disk is active
    unsigned long long paths_count; // number of paths defined to the disk
    unsigned long long qdepth;      // instantaneous queue depth (equests sent to disk and not completed yet)
    unsigned long long q_full;      // queue full occurrence count (times the disk is not accepting any more request)
    unsigned long long q_sampled;   // accumulated sampled queue depth
    unsigned long long rserv;       // read service time
    unsigned long long rtimeout;    // number of read request timeout
    unsigned long long rfailed;     // number of failed read requests
    unsigned long long min_rserv;   // minimum read service time
    unsigned long long max_rserv;   // maximum read service time
    unsigned long long wserv;       // write service time
    unsigned long long wtimeout;    // number of write request timeout
    unsigned long long wfailed;     // number of failed write requests
    unsigned long long min_wserv;   // minimum write service time
    unsigned long long max_wserv;   // maximum write service time
    unsigned long long wq_depth;    // instantaneous wait queue depth (requests waiting to be sent to disk)
    unsigned long long wq_sampled;  // accumulated sampled wq_depth
    unsigned long long wq_time;     // accumulated wait queuing time
    unsigned long long wq_min_time; // minimum wait queuing time
    unsigned long long wq_max_time; // maximum wait queuing time
} zx_disk_t;

typedef struct zx_disk_stat_t {
    int ndisks;
    unsigned long long size;      // total size of all the disks (mb)
    unsigned long long free;      // total free space of all the disk (mb)
    unsigned long long rxfers;    // number of transfers from disk
    unsigned long long xfers;     // total number of transfers to/from disk
    unsigned long long wblks;     // 512 bytes blocks written via adapter
    unsigned long long rblks;     // 512 bytes blocks read via adapter
    unsigned long long time;      // amount of time disks are active
    zx_disk_t *disks_stat;
    zx_disk_t *disks_stat_1s;
} zx_disk_stat_t;

zx_disk_stat_t *zx_disk_stat_init();

void zx_disk_stat_destroy(zx_disk_stat_t *stat);


typedef struct zx_diskadapter_t {
    char name[IDENTIFIER_LENGTH]; // name of the diskadapter
    int ndisks;                   // number of disks connected
    unsigned long long size;      // total size of all the disks (mb)
    unsigned long long free;      // total free space of all the disk (mb)
    unsigned long long rxfers;    // number of transfers from disk
    unsigned long long xfers;     // total number of transfers to/from disk
    unsigned long long wblks;     // 512 bytes blocks written via adapter
    unsigned long long rblks;     // 512 bytes blocks read via adapter
    unsigned long long time;      // amount of time disks are active
} zx_diskadapter_t;

typedef struct zx_diskadapter_stat_t {
    int ndiskadapters;
    zx_diskadapter_t *diskadapters_stat;
    zx_diskadapter_t *diskadapters_stat_1s;
} zx_diskadapter_stat_t;

zx_diskadapter_stat_t *zx_diskadapter_stat_init();

void zx_diskadapter_stat_destroy(zx_diskadapter_stat_t *stat);


typedef struct zx_diskpath_t {
    char name[IDENTIFIER_LENGTH];       // name of the path
    char adapter[IDENTIFIER_LENGTH];    // name of the adapter
    unsigned long long rxfers;          // number of transfers from disk
    unsigned long long xfers;           // total number of transfers via the path
    unsigned long long rblks;           // number of blocks read
    unsigned long long wblks;           // number of blocks written
    unsigned long long time;            // amount of time path is active
    unsigned long long q_full;          // queue full occurrence count (times the disk is not accepting any request)
    unsigned long long q_sampled;       // accumulated sampled queue depth
    unsigned long long rserv;           // read service time
    unsigned long long rtimeout;        // number of read request timeout
    unsigned long long rfailed;         // number of failed read requests
    unsigned long long min_rserv;       // minimum read service time
    unsigned long long max_rserv;       // maximum read service time
    unsigned long long wserv;           // write service time
    unsigned long long wtimeout;        // number of write request timeout
    unsigned long long wfailed;         // number of failed write requests
    unsigned long long min_wserv;       // minimum write service time
    unsigned long long max_wserv;       // maximum write service time
    unsigned long long wq_depth;        // instantaneous wait queue depth (requests waiting to be sent to disk)
    unsigned long long wq_sampled;      // accumulated sampled wq_depth
    unsigned long long wq_time;         // accumulated wait queuing time
    unsigned long long wq_min_time;     // minimum wait queuing time
    unsigned long long wq_max_time;     // maximum wait queuing time
} zx_diskpath_t;

typedef struct zx_diskpath_stat_t {
    int ndiskpaths;
    zx_diskpath_t *diskpaths_stat;
    zx_diskpath_t *diskpaths_stat_1s;
} zx_diskpath_stat_t;

zx_diskpath_stat_t *zx_diskpath_stat_init();

void zx_diskpath_stat_destroy(zx_diskpath_stat_t *stat);

typedef struct zx_diskvolume_t {
    char name[IDENTIFIER_LENGTH];       // logical volume
    char vgname[IDENTIFIER_LENGTH];     // volume group name
    unsigned long long open_close;      // LVM_QLVOPEN
    unsigned long long state;           // LVM_CONSIST
    unsigned long long mirror_policy;   // LVM_PARALLEL
    unsigned long long mirror_write_consistency; // LVM_CONSIST
    unsigned long long write_verify;    // LVM_VERIFY
    unsigned long long ppsize;          // physical partition size in MB
    unsigned long long logical_partitions;  // total number of logical partitions configured for this logical volume
    unsigned long long mirrors;         // number of physical mirrors for each logical partition
    unsigned long long iocnt;           // number of read and write requests
    unsigned long long kbreads;         // number of kilobytes read
    unsigned long long kbwrites;        // number of kilobytes written
} zx_diskvolume_t;

typedef struct zx_diskvolume_stat_t {
    int ndiskvolumes;
    zx_diskvolume_t *diskvolumes_stat;
} zx_diskvolume_stat_t;

zx_diskvolume_stat_t *zx_diskvolume_stat_init();

void zx_diskvolume_stat_destroy(zx_diskvolume_stat_t *stat);

#endif