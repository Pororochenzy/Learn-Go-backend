#include "cpu.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/proc.h> // SBITS
#include <sys/systemcfg.h>
#include "../util/zx_common.h"
#include "../util/zx_exec.h"

#define XINTFRAC	((double)(_system_configuration.Xint)/(double)(_system_configuration.Xfrac))
/* convert physical processor tics to seconds */
#define HTIC2SEC(x)	((double)x * XINTFRAC)/(double)1000000000.0

#define PERIOD 2

static unsigned long long hertz = 0;

// 命令行获取开机时间
static unsigned long long zx_uptime() {

    int timeout = 3;
    unsigned long long idays = 0, ihours = 0, imins = 0;
    char *days = NULL, *hours = NULL, *mins = NULL;
    char error[MAX_STRING_LEN];
    if (SUCCEED != zx_execute("uptime | awk '{print $3}'",
            &days, error, sizeof(error), timeout)) {
        printf("uptime days error:%s\n", error);
        return 0;
    }
    idays = strtoul(days, NULL, 10);

    if (SUCCEED != zx_execute("uptime | awk '{print $5}' | sed 's/[:,]/ /g' | awk '{print $1}'",
            &hours, error, sizeof(error), timeout)) {
        printf("uptime hours error:%s\n", error);
        return 0;
    }
    ihours = strtoul(hours, NULL, 10);

    if (SUCCEED != zx_execute("uptime | awk '{print $5}' | sed 's/[:,]/ /g' | awk '{print $2}'",
            &mins, error, sizeof(error), timeout)) {
        printf("uptime mins error:%s\n", error);
        return 0;
    }
    imins = strtoul(mins, NULL, 10);

    return (idays*SEC_PER_DAY + ihours*SEC_PER_HOUR + imins*SEC_PER_MIN);
}

// 命令行获取完整的cpu信息
static void zx_cpu_info_by_cmd(zx_cpu_stat_t *stat) {
    int timeout = 3;
    char *result = NULL;
    char error[MAX_STRING_LEN];

    // 填充默认值
    stat->ncpus = 0;
    snprintf(stat->desc, IDENTIFIER_LENGTH, "%s", "");
    stat->mhz = 0.0;
    stat->user_pct = 0.0;
    stat->sys_pct = 0.0;
    stat->idle_pct = 0.0;
    stat->wait_pct = 0.0;
    stat->pswitch = 0;
    stat->syscall = 0;
    stat->sysread = 0;
    stat->syswrite = 0;
    stat->sysfork = 0;
    stat->sysexec = 0;
    stat->load_avg1 = 0;
    stat->load_avg5 = 0;
    stat->load_avg15 = 0;
    stat->cpus_stat = NULL;

    // CPU数量
    if (SUCCEED != zx_execute("pmcycles -m | wc -l",
            &result, error, sizeof(error), timeout)) {
        printf("pmcycles -m error:%s\n", error);
        return;
    }
    stat->ncpus = strtoul(result, NULL, 10);
    if (stat->ncpus < 1) {
        printf("get cpu number error\n");
        return;
    }

    // CPU频率
    if (SUCCEED != zx_execute("pmcycles | awk '{print $5}'",
            &result, error, sizeof(error), timeout)) {
        printf("pmcycles error:%s\n", error);
        return;
    }
    stat->mhz = strtod(result, NULL);

    // CPU类型
    if (SUCCEED != zx_execute("lsattr -E -l proc0 | grep 'Processor type' | awk '{print $2}'",
            &result, error, sizeof(error), timeout)) {
        printf("lsattr -E -l proc0 error:%s\n", error);
        return;
    }
    zx_remove_whitespace(result);
    snprintf(stat->desc, IDENTIFIER_LENGTH, "%s", result);

    // 开机时间
    stat->uptime = zx_uptime();

    // 使用率(% user % sys % idle % iowait)
    if (SUCCEED != zx_execute("iostat -t | sed -n '$p' | awk '{print $3}'",
            &result, error, sizeof(error), timeout)) {
        printf("iostat -t error:%s\n", error);
        return;
    }
    stat->user_pct = strtod(result, NULL);

    if (SUCCEED != zx_execute("iostat -t | sed -n '$p' | awk '{print $4}'",
            &result, error, sizeof(error), timeout)) {
        printf("iostat -t error:%s\n", error);
        return;
    }
    stat->sys_pct = strtod(result, NULL);

    if (SUCCEED != zx_execute("iostat -t | sed -n '$p' | awk '{print $5}'",
            &result, error, sizeof(error), timeout)) {
        printf("iostat -t error:%s\n", error);
        return;
    }
    stat->idle_pct = strtod(result, NULL);

    if (SUCCEED != zx_execute("iostat -t | sed -n '$p' | awk '{print $6}'",
            &result, error, sizeof(error), timeout)) {
        printf("iostat -t error:%s\n", error);
        return;
    }
    stat->wait_pct = strtod(result, NULL);
}

// 计算CPU整体使用率
static void zx_cpu_util(double *usr_pct, double *sys_pct, double *idle_pct, double *wait_pct) {

    perfstat_partition_total_t lparstats;
    perfstat_cpu_total_t cpustats;
    perfstat_partition_total(NULL, &lparstats, sizeof(perfstat_partition_total_t), 1);
    perfstat_cpu_total(NULL, &cpustats, sizeof(perfstat_cpu_total_t), 1);

    unsigned long long last_vcsw      = lparstats.vol_virt_cswitch + lparstats.invol_virt_cswitch; 
    unsigned long long last_time_base = lparstats.timebase_last;
    unsigned long long last_phint     = lparstats.phantintrs;
    unsigned long long last_pit       = lparstats.pool_idle_time;

    unsigned long long last_pcpu_user = lparstats.puser;
    unsigned long long last_pcpu_sys  = lparstats.psys;
    unsigned long long last_pcpu_idle = lparstats.pidle;
    unsigned long long last_pcpu_wait = lparstats.pwait;

    unsigned long long last_lcpu_user = cpustats.user;
    unsigned long long last_lcpu_sys  = cpustats.sys;
    unsigned long long last_lcpu_idle = cpustats.idle;
    unsigned long long last_lcpu_wait = cpustats.wait;

    unsigned long long last_busy_donated = lparstats.busy_donated_purr;
    unsigned long long last_idle_donated = lparstats.idle_donated_purr;

    unsigned long long last_busy_stolen = lparstats.busy_stolen_purr;
    unsigned long long last_idle_stolen = lparstats.idle_stolen_purr;

    sleep(PERIOD);
    perfstat_partition_total(NULL, &lparstats, sizeof(perfstat_partition_total_t), 1);
    perfstat_cpu_total(NULL, &cpustats, sizeof(perfstat_cpu_total_t), 1);


    /* calculate physcial processor tics during the last interval in user, system, idle and wait mode  */
    unsigned long long delta_pcpu_user  = lparstats.puser - last_pcpu_user; 
    unsigned long long delta_pcpu_sys   = lparstats.psys  - last_pcpu_sys;
    unsigned long long delta_pcpu_idle  = lparstats.pidle - last_pcpu_idle;
    unsigned long long delta_pcpu_wait  = lparstats.pwait - last_pcpu_wait;
   
    /* calculate total physcial processor tics during the last interval */
    unsigned long long pcputime = delta_pcpu_user + delta_pcpu_sys + delta_pcpu_idle + delta_pcpu_wait;
    unsigned long long delta_purr = pcputime;

    /* calculate clock tics during the last interval in user, system, idle and wait mode */
    unsigned long long delta_lcpu_user  = cpustats.user - last_lcpu_user; 
    unsigned long long delta_lcpu_sys   = cpustats.sys  - last_lcpu_sys;
    unsigned long long delta_lcpu_idle  = cpustats.idle - last_lcpu_idle;
    unsigned long long delta_lcpu_wait  = cpustats.wait - last_lcpu_wait;
   
    /* calculate total clock tics during the last interval */ 
    unsigned long long lcputime = delta_lcpu_user + delta_lcpu_sys + delta_lcpu_idle + delta_lcpu_wait;

    /* calculate entitlement for this partition - entitled physical processors for this partition */
    double entitlement = (double)(lparstats.entitled_proc_capacity / 100.0);

    /* calculate delta time in terms of physical processor tics */
    unsigned long long delta_time_base = lparstats.timebase_last - last_time_base;
    
    if (lparstats.type.b.shared_enabled) { /* partition is a SPLPAR */
        /* calculate entitled physical processor tics for this partitions */
        unsigned long long entitled_purr = delta_time_base * entitlement;
        if (entitled_purr < delta_purr) { /* for uncapped SPLPAR */
            /* in case of uncapped SPLPAR, consider entitled physical processor tics or 
             * consumed physical processor tics, which ever is greater */ 
            entitled_purr = delta_purr;
        }
        /* calculate unused physical processor tics out of the entitled physical processor tics */
        unsigned long long unused_purr = entitled_purr - delta_purr;
       
        /* distributed unused physical processor tics amoung wait and idle proportionally to wait and idle in clock tics */
        delta_pcpu_wait += unused_purr * ((double)delta_lcpu_wait / (double)(delta_lcpu_wait + delta_lcpu_idle));
        delta_pcpu_idle += unused_purr * ((double)delta_lcpu_idle / (double)(delta_lcpu_wait + delta_lcpu_idle));
      
        /* far SPLPAR, consider the entitled physical processor tics as the actual delta physical processor tics */
        pcputime = entitled_purr;
    } else if (lparstats.type.b.donate_enabled) { /* if donation is enabled for this DLPAR */
        /* calculate busy stolen and idle stolen physical processor tics during the last interval */ 
        /* these physical processor tics are stolen from this partition by the hypervsior
         * which will be used by wanting partitions */  
        unsigned long long delta_busy_stolen = lparstats.busy_stolen_purr - last_busy_stolen;
        unsigned long long delta_idle_stolen = lparstats.idle_stolen_purr - last_idle_stolen; 

        /* calculate busy donated and idle donated physical processor tics during the last interval */
        /* these physical processor tics are voluntarily donated by this partition to the hypervsior
         * which will be used by wanting partitions */  
        unsigned long long delta_busy_donated = lparstats.busy_donated_purr - last_busy_donated;
        unsigned long long delta_idle_donated = lparstats.idle_donated_purr - last_idle_donated;

        /* add busy donated and busy stolen to the kernel bucket, as cpu
         * cycles were donated / stolen when this partition is busy */
        delta_pcpu_sys += delta_busy_donated;
        delta_pcpu_sys += delta_busy_stolen;

        /* distribute idle stolen to wait and idle proportionally to the logical wait and idle in clock tics, as
         * cpu cycles were stolen when this partition is idle or in wait */
        delta_pcpu_wait += delta_idle_stolen * ((double)delta_lcpu_wait / (double)(delta_lcpu_wait + delta_lcpu_idle));
        delta_pcpu_idle += delta_idle_stolen * ((double)delta_lcpu_idle / (double)(delta_lcpu_wait + delta_lcpu_idle));

        /* distribute idle donated to wait and idle proportionally to the logical wait and idle in clock tics, as
         * cpu cycles were donated when this partition is idle or in wait */
        delta_pcpu_wait += delta_idle_donated * ((double)delta_lcpu_wait / (double)(delta_lcpu_wait + delta_lcpu_idle));
        delta_pcpu_idle += delta_idle_donated * ((double)delta_lcpu_idle / (double)(delta_lcpu_wait + delta_lcpu_idle));
     
        /* add donated to the total physical processor tics for CPU usage calculation, as they were 
         * distributed to respective buckets accordingly */
        pcputime +=  (delta_idle_donated + delta_busy_donated);

        /* add stolen to the total physical processor tics for CPU usage calculation, as they were 
         * distributed to respective buckets accordingly */
        pcputime +=  (delta_idle_stolen + delta_busy_stolen);
    }

    /* Processor Utilization - Applies for both SPLPAR and DLPAR*/
    *usr_pct = (double)delta_pcpu_user * 100.0 / (double)pcputime;
    *sys_pct = (double)delta_pcpu_sys  * 100.0 / (double)pcputime;
    *wait_pct = (double)delta_pcpu_wait * 100.0 / (double)pcputime;
    *idle_pct = (double)delta_pcpu_idle * 100.0 / (double)pcputime;

    if (lparstats.type.b.shared_enabled) { /* print SPLPAR specific stats */  
        /* Physical Processor Consumed by this partition */  
        double physc = (double)delta_purr / (double)delta_time_base;

        /* Percentage of Entitlement Consumed - percentage of entitled physical processor tics consumed */
        double entc = (double)((physc / entitlement) * 100);

        /* Logical Processor Utilization of this partition */
        double lbusy = (double)(delta_lcpu_user + delta_lcpu_sys) * 100.0 / (double)lcputime;

        /* Virtual CPU Context Switches per second */
        unsigned long long vcsw = lparstats.vol_virt_cswitch + lparstats.invol_virt_cswitch; 
	    double delta_sec = HTIC2SEC(delta_time_base);
        double vcsw_ps = (double)(vcsw - last_vcsw) / delta_sec;
        
        /* Phantom Interrupts per second */
        double phint = (double)(lparstats.phantintrs - last_phint) / delta_sec;
        
        if (lparstats.type.b.pool_util_authority) {
            /* Available physical Processor units available in the shared pool (app) */
            double app = (double)(lparstats.pool_idle_time - last_pit) / XINTFRAC*(double)delta_time_base;

            printf("%5s %5s %6s %6s %5s %5s %5s %5s %4s %5s\n",
                "%user", "%sys", "%wait", "%idle", "physc", "%entc", "lbusy", "app", "vcsw", "phint");
            printf("%5.1f %5.1f %6.1f %6.1f %5.2f %5.1f %5.1f %5.2f %4.0f %5.0f\n", 
                *usr_pct, *sys_pct, *wait_pct, *idle_pct, physc, entc, lbusy, app, vcsw_ps, phint);

        } else {

            printf("%5s %5s %6s %6s %5s %5s %5s %4s %5s\n",
                "%user", "%sys", "%wait", "%idle", "physc", "%entc", "lbusy", "vcsw", "phint");
            printf("%5.1f %5.1f %6.1f %6.1f %5.2f %5.1f %5.1f %4.0f %5.0f\n", 
                *usr_pct, *sys_pct, *wait_pct, *idle_pct, physc, entc, lbusy, vcsw_ps, phint);
            
        }
    } else if (lparstats.type.b.donate_enabled) { /* print donation-enabled DLPAR specific stats */
        /* Physical Processor Consumed by this partition 
         * (excluding donated and stolen physical processor tics). */
        double physc = (double)delta_purr / (double)delta_time_base;

        /* Virtual CPU Context Switches per second */
        unsigned long long vcsw = lparstats.vol_virt_cswitch + lparstats.invol_virt_cswitch; 
	    double delta_sec = HTIC2SEC(delta_time_base);
        double vcsw_ps = (double)(vcsw - last_vcsw) / delta_sec;
        
        printf("%5s %5s %6s %6s %6s %6s\n", "%user", "%sys", "%wait", "%idle", "%phsyc", "%vcsw\n");
        printf("%5.1f %5.1f %6.1f %6.1f %5.2f %4.0f\n", *usr_pct, *sys_pct, *wait_pct, *idle_pct, physc, vcsw_ps);

    } else {

        printf("%5s %5s %6s %6s\n", "%user", "%sys", "%wait", "%idle");
        printf("%5.1f %5.1f %6.1f %6.1f\n", *usr_pct, *sys_pct, *wait_pct, *idle_pct);

    }
}

zx_cpu_stat_t *zx_cpu_stat_init() {
    zx_cpu_stat_t *stat = zx_malloc(NULL, sizeof(zx_cpu_stat_t));
    if (stat == NULL) {
        return NULL;
    }
    memset((void *)stat, 0, sizeof(zx_cpu_stat_t));

    if (hertz == 0) {
        hertz = sysconf(_SC_CLK_TCK); // 每秒时钟周期
    }

    int ret = perfstat_cpu(NULL, NULL, sizeof(perfstat_cpu_t), 0);
    if (ret < 1) {
        perror("perfstat_cpu");
        // API采集失败时，尝试命令行采集
        zx_cpu_info_by_cmd(stat);
        return stat;
    }
    stat->ncpus = ret;

    perfstat_cpu_t *oldt = zx_malloc(NULL, stat->ncpus * sizeof(perfstat_cpu_t));
    perfstat_cpu_t *newt = zx_malloc(NULL, stat->ncpus * sizeof(perfstat_cpu_t));
    perfstat_cpu_total_t oldt_total, newt_total;

    perfstat_id_t first_cpu;
    strscpy(first_cpu.name, FIRST_CPU);

    perfstat_cpu(&first_cpu, oldt, sizeof(perfstat_cpu_t), stat->ncpus);
    perfstat_cpu_total(NULL, &oldt_total, sizeof(perfstat_cpu_total_t), 1);
    sleep(PERIOD);
    perfstat_cpu(&first_cpu, newt, sizeof(perfstat_cpu_t), stat->ncpus);
    perfstat_cpu_total(NULL, &newt_total, sizeof(perfstat_cpu_total_t), 1);

#ifdef AIX_VERSION_7X

    perfstat_rawdata_t data;
    data.type = UTIL_CPU;
    data.curstat = newt;
    data.prevstat = oldt;
    data.sizeof_data = sizeof(perfstat_cpu_t);
    data.cur_elems = stat->ncpus;
    data.prev_elems = stat->ncpus;

    perfstat_cpu_util_t *util = zx_malloc(NULL, stat->ncpus * sizeof(perfstat_cpu_util_t));
    perfstat_cpu_util(&data, util, sizeof(perfstat_cpu_util_t), stat->ncpus);

    perfstat_rawdata_t data_total;
    data_total.type = UTIL_CPU_TOTAL;
    data_total.curstat = &newt_total;
    data_total.prevstat= &oldt_total;
    data_total.sizeof_data = sizeof(perfstat_cpu_total_t);
    data_total.cur_elems = 1;
    data_total.prev_elems = 1;

    perfstat_cpu_util_t util_total;
    perfstat_cpu_util(&data_total, &util_total, sizeof(perfstat_cpu_util_t), 1);

    stat->user_pct = util_total.user_pct;
    stat->sys_pct = util_total.kern_pct;
    stat->idle_pct = util_total.idle_pct;
    stat->wait_pct = util_total.wait_pct;

#else

    double user, sys, idle, wait;
    zx_cpu_util(&user, &sys, &idle, &wait);
    stat->user_pct = user;
    stat->sys_pct = sys;
    stat->idle_pct = idle;
    stat->wait_pct = wait;

#endif

    snprintf(stat->desc, IDENTIFIER_LENGTH, "%s", newt_total.description);
    stat->mhz = newt_total.processorHZ / 1000000.0;
    stat->pswitch = newt_total.pswitch;
    stat->syscall = newt_total.syscall;
    stat->sysread = newt_total.sysread;
    stat->syswrite = newt_total.syswrite;
    stat->sysfork = newt_total.sysfork;
    stat->sysexec = newt_total.sysexec;
    stat->load_avg1 = newt_total.loadavg[0] / (1 << SBITS);
    stat->load_avg5 = newt_total.loadavg[1] / (1 << SBITS);
    stat->load_avg15 = newt_total.loadavg[2] / (1 << SBITS);
    stat->uptime = (unsigned long long)((unsigned long long)newt_total.lbolt / hertz);
    // 针对某些平台获取的开机时间溢出的情况，通过命令行获取
    if (stat->uptime > ZX_JAN_2038) {
        stat->uptime = zx_uptime();
    }

    stat->cpus_stat = zx_malloc(NULL, stat->ncpus * sizeof(zx_cpu_t));
    for (int i = 0;i < stat->ncpus; i++) {
        snprintf(stat->cpus_stat[i].name, IDENTIFIER_LENGTH, "%s", newt[i].name);

#ifdef AIX_VERSION_7X

        stat->cpus_stat[i].user_pct = util[i].user_pct;
        stat->cpus_stat[i].sys_pct = util[i].kern_pct;
        stat->cpus_stat[i].idle_pct = util[i].idle_pct;
        stat->cpus_stat[i].wait_pct = util[i].wait_pct;
#else
        // todo 暂只计算整体使用率
        stat->cpus_stat[i].user_pct = 0;
        stat->cpus_stat[i].sys_pct = 0;
        stat->cpus_stat[i].idle_pct = 0;
        stat->cpus_stat[i].wait_pct = 0;
#endif
        stat->cpus_stat[i].pswitch = newt[i].pswitch;
        stat->cpus_stat[i].syscall = newt[i].syscall;
        stat->cpus_stat[i].sysread = newt[i].sysread;
        stat->cpus_stat[i].syswrite = newt[i].syswrite;
        stat->cpus_stat[i].sysfork = newt[i].sysfork;
        stat->cpus_stat[i].sysexec = newt[i].sysexec;
    }

    zx_free(oldt);
    zx_free(newt);

#ifdef AIX_VERSION_7X

    zx_free(util);

#endif

    return stat;
}

void zx_cpu_stat_destroy(zx_cpu_stat_t *stat) {
    if (stat != NULL) {
        if (stat->cpus_stat != NULL) {
            zx_free(stat->cpus_stat);
        }
        zx_free(stat);
    }
}