#ifndef __THREAD_JOB_H__
#define __THREAD_JOB_H__

#include "tcp_packet.h"
#include "tcp_client.h"

typedef struct thread_job *thread_job_ptr;

thread_job_ptr thread_job_new(tcp_client_ptr client, tcp_packet_ptr packet, tcp_packet_d4m_ptr d4m);

void thread_job_free(thread_job_ptr job);

tcp_client_ptr thread_job_client(thread_job_ptr job);

tcp_packet_ptr thread_job_packet(thread_job_ptr job);

tcp_packet_d4m_ptr thread_job_d4m(thread_job_ptr job);

#endif