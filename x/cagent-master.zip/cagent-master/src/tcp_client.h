#ifndef __TCP_CLIENT_H__
#define __TCP_CLIENT_H__

#include <stdio.h>
#include <netinet/in.h>
#include <pthread.h>

#include "../libs/C-Snip/queue.h"
#include "../libs/C-Snip/buf.h"

typedef struct tcp_client* tcp_client_ptr;

// 创建客户端，失败返回-1
tcp_client_ptr tcp_client_new(const char *host, int port);

// 客户端开始工作
void tcp_client_run(tcp_client_ptr c);

// 主动停止客户端工作线程
void tcp_client_stop(tcp_client_ptr c);

// 阻塞等待客户端线程结束
void tcp_client_wait(tcp_client_ptr c);

// 释放客户端资源
void tcp_client_free(tcp_client_ptr c);

// ping检测
void tcp_client_ping(tcp_client_ptr c);

// pong处理(重置ping计数)
void tcp_client_pong(tcp_client_ptr c);

// 发送队列
void tcp_client_sendmq_push(tcp_client_ptr c, struct buf *bf);
void tcp_client_sendmq_pop(tcp_client_ptr c, struct buf *bf);

// 接收队列
void tcp_client_recvmq_push(tcp_client_ptr c, struct buf *bf);
void tcp_client_recvmq_pop(tcp_client_ptr c, struct buf *bf);

int tcp_client_running(tcp_client_ptr c);
int tcp_client_connected(tcp_client_ptr c);

#endif