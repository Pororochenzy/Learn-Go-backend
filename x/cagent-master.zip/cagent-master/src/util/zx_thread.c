#include "zx_thread.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>

#include "zx_common.h"

/* 0 - no timeout occurred, 1 - SIGALRM took place */
static volatile int	zx_timed_out;

static void zx_alarm_flag_set() {
    zx_timed_out = 1;
}

static void zx_alarm_flag_clear() {
    zx_timed_out = 0;
}

unsigned int zx_alarm_on(unsigned int seconds) {
    zx_alarm_flag_clear();
	return alarm(seconds);
}

unsigned int zx_alarm_off() {
    unsigned int ret = alarm(0);
	zx_alarm_flag_clear();
	return ret;
}

int	zx_alarm_timed_out() {
    return (0 == zx_timed_out ? -1 : 0);
}

/******************************************************************************
 *                                                                            *
 * Function: zx_fork                                                          *
 *                                                                            *
 * Purpose: Flush stdout and stderr before forking                            *
 *                                                                            *
 * Return value: same as system fork() function                               *
 *                                                                            *
 ******************************************************************************/
int	zx_fork() {
	fflush(stdout);
	fflush(stderr);
	return fork();
}

/******************************************************************************
 *                                                                            *
 * Function: zx_child_fork                                                    *
 *                                                                            *
 * Purpose: fork from master process and set SIGCHLD handler                  *
 *                                                                            *
 * Return value: same as system fork() function                               *
 *                                                                            *
 * Comments: use this function only for forks from the main process           *
 *                                                                            *
 ******************************************************************************/
void zx_child_fork(pid_t *pid) {
	sigset_t mask, orig_mask;

	/* block SIGTERM, SIGINT and SIGCHLD during fork to avoid deadlock (we've seen one in __unregister_atfork()) */
	sigemptyset(&mask);
	sigaddset(&mask, SIGTERM);
	sigaddset(&mask, SIGINT);
	sigaddset(&mask, SIGCHLD);
	sigprocmask(SIG_BLOCK, &mask, &orig_mask);

	/* set process id instead of returning, this is to avoid race condition when signal arrives before return */
	*pid = zx_fork();

	sigprocmask(SIG_SETMASK, &orig_mask, NULL);

	/* ignore SIGCHLD to avoid problems with exiting scripts in zx_execute() and other cases */
	if (0 == *pid) {
		signal(SIGCHLD, SIG_DFL);
    }
}

/******************************************************************************
 *                                                                            *
 * Function: zx_thread_start                                                  *
 *                                                                            *
 * Purpose: Start the handled function as "thread"                            *
 *                                                                            *
 * Parameters: thread_handler - [IN] new thread starts execution from this    *
 *                                handler function                            *
 *             thread_args - [IN] arguments for thread function               *
 *             pid         - [OUT] handle to a newly created thread           *
 *                                                                            *
 * Comments: The zx_thread_exit must be called from the handler!              *
 *                                                                            *
 ******************************************************************************/
void zx_thread_start(zx_thread_handler_t thread_handler, void *thread_args, pid_t *pid) {

	zx_child_fork(pid);

    /* child process */
	if (0 == *pid) {
		(*thread_handler)(thread_args);

		/* The zx_thread_exit must be called from the handler. */
		/* And in normal case the program will never reach this point. */
		THIS_SHOULD_NEVER_HAPPEN;
		/* program will never reach this point */
	} else if (-1 == *pid) {
		printf("failed to fork: %s\n", strerror(errno));
		*pid = (pid_t)(-1);
	}
}

/******************************************************************************
 *                                                                            *
 * Function: zx_thread_wait                                                   *
 *                                                                            *
 * Purpose: Waits until the "thread" is in the signalled state                *
 *                                                                            *
 * Parameters: "thread" handle                                                *
 *                                                                            *
 * Return value: process or thread exit code                                  *
 *                                                                            *
 ******************************************************************************/
int	zx_thread_wait(pid_t pid) {

	int	status = 0;	/* significant 8 bits of the status */

	if (0 >= waitpid(pid, &status, 0)) {
		printf("Error waiting for process with PID %d: %s\n", (int)pid, strerror(errno));
		return -1;
	}

	status = WEXITSTATUS(status);
	return status;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_threads_wait                                                  *
 *                                                                            *
 * Purpose: Waits until the "threads" are in the signalled state              *
 *                                                                            *
 * Parameters: "threads" handles                                              *
 *                                                                            *
 ******************************************************************************/
void zx_threads_wait(pid_t *pids, int pids_num) {
	int		i;
	sigset_t	set;

	/* ignore SIGCHLD signals in order for zx_sleep() to work */
	sigemptyset(&set);
	sigaddset(&set, SIGCHLD);
	sigprocmask(SIG_BLOCK, &set, NULL);

	for (i = 0; i < pids_num; i++) {
		if (pids[i]) {
            zx_thread_kill(pids[i]);
        }
	}

	for (i = 0; i < pids_num; i++) {
		if (pids[i]) {
			zx_thread_wait(pids[i]);
        }
		pids[i] = 0;
	}
}

/* Calling _exit() to terminate child process immediately is important. */
void zx_thread_exit(int status) {
    _exit(status);
}

long int zx_thread_pid() {
	return (long int)getpid();
}

void zx_thread_kill(pid_t pid) {
	kill(pid, SIGTERM);
}