#ifndef __ZX_MD5_H__
#define __ZX_MD5_H__

#define ZX_MD5_STR_LEN 32

int zx_md5_string(unsigned char *s, unsigned int len, char *md5);

int zx_md5_file(const char *filepath, char *md5);

#endif