#ifndef __ZX_CONFIG_H__
#define __ZX_CONFIG_H__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

typedef struct zx_cfg_pair_t {
	char *key;
	char *value;
	struct zx_cfg_pair_t *next;
} zx_cfg_pair_t;

typedef struct zx_cfg_section_t {
	char *name;
	struct zx_cfg_pair_t *pairs;
	struct zx_cfg_section_t *next;
} zx_cfg_section_t;

typedef struct zx_cfg_file_t {
	char *name;
	struct zx_cfg_section_t *sections;
} zx_cfg_file_t;


zx_cfg_file_t *zx_cfg_open(const char *path);

zx_cfg_section_t *zx_cfg_find_section(zx_cfg_file_t *file, char *name);

zx_cfg_pair_t *zx_cfg_find_pair(zx_cfg_section_t *section, char *key);

char *zx_cfg_find_value(zx_cfg_section_t *section, char *key);

int zx_cfg_check_pair(zx_cfg_section_t *section, char *key, char *value);

void zx_cfg_close(zx_cfg_file_t **file);

#endif