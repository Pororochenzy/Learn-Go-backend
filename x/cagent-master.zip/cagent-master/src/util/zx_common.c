#include "zx_common.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <fcntl.h>
#include <ctype.h>
#include <unistd.h>
#include <errno.h>

/******************************************************************************
 *                                                                            *
 * Function: zx_error                                                         *
 *                                                                            *
 * Purpose: Print error text to the stderr                                    *
 *                                                                            *
 * Parameters: fmt - format of message                                        *
 *                                                                            *
 * Return value:                                                              *
 *                                                                            *
 ******************************************************************************/
void zx_error(const char *fmt, ...)
{
	va_list	args;

	va_start(args, fmt);

	fprintf(stderr, "cagent [%li]: ", (long int)getpid());
	vfprintf(stderr, fmt, args);
	fprintf(stderr, "\n");
	fflush(stderr);

	va_end(args);
}

/******************************************************************************
 *                                                                            *
 * Function: zx_calloc2                                                       *
 *                                                                            *
 * Purpose: allocates nmemb * size bytes of memory and fills it with zeros    *
 *                                                                            *
 * Return value: returns a pointer to the newly allocated memory              *
 *                                                                            *
 ******************************************************************************/

void *zx_calloc2(const char *filename, int line, void *old, size_t nmemb, size_t size) {
	int	max_attempts;
	void *ptr = NULL;

	/* old pointer must be NULL */
	if (NULL != old) {
		printf("[file:%s,line:%d] zx_calloc: allocating already allocated memory. "
				"Please report this to developers.\n", filename, line);
	}

	for (
		max_attempts = 10, nmemb = MAX(nmemb, 1), size = MAX(size, 1);
		0 < max_attempts && NULL == ptr;
		ptr = calloc(nmemb, size), max_attempts--
	);

	if (NULL != ptr) {
		return ptr;
  }

	printf("[file:%s,line:%d] zx_calloc: out of memory. Requested %zu bytes.\n", filename, line, size);
	exit(EXIT_FAILURE);
}

/******************************************************************************
 *                                                                            *
 * Function: zx_malloc2                                                       *
 *                                                                            *
 * Purpose: allocates size bytes of memory                                    *
 *                                                                            *
 * Return value: returns a pointer to the newly allocated memory              *
 *                                                                            *
 ******************************************************************************/
void *zx_malloc2(const char *filename, int line, void *old, size_t size) {
	int	max_attempts;
	void *ptr = NULL;

	/* old pointer must be NULL */
	if (NULL != old) {
		printf("[file:%s,line:%d] zx_malloc: allocating already allocated memory. "
				"Please report this to developers.\n", filename, line);
	}

	for (
		max_attempts = 10, size = MAX(size, 1);
		0 < max_attempts && NULL == ptr;
		ptr = malloc(size), max_attempts--
	);

	if (NULL != ptr) {
		return ptr;
  	}

	printf("[file:%s,line:%d] zx_malloc: out of memory. Requested %zu bytes.\n", filename, line, size);
	exit(EXIT_FAILURE);
}

/******************************************************************************
 *                                                                            *
 * Function: zx_realloc2                                                      *
 *                                                                            *
 * Purpose: changes the size of the memory block pointed to by old            *
 *          to size bytes                                                     *
 *                                                                            *
 * Return value: returns a pointer to the newly allocated memory              *
 *                                                                            *
 ******************************************************************************/
void *zx_realloc2(const char *filename, int line, void *old, size_t size) {
	int	max_attempts;
	void *ptr = NULL;

	for (
		max_attempts = 10, size = MAX(size, 1);
		0 < max_attempts && NULL == ptr;
		ptr = realloc(old, size), max_attempts--
	);

	if (NULL != ptr) {
		return ptr;
	}

	printf("[file:%s,line:%d] zx_realloc: out of memory. Requested %zu bytes.\n", filename, line, size);
	exit(EXIT_FAILURE);
}

char *zx_strdup2(const char *filename, int line, char *old, const char *str) {
	int	retry;
	char *ptr = NULL;

	zx_free(old);

	for (retry = 10; 0 < retry && NULL == ptr; ptr = strdup(str), retry--) ;

	if (NULL != ptr) {
		return ptr;
  }

	printf("[file:%s,line:%d] zx_strdup: out of memory. Requested %zu bytes.\n", filename, line, strlen(str) + 1);
	exit(EXIT_FAILURE);
}

/******************************************************************************
 *                                                                            *
 * Function: zx_snprintf                                                      *
 *                                                                            *
 * Purpose: Secure version of snprintf function.                              *
 *          Add zero character at the end of string.                          *
 *                                                                            *
 * Parameters: str - destination buffer pointer                               *
 *             count - size of destination buffer                             *
 *             fmt - format                                                   *
 *                                                                            *
 * Return value:                                                              *
 *                                                                            *
 ******************************************************************************/
size_t	zx_snprintf(char *str, size_t count, const char *fmt, ...) {

	size_t	written_len;
	va_list	args;

	va_start(args, fmt);
	written_len = zx_vsnprintf(str, count, fmt, args);
	va_end(args);

	return written_len;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_snprintf_alloc                                                *
 *                                                                            *
 * Purpose: Secure version of snprintf function.                              *
 *          Add zero character at the end of string.                          *
 *          Reallocs memory if not enough.                                    *
 *                                                                            *
 * Parameters: str       - [IN/OUT] destination buffer pointer                *
 *             alloc_len - [IN/OUT] already allocated memory                  *
 *             offset    - [IN/OUT] offset for writing                        *
 *             fmt       - [IN] format                                        *
 *                                                                            *
 * Return value:                                                              *
 *                                                                            *
 ******************************************************************************/
void	zx_snprintf_alloc(char **str, size_t *alloc_len, size_t *offset, const char *fmt, ...) {

	va_list	args;
	size_t	avail_len, written_len;

retry:
	if (NULL == *str) {
		/* zx_vsnprintf() returns bytes actually written instead of bytes to write, */
		/* so we have to use the standard function                                  */
		va_start(args, fmt);
		*alloc_len = vsnprintf(NULL, 0, fmt, args) + 2;	/* '\0' + one byte to prevent the operation retry */
		va_end(args);
		*offset = 0;
		*str = (char *)zx_malloc(*str, *alloc_len);
	}

	avail_len = *alloc_len - *offset;
	va_start(args, fmt);
	written_len = zx_vsnprintf(*str + *offset, avail_len, fmt, args);
	va_end(args);

	if (written_len == avail_len - 1) {
		*alloc_len *= 2;
		*str = (char *)zx_realloc(*str, *alloc_len);

		goto retry;
	}

	*offset += written_len;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_vsnprintf                                                     *
 *                                                                            *
 * Purpose: Secure version of vsnprintf function.                             *
 *          Add zero character at the end of string.                          *
 *                                                                            *
 * Parameters: str   - [IN/OUT] destination buffer pointer                    *
 *             count - [IN] size of destination buffer                        *
 *             fmt   - [IN] format                                            *
 *                                                                            *
 * Return value: the number of characters in the output buffer                *
 *               (not including the trailing '\0')                            *
 *                                                                            *
 ******************************************************************************/
size_t	zx_vsnprintf(char *str, size_t count, const char *fmt, va_list args) {
	int	written_len = 0;

	if (0 < count) {
		if (0 > (written_len = vsnprintf(str, count, fmt, args))) {
			written_len = (int)count - 1;		/* count an output error as a full buffer */
		} else {
			written_len = MIN(written_len, (int)count - 1);		/* result could be truncated */
		}
	}
	str[written_len] = '\0';	/* always write '\0', even if buffer size is 0 or vsnprintf() error */

	return (size_t)written_len;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_strncpy_alloc, zx_strcpy_alloc, zx_chrcpy_alloc               *
 *                                                                            *
 * Purpose: If there is no '\0' byte among the first n bytes of src,          *
 *          then all n bytes will be placed into the dest buffer.             *
 *          In other case only strlen() bytes will be placed there.           *
 *          Add zero character at the end of string.                          *
 *          Reallocs memory if not enough.                                    *
 *                                                                            *
 * Parameters: str       - [IN/OUT] destination buffer pointer                *
 *             alloc_len - [IN/OUT] already allocated memory                  *
 *             offset    - [IN/OUT] offset for writing                        *
 *             src       - [IN] copied string                                 *
 *             n         - [IN] maximum number of bytes to copy               *
 *                                                                            *
 ******************************************************************************/
void zx_strncpy_alloc(char **str, size_t *alloc_len, size_t *offset, const char *src, size_t n) {

	if (NULL == *str) {

		*alloc_len = n + 1;
		*offset = 0;
		*str = (char *)zx_malloc(*str, *alloc_len);

	} else if (*offset + n >= *alloc_len) {

		while (*offset + n >= *alloc_len) {
			*alloc_len *= 2;
		}

		*str = (char *)zx_realloc(*str, *alloc_len);

	}

	while (0 != n && '\0' != *src) {
		(*str)[(*offset)++] = *src++;
		n--;
	}

	(*str)[*offset] = '\0';
}

void zx_strcpy_alloc(char **str, size_t *alloc_len, size_t *offset, const char *src) {
	zx_strncpy_alloc(str, alloc_len, offset, src, strlen(src));
}

void zx_chrcpy_alloc(char **str, size_t *alloc_len, size_t *offset, char c) {
	zx_strncpy_alloc(str, alloc_len, offset, &c, 1);
}

void zx_str_memcpy_alloc(char **str, size_t *alloc_len, size_t *offset, const char *src, size_t n) {
	if (NULL == *str) {

		*alloc_len = n + 1;
		*offset = 0;
		*str = (char *)zx_malloc(*str, *alloc_len);

	} else if (*offset + n >= *alloc_len) {

		while (*offset + n >= *alloc_len) {
			*alloc_len *= 2;
		}
	
		*str = (char *)zx_realloc(*str, *alloc_len);

	}

	memcpy(*str + *offset, src, n);
	*offset += n;
	(*str)[*offset] = '\0';
}

/******************************************************************************
 *                                                                            *
 * Function: zx_strlcpy                                                       *
 *                                                                            *
 * Purpose: Copy src to string dst of size siz. At most siz - 1 characters    *
 *          will be copied. Always null terminates (unless siz == 0).         *
 *                                                                            *
 * Return value: the number of characters copied (excluding the null byte)    *
 *                                                                            *
 ******************************************************************************/
size_t zx_strlcpy(char *dst, const char *src, size_t siz) {
	const char	*s = src;

	if (0 != siz) {
		while (0 != --siz && '\0' != *s) {
			*dst++ = *s++;
		}

		*dst = '\0';
	}

	return s - src;	/* count does not include null */
}

/******************************************************************************
 *                                                                            *
 * Function: zx_strlcat                                                      *
 *                                                                            *
 * Purpose: Appends src to string dst of size siz (unlike strncat, size is    *
 *          the full size of dst, not space left). At most siz - 1 characters *
 *          will be copied. Always null terminates (unless                    *
 *          siz <= strlen(dst)).                                              *
 *                                                                            *
 ******************************************************************************/
void zx_strlcat(char *dst, const char *src, size_t siz) {
	while ('\0' != *dst) {
		dst++;
		siz--;
	}
	zx_strlcpy(dst, src, siz);
}

/******************************************************************************
 *                                                                            *
 * Function: zx_strlcpy_utf8                                                  *
 *                                                                            *
 * Purpose: copies utf-8 string + terminating zero character into specified   *
 *          buffer                                                            *
 *                                                                            *
 * Return value: the number of copied bytes excluding terminating zero        *
 *               character.                                                   *
 *                                                                            *
 * Comments: If the source string is larger than destination buffer then the  *
 *           string is truncated after last valid utf-8 character rather than *
 *           byte.                                                            *
 *                                                                            *
 ******************************************************************************/
size_t	zx_strlcpy_utf8(char *dst, const char *src, size_t size) {
	size = zx_strlen_utf8_nbytes(src, size - 1);
	memcpy(dst, src, size);
	dst[size] = '\0';

	return size;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_dvsprintf                                                     *
 *                                                                            *
 * Purpose: dynamical formatted output conversion                             *
 *                                                                            *
 * Return value: formatted string                                             *
 *                                                                            *
 * Comments: returns a pointer to allocated memory                            *
 *                                                                            *
 ******************************************************************************/
char	*zx_dvsprintf(char *dest, const char *f, va_list args) {
	char	*string = NULL;
	int	n, size = MAX_STRING_LEN >> 1;

	va_list curr;

	while (1) {
		string = (char *)zx_malloc(string, size);

		va_copy(curr, args);
		n = vsnprintf(string, size, f, curr);
		va_end(curr);

		if (0 <= n && n < size)
			break;

		/* result was truncated */
		if (-1 == n) {
			size = size * 3 / 2 + 1;	/* the length is unknown */
		} else {
			size = n + 1;	/* n bytes + trailing '\0' */
		}

		zx_free(string);
	}

	zx_free(dest);
	return string;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_dsprintf                                                      *
 *                                                                            *
 * Purpose: dynamical formatted output conversion                             *
 *                                                                            *
 * Return value: formatted string                                             *
 *                                                                            *
 * Comments: returns a pointer to allocated memory                            *
 *                                                                            *
 ******************************************************************************/
char *zx_dsprintf(char *dest, const char *f, ...) {
	char	*string;
	va_list args;

	va_start(args, f);
	string = zx_dvsprintf(dest, f, args);
	va_end(args);

	return string;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_strdcat                                                       *
 *                                                                            *
 * Purpose: dynamical cating of strings                                       *
 *                                                                            *
 * Return value: new pointer of string                                        *
 *                                                                            *
 * Comments: returns a pointer to allocated memory                            *
 *           zx_strdcat(NULL, "") will return "", not NULL!                   *
 *                                                                            *
 ******************************************************************************/
char *zx_strdcat(char *dest, const char *src) {
	size_t	len_dest, len_src;

	if (NULL == src)
		return dest;

	if (NULL == dest)
		return zx_strdup(NULL, src);

	len_dest = strlen(dest);
	len_src = strlen(src);

	dest = (char *)zx_realloc(dest, len_dest + len_src + 1);
	zx_strlcpy(dest + len_dest, src, len_src + 1);
	return dest;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_strdcatf                                                      *
 *                                                                            *
 * Purpose: dynamical cating of formated strings                              *
 *                                                                            *
 * Return value: new pointer of string                                        *
 *                                                                            *
 * Comments: returns a pointer to allocated memory                            *
 *                                                                            *
 ******************************************************************************/
char *zx_strdcatf(char *dest, const char *f, ...) {
	char	*string, *result;
	va_list	args;

	va_start(args, f);
	string = zx_dvsprintf(NULL, f, args);
	va_end(args);

	result = zx_strdcat(dest, string);

	zx_free(string);
	return result;
}


/* Has to be rewritten to avoid malloc */
char *zx_string_replace(const char *str, const char *sub_str1, const char *sub_str2) {
	char *new_str = NULL;
	const char *p;
	const char *q;
	const char *r;
	char *t;
	long len;
	long diff;
	unsigned long count = 0;

	assert(str);
	assert(sub_str1);
	assert(sub_str2);

	len = (long)strlen(sub_str1);

	/* count the number of occurrences of sub_str1 */
	for ( p=str; (p = strstr(p, sub_str1)); p+=len, count++ );

	if (0 == count) {
		return zx_strdup(NULL, str);
	}

	diff = (long)strlen(sub_str2) - len;

  /* allocate new memory */
	new_str = (char *)zx_malloc(new_str, (size_t)(strlen(str) + count*diff + 1)*sizeof(char));

	for (q=str,t=new_str,p=str; (p = strstr(p, sub_str1)); ) {
		/* copy until next occurrence of sub_str1 */
		for ( ; q < p; *t++ = *q++);
	
		q += len;
		p = q;

		for ( r = sub_str2; (*t++ = *r++); );

		--t;
	}
	/* copy the tail of str */
	for( ; *q ; *t++ = *q++ );

	*t = '\0';
	return new_str;
}

void zx_strlower(char *str) {
	for (; '\0' != *str; str++) {
		*str = tolower(*str);
	}
}

void zx_strupper(char *str) {
	for (; '\0' != *str; str++) {
		*str = toupper(*str);
	}
}

/******************************************************************************
 *                                                                            *
 * Function: zx_rtrim                                                         *
 *                                                                            *
 * Purpose: Strip characters from the end of a string                         *
 *                                                                            *
 * Parameters: str - string for processing                                    *
 *             charlist - null terminated list of characters                  *
 *                                                                            *
 * Return value: number of trimmed characters                                 *
 *                                                                            *
 ******************************************************************************/
int	zx_rtrim(char *str, const char *charlist) {
	char	*p;
	int	count = 0;

	if (NULL == str || '\0' == *str)
		return count;

	for (p = str + strlen(str) - 1; p >= str && NULL != strchr(charlist, *p); p--) {
		*p = '\0';
		count++;
	}

	return count;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_ltrim                                                         *
 *                                                                            *
 * Purpose: Strip characters from the beginning of a string                   *
 *                                                                            *
 * Parameters: str - string for processing                                    *
 *             charlist - null terminated list of characters                  *
 *                                                                            *
 * Return value:                                                              *
 *                                                                            *
 ******************************************************************************/
void zx_ltrim(char *str, const char *charlist) {
	char	*p;

	if (NULL == str || '\0' == *str)
		return;

	for (p = str; '\0' != *p && NULL != strchr(charlist, *p); p++) ;

	if (p == str)
		return;

	while ('\0' != *p) {
		*str++ = *p++;
	}

	*str = '\0';
}

/******************************************************************************
 *                                                                            *
 * Function: zx_lrtrim                                                        *
 *                                                                            *
 * Purpose: Removes leading and trailing characters from the specified        *
 *          character string                                                  *
 *                                                                            *
 * Parameters: str      - [IN/OUT] string for processing                      *
 *             charlist - [IN] null terminated list of characters             *
 *                                                                            *
 ******************************************************************************/
void zx_lrtrim(char *str, const char *charlist) {
	zx_rtrim(str, charlist);
	zx_ltrim(str, charlist);
}

/******************************************************************************
 *                                                                            *
 * Function: zx_remove_chars                                                  *
 *                                                                            *
 * Purpose: Remove characters 'charlist' from the whole string                *
 *                                                                            *
 * Parameters: str - string for processing                                    *
 *             charlist - null terminated list of characters                  *
 *                                                                            *
 * Return value:                                                              *
 *                                                                            *
 ******************************************************************************/
void zx_remove_chars(char *str, const char *charlist) {
	char *p;

	if (NULL == str || NULL == charlist || '\0' == *str || '\0' == *charlist)
		return;

	for (p = str; '\0' != *p; p++) {
		if (NULL == strchr(charlist, *p)) {
			*str++ = *p;
		}
	}

	*str = '\0';
}

size_t zx_strlen_utf8(const char *text) {
	size_t	n = 0;
	while ('\0' != *text) {
		if (0x80 != (0xc0 & *text++)) {
			n++;
		}
	}
	return n;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_utf8_char_len                                                 *
 *                                                                            *
 * Purpose: Returns the size (in bytes) of an UTF-8 encoded character or 0    *
 *          if the character is not a valid UTF-8.                            *
 *                                                                            *
 * Parameters: text - [IN] pointer to the 1st byte of UTF-8 character         *
 *                                                                            *
 ******************************************************************************/
size_t zx_utf8_char_len(const char *text) {
	if (0 == (*text & 0x80)) {
		/* ASCII */
		return 1;
	} else if (0xc0 == (*text & 0xe0)) {
		/* 11000010-11011111 starts a 2-byte sequence */
		return 2;
	} else if (0xe0 == (*text & 0xf0)) {
		/* 11100000-11101111 starts a 3-byte sequence */
		return 3;
	}	else if (0xf0 == (*text & 0xf8)) {
		/* 11110000-11110100 starts a 4-byte sequence */
		return 4;
	}
	/* not a valid UTF-8 character */
	return 0;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_strlen_utf8_nchars                                            *
 *                                                                            *
 * Purpose: calculates number of bytes in utf8 text limited by utf8_maxlen    *
 *          characters                                                        *
 *                                                                            *
 ******************************************************************************/
size_t zx_strlen_utf8_nchars(const char *text, size_t utf8_maxlen) {
	size_t	sz = 0, csz = 0;
	const char	*next;

	while ('\0' != *text && 0 < utf8_maxlen && 0 != (csz = zx_utf8_char_len(text))) {
		next = text + csz;
		while (next > text) {
			if ('\0' == *text++) {
				return sz;
			}
		}
		sz += csz;
		utf8_maxlen--;
	}

	return sz;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_strlen_utf8_nbytes                                            *
 *                                                                            *
 * Purpose: calculates number of bytes in utf8 text limited by maxlen bytes   *
 *                                                                            *
 ******************************************************************************/
size_t zx_strlen_utf8_nbytes(const char *text, size_t maxlen) {
	size_t	sz;
	sz = strlen(text);
	if (sz > maxlen) {
		sz = maxlen;

		/* ensure that the string is not cut in the middle of UTF-8 sequence */
		while (0x80 == (0xc0 & text[sz]) && 0 < sz) {
			sz--;
		}
	}
	return sz;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_replace_utf8                                                  *
 *                                                                            *
 * Purpose: replace non-ASCII UTF-8 characters with '?' character             *
 *                                                                            *
 * Parameters: text - [IN] pointer to the first char                          *
 *                                                                            *
 ******************************************************************************/
char *zx_replace_utf8(const char *text) {
	int	n;
	char	*out, *p;
	out = p = (char *)zx_malloc(NULL, strlen(text) + 1);

	while ('\0' != *text) {
		if (0 == (*text & 0x80)) {
			/* ASCII */
			n = 1;
		} else if (0xc0 == (*text & 0xe0)) {
			/* 11000010-11011111 is a start of 2-byte sequence */
			n = 2;
		} else if (0xe0 == (*text & 0xf0)) {
			/* 11100000-11101111 is a start of 3-byte sequence */
			n = 3;
		} else if (0xf0 == (*text & 0xf8)) {
			/* 11110000-11110100 is a start of 4-byte sequence */
			n = 4;
		} else {
			goto bad;
		}

		if (1 == n) {
			*p++ = *text++;
		} else {
			*p++ = ZX_UTF8_REPLACE_CHAR;

			while (0 != n) {
				if ('\0' == *text) {
					goto bad;
				}
				n--;
				text++;
			}
		}
	}

	*p = '\0';
	return out;

bad:
	zx_free(out);
	return NULL;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_is_utf8                                                       *
 *                                                                            *
 * Purpose: check UTF-8 sequences                                             *
 *                                                                            *
 * Parameters: text - [IN] pointer to the string                              *
 *                                                                            *
 * Return value: SUCCEED if string is valid or FAIL otherwise                 *
 *                                                                            *
 ******************************************************************************/
int	zx_is_utf8(const char *text) {
	unsigned int	utf32;
	unsigned char	*utf8;
	size_t	i, mb_len, expecting_bytes = 0;

	while ('\0' != *text) {
		/* single ASCII character */
		if (0 == (*text & 0x80)) {
			text++;
			continue;
		}

		/* unexpected continuation byte or invalid UTF-8 bytes '\xfe' & '\xff' */
		if (0x80 == (*text & 0xc0) || 0xfe == (*text & 0xfe)) {
			return FAIL;
		}

		/* multibyte sequence */

		utf8 = (unsigned char *)text;

		if (0xc0 == (*text & 0xe0))		/* 2-bytes multibyte sequence */
			expecting_bytes = 1;
		else if (0xe0 == (*text & 0xf0))	/* 3-bytes multibyte sequence */
			expecting_bytes = 2;
		else if (0xf0 == (*text & 0xf8))	/* 4-bytes multibyte sequence */
			expecting_bytes = 3;
		else if (0xf8 == (*text & 0xfc))	/* 5-bytes multibyte sequence */
			expecting_bytes = 4;
		else if (0xfc == (*text & 0xfe))	/* 6-bytes multibyte sequence */
			expecting_bytes = 5;

		mb_len = expecting_bytes + 1;
		text++;

		for (; 0 != expecting_bytes; expecting_bytes--) {
			/* not a continuation byte */
			if (0x80 != (*text++ & 0xc0)) {
				return FAIL;
			}
		}

		/* overlong sequence */
		if (0xc0 == (utf8[0] & 0xfe) ||
				(0xe0 == utf8[0] && 0x00 == (utf8[1] & 0x20)) ||
				(0xf0 == utf8[0] && 0x00 == (utf8[1] & 0x30)) ||
				(0xf8 == utf8[0] && 0x00 == (utf8[1] & 0x38)) ||
				(0xfc == utf8[0] && 0x00 == (utf8[1] & 0x3c))) {
			return FAIL;
		}

		utf32 = 0;

		if (0xc0 == (utf8[0] & 0xe0))
			utf32 = utf8[0] & 0x1f;
		else if (0xe0 == (utf8[0] & 0xf0))
			utf32 = utf8[0] & 0x0f;
		else if (0xf0 == (utf8[0] & 0xf8))
			utf32 = utf8[0] & 0x07;
		else if (0xf8 == (utf8[0] & 0xfc))
			utf32 = utf8[0] & 0x03;
		else if (0xfc == (utf8[0] & 0xfe))
			utf32 = utf8[0] & 0x01;

		for (i = 1; i < mb_len; i++) {
			utf32 <<= 6;
			utf32 += utf8[i] & 0x3f;
		}

		/* according to the Unicode standard the high and low
		 * surrogate halves used by UTF-16 (U+D800 through U+DFFF)
		 * and values above U+10FFFF are not legal
		 */
		if (utf32 > 0x10ffff || 0xd800 == (utf32 & 0xf800)) {
			return FAIL;
		}
	}

	return SUCCEED;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_replace_invalid_utf8                                          *
 *                                                                            *
 * Purpose: replace invalid UTF-8 sequences of bytes with '?' character       *
 *                                                                            *
 * Parameters: text - [IN/OUT] pointer to the first char                      *
 *                                                                            *
 ******************************************************************************/
void zx_replace_invalid_utf8(char *text) {
	char *out = text;
	while ('\0' != *text) {
		if (0 == (*text & 0x80)) {
			/* single ASCII character */
			*out++ = *text++;
		} else if (0x80 == (*text & 0xc0) ||		/* unexpected continuation byte */
				0xfe == (*text & 0xfe))		/* invalid UTF-8 bytes '\xfe' & '\xff' */
		{
			*out++ = ZX_UTF8_REPLACE_CHAR;
			text++;
		} else {
			/* multibyte sequence */
			unsigned int	utf32;
			unsigned char	*utf8 = (unsigned char *)out;
			size_t i, mb_len, expecting_bytes = 0;
			int ret = SUCCEED;

			if (0xc0 == (*text & 0xe0))		/* 2-bytes multibyte sequence */
				expecting_bytes = 1;
			else if (0xe0 == (*text & 0xf0))	/* 3-bytes multibyte sequence */
				expecting_bytes = 2;
			else if (0xf0 == (*text & 0xf8))	/* 4-bytes multibyte sequence */
				expecting_bytes = 3;
			else if (0xf8 == (*text & 0xfc))	/* 5-bytes multibyte sequence */
				expecting_bytes = 4;
			else if (0xfc == (*text & 0xfe))	/* 6-bytes multibyte sequence */
				expecting_bytes = 5;

			*out++ = *text++;

			for (; 0 != expecting_bytes; expecting_bytes--) {
				/* not a continuation byte */ 
				if (0x80 != (*text & 0xc0))	{
					ret = FAIL;
					break;
				}

				*out++ = *text++;
			}

			mb_len = out - (char *)utf8;

			if (SUCCEED == ret) {
				if (0xc0 == (utf8[0] & 0xfe) ||	/* overlong sequence */
						(0xe0 == utf8[0] && 0x00 == (utf8[1] & 0x20)) ||
						(0xf0 == utf8[0] && 0x00 == (utf8[1] & 0x30)) ||
						(0xf8 == utf8[0] && 0x00 == (utf8[1] & 0x38)) ||
						(0xfc == utf8[0] && 0x00 == (utf8[1] & 0x3c))) {
					ret = FAIL;
				}
			}

			if (SUCCEED == ret) {
				utf32 = 0;

				if (0xc0 == (utf8[0] & 0xe0))
					utf32 = utf8[0] & 0x1f;
				else if (0xe0 == (utf8[0] & 0xf0))
					utf32 = utf8[0] & 0x0f;
				else if (0xf0 == (utf8[0] & 0xf8))
					utf32 = utf8[0] & 0x07;
				else if (0xf8 == (utf8[0] & 0xfc))
					utf32 = utf8[0] & 0x03;
				else if (0xfc == (utf8[0] & 0xfe))
					utf32 = utf8[0] & 0x01;

				for (i = 1; i < mb_len; i++) {
					utf32 <<= 6;
					utf32 += utf8[i] & 0x3f;
				}

				/* according to the Unicode standard the high and low
				 * surrogate halves used by UTF-16 (U+D800 through U+DFFF)
				 * and values above U+10FFFF are not legal
				 */
				if (utf32 > 0x10ffff || 0xd800 == (utf32 & 0xf800)) {
					ret = FAIL;
				}
			}

			if (SUCCEED != ret) {
				out -= mb_len;
				*out++ = ZX_UTF8_REPLACE_CHAR;
			}
		}
	}

	*out = '\0';
}

void zx_redirect_stdio(const char *filename) {
	int fd;
	const char default_file[] = "/dev/null";
	int open_flags = O_WRONLY;

	if (NULL != filename && '\0' != *filename) {
		open_flags |= O_CREAT | O_APPEND;
	} else {
		filename = default_file;
	}

	if (-1 == (fd = open(filename, open_flags, 0666))) {
		zx_error("cannot open \"%s\": %s", filename, strerror(errno));
		exit(EXIT_FAILURE);
	}

	fflush(stdout);
	if (-1 == dup2(fd, STDOUT_FILENO)) {
		zx_error("cannot redirect stdout to \"%s\": %s", filename, strerror(errno));
	}

	fflush(stderr);
	if (-1 == dup2(fd, STDERR_FILENO)) {
		zx_error("cannot redirect stderr to \"%s\": %s", filename, strerror(errno));
	}

	close(fd);

	if (-1 == (fd = open(default_file, O_RDONLY))) {
		zx_error("cannot open \"%s\": %s", default_file, strerror(errno));
		exit(EXIT_FAILURE);
	}

	if (-1 == dup2(fd, STDIN_FILENO)) {
		zx_error("cannot redirect stdin to \"%s\": %s", default_file, strerror(errno));
	}

	close(fd);
}