#ifndef __ZX_THREAD_H__
#define __ZX_THREAD_H__

#include <sys/types.h>

unsigned int zx_alarm_on(unsigned int seconds);

unsigned int zx_alarm_off();

int	zx_alarm_timed_out();


typedef void *(*zx_thread_handler_t)(void *);

int	 zx_fork();

void zx_child_fork(pid_t *pid);

void zx_thread_start(zx_thread_handler_t thread_handler, void *thread_args, pid_t *pid);

int	 zx_thread_wait(pid_t pid);

void zx_threads_wait(pid_t *pids, int pids_num);

void zx_thread_exit(int status);

void zx_thread_kill(pid_t pid);

long int zx_thread_pid();

#endif