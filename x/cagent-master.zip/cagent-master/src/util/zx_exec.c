#include "zx_exec.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include "zx_common.h"
#include "zx_thread.h"

#define PIPE_BUFFER_SIZE    4096

/******************************************************************************
 *                                                                            *
 * Function: zx_popen                                                         *
 *                                                                            *
 * Purpose: this function opens a process by creating a pipe, forking,        *
 *          and invoking the shell                                            *
 *                                                                            *
 * Parameters: pid     - [OUT] child process PID                              *
 *             command - [IN] a pointer to a null-terminated string           *
 *                       containing a shell command line                      *
 *                                                                            *
 * Return value: on success, reading file descriptor is returned. On error,   *
 *               -1 is returned, and errno is set appropriately               *
 *                                                                            *
 ******************************************************************************/
static int	zx_popen(pid_t *pid, const char *command) {

	// printf("In %s() command:'%s'\n", __func__, command);

	int	fd[2], stdout_orig, stderr_orig;

	if (-1 == pipe(fd)) {
		return -1;
	}

	if (-1 == (*pid = zx_fork())) {
		close(fd[0]);
		close(fd[1]);
		return -1;
	}

    /* parent process */
	if (0 != *pid) {
		close(fd[1]);
		// printf("End of %s():%d\n", __func__, fd[0]);
		return fd[0];
	}

	/* child process */

	close(fd[0]);

	/* set the child as the process group leader, otherwise orphans may be left after timeout */
	if (-1 == setpgid(0, 0)) {
		printf("%s(): failed to create a process group: %s\n", __func__, strerror(errno));
		exit(EXIT_FAILURE);
	}

	// printf("%s(): executing script\n", __func__);

	/* preserve stdout and stderr to restore them in case execl() fails */

	stdout_orig = dup(STDOUT_FILENO);
	stderr_orig = dup(STDERR_FILENO);
	fcntl(stdout_orig, F_SETFD, FD_CLOEXEC);
	fcntl(stderr_orig, F_SETFD, FD_CLOEXEC);

	/* redirect output right before script execution after all logging is done */

	dup2(fd[1], STDOUT_FILENO);
	dup2(fd[1], STDERR_FILENO);
	close(fd[1]);

	execl("/bin/sh", "sh", "-c", command, NULL);

	/* restore original stdout and stderr, because we don't want our output to be confused with script's output */

	dup2(stdout_orig, STDOUT_FILENO);
	dup2(stderr_orig, STDERR_FILENO);
	close(stdout_orig);
	close(stderr_orig);

	/* this message may end up in stdout or stderr, that's why we needed to save and restore them */
	printf("execl() failed for [%s]: %s\n", command, strerror(errno));

	/* execl() returns only when an error occurs, let parent process know about it */
	exit(EXIT_FAILURE);
}


/******************************************************************************
 *                                                                            *
 * Function: zx_waitpid                                                       *
 *                                                                            *
 * Purpose: this function waits for process to change state                   *
 *                                                                            *
 * Parameters: pid     - [IN] child process PID                               *
 *             status  - [OUT] process status								  *
 *                                                                            *
 * Return value: on success, PID is returned. On error,                       *
 *               -1 is returned, and errno is set appropriately               *
 *                                                                            *
 ******************************************************************************/
static int zx_waitpid(pid_t pid, int *status) {
	int	rc, result;

	// printf("In %s()\n", __func__);

	do
	{
#ifdef WCONTINUED
		static int	wcontinued = WCONTINUED;
retry:
		if (-1 == (rc = waitpid(pid, &result, WUNTRACED | wcontinued)))
		{
			if (EINVAL == errno && 0 != wcontinued)
			{
				wcontinued = 0;
				goto retry;
			}
#else
		if (-1 == (rc = waitpid(pid, &result, WUNTRACED)))
		{
#endif
			printf("%s() waitpid failure: %s\n", __func__, strerror(errno));
			goto exit;
		}

		if (WIFEXITED(result)) {
			// printf("%s() exited, status:%d\n", __func__, WEXITSTATUS(result));
		} else if (WIFSIGNALED(result)) {
			printf("%s() killed by signal %d\n", __func__, WTERMSIG(result));
		} else if (WIFSTOPPED(result)) {
			printf("%s() stopped by signal %d\n", __func__, WSTOPSIG(result));
#ifdef WIFCONTINUED
		} else if (WIFCONTINUED(result)) {
			printf("%s() continued\n", __func__);
#endif
		}
	} while (!WIFEXITED(result) && !WIFSIGNALED(result));

exit:
	if (NULL != status) {
		*status = result;
	}

	// printf("End of %s():%d\n", __func__, rc);
	return rc;
}


/******************************************************************************
 *                                                                            *
 * Function: zx_execute                                                       *
 *                                                                            *
 * Purpose: this function executes a script and returns result from stdout    *
 *                                                                            *
 * Parameters: command       - [IN] command for execution                     *
 *             output        - [OUT] buffer for output, if NULL - ignored     *
 *             error         - [OUT] error string if function fails           *
 *             max_error_len - [IN] length of error buffer                    *
 *             timeout       - [IN] execution timeout                         *
 *                                                                            *
 * Return value: SUCCEED if processed successfully, TIMEOUT_ERROR if          *
 *               timeout occurred or FAIL otherwise                           *
 *                                                                            *
 ******************************************************************************/
int	zx_execute(const char *command, char **output, char *error, size_t max_error_len, int timeout) {

	size_t	buf_size = PIPE_BUFFER_SIZE, offset = 0;
	int		ret 	 = FAIL;
	char	*buffer  = NULL;
	pid_t	pid;
	int		fd;

	*error = '\0';

	if (NULL != output) {
		free(*output);
	}

	buffer = (char *)zx_malloc(buffer, buf_size);
	*buffer = '\0';

	zx_alarm_on(timeout);

	if (-1 != (fd = zx_popen(&pid, command))) {
		int	rc, status;
		char tmp_buf[PIPE_BUFFER_SIZE];

		while (0 < (rc = read(fd, tmp_buf, sizeof(tmp_buf) - 1)) &&  MAX_EXECUTE_OUTPUT_LEN > offset + rc) {
			tmp_buf[rc] = '\0';
			zx_strcpy_alloc(&buffer, &buf_size, &offset, tmp_buf);
		}

		close(fd);

		if (-1 == rc || -1 == zx_waitpid(pid, &status)) {
			if (EINTR == errno) {
				ret = TIMEOUT_ERROR;
			} else {
				zx_snprintf(error, max_error_len, "zx_waitpid() failed: %s", strerror(errno));
			}

			/* kill the whole process group, pid must be the leader */
			if (-1 == kill(-pid, SIGTERM)) {
				printf("failed to kill [%s]: %s\n", command, strerror(errno));
			}

			zx_waitpid(pid, NULL);
		} else if (MAX_EXECUTE_OUTPUT_LEN <= offset + rc) {

			printf("command output exceeded limit of %d KB\n",  MAX_EXECUTE_OUTPUT_LEN / ZX_KIBIBYTE);

		} else if (0 == WIFEXITED(status) || 0 != WEXITSTATUS(status)) {
			if ('\0' == *buffer) {
				if (WIFEXITED(status)) {
					zx_snprintf(error, max_error_len, "Process exited with code: %d.", WEXITSTATUS(status));
				} else if (WIFSIGNALED(status)) {
					zx_snprintf(error, max_error_len, "Process killed by signal: %d.", WTERMSIG(status));
				} else {
					zx_strlcpy(error, "Process terminated unexpectedly.", max_error_len);
				}
			} else {
				zx_strlcpy(error, buffer, max_error_len);
			}
		} else {
			ret = SUCCEED;
		}
	} else {
		zx_strlcpy(error, strerror(errno), max_error_len);
	}

	zx_alarm_off();

	if (TIMEOUT_ERROR == ret) {
		zx_strlcpy(error, "Timeout while executing a shell script.", max_error_len);
	} else if ('\0' != *error) {
		printf("Failed to execute command \"%s\": %s\n", command, error);
	}

	if (SUCCEED != ret || NULL == output) {
		zx_free(buffer);
	}

	if (NULL != output) {
		*output = buffer;
	}

	return ret;
}

/******************************************************************************
 *                                                                            *
 * Function: zx_execute_nowait                                                *
 *                                                                            *
 * Purpose: this function executes a script in the background and             *
 *          suppresses the std output                                         *
 *                                                                            *
 * Parameters: command - [IN] command for execution                           *
 *                                                                            *
 ******************************************************************************/
int	zx_execute_nowait(const char *command) {
	pid_t pid;

	/* use a double fork for running the command in background */
	if (-1 == (pid = zx_fork())) {
		printf("first fork() failed for executing [%s]: %s\n", command, strerror(errno));
		return FAIL;
	} else if (0 != pid) {
		waitpid(pid, NULL, 0);
		return SUCCEED;
	}

	/* This is the child process. Now create a grand child process which */
	/* will be replaced by execl() with the actual command to be executed. */

	pid = zx_fork();

	switch (pid) {
		case -1:
			printf("second fork() failed for executing [%s]: %s\n", command, strerror(errno));
			break;
		case 0:
			/* this is the grand child process */

			/* suppress the output of the executed script, otherwise */
			/* the output might get written to a logfile or elsewhere */
			zx_redirect_stdio(NULL);

			/* replace the process with actual command to be executed */
			execl("/bin/sh", "sh", "-c", command, NULL);

			/* execl() returns only when an error occurs */
			printf("execl() failed for [%s]: %s\n", command, strerror(errno));
			break;
		default:
			/* this is the child process, exit to complete the double fork */

			waitpid(pid, NULL, WNOHANG);
			break;
	}

	/* always exit, parent has already returned */
	exit(EXIT_SUCCESS);
}
