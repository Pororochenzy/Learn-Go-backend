#ifndef __ZX_EXEC_H__
#define __ZX_EXEC_H__

#include <stddef.h>

int	zx_execute(const char *command, char **buffer, char *error, size_t max_error_len, int timeout);

int	zx_execute_nowait(const char *command);

#endif