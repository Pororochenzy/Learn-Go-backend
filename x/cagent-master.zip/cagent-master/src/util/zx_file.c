#include "zx_file.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <errno.h>
#include <string.h>
#include <sys/stat.h>
#include "zx_time.h"

// 和GNU的getline实现一致，行尾的"\n"、"\r\n"需另行处理
ssize_t zx_getline(char **lineptr, size_t *n, FILE *stream) {
    char *bufptr = NULL;
    char *p = bufptr;
    size_t size;
    int c;

    if (lineptr == NULL) {
        return -1;
    }
    if (stream == NULL) {
        return -1;
    }
    if (n == NULL) {
        return -1;
    }
    bufptr = *lineptr;
    size = *n;

    c = fgetc(stream);
    if (c == EOF) {
        return -1;
    }
    if (bufptr == NULL) {
        bufptr = malloc(128);
        if (bufptr == NULL) {
            return -1;
        }
        size = 128;
    }
    p = bufptr;
    while(c != EOF) {
        if ((p - bufptr) > (size - 1)) {
            size = size + 128;
            bufptr = realloc(bufptr, size);
            if (bufptr == NULL) {
                return -1;
            }
        }
        *p++ = c;
        if (c == '\n') {
            break;
        }
        c = fgetc(stream);
    }

    *p++ = '\0';
    *lineptr = bufptr;
    *n = size;

    return p - bufptr - 1;
}

// -1 失败、0 结束(执行完、超时)、>0 成功
ssize_t zx_getline2(FILE *stream, struct buf *line, int timeout) {
    assert(stream != NULL);

    char *bufptr = malloc(128);
    if (bufptr == NULL) {
        return -1;
    }
    size_t size = 128;
    char *p = bufptr;
    unsigned long long st = nowtime();
    int c = 0;
    while (nowtime() - st < timeout) {
        if ((p - bufptr) > (size - 1)) {
            size += 128;
            bufptr = realloc(bufptr, size);
            if (bufptr == NULL) {
                free(bufptr);
                return -1;
            }
        }
        c = fgetc(stream); // todo 这里还是会阻塞
        if (c == EOF) {
            break;
        }
        *p++ = c;
        if (c == '\n') {
            break;
        }
    }
    *p++ = '\0';
    buf_puts(line, bufptr);
    free(bufptr);
    return buf_len(line);
}

unsigned long zx_file_size(const char *filename) {
    struct stat buf;
    if (stat(filename, &buf) < 0) {
        return 0;
    }
    return (unsigned long)buf.st_size;
}

void zx_file_name(const char *filepath, struct buf *filename) {
    assert(filepath != NULL && filename != NULL);
    buf_clear(filename);
    for (int i = 0; filepath[i] != '\0'; i++) {
        if (filepath[i] == '/') {
            buf_clear(filename);
        } else {
            buf_putc(filename, filepath[i]);
        } 
    }
    buf_putc(filename, '\0');
}