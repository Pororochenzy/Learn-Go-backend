#include "zx_time.h"
#include <stdio.h>
#include <time.h>
#include <sys/time.h>

unsigned long long nowtime() {
    struct timeval now;
    gettimeofday(&now, NULL);
    unsigned long long sec = now.tv_sec;
    return sec;
}

unsigned long long nowtime_ms() {
    struct timeval now;
    gettimeofday(&now, NULL);
    unsigned long long ms = (unsigned long long)now.tv_sec * 1000 + (unsigned long long)now.tv_usec / 1000;
    return ms;
}

unsigned long long nowtime_us() {
    struct timeval now;
    gettimeofday(&now, NULL);
    unsigned long long us = (unsigned long long)now.tv_sec * 1000000 + (unsigned long long)now.tv_usec;
    return us;
}