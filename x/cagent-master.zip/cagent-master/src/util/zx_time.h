#ifndef __ZX_TIME_H__
#define __ZX_TIME_H__

unsigned long long nowtime();

unsigned long long nowtime_ms();

unsigned long long nowtime_us();

#endif