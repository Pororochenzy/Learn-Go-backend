#include "zx_config.h"
#include "zx_file.h"


static zx_cfg_section_t *add_section(zx_cfg_file_t *file, char *name) {

	zx_cfg_section_t *thisSection = NULL;
	zx_cfg_section_t *prevSection = NULL;

	if ((thisSection = zx_cfg_find_section(file, name))) {
		return thisSection;
	}

	thisSection = malloc(sizeof(zx_cfg_section_t));

	thisSection->name = malloc(strlen(name) + 1);
	memcpy(thisSection->name, name, strlen(name) + 1);

	thisSection->next = 0;
	thisSection->pairs = 0;

	prevSection = file->sections;

	if (!prevSection) {
		file->sections = thisSection;
		return thisSection;
	}

	while (prevSection && prevSection->next) {
		prevSection = prevSection->next;
	}

	prevSection->next = thisSection;

	return thisSection;
}

static zx_cfg_pair_t *add_pair(zx_cfg_section_t *section, char *key, char *value) {

	zx_cfg_pair_t *thisPair = 0;
	zx_cfg_pair_t *prevPair = 0;

	if ((thisPair = zx_cfg_find_pair(section, key))) {

		thisPair->value = realloc(thisPair->value, strlen(value) + 1);
		memcpy(thisPair->value, value, strlen(value) + 1);
		return thisPair;
	}

	thisPair = malloc(sizeof(zx_cfg_pair_t));

	thisPair->key = malloc(strlen(key) + 1);
	memcpy(thisPair->key, key, strlen(key) + 1);

	thisPair->value = malloc(strlen(value) + 1);
	memcpy(thisPair->value, value, strlen(value) + 1);

	thisPair->next = 0;

	prevPair = section->pairs;

	if (!prevPair) {
		section->pairs = thisPair;
		return thisPair;
	}

	while (prevPair && prevPair->next) {
		prevPair = prevPair->next;
	}

	prevPair->next = thisPair;

	return thisPair;
}

zx_cfg_file_t *zx_cfg_open(const char *path) {

	FILE *confDataFile = NULL;

	zx_cfg_file_t *confFile = NULL;
	zx_cfg_section_t *thisSection = NULL;

	char *line = NULL;
	size_t lineLen = 0;

	char *lineStart = NULL;
	char *lineEnd = NULL;
	char *keyStart = NULL;
	char *keyEnd = NULL;

	if (!(confDataFile = fopen(path, "r"))) {
		return NULL;
	}

	confFile = malloc(sizeof(zx_cfg_file_t));
	confFile->name = malloc(strlen(path) + 1);
	confFile->sections = NULL;
	memcpy(confFile->name, path, strlen(path) + 1);

	thisSection = add_section(confFile, "root");

	while (zx_getline(&line, &lineLen, confDataFile) != -1) {
		for (lineStart = line; *lineStart != '\0'; ++lineStart) {
			if (!isspace(*lineStart)) {
				break;
			}
		}

		if (*lineStart == '\0') {
			continue;
		}

		if (*lineStart == '#') {
			continue;
		}

		if (*lineStart == '[') {
			++lineStart;
			for (lineEnd = lineStart; *lineEnd != '\0'; ++lineEnd) {
				if (*lineEnd == ']') {
					break;
				}
			}

			if (*lineEnd != ']') {
				continue;
			}

			for (lineStart = lineStart; lineStart != lineEnd;
			     ++lineStart) {
				if (!isspace(*lineStart)) {
					break;
				}
			}

			if (lineStart == lineEnd) {
				continue;
			}

			for (lineEnd = lineEnd - 1; lineEnd != lineStart;
			     --lineEnd) {
				if (!isspace(*lineEnd)) {
					break;
				}
			}

			lineEnd[1] = '\0';

			thisSection = add_section(confFile, lineStart);

			continue;
		} else {
			for (lineEnd = lineStart; *lineEnd != '\0'; ++lineEnd) {
				if (*lineEnd == '=') {
					break;
				}
			}

			if (*lineEnd != '=') {
				continue;
			}

			if (lineEnd == lineStart) {
				continue;
			}

			keyStart = lineEnd + 1;

			for (lineEnd = lineEnd - 1; lineEnd != lineStart;
			     --lineEnd) {
				if (!isspace(*lineEnd)) {
					break;
				}
			}

			lineEnd[1] = '\0';
			for (keyEnd = keyStart; *keyEnd != '\0'; ++keyEnd) {
				if (*keyEnd == '\n') {
					break;
				}
			}

			if (keyEnd == keyStart) {
				continue;
			}

			for (keyEnd = keyEnd; keyEnd != keyStart; --keyEnd) {
				if (!isspace(*keyEnd)) {
					break;
				}
			}

			for (keyStart = keyStart; keyStart != keyEnd;
			     ++keyStart) {
				if (!isspace(*keyStart)) {
					break;
				}
			}

			keyEnd[1] = '\0';

			add_pair(thisSection, lineStart, keyStart);
		}
	}

	free(line);
	fclose(confDataFile);

	return confFile;
}

zx_cfg_section_t *zx_cfg_find_section(zx_cfg_file_t *file, char *name) {

	if (!file || !name) {
		return NULL;
	}

	zx_cfg_section_t *thisSection = file->sections;

	while (thisSection) {
		if (!strcmp(thisSection->name, name)) {
			break;
		}

		thisSection = thisSection->next;
	}

	return thisSection;
}

zx_cfg_pair_t *zx_cfg_find_pair(zx_cfg_section_t *section, char *key) {

	if (!section || !key) {
		return NULL;
	}

	zx_cfg_pair_t *thisPair = section->pairs;

	while (thisPair) {
		if (!strcmp(thisPair->key, key)) {
			break;
		}

		thisPair = thisPair->next;
	}

	return thisPair;
}

char *zx_cfg_find_value(zx_cfg_section_t *section, char *key) {
	zx_cfg_pair_t *thisPair = NULL;

	if (!(thisPair = zx_cfg_find_pair(section, key))) {
		return NULL;
	}

	return thisPair->value;
}

void zx_cfg_close(zx_cfg_file_t **file) {

	zx_cfg_section_t *thisSection = NULL;
	zx_cfg_section_t *nextSection = NULL;

	zx_cfg_pair_t *thisPair = NULL;
	zx_cfg_pair_t *nextPair = NULL;

	if (!file || !(*file)) {
		return;
	}

	thisSection = (*file)->sections;

	while (thisSection) {
		thisPair = thisSection->pairs;

		while (thisPair) {
			nextPair = thisPair->next;

			free(thisPair->key);
			free(thisPair->value);
			free(thisPair);

			thisPair = nextPair;
		}

		nextSection = thisSection->next;

		free(thisSection->name);
		free(thisSection);

		thisSection = nextSection;
	}

	free((*file)->name);
	free(*file);
	*file = NULL;
}

int zx_cfg_check_pair(zx_cfg_section_t *section, char *key, char *value) {

	if(!section || !key || !value){
		return 0;
	}

	char *thisValue = zx_cfg_find_value(section, key);
	if(!thisValue){
		return 0;
	}

	return (!strcmp(value, thisValue));
}