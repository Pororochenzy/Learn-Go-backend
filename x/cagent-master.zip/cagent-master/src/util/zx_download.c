#include "zx_download.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include "zx_time.h"
#include "zx_file.h"

struct HTTP_RES_HEADER {
    int status_code;        // HTTP/1.1 '200' OK
    char content_type[128]; // Content-Type: application/gzip
    long content_length;    // Content-Length: 11683079
};

void parse_url(const char *url, char *host, int *port, char *filename) {
    int j = 0;
    int start = 0;
    *port = 80;
    char *patterns[] = {"http://", "https://", NULL};

    // 分离下载地址中的http协议
    for (int i = 0; patterns[i]; i++) {
        if (strncmp(url, patterns[i], strlen(patterns[i])) == 0) {
            start = strlen(patterns[i]);
            *port = (i == 0) ? 80 : 443; // 默认端口
            break;
        }
    }

    // 解析域名, 这里处理时域名后面的端口号会保留
    for (int i = start; url[i] != '/' && url[i] != '\0'; i++, j++) {
        host[j] = url[i];
    }
    host[j] = '\0';

    // 解析端口号
    char *pos = strstr(host, ":");
    if (pos) {
        sscanf(pos, ":%d", port);
    }

    // 删除域名端口号
    for (int i = 0; i < (int)strlen(host); i++) {
        if (host[i] == ':') {
            host[i] = '\0';
            break;
        }
    }

    // 获取下载文件名
    j = 0;
    for (int i = start; url[i] != '\0'; i++) {
        if (url[i] == '/') {
            j = 0;
        } else {
            filename[j++] = url[i];
        } 
    }
    filename[j] = '\0';
}

struct HTTP_RES_HEADER parse_header(const char *response) {
    struct HTTP_RES_HEADER resp;

    // 获取返回代码
    char *pos = strstr(response, "HTTP/");
    if (pos) {
        sscanf(pos, "%*s %d", &resp.status_code);
    }

    // 获取返回类型
    pos = strstr(response, "Content-Type:");
    if (pos) {
        sscanf(pos, "%*s %s", resp.content_type);
    }

    // 获取返回长度
    pos = strstr(response, "Content-Length:");
    if (pos) {
        sscanf(pos, "%*s %ld", &resp.content_length);
    }

    return resp;
}

void get_ip_addr(char *hostname, char *ip_addr) {
    // 此函数将会访问DNS服务器
    struct hostent *host = gethostbyname(hostname);
    if (!host) {
        ip_addr = NULL;
        return;
    }

    for (int i = 0; host->h_addr_list[i]; i++) {
        strcpy(ip_addr, inet_ntoa(*(struct in_addr*)host->h_addr_list[i]));
        break;
    }
}

void progress_bar(long cur_size, long total_size, double speed) {
    float percent = (float) cur_size / total_size;
    const int numTotal = 50;
    int numShow = (int)(numTotal * percent);

    if (numShow == 0) {
        numShow = 1;
    }

    if (numShow > numTotal) {
        numShow = numTotal;
    }

    char sign[51] = {0};
    memset(sign, '=', numTotal);

    printf("\r%.2f%%[%-*.*s] %.2f/%.2fKB %4.0fKB/s",
        percent * 100, numTotal, numShow, sign, cur_size / 1024.0, total_size / 1024.0, speed);
    fflush(stdout);

    if (numShow == numTotal) {
        printf("\n");
    }
}

int download(int sockfd, const char *filename, long content_length) {
    int fd = open(filename, O_CREAT | O_WRONLY | O_TRUNC, S_IRWXG | S_IRWXO | S_IRWXU);
    if (fd < 0) {
        printf("文件创建失败!\n");
        return -1;
    }

    char buf[8192];
    int prelen = 0;
    double speed = 0.0;
    long hasrecieve = 0;
    unsigned long long t_start = nowtime_ms();
    unsigned long long t_end = t_start;
    while (hasrecieve < content_length) {
        int len = read(sockfd, buf, sizeof(buf));
        write(fd, buf, len);
        t_end = nowtime_ms();

        // 更新已经下载的长度
        hasrecieve += len;

        // 当一个时间段大于1s时，计算一次速度
        long diff = t_end - t_start;
        if (diff >= 1000) {
            speed = (double)(hasrecieve - prelen) / (double)diff * (1000.0 / 1024.0); // KB/s
            prelen = hasrecieve;
            diff = 0;
            t_start = nowtime_us();
        } else {
            // 如果1s之内就下载完毕，也计算一次速度
            if (hasrecieve >= content_length) {
                speed = (double)(hasrecieve - prelen) / (double)diff * (1000.0 / 1024.0); // KB/s
            }
        }
        progress_bar(hasrecieve, content_length, speed);
    }
    return 0;
}

int zx_download(const char *url, const char *filename) {
    char host[64] = {0};
    char ip_addr[16] = {0};
    char fname[1024] = {0};
    int port = 80;
    // 解析url
    printf("正在解析下载地址...\n");
    parse_url(url, host, &port, fname);
    if (filename != NULL) {
        snprintf(fname, 1024, "%s", filename);
    }

    // 解析主机ip
    printf("在获取远程服务器IP地址..\n");
    get_ip_addr(host, ip_addr);
    if (strlen(ip_addr) == 0) {
        printf("无法获取到远程服务器的IP地址\n");
        return -1;
    }

    // 设置http请求头信息
    char header[2048] = {0};
    snprintf(header, 2048, \
        "GET %s HTTP/1.1\r\n" \
        "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n" \
        "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537(KHTML, like Gecko) \
        Chrome/47.0.2526Safari/537.36\r\n" \
        "Host: %s\r\n" \
        "Connection: keep-alive\r\n" \
        "\r\n" \
    , url, host);

    // 创建套接字
    printf("创建网络套接字...\n");
    int sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sockfd < 0) {
        perror("套接字创建失败");
        return -1;
    }

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = inet_addr(ip_addr);
    addr.sin_port = htons(port);

    // 连接远程主机
    printf("正在连接远程主机...\n");
    // todo 异常情况下会阻塞，下面读写也是
    if (-1 == connect(sockfd, (struct sockaddr *)&addr, sizeof(addr))) {
        perror("连接远程主机失败");
        return -1;
    }

    printf("正在发送http下载请求...\n");
    write(sockfd, header, strlen(header));

    int mem_size = 4096;
    int length = 0;
    int len;
    char *buf = (char *)malloc(mem_size * sizeof(char));
    char *response = (char *)malloc(mem_size * sizeof(char));

    // 每次单个字符读取响应头信息
    printf("等待http响应...\n");
    while ((len = read(sockfd, buf, 1)) != 0) {
        // 动态申请内存
        if (length + len > mem_size) {
            mem_size *= 2;
            char * temp = (char *)realloc(response, sizeof(char) * mem_size);
            if (temp == NULL) {
                printf("动态申请内存失败\n");
                return -1;
            }
            response = temp;
        }

        buf[len] = '\0';
        strcat(response, buf);

        // 找到响应头的头部信息
        int flag = 0;
        for (int i = strlen(response) - 1; response[i] == '\r' || response[i] == '\n'; i--, flag++);
        // 连续两个回车、换行表示header部分结尾
        if (flag == 4) {
            break;
        }

        length += len;
    }

    printf("正在解析http响应头...\n");
    struct HTTP_RES_HEADER resp = parse_header(response);
    if (resp.status_code != 200) {
        printf("文件无法下载, 远程主机返回: %d\n", resp.status_code);
        return -1;
    }
    printf("HTTP响应代码: %d\n", resp.status_code);
    printf("HTTP文档类型: %s\n", resp.content_type);
    printf("HTTP主体长度: %ld字节\n", resp.content_length);
    download(sockfd, fname, resp.content_length);

    if (resp.content_length == zx_file_size(fname)) {
        printf("文件%s下载成功! ^_^\n\n", fname);
    } else {
        printf("文件下载中有数据丢失, 下载失败!\n\n");
        remove(fname);
    }
    close(sockfd);
    return 0;
}