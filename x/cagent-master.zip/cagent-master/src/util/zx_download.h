#ifndef __ZX_DOWNLOAD_H__
#define __ZX_DOWNLOAD_H__

int zx_download(const char *url, const char *filename);

#endif