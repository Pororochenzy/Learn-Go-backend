#ifndef __ZX_COMMON_H__
#define __ZX_COMMON_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#ifndef va_copy
#	if defined(__va_copy)
#		define va_copy(d, s) __va_copy(d, s)
#	else
#		define va_copy(d, s) memcpy(&d, &s, sizeof(va_list))
#	endif
#endif

#if defined(__GNUC__) || defined(__clang__)
#	define __zx_attr_format_printf(idx1, idx2) __attribute__((__format__(__printf__, (idx1), (idx2))))
#else
#	define __zx_attr_format_printf(idx1, idx2)
#endif

#if defined(__GNUC__) && __GNUC__ >= 7
#	define ZX_FALLTHROUGH	__attribute__ ((fallthrough))
#else
#	define ZX_FALLTHROUGH
#endif

#define	SUCCEED			 0
#define	FAIL			-1
#define	NOTSUPPORTED	-2
#define	NETWORK_ERROR	-3
#define	TIMEOUT_ERROR	-4
#define	AGENT_ERROR		-5
#define	GATEWAY_ERROR	-6
#define	CONFIG_ERROR	-7

#define ZX_KIBIBYTE		1024
#define ZX_MEBIBYTE		1048576
#define ZX_GIBIBYTE		1073741824
#define ZX_TEBIBYTE		__UINT64_C(1099511627776)

#define SEC_PER_MIN			60
#define SEC_PER_HOUR		3600
#define SEC_PER_DAY			86400
#define SEC_PER_WEEK		(7 * SEC_PER_DAY)
#define SEC_PER_MONTH		(30 * SEC_PER_DAY)
#define SEC_PER_YEAR		(365 * SEC_PER_DAY)
#define ZX_JAN_2038			2145916800
#define ZX_JAN_1970_IN_SEC	2208988800.0	/* 1970 - 1900 in seconds */

#define ZX_MAX_RECV_DATA_SIZE	(128 * ZX_MEBIBYTE)
#define MAX_ID_LEN				21
#define MAX_STRING_LEN			2048
#define MAX_BUFFER_LEN			65536
#define MAX_ZX_HOSTNAME_LEN		128
#define MAX_ZX_DNSNAME_LEN		255	/* maximum host DNS name length from RFC 1035 (without terminating '\0') */
#define MAX_EXECUTE_OUTPUT_LEN	(512 * ZX_KIBIBYTE)

#ifndef MAX
#	define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#	define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef SWAP
#   define SWAP(a, b) ((a) = (a) ^ (b); (b) = (a) ^ (b); (a) = (a) ^ (b))
#endif

#define zx_calloc(old, nmemb, size)	zx_calloc2(__FILE__, __LINE__, old, nmemb, size)
#define zx_malloc(old, size)		zx_malloc2(__FILE__, __LINE__, old, size)
#define zx_realloc(src, size)		zx_realloc2(__FILE__, __LINE__, src, size)
#define zx_strdup(old, str)		    zx_strdup2(__FILE__, __LINE__, old, str)

#define zx_free(ptr)   \
do {				\
	if (ptr) {		\
		free(ptr);	\
		ptr = NULL;	\
	}			    \
} while(0)

#define THIS_SHOULD_NEVER_HAPPEN	\
do {								\
	printf("ERROR [file:%s,line:%d] Something impossible has just happened.\n", __FILE__, __LINE__);	\
} while (0)

void zx_error(const char *fmt, ...) __zx_attr_format_printf(1, 2);

// memory
void *zx_calloc2(const char *filename, int line, void *old, size_t nmemb, size_t size);
void *zx_malloc2(const char *filename, int line, void *old, size_t size);
void *zx_realloc2(const char *filename, int line, void *old, size_t size);
char *zx_strdup2(const char *filename, int line, char *old, const char *str);

// string
size_t zx_snprintf(char *str, size_t count, const char *fmt, ...)  __zx_attr_format_printf(3, 4);

void zx_snprintf_alloc(char **str, size_t *alloc_len, size_t *offset, const char *fmt, ...)  __zx_attr_format_printf(4, 5);

size_t zx_vsnprintf(char *str, size_t count, const char *fmt, va_list args);
void zx_strncpy_alloc(char **str, size_t *alloc_len, size_t *offset, const char *src, size_t n);
void zx_strcpy_alloc(char **str, size_t *alloc_len, size_t *offset, const char *src);
void zx_chrcpy_alloc(char **str, size_t *alloc_len, size_t *offset, char c);
void zx_str_memcpy_alloc(char **str, size_t *alloc_len, size_t *offset, const char *src, size_t n);
void zx_strsplit(const char *src, char delimiter, char **left, char **right);

// secure string copy
#define strscpy(x, y)	zx_strlcpy(x, y, sizeof(x))
#define strscat(x, y)	zx_strlcat(x, y, sizeof(x))
size_t	zx_strlcpy(char *dst, const char *src, size_t siz);
void	zx_strlcat(char *dst, const char *src, size_t siz);
size_t	zx_strlcpy_utf8(char *dst, const char *src, size_t size);

char *zx_dvsprintf(char *dest, const char *f, va_list args);
char *zx_dsprintf(char *dest, const char *f, ...) __zx_attr_format_printf(2, 3);
char *zx_strdcat(char *dest, const char *src);
char *zx_strdcatf(char *dest, const char *f, ...) __zx_attr_format_printf(2, 3);

char *zx_string_replace(const char *str, const char *sub_str1, const char *sub_str2);

// string convert
void zx_strlower(char *str);
void zx_strupper(char *str);
int	zx_rtrim(char *str, const char *charlist);
void zx_ltrim(char *str, const char *charlist);
void zx_lrtrim(char *str, const char *charlist);
void zx_remove_chars(char *str, const char *charlist);
#define ZX_WHITESPACE	" \t\r\n"
#define zx_remove_whitespace(str)	zx_remove_chars(str, ZX_WHITESPACE)

// utf-8
#define ZX_MAX_BYTES_IN_UTF8_CHAR	4
#define ZX_UTF8_REPLACE_CHAR		'?'

size_t zx_utf8_char_len(const char *text);
size_t zx_strlen_utf8(const char *text);
size_t zx_strlen_utf8_nchars(const char *text, size_t utf8_maxlen);
size_t zx_strlen_utf8_nbytes(const char *text, size_t maxlen);
int zx_is_utf8(const char *text);
char *zx_replace_utf8(const char *text);
void zx_replace_invalid_utf8(char *text);


// io redirect
void zx_redirect_stdio(const char *filename);

#endif