#ifndef __ZX_FILE_H__
#define __ZX_FILE_H__

#include <stdio.h>
#include "../../libs/C-Snip/buf.h"

ssize_t zx_getline(char **lineptr, size_t *n, FILE *stream);

ssize_t zx_getline2(FILE *stream, struct buf *line, int timeout);

unsigned long zx_file_size(const char *filename);

void zx_file_name(const char *filepath, struct buf *filename);

#endif