#ifndef __TCP_PACKET_H__
#define __TCP_PACKET_H__

#include "../libs/C-Snip/buf.h"

// 方便起见，以下结构体字段暂不封装

// 消息结构
typedef struct tcp_packet *tcp_packet_ptr;
typedef struct tcp_packet
{
    struct buf *type;
    struct buf *uuid;
    struct buf *from;
    struct buf *to;
    struct buf *back_to_mq;
    struct buf *data;
    unsigned long long timestamp;
    int isback;
} tcp_packet;

tcp_packet_ptr tcp_packet_new();

tcp_packet_ptr tcp_packet_deep_copy(tcp_packet_ptr packet);

struct buf *tcp_packet_to_string(tcp_packet_ptr packet);

int tcp_packet_parse(struct buf *bf, tcp_packet_ptr packet); 

void tcp_packet_clear(tcp_packet_ptr packet);

void tcp_packet_free(tcp_packet_ptr packet);

// 任务类型
typedef enum TAgentType {
    TypeCommand = 0, // 命令
	TypeScript  = 1, // 脚本
} TAgentType;

// 任务执行状态
typedef enum TAgentState {
    TAgentStateExecuting  = 1, // 执行中
	TAgentStateTerminated = 2, // 终止
	TAgentStateFinished   = 3, // 完成
    TAgentStateException  = 4, // 异常
} TAgentState;

// (订阅/发布)下发的数据结构
typedef struct tcp_packet_data_from_mq *tcp_packet_d4m_ptr;
typedef struct tcp_packet_data_from_mq {
    struct buf *session_id;
    int pkg_type;
    int type;                 // 0-命令、1-脚本
    struct buf *control;      // start、stop
    struct buf *command;
    struct buf *command_type; // shell, perl, cmd, python, ruby
    long script_id;
    struct buf *execute_path; // 执行命令或脚本路径
    struct buf *script_md5;   // 脚本內容md5
    struct buf *script_path;  // 脚本路径
} tcp_packet_data_from_mq;

tcp_packet_d4m_ptr tcp_packet_new_d4m();

tcp_packet_d4m_ptr tcp_packet_deep_copy_d4m(tcp_packet_d4m_ptr d4m);

int tcp_packet_parse_d4m(struct buf *bf, tcp_packet_d4m_ptr d4m);

void tcp_packet_clear_d4m(tcp_packet_d4m_ptr d4m);

void tcp_packet_free_d4m(tcp_packet_d4m_ptr d4m);

// (订阅/发布)上报的数据结构
typedef struct tcp_packet_data_to_mq *tcp_packet_d2m_ptr;
typedef struct tcp_packet_data_to_mq {
    struct buf *session_id; // 从下发数据中获取
    int pkg_type;           // 0-命令、1-脚本
    struct buf *msg;        // 返回消息
    int state;              // 任务执行状态，1-执行中，2-终止，3-完成，4-异常(暂未使用)
    int ret_code;           // 任务执行返回值，0-成功、1-失败(-1也表示失败)
    struct buf *ret_msg;    // 任务执行结果
} tcp_packet_data_to_mq;

tcp_packet_d2m_ptr tcp_packet_new_d2m();

tcp_packet_d2m_ptr tcp_packet_deep_copy_d2m(tcp_packet_d2m_ptr d2m);

struct buf *tcp_packet_d2m_to_string(tcp_packet_d2m_ptr d2m);

void tcp_packet_clear_d2m(tcp_packet_d2m_ptr d2m);

void tcp_packet_free_d2m(tcp_packet_d2m_ptr d2m);

#endif