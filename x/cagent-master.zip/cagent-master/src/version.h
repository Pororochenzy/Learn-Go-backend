#ifndef __CAGENT_VERSION_H_
#define __CAGENT_VERSION_H_

#define CAGENT_VERSION   "CAgent.v0.1"

#endif