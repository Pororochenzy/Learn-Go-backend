#include "tcp_packet.h"
#include <stdio.h>
#include <assert.h>
#include "../libs/parson/parson.h"

tcp_packet_ptr tcp_packet_new() {
    tcp_packet_ptr packet = (tcp_packet_ptr)malloc(sizeof(struct tcp_packet));
    if (packet != NULL) {
        packet->type = buf_empty();
        packet->uuid = buf_empty();
        packet->from = buf_empty();
        packet->to = buf_empty();
        packet->back_to_mq = buf_empty();
        packet->data = buf_empty();
        packet->timestamp = 0;
        packet->isback = 0;
    }
    return packet;
}

tcp_packet_ptr tcp_packet_deep_copy(tcp_packet_ptr packet) {
    tcp_packet_ptr copy = tcp_packet_new();
    if (copy != NULL) {
        buf_puts(copy->type, buf_str(packet->type));
        buf_puts(copy->uuid, buf_str(packet->uuid));
        buf_puts(copy->from, buf_str(packet->from));
        buf_puts(copy->to, buf_str(packet->to));
        buf_puts(copy->back_to_mq, buf_str(packet->back_to_mq));
        buf_puts(copy->data, buf_str(packet->data));
        copy->timestamp = packet->timestamp;
        copy->isback = packet->isback;
    }
    return copy;
}

struct buf *tcp_packet_to_string(tcp_packet_ptr packet) {
    assert(packet != NULL);

    JSON_Value *root_value = json_value_init_object();
    JSON_Object *root_object = json_value_get_object(root_value);
    json_object_set_string(root_object, "mq_type", buf_str(packet->type));
    json_object_set_string(root_object, "uuid", buf_str(packet->uuid));
    json_object_set_string(root_object, "from", buf_str(packet->from));
    json_object_set_string(root_object, "to", buf_str(packet->to));
    json_object_set_string(root_object, "back_to", buf_str(packet->back_to_mq));
    json_object_set_string(root_object, "data", buf_str(packet->data));
    json_object_set_number(root_object, "unixtime", (double)(packet->timestamp));
    json_object_set_boolean(root_object, "msg_back", packet->isback);
    char *serialized_string = json_serialize_to_string(root_value);
    struct buf *bf = buf_empty();
    buf_puts(bf, serialized_string);
    json_free_serialized_string(serialized_string);
    json_value_free(root_value);
    return bf;
}

int tcp_packet_parse(struct buf *bf, tcp_packet_ptr packet) {
    assert(bf != NULL && packet != NULL);

    tcp_packet_clear(packet);
    JSON_Value *root_value = json_parse_string(buf_str(bf));
    if (root_value == NULL) {
        printf("解析消息错误\n");
        return -1;
    }

    JSON_Object *root_object = json_value_get_object(root_value);
    buf_puts(packet->type, json_object_get_string(root_object, "mq_type"));
    buf_puts(packet->uuid, json_object_get_string(root_object, "uuid"));
    buf_puts(packet->from, json_object_get_string(root_object, "from"));
    buf_puts(packet->to, json_object_get_string(root_object, "to"));
    buf_puts(packet->back_to_mq, json_object_get_string(root_object, "back_to"));
    buf_puts(packet->data, json_object_get_string(root_object, "data"));
    packet->timestamp = (unsigned long long)json_object_get_number(root_object, "unixtime");
    packet->isback = json_object_get_boolean(root_object, "msg_back");
    json_value_free(root_value);
    return 0;
}

void tcp_packet_clear(tcp_packet_ptr packet) {
    assert(packet != NULL);

    buf_clear(packet->type);
    buf_clear(packet->uuid);
    buf_clear(packet->from);
    buf_clear(packet->to);
    buf_clear(packet->back_to_mq);
    buf_clear(packet->data);
    packet->timestamp = 0;
    packet->isback = 0;
}

void tcp_packet_free(tcp_packet_ptr packet) {
    if (packet != NULL) {
        buf_free(packet->type);
        buf_free(packet->uuid);
        buf_free(packet->from);
        buf_free(packet->to);
        buf_free(packet->back_to_mq);
        buf_free(packet->data);
        packet = NULL;
    }
}

tcp_packet_d4m_ptr tcp_packet_new_d4m() {
    tcp_packet_d4m_ptr d4m = (tcp_packet_d4m_ptr)malloc(sizeof(struct tcp_packet_data_from_mq));
    if (d4m != NULL) {
        d4m->session_id = buf_empty();
        d4m->control = buf_empty();
        d4m->command = buf_empty();
        d4m->command_type = buf_empty();
        d4m->execute_path = buf_empty();
        d4m->script_md5 = buf_empty();
        d4m->script_path = buf_empty();
        d4m->pkg_type = 0;
        d4m->type = 0;
        d4m->script_id = 0;
    }
    return d4m;
}

tcp_packet_d4m_ptr tcp_packet_deep_copy_d4m(tcp_packet_d4m_ptr d4m) {
    tcp_packet_d4m_ptr copy = tcp_packet_new_d4m();
    if (copy != NULL) {
        buf_puts(copy->session_id, buf_str(d4m->session_id));
        buf_puts(copy->control, buf_str(d4m->control));
        buf_puts(copy->command, buf_str(d4m->command));
        buf_puts(copy->command_type, buf_str(d4m->command_type));
        buf_puts(copy->execute_path, buf_str(d4m->execute_path));
        buf_puts(copy->script_md5, buf_str(d4m->script_md5));
        buf_puts(copy->script_path, buf_str(d4m->script_path));
        copy->pkg_type = d4m->pkg_type;
        copy->type = d4m->type;
        copy->script_id = d4m->script_id;
    }
    return copy;
}

int tcp_packet_parse_d4m(struct buf *bf, tcp_packet_d4m_ptr d4m) {
    assert(bf != NULL && d4m != NULL);

    tcp_packet_clear_d4m(d4m);
    JSON_Value *root_value = json_parse_string(buf_str(bf));
    if (root_value == NULL) {
        printf("解析消息错误\n");
        return -1;
    }

    JSON_Object *root_object = json_value_get_object(root_value);
    buf_puts(d4m->session_id, json_object_get_string(root_object, "session_id"));
    buf_puts(d4m->control, json_object_get_string(root_object, "control"));
    buf_puts(d4m->command, json_object_get_string(root_object, "command"));
    buf_puts(d4m->command_type, json_object_get_string(root_object, "command_type"));
    buf_puts(d4m->execute_path, json_object_get_string(root_object, "execute_path"));
    buf_puts(d4m->script_md5, json_object_get_string(root_object, "script_md5"));
    buf_puts(d4m->script_path, json_object_get_string(root_object, "script_path"));
    d4m->pkg_type = (int)json_object_get_number(root_object, "pkg_type");
    d4m->type = (int)json_object_get_number(root_object, "type");
    d4m->script_id = (long)json_object_get_number(root_object, "script_id");
    json_value_free(root_value);
    return 0;
}

void tcp_packet_clear_d4m(tcp_packet_d4m_ptr d4m) {
    assert(d4m != NULL);
    
    buf_clear(d4m->session_id);
    buf_clear(d4m->control);
    buf_clear(d4m->command);
    buf_clear(d4m->command_type);
    buf_clear(d4m->execute_path);
    buf_clear(d4m->script_md5);
    buf_clear(d4m->script_path);
    d4m->pkg_type = 0;
    d4m->type = 0;
    d4m->script_id = 0;
}

void tcp_packet_free_d4m(tcp_packet_d4m_ptr d4m) {
    if (d4m != NULL) {
        buf_free(d4m->session_id);
        buf_free(d4m->control);
        buf_free(d4m->command);
        buf_free(d4m->command_type);
        buf_free(d4m->execute_path);
        buf_free(d4m->script_md5);
        buf_free(d4m->script_path);
        d4m = NULL;
    }
}

tcp_packet_d2m_ptr tcp_packet_new_d2m() {
    tcp_packet_d2m_ptr d2m = (tcp_packet_d2m_ptr)malloc(sizeof(struct tcp_packet_data_to_mq));
    if (d2m != NULL) {
        d2m->session_id = buf_empty();
        d2m->msg = buf_empty();
        d2m->ret_msg = buf_empty();
        d2m->pkg_type = 0;
        d2m->state = 0;
        d2m->ret_code = 0;
    }
    return d2m;
}

tcp_packet_d2m_ptr tcp_packet_deep_copy_d2m(tcp_packet_d2m_ptr d2m) {
    tcp_packet_d2m_ptr copy = tcp_packet_new_d2m();
    if (copy != NULL) {
        buf_puts(copy->session_id, buf_str(d2m->session_id));
        buf_puts(copy->msg, buf_str(d2m->msg));
        buf_puts(copy->ret_msg, buf_str(d2m->ret_msg));
        copy->pkg_type = d2m->pkg_type;
        copy->state = d2m->state;
        copy->ret_code = d2m->ret_code;
    }
    return copy;
}

struct buf *tcp_packet_d2m_to_string(tcp_packet_d2m_ptr d2m) {
    assert(d2m != NULL);

    JSON_Value *root_value = json_value_init_object();
    JSON_Object *root_object = json_value_get_object(root_value);
    json_object_set_string(root_object, "session_id", buf_str(d2m->session_id));
    json_object_set_string(root_object, "msg", buf_str(d2m->msg));
    json_object_set_string(root_object, "ret_msg", buf_str(d2m->ret_msg));
    json_object_set_number(root_object, "pkg_type", (double)(d2m->pkg_type));
    json_object_set_number(root_object, "state", (double)(d2m->state));
    json_object_set_number(root_object, "ret_code", (double)(d2m->ret_code));
    char *serialized_string = json_serialize_to_string(root_value);
    struct buf *bf = buf_empty();
    buf_puts(bf, serialized_string);
    json_free_serialized_string(serialized_string);
    json_value_free(root_value);
    return bf;
}

void tcp_packet_clear_d2m(tcp_packet_d2m_ptr d2m) {
    assert(d2m != NULL);
    
    buf_clear(d2m->session_id);
    buf_clear(d2m->msg);
    buf_clear(d2m->ret_msg);
    d2m->pkg_type = 0;
    d2m->state = 0;
    d2m->ret_code = 0;
}

void tcp_packet_free_d2m(tcp_packet_d2m_ptr d2m) {
    if (d2m != NULL) {
        buf_free(d2m->session_id);
        buf_free(d2m->msg);
        buf_free(d2m->ret_msg);
        d2m = NULL;
    }
}