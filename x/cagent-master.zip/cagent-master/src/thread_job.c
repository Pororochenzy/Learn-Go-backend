#include "thread_job.h"
#include <assert.h>

typedef struct thread_job {
    tcp_client_ptr client;
    tcp_packet_ptr packet;
    tcp_packet_d4m_ptr d4m;
} thread_job;

thread_job_ptr thread_job_new(tcp_client_ptr client, tcp_packet_ptr packet, tcp_packet_d4m_ptr d4m) {
    thread_job_ptr job = (thread_job_ptr)malloc(sizeof(struct thread_job));
    if (job != NULL) {
        job->client = client;
        job->packet = tcp_packet_deep_copy(packet);
        job->d4m = tcp_packet_deep_copy_d4m(d4m);
    }
    return job;
}

void thread_job_free(thread_job_ptr job) {
    if (job != NULL) {
        tcp_packet_free(job->packet);
        tcp_packet_free_d4m(job->d4m);
    }
}

tcp_client_ptr thread_job_client(thread_job_ptr job) {
    assert(job != NULL);
    return job->client;
}

tcp_packet_ptr thread_job_packet(thread_job_ptr job) {
    assert(job != NULL);
    return job->packet;
}

tcp_packet_d4m_ptr thread_job_d4m(thread_job_ptr job) {
    assert(job != NULL);
    return job->d4m;
}