#ifndef __THREAD_WORKER_H__
#define __THREAD_WORKER_H__

void *thread_keeper(void *arg);

void *thread_collector(void *arg);

void *thread_executor(void *arg);

#endif