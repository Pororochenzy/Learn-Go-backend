#include "tcp_client.h"

#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <assert.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <pthread.h>

#include "../libs/C-Snip/strings.h"

#define MSG_HEAD_FLAG    "\r\n\r\n"  // 0x0d,0x0a,0x0d,0x0a
#define MSG_HEAD_LEN     8
#define CONNECT_GAP_TIME_MIN    1    // 连续重连的最小间隙时间
#define CONNECT_GAP_TIME_MAX    64   // 连续重连的最大间隙时间
#define CONNECT_GAP_TIME_GROW(pt)    (*pt = (*pt < CONNECT_GAP_TIME_MAX) ? 2*(*pt) : (*pt))
#define CONNECT_GAP_TIME_RESET(pt)   (*pt = CONNECT_GAP_TIME_MIN)

typedef struct tcp_client
{
    int sockfd;
    struct sockaddr_in remote_addr;

    int running;
    int connected;
    int ping;

    struct queue *sendmq;
    struct queue *recvmq;
    struct buf  *recvbuf;

    pthread_mutex_t sendmq_mtx;
    pthread_mutex_t recvmq_mtx;
    pthread_t run_thread;
} tcp_client;

// 's' must be null-terminated chars
void show_error(const char *s) {
    if (s == NULL) {
        printf("错误码:%d, 错误描述:%s\n", errno, strerror(errno));
    } else {
        printf("%s, 错误码:%d, 错误描述:%s\n", s, errno, strerror(errno));
    }
}

tcp_client_ptr tcp_client_new(const char *host, int port) {
    tcp_client_ptr c = (tcp_client_ptr)malloc(sizeof(struct tcp_client));
    if (c != NULL) {
        c->sockfd = -1;
        c->running = 0;
        c->connected = 0;
        c->ping = 0;
        
        c->remote_addr.sin_family = AF_INET;
        c->remote_addr.sin_port = htons(port);
        c->remote_addr.sin_addr.s_addr = inet_addr(host);
        memset(&(c->remote_addr.sin_zero), 0, sizeof(c->remote_addr.sin_zero));

        c->sendmq = queue_new();
        c->recvmq= queue_new();
        c->recvbuf = buf_empty();

        pthread_mutex_init(&c->sendmq_mtx, NULL);
        pthread_mutex_init(&c->recvmq_mtx, NULL);
    }
    return c;
}

void *run_thread(void *arg) {
    assert(arg != NULL);
    tcp_client_ptr c = (tcp_client_ptr )arg;

    char tmpbuf[1024];
    struct timeval timeout;
    timeout.tv_sec = 2;   
    timeout.tv_usec = 0;

    int gap_time = CONNECT_GAP_TIME_MIN;
    fd_set readfds, writefds;
    while (c->running) {
        // 自动重连
        if (!c->connected) {
            if (c->sockfd > 0) {
                printf("关闭旧的套接字\n");
                close(c->sockfd);
                c->sockfd = -1;
            }

            if ((c->sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) {
                show_error("创建套接字失败");
                sleep(1);
                continue;
            }

            fcntl(c->sockfd, F_SETFL, fcntl(c->sockfd, F_GETFL, 0) | O_NONBLOCK); // 套接字设置非阻塞属性
            printf("连接服务器...\n");
            if (-1 == connect(c->sockfd, (struct sockaddr*)&c->remote_addr, sizeof(struct sockaddr_in))) {
                if (errno != EINPROGRESS) {
                    show_error("连接服务器失败");
                    printf("%d秒后将重连\n", gap_time);
                    int i = 0;
                    while (c->running && i++ < gap_time) {
                        sleep(1);
                    }
                    CONNECT_GAP_TIME_GROW(&gap_time);
                    continue;
                }
            }
        }

        FD_ZERO(&readfds);FD_SET(c->sockfd, &readfds);
        FD_ZERO(&writefds);FD_SET(c->sockfd, &writefds);
        int result = select(c->sockfd+1, &readfds, &writefds, NULL, &timeout);
        switch (result)
        {
        case 0:
            printf("select timeout\n");
            break;
        case -1:
            show_error("select");
            sleep(1);
            break;
        default:
            // 检查套接字是否可用
            {
                int opt; 
                socklen_t optlen = sizeof(int);
                getsockopt(c->sockfd, SOL_SOCKET, SO_ERROR, (void *)&opt, &optlen);
                if (opt != 0 ) {
                    printf("套接字错误\n");
                    printf("%d秒后将重连\n", gap_time);
                    if (c->connected == 0) {
                        int i = 0;
                        while (c->running && i++ < gap_time) {
                            sleep(1);
                        }
                        CONNECT_GAP_TIME_GROW(&gap_time);
                    } else {
                        c->connected = 0;
                    }
                    continue;
                } 
                if (c->connected == 0) {
                    printf("连接服务器成功\n");
                    c->connected = 1;
                    CONNECT_GAP_TIME_RESET(&gap_time);
                }
            }

            // 写数据至系统发送队列
            if (FD_ISSET(c->sockfd, &writefds)) {
                struct buf *bf = buf_empty();
                tcp_client_sendmq_pop(c, bf);
                if (buf_len(bf) > 0) {
                    struct buf *packet = buf_new(MSG_HEAD_FLAG);
                    int ilen = (int)buf_len(bf);
                    buf_putc(packet, (ilen & 0xFF000000)>>24);
                    buf_putc(packet, (ilen & 0x00FF0000)>>16);
                    buf_putc(packet, (ilen & 0x0000FF00)>>8);
                    buf_putc(packet, (ilen & 0x000000FF));
                    buf_sprintf(packet, "%s", buf_str(bf));
                    if (-1 == send(c->sockfd, buf_str(packet), buf_len(packet), 0)) {
                        show_error("发送数据错误");
                    }
                    buf_free(packet);
                }
                buf_free(bf);
            }

            // 从系统接收队列中读取数据
            if (FD_ISSET(c->sockfd, &readfds)) {
                while (c->running && c->connected) {
                    memset(tmpbuf, 0, sizeof(tmpbuf));
                    int ret = recv(c->sockfd, tmpbuf, sizeof(tmpbuf)-1, 0);
                    if (ret == 0) {
                        printf("连接异常\n");
                        c->connected = 0;
                        sleep(1);
                        break;
                    } else if (ret < 0) {
                        if (errno == EINTR) {
                            continue;
                        }
                        
                        if (errno == ECONNRESET) {
                            show_error("对端中断连接");
                            c->connected = 0;
                            sleep(1);
                        }
                        break;
                    } else {
                        // 缓存数据
                        buf_put(c->recvbuf, tmpbuf, ret);

                        // 处理程序接收缓存中所有消息(可能一次接收了多个数据包)
                        while (c->running && c->connected) {
                            // 如果长度不够一个数据包头
                            if (buf_len(c->recvbuf) < MSG_HEAD_LEN) {
                                break;
                            }
                            
                            // 寻找数据包头
                            size_t total = buf_len(c->recvbuf);
                            char *bufstr = buf_str(c->recvbuf);
                            // size_t start = strings_search_ex(bufstr, total, MSG_HEAD_FLAG, 0);
                            size_t start = strings_search(bufstr, MSG_HEAD_FLAG, 0);
                            if (start < total) {
                                if (total - start > MSG_HEAD_LEN) {
                                    // 取数据长度
                                    char *head = bufstr + start;
                                    int ilen = ((head[4]&0xFF)<<24) | ((head[5]&0xFF)<<16) |
                                                ((head[6]&0xFF)<<8) | (head[7]&0xFF);
                                    
                                    // 取数据部分
                                    size_t end = start + MSG_HEAD_LEN + ilen;
                                    if (total >= end) {
                                        struct buf *bf = buf_empty();
                                        buf_put(bf, bufstr + start + MSG_HEAD_LEN, ilen);
                                        tcp_client_recvmq_push(c, bf);
                                        buf_free(bf);
                                        start = end;
                                    }
                                }
                                // 删除无用数据
                                buf_lrm(c->recvbuf, start);
                            } else {
                                // 未发现包头
                                if (buf_len(c->recvbuf) > 2*MSG_HEAD_LEN) {
                                    buf_lrm(c->recvbuf, MSG_HEAD_LEN);
                                }
                            }

                        } // end while
                    }
                } // end while
            } // end if read

            usleep(20000); // 20ms 避免CPU占用过高
        }
    }
    pthread_exit(NULL);
    return EXIT_SUCCESS;
}

void tcp_client_run(tcp_client_ptr c) {
    assert(c != NULL);
    c->running = 1;
    pthread_create(&c->run_thread, NULL, run_thread, (void*)c);
}

void tcp_client_stop(tcp_client_ptr c) {
    assert(c != NULL);
    c->running = 0;
}

void tcp_client_wait(tcp_client_ptr c) {
    assert(c != NULL);
    pthread_join(c->run_thread, NULL);
}

void tcp_client_ping(tcp_client_ptr c) {
    assert(c != NULL);
    printf("发送ping\n");
    if (c->ping++ >= 3) {
        printf("连续3次ping不通，将尝试重连\n");
        c->ping = 0;
        c->connected = 0;
    }
}

void tcp_client_pong(tcp_client_ptr c) {
    assert(c != NULL);
    printf("收到pong\n");
    c->ping = 0;
}

void tcp_client_free(tcp_client_ptr c) {
    if (c != NULL) {
        tcp_client_stop(c);
        if (c->sockfd > 0) {
            close(c->sockfd);
        }

        // 释放内存
        buf_free(c->recvbuf);

        pthread_mutex_lock(&c->sendmq_mtx);
        queue_free(c->sendmq);
        pthread_mutex_unlock(&c->sendmq_mtx);

        pthread_mutex_lock(&c->recvmq_mtx);
        queue_free(c->recvmq);
        pthread_mutex_unlock(&c->recvmq_mtx);

        // 释放锁和条件变量
        pthread_mutex_destroy(&c->sendmq_mtx);
        pthread_mutex_destroy(&c->recvmq_mtx);

        c = NULL;
    }
}

void tcp_client_sendmq_push(tcp_client_ptr c, struct buf *bf) {
    assert(c != NULL && bf != NULL);
    struct buf *p = buf_empty();
    buf_puts(p, buf_str(bf));
    pthread_mutex_lock(&c->sendmq_mtx);
    queue_push(c->sendmq, (void *)p);
    pthread_mutex_unlock(&c->sendmq_mtx);
}

void tcp_client_sendmq_pop(tcp_client_ptr c, struct buf *bf) {
    assert(c != NULL && bf != NULL);
    buf_clear(bf);
    pthread_mutex_lock(&c->sendmq_mtx);
    struct buf *p = (struct buf *)queue_pop(c->sendmq);
    if (p != NULL) {
        buf_puts(bf, buf_str(p));
        buf_free(p);
    }
    pthread_mutex_unlock(&c->sendmq_mtx);
}

void tcp_client_recvmq_push(tcp_client_ptr c, struct buf *bf) {
    assert(c != NULL && bf != NULL);
    struct buf *p = buf_empty();
    buf_puts(p, buf_str(bf));
    pthread_mutex_lock(&c->recvmq_mtx);
    queue_push(c->recvmq, (void *)p);
    pthread_mutex_unlock(&c->recvmq_mtx);
}

void tcp_client_recvmq_pop(tcp_client_ptr c, struct buf *bf) {
    assert(c != NULL && bf != NULL);
    buf_clear(bf);
    pthread_mutex_lock(&c->recvmq_mtx);
    struct buf *p = (struct buf *)queue_pop(c->recvmq);
    if (p != NULL) {
        buf_puts(bf, buf_str(p));
        buf_free(p);
    }
    pthread_mutex_unlock(&c->recvmq_mtx);
}

int tcp_client_running(tcp_client_ptr c) {
    assert(c != NULL);
    return c->running;
}

int tcp_client_connected(tcp_client_ptr c) {
    assert(c != NULL);
    return c->connected;
}