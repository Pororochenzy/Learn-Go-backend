/* IBM_PROLOG_BEGIN_TAG                                                   */
/* This is an automatically generated prolog.                             */
/*                                                                        */
/* bos61L src/bos/usr/ccs/lib/libperfstat/simplempstat.c 1.2.1.2          */
/*                                                                        */
/* Licensed Materials - Property of IBM                                   */
/*                                                                        */
/* Restricted Materials of IBM                                            */
/*                                                                        */
/* COPYRIGHT International Business Machines Corp. 2008,2010              */
/* All Rights Reserved                                                    */
/*                                                                        */
/* US Government Users Restricted Rights - Use, duplication or            */
/* disclosure restricted by GSA ADP Schedule Contract with IBM Corp.      */
/*                                                                        */
/* IBM_PROLOG_END_TAG                                                     */
static char sccsid[] = "@(#)66        1.2.1.2  src/bos/usr/ccs/lib/libperfstat/simplempstat.c, libperfstat, bos61L, l2010_29B3 7/21/10 04:57:12";

/* The sample program used to Display            *
 * the cpu usage metrics for all cpus            */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <libperfstat.h>
#include <errno.h>
#include <wpars/wparcfg.h>

/* To Check whether malloc is successful or not */

#define CHECK_FOR_MALLOC_NULL(X) {  if ((X) == NULL) {\
                                       perror ("malloc");\
                                       exit(2);\
                                     }\
                                 }

/* Convert 4K pages to MB */
#define AS_MB(X) ((X) * 4096/1024/1024)

/* WPAR ID for global will always be zero */
#define IS_GLOBAL(X) (!(X)) 

/* Non zero WPAR ID indicates WPAR */
#define IS_WPAR(X) ((X))

/* For WPAR, use NULL else use the actual WPAR ID (for global) */
#define WPAR_ID ((cid)?NULL:&wparid)

/* To store the count of Logical CPUs in the LPAR */

/* Default values for interval and count */

#define INTERVAL_DEFAULT 1
#define COUNT_DEFAULT    1


static int  ncpu, atflag; 
static int returncode, count = COUNT_DEFAULT, interval = INTERVAL_DEFAULT;
unsigned long long  last_user, last_sys, last_idle, last_wait, last_timebase;
unsigned long long delta_user, delta_sys, delta_wait, delta_idle, delta_total, delta_timebase;

/* store LPAR level stats */
perfstat_cpu_total_t          *totalcinfo, *totalcinfo_last;
perfstat_memory_total_t       minfo;
perfstat_partition_total_t    pinfo, qinfo;
perfstat_cpu_t		      *cinfo, *cinfo_last;

/* stores wpar id for perfstat library */
perfstat_id_wpar_t         wparid;

/* store per WPAR stats */
perfstat_wpar_total_t        winfo; 
perfstat_cpu_total_wpar_t    cinfo_wpar; 
	
/* store current WPAR ID */
cid_t cid; 
char wpar[MAXCORRALNAMELEN+1];

/* support for remote node statistics collection in a cluster environment */
perfstat_id_node_t nodeid;
char nodename[MAXHOSTNAMELEN];
int nflag = 0;
/* display the usage */

void showusage(char *cmd)
{
   if (!cid)
       fprintf(stderr, "usage: %s [-@ { ALL | WPARNAME } | -n nodename ] [-i <interval in seconds> ] [-c <number of iterations> ]\n", cmd);
   else
       fprintf(stderr, "usage: %s [-i <interval in seconds> ] [-c <number of iterations> ]\n", cmd);
   exit(1);
}

/* Save the current values for the next iteration */
	
void save_last_values (void)
{
   memcpy( totalcinfo_last, totalcinfo, sizeof(perfstat_cpu_total_t));
   memcpy( cinfo_last, cinfo, sizeof(perfstat_cpu_t));
}

void initialise(void)
{
   totalcinfo = (perfstat_cpu_total_t *)malloc(sizeof(perfstat_cpu_total_t));
   CHECK_FOR_MALLOC_NULL(totalcinfo);

   totalcinfo_last = (perfstat_cpu_total_t *)malloc(sizeof(perfstat_cpu_total_t));
   CHECK_FOR_MALLOC_NULL(totalcinfo_last);

   cinfo = (perfstat_cpu_t *)malloc(sizeof(perfstat_cpu_t) * ncpu);
   CHECK_FOR_MALLOC_NULL(cinfo);

   cinfo_last = (perfstat_cpu_t *)malloc(sizeof(perfstat_cpu_t) * ncpu);
   CHECK_FOR_MALLOC_NULL(cinfo_last);
 
}

void display_configuration (void)
{
   unsigned long long memlimit;
   double cpulimit;
   int i ,totalcpu;

   /* gather LPAR level data */
   if(nflag) {
      strncpy(nodeid.u.nodename, nodename, MAXHOSTNAMELEN);
      nodeid.spec = NODENAME;
      if (perfstat_partition_total_node(&nodeid, &pinfo, sizeof(perfstat_partition_total_t), 1) <= 0) {
          perror("perfstat_partition_total_node:");
          exit(1);
      }
      
      if (perfstat_memory_total_node(&nodeid, &minfo, sizeof(perfstat_memory_total_t), 1) <= 0) {
          perror("perfstat_memory_total_node:");
          exit(1);
      }

      totalcpu = perfstat_cpu_node(&nodeid, NULL, sizeof(perfstat_cpu_t), 0);
   }
   else {
      if (perfstat_partition_total(NULL, &pinfo, sizeof(perfstat_partition_total_t), 1) <= 0) {
          perror("perfstat_partition_total:");
          exit(1);
      }
      
      if (perfstat_memory_total(NULL, &minfo, sizeof(perfstat_memory_total_t), 1) <= 0) {
          perror("perfstat_memory_total:");
          exit(1);
      }

      totalcpu = perfstat_cpu(NULL, NULL, sizeof(perfstat_cpu_t), 0);
   }
   
   /* print LPAR configuration */
   printf("lpar configuration : ");
   printf("lcpus = %d ", totalcpu); /* number of CPUs online */
   printf("mem = %lluMB ", AS_MB(minfo.real_total)); /* real memory */
   printf("ent = %#5.2f\n", (double)pinfo.entitled_proc_capacity/100.0); /* entitled capacity */

}

/*
 * NAME: display_metrics_global
 *       used to display the metrics when called from global 
 *
 */        

void display_metrics_global(void)
{
   int i;
   perfstat_id_t first;

   strcpy(first.name, FIRST_CPU);
   if(nflag){
       strncpy(nodeid.u.nodename, nodename, MAXHOSTNAMELEN);
       nodeid.spec = NODENAME;
       if (perfstat_cpu_total_node(&nodeid, totalcinfo_last, sizeof(perfstat_cpu_total_t), 1) <= 0){
           perror("perfstat_cpu_total_node:");
           exit(1);
       }
    
       if (perfstat_cpu_node(&nodeid, cinfo_last, sizeof(perfstat_cpu_t), ncpu) <= 0){
           perror("perfstat_cpu_node:");
           exit(1);
       }
    
       if (perfstat_partition_total_node(&nodeid, &qinfo, sizeof(perfstat_partition_total_t), 1) <= 0){
           perror("perfstat_partition_total_node:");
           exit(1);
       }
   }
   else{
       if (perfstat_cpu_total(NULL, totalcinfo_last, sizeof(perfstat_cpu_total_t), 1) <= 0){
           perror("perfstat_cpu_total:");
           exit(1);
       }
    
       if (perfstat_cpu(&first, cinfo_last, sizeof(perfstat_cpu_t), ncpu) <= 0){
           perror("perfstat_cpu:");
           exit(1);
       }
    
       if (perfstat_partition_total(NULL, &qinfo, sizeof(perfstat_partition_total_t), 1) <= 0){
           perror("perfstat_partition_total:");
           exit(1);
       }
   }
   printf("\n cpu\tuser\tsys\twait\tidle\n\n");

   while(count)
   {
      sleep(interval);

      if(nflag){
          if (perfstat_cpu_total_node(&nodeid, totalcinfo, sizeof(perfstat_cpu_total_t), 1) <= 0){
              perror("perfstat_cpu_total_node:");
              exit(1);
          }
    
          if (perfstat_cpu_node(&nodeid, cinfo, sizeof(perfstat_cpu_t), ncpu) <= 0){
              perror("perfstat_cpu_node:");
              exit(1);
          }
    
          if (perfstat_partition_total_node(&nodeid, &pinfo, sizeof(perfstat_partition_total_t), 1) <= 0){
              perror("perfstat_partition_total_node:");
              exit(1);
          }
      }
      else{
          if (perfstat_cpu_total(NULL, totalcinfo, sizeof(perfstat_cpu_total_t), 1) <= 0){
              perror("perfstat_cpu_total:");
              exit(1);
          }
    
          if (perfstat_cpu(&first, cinfo, sizeof(perfstat_cpu_t), ncpu) <= 0){
              perror("perfstat_cpu:");
              exit(1);
          }
    
          if (perfstat_partition_total(NULL, &pinfo, sizeof(perfstat_partition_total_t), 1) <= 0){
              perror("perfstat_partition_total:");
              exit(1);
          }
      }

      for(i = 0; i < ncpu; i++){
          delta_user = cinfo[i].puser - cinfo_last[i].puser;
          delta_sys  = cinfo[i].psys  - cinfo_last[i].psys;
          delta_idle = cinfo[i].pidle - cinfo_last[i].pidle;
          delta_wait = cinfo[i].pwait - cinfo_last[i].pwait; 
          delta_total= delta_user + delta_sys + delta_idle + delta_wait;
          delta_timebase = pinfo.timebase_last - qinfo.timebase_last;

          printf("%s\t%#4.1f\t%#4.1f\t%#4.1f\t%#4.1f\n",cinfo[i].name,
							     ((double)(delta_user)/(double)(delta_total) * 100.0),
							     ((double)(delta_sys)/(double)(delta_total) * 100.0),
							     ((double)(delta_wait)/(double)(delta_total) * 100.0),
							     ((double)(delta_idle)/(double)(delta_total) * 100.0));
      }
      delta_user = totalcinfo->puser - totalcinfo_last->puser;
      delta_sys  = totalcinfo->psys  - totalcinfo_last->psys;
      delta_wait = totalcinfo->pwait - totalcinfo_last->pwait;
      delta_idle = totalcinfo->pidle - totalcinfo_last->pidle;
      delta_total= delta_user + delta_sys + delta_idle + delta_wait;

      printf("%s\t%#4.1f\t%#4.1f\t%#4.1f\t%#4.1f\n\n","ALL",((double)(delta_user)/(double)(delta_total) * 100.0),
						  ((double)(delta_sys)/(double)(delta_total) * 100.0),
						  ((double)(delta_wait)/(double)(delta_total) * 100.0),
						  ((double)(delta_idle)/(double)(delta_total) * 100.0));

      count--;
      save_last_values();
   }
}

/*
 *NAME: display_metrics_wpar
 *      used to display the metrics when called from wpar
 *
 */
void display_metrics_wpar(void)
{

   int i;
   char last[5];
   perfstat_id_wpar_t first;
   /*first.spec = WPARNAME;*/
   strcpy(first.name,NULL );
   if (perfstat_wpar_total( NULL, &winfo, sizeof(perfstat_wpar_total_t), 1) <= 0){
       perror("perfstat_wpar_total:");
       exit(1);
   }

   if (perfstat_cpu_total_rset(NULL, totalcinfo_last, sizeof(perfstat_cpu_total_t), 1) <= 0){
       perror("perfstat_cpu_total_rset:");
       exit(1);
   }

   if (perfstat_cpu_rset(NULL, cinfo_last, sizeof(perfstat_cpu_t), ncpu) <= 0){
       perror("perfstat_cpu_rset:");
       exit(1);
   }

   if (perfstat_partition_total(NULL, &qinfo, sizeof(perfstat_partition_total_t), 1) <= 0){
       perror("perfstat_partition_total:");
       exit(1);
   }
   printf("\n cpu\tuser\tsys\twait\tidle\n\n");

   while(count)
   {
      sleep(interval);

      if (perfstat_cpu_total_rset(NULL, totalcinfo, sizeof(perfstat_cpu_total_t), 1) <= 0){
          perror("perfstat_cpu_total_rset:");
          exit(1);
      }

      if (perfstat_cpu_rset(NULL, cinfo, sizeof(perfstat_cpu_t), ncpu) <= 0){
          perror("perfstat_cpu_rset:");
          exit(1);
      }

      if (perfstat_partition_total(NULL, &pinfo, sizeof(perfstat_partition_total_t), 1) <= 0){
          perror("perfstat_partition_total:");
          exit(1);
      }

      for(i=0; i<ncpu; i++){
          delta_user = cinfo[i].puser - cinfo_last[i].puser;
          delta_sys  = cinfo[i].psys  - cinfo_last[i].psys;
          delta_idle = cinfo[i].pidle - cinfo_last[i].pidle;
          delta_wait = cinfo[i].pwait - cinfo_last[i].pwait;
          delta_total= delta_user + delta_sys + delta_idle + delta_wait;
          delta_timebase = pinfo.timebase_last - qinfo.timebase_last;

          printf("%s\t%#4.1f\t%#4.1f\t%#4.1f\t%#4.1f\n",cinfo[i].name,((double)(delta_user)/(double)(delta_total) * 100.0),
                                                             ((double)(delta_sys)/(double)(delta_total) * 100.0),
                                                             ((double)(delta_wait)/(double)(delta_total) * 100.0),
                                                             ((double)(delta_idle)/(double)(delta_total) * 100.0));
      }

      delta_user = totalcinfo->puser - totalcinfo_last->puser;
      delta_sys  = totalcinfo->psys  - totalcinfo_last->psys;
      delta_wait = totalcinfo->pwait - totalcinfo_last->pwait;
      delta_idle = totalcinfo->pidle - totalcinfo_last->pidle;
      delta_total= delta_user + delta_sys + delta_idle + delta_wait;

      if (winfo.type.b.cpu_rset)
          strcpy(last,"RST");
      else
          strcpy(last,"ALL");

      printf("%s\t%#4.1f\t%#4.1f\t%#4.1f\t%#4.1f\n\n",last,((double)(delta_user)/(double)(delta_total) * 100.0),
                                                  ((double)(delta_sys)/(double)(delta_total) * 100.0),
                                                  ((double)(delta_wait)/(double)(delta_total) * 100.0),
                                                  ((double)(delta_idle)/(double)(delta_total) * 100.0));

      count--;
      save_last_values();
   }

}

/*
 * NAME: display_metrics_wpar_from_global
 *       display metrics of wpar when called from global
 *
 */	
void display_metrics_wpar_from_global(void)
{
   char last[5];
   int i;
   if (perfstat_wpar_total( &wparid, &winfo, sizeof(perfstat_wpar_total_t), 1) <= 0){
       perror("perfstat_wpar_total:");
       exit(1);
   }
   if (winfo.type.b.cpu_rset)
       strcpy(last,"RST");
   else
       strcpy(last,"ALL");

   strcpy(wparid.u.wparname,wpar);
 
   if (perfstat_cpu_total_rset(&wparid, totalcinfo_last, sizeof(perfstat_cpu_total_t), 1) <= 0){
       perror("perfstat_cpu_total_rset:");
       exit(1);
   }

   if (perfstat_cpu_rset(&wparid, cinfo_last, sizeof(perfstat_cpu_t), ncpu) <= 0){
       perror("perfstat_cpu_rset:");
       exit(1);
   }

   if (perfstat_partition_total(NULL, &qinfo, sizeof(perfstat_partition_total_t), 1) <= 0){
       perror("perfstat_partition_total:");
       exit(1);
   }

   printf("\n cpu\tuser\tsys\twait\tidle\n\n");

   while(count)
   {
       sleep(interval);

       if (perfstat_cpu_total_rset(&wparid, totalcinfo, sizeof(perfstat_cpu_total_t), 1) <= 0){
           perror("perfstat_cpu_total_rset:");
           exit(1);
       }

       if (perfstat_cpu_rset(&wparid, cinfo, sizeof(perfstat_cpu_t), ncpu) <= 0){
           perror("perfstat_cpu_rset:");
           exit(1);
       }

       if (perfstat_partition_total(NULL, &pinfo, sizeof(perfstat_partition_total_t), 1) <= 0){
           perror("perfstat_partition_total:");
           exit(1);
       }

       for(i = 0; i < ncpu; i++){
           delta_user = cinfo[i].puser - cinfo_last[i].puser;
           delta_sys  = cinfo[i].psys  - cinfo_last[i].psys;
           delta_idle = cinfo[i].pidle - cinfo_last[i].pidle;
           delta_wait = cinfo[i].pwait - cinfo_last[i].pwait;
           delta_total= delta_user + delta_sys + delta_idle + delta_wait;
           delta_timebase = pinfo.timebase_last - qinfo.timebase_last;

       printf("%s\t%#4.1f\t%#4.1f\t%#4.1f\t%#4.1f\n",cinfo[i].name,((double)(delta_user)/(double)(delta_total) * 100.0),
                                                             ((double)(delta_sys)/(double)(delta_total) * 100.0),
                                                             ((double)(delta_wait)/(double)(delta_total) * 100.0),
                                                             ((double)(delta_idle)/(double)(delta_total) * 100.0));
       }

       delta_user = totalcinfo->puser - totalcinfo_last->puser;
       delta_sys  = totalcinfo->psys  - totalcinfo_last->psys;
       delta_wait = totalcinfo->pwait - totalcinfo_last->pwait;
       delta_idle = totalcinfo->pidle - totalcinfo_last->pidle;
       delta_total= delta_user + delta_sys + delta_idle + delta_wait;

       printf("%s\t%#4.1f\t%#4.1f\t%#4.1f\t%#4.1f\n\n",last, ((double)(delta_user)/(double)(delta_total) * 100.0),
                                                  ((double)(delta_sys)/(double)(delta_total) * 100.0),
                                                  ((double)(delta_wait)/(double)(delta_total) * 100.0),
                                                  ((double)(delta_idle)/(double)(delta_total) * 100.0));

       count--;
       save_last_values();
   }

}

/*
 *NAME: main
 *
 */

int main(int argc,char* argv[])
{
   int c, rc;
 
   cid = corral_getcid();

   while((c = getopt(argc, argv, "@:n:i:c:"))!= EOF){
       switch(c)
       {
           case 'i':               /* Interval */
                    interval = atoi(optarg);
                    if( interval <= 0 )
                        interval = INTERVAL_DEFAULT;
                    break;
           case 'c':               /* Number of interations */
                    count = atoi(optarg);
                    if( count <= 0 )
                        count = COUNT_DEFAULT;
                    break;
           case 'n':               /* Node name in a cluster environment */
                    strncpy(nodename, optarg, MAXHOSTNAMELEN);
                    nodename[MAXHOSTNAMELEN-1] = '\0';
                    nflag = 1;
                    break;
           case '@':               /* Per-WPAR stats */
                    if (IS_WPAR(cid))
                        showusage(argv[0]);
                    atflag = 1;
                    strcpy(wpar, optarg);
                    break;
           default:
                    /* Invalid arguments. Print the usage and terminate */
                    showusage(argv[0]);
       }
   }
   if (nflag && atflag){
       showusage(argv[0]);
   } 
   if(nflag)
   {   /* perfstat_config needs to be called to enable cluster statistics collection */
       rc = perfstat_config(PERFSTAT_ENABLE|PERFSTAT_CLUSTER_STATS, NULL);
       if (rc == -1)
       {
           perror("cluster statistics collection is not available");
           exit(-1);
       }
   }
   if (atflag){
       wparid.spec = WPARNAME;
       strcpy(wparid.u.wparname,wpar);
       ncpu = perfstat_cpu_rset ( &wparid, NULL, sizeof(perfstat_cpu_t), 0);
   }
   else if (nflag){
       nodeid.spec = NODENAME;
       strncpy(nodeid.u.nodename, nodename, MAXHOSTNAMELEN);
       ncpu = perfstat_cpu_node(&nodeid, NULL, sizeof(perfstat_cpu_t), 0);
   }
   else if (IS_GLOBAL(cid)){
       ncpu = perfstat_cpu(NULL, NULL, sizeof(perfstat_cpu_t), 0);
   }
   else{
       ncpu = perfstat_cpu_rset(NULL, NULL, sizeof(perfstat_cpu_t), 0);
   }

   initialise();
   display_configuration();
 
   if(atflag)
       display_metrics_wpar_from_global();
   else if (cid)
       display_metrics_wpar();
   else
       display_metrics_global(); 

   if(nflag)
   {   /* Now disable cluster statistics by calling perfstat_config */
       perfstat_config(PERFSTAT_DISABLE|PERFSTAT_CLUSTER_STATS, NULL);
   }
   return(0);
}
